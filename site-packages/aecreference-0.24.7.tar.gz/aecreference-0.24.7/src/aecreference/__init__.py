from importlib.resources import files
import pandas as pd
from frictionless import Package

PTH_PKG = files("aecreference").joinpath("nzc").joinpath("datapackage.yaml")
pkg = Package(PTH_PKG)  # TODO: can probs just expose pkg

class DataLoader:

    @property
    def building_types(self) -> list:
        return pkg.get_resource("building-types").read_text().split("\n")  
    
    @property
    def energy_use_intensity(self) -> pd.DataFrame:
        return pkg.get_resource("energy-use-intensity").to_pandas()
    
    @property
    def energy_use_intensity_metadata(self) -> dict:
        return pkg.get_resource("energy-use-intensity").to_dict()
    

    @property
    def life_cycle_module(self) -> pd.DataFrame:
        return pkg.get_resource("life-cycle-modules").to_pandas()

    @property
    def rics_building_element_category(self) -> pd.DataFrame:
        return pkg.get_resource("rics-building-element-category").to_pandas()

aecdata = DataLoader()
# end