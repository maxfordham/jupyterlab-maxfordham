# SPDX-FileCopyrightText: 2024-present jgunstone <j.gunstone@maxfordham.com>
#
# SPDX-License-Identifier: MIT
