from aecreference import aecdata
import pandas as pd

def test_get_eui():
    eui = aecdata.energy_use_intensity
    assert eui.Unit.to_list()[0] == "kWh/m²GIA/yr"
    assert isinstance(eui, pd.DataFrame)

def test_get_eui_metadata():
    eui_metadata = aecdata.energy_use_intensity_metadata
    assert isinstance(eui_metadata, dict)

def test_building_types():
    building_types = aecdata.building_types
    assert isinstance(building_types, list)

def test_rics_building_element_category():
    assert isinstance(aecdata.rics_building_element_category, pd.DataFrame)