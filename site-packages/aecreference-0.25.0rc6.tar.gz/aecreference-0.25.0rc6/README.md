# aecreference - DEPRECATED

`aecreference` IS NO LONGER IN USE AND WILL BE DELETED SOON.
PLEASE USE [netzero-metrics-reference-data](https://github.com/maxfordham/netzero-metrics-reference-data).

---------

Reference Data.
Could be used as either a python module, or just a plain URL datapath to load the [datapackage](https://datapackage.org/) from [Github using python](https://framework.frictionlessdata.io/docs/portals/github.html) or [using javascript](https://github.com/frictionlessdata/frictionless-js?tab=readme-ov-file#open).
In `scripts` datapackages are built and placed in `src`. Scripts are not packaged, but the data in `src` is.
The folders within `src/aecreference` are defined based on the [datapackage](https://datapackage.org/) standard.

```console
.
├── scripts/
│   └── create_datapackage.py
│   └── ...
├── src/
│   └── aecreference/
│       ├── __init__.py  # load data into python module
│       ├── pkg1/ # e.g. NZC data
│       │   ├── datapackage.yaml
│       │   ├── res1.csv
│       │   ├── res2.csv 
│       │   └── ...etc
│       └── pkg2/ # add other data packages
└── tests/
    └── test_aecreference.py
```

Future - suggest using [datapackage catalog](https://framework.frictionlessdata.io/docs/framework/catalog.html) once that has matured as a way to store files as the package develops.

[![PyPI - Version](https://img.shields.io/pypi/v/aecreference.svg)](https://pypi.org/project/aecreference)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/aecreference.svg)](https://pypi.org/project/aecreference)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install aecreference
```
