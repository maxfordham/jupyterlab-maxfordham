from netzero_metrics.constants import nzdata
import pandas as pd

def test_get_eui():
    eui = nzdata.energy_use_intensity
    assert eui.Unit.to_list()[0] == "kWh/m²GIA/yr"
    assert isinstance(eui, pd.DataFrame)

def test_get_eui_metadata():
    eui_metadata = nzdata.energy_use_intensity_metadata
    assert isinstance(eui_metadata, dict)

def test_building_types():
    building_types = nzdata.building_types
    assert isinstance(building_types, list)

def test_rics_building_element_category():
    assert isinstance(nzdata.rics_building_element_category, pd.DataFrame)