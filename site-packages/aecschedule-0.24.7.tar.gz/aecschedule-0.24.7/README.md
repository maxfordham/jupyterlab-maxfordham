# aecschedule

Generate Max Fordham formatted PDF schedules from `aectemplater` data.

<table>
  <tr>
    <td><img src="docs/images/schedule-pdf-page-1.png" width="300"/></td>
    <td><img src="docs/images/schedule-pdf-page-2.png" width="300"/></td>
  </tr>
  <tr>
    <td><img src="docs/images/schedule-pdf-page-3.png" width="300"/></td>
    <td><img src="docs/images/schedule-pdf-page-4.png" width="300"/></td>
  </tr>
</table>

## Installation

Create a conda environment from the [environment.yml](./environment.yml) file:

```bash
mamba env create -f environment.yml
```

Install tinytex

```bash
quarto install tinytex
```

Install libfontconfig

```bash
sudo apt-get install libfontconfig
```