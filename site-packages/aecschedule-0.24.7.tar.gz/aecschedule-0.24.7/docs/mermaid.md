# Diagram

```mermaid
graph TD
    A(Revit) -.->|pyrevit| B(schedule data)
    AA(Excel fa:fa-file-excel) -.-> |python| B
    A1(aectemplater fa:fa-cloud) -->|api| B1(schedule definitions)
    B --> C{aecschedule fa:fa-wand-magic-sparkles}
    B1 --> C
    A2(schedule metadata) --> C
    C --> D[output schedule fa:fa-file-pdf]
```
