********
Releases
********

----

.. changelog::
    :github: https://github.com/maxfordham/aecschedule/releases/