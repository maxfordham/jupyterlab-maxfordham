"""Output components for generating markdown from document data."""

import copy
import pathlib
import traceback
import typing as ty

import pandas as pd
from aectemplater_schemas.data.utils import UnitsBaseData
from aectemplater_schemas.document import DocumentData
from aectemplater_schemas.images import ImagePrefix, PdtImage
from aectemplater_schemas.object import ObjectData, ObjectDataGrid
from jinja2 import Environment, FileSystemLoader
from natsort import index_natsorted

from aecschedule.constants import (
    DIR_TEMPLATES,
    PAGE_ITEM_TEMPLATE,
    TABLE_TEMPLATE,
)
from aecschedule.logging_handler import Loggers

loggers = Loggers()
loggers.get_loggers()
logger = loggers.console_logger

UDATA = UnitsBaseData()


def get_types_and_instances_from_document_data(document_data: DocumentData) -> ty.Tuple[DocumentData, DocumentData]:
    types: DocumentData = DocumentData([])
    instances: DocumentData = DocumentData([])
    for data in document_data.root:
        if data.schema_.items.parameter_type == "I":
            instances.root.append(data)
        elif data.schema_.items.parameter_type == "T":
            types.root.append(data)
        else:
            logger.warning(f"Document data {data.schema_['title']} not classified as type or instance")
    return types, instances


class Table:
    """A table represents many like objects (same schema) row-wise
    i.e a list of spec objects either type or instance."""

    def __init__(
        self,
        title: str,
        object_data: ObjectDataGrid,
        modifiers: ty.Optional[ty.List[ty.Callable]] = None,
        ignore_parameters: ty.Optional[list[str]] = None,
    ):
        if modifiers is None:
            self.modifiers = []
        else:
            self.modifiers = modifiers
        if ignore_parameters is None:
            self.ignore_parameters = []
        else:
            self.ignore_parameters = ignore_parameters
        self.title = title
        self.schema = copy.deepcopy(object_data.schema_.items)
        self.data = copy.deepcopy(object_data.data)
        self.file_loader = FileSystemLoader(DIR_TEMPLATES)
        self.env = Environment(loader=self.file_loader)
        self.df = self._build_data_frame_from_properties()
        self.md = self._build_markdown_from_properties(df=self.df)

    def _apply_modifiers(self, data: list[dict], schema: dict) -> tuple[list[dict], dict]:
        for mod in self.modifiers:
            for i, di in enumerate(data):
                try:
                    data[i], schema = mod(data=di, schema=schema)
                except Exception as _:
                    logger.warning(f"Warning: Error applying mod {mod.__name__}")
                    logger.warning(traceback.format_exc())
        return data, schema

    def _build_data_frame_from_properties(self) -> pd.DataFrame:
        data = self.data
        schema = self.schema
        data, schema = self._apply_modifiers(
            data,
            schema,
        )
        # ^ NOTE: info in `schema` is used with modifiers to manipulate `data`
        # Only data required for output data frame
        df = pd.DataFrame.from_records(data)
        return df

    def _build_markdown_from_properties(self, df: pd.DataFrame) -> str:
        cols = [df.index.name, *df.columns.tolist()]
        number_of_columns = len(cols)
        if number_of_columns == 0:
            return ""

        # Set the column widths for the table
        # NOTE: The widths are set to fixed values for some columns and calculated for others
        fixed_widths = {
            None: 2,
            "Mark": 15,
            "Type Mark": 15,
        }
        col_widths = {x: fixed_widths.get(x) for x in cols}
        sum_fixed = sum([v for v in col_widths.values() if v is not None])
        count_calced = sum([1 for v in col_widths.values() if v is None])
        if count_calced > 0:
            calced_width = (100 - sum_fixed) / count_calced
            col_widths = {k: (v if v is not None else calced_width) for k, v in col_widths.items()}

        return (
            df.to_markdown(tablefmt="grid", stralign="left")
            + '\n\n: {tbl-colwidths="'
            + str([round(float(w), 2) for w in col_widths.values()])
            + '"}\n'
        )

    def generate_markdown(self) -> str:
        if not self.md:
            return ""
        else:
            template = self.env.get_template(TABLE_TEMPLATE)
            return template.render(
                title=self.title,
                table=self.md,
            )


class MergedTable(Table):
    # TODO: Add functionality to filter by column names (e.g. could come from a PropertySet)
    """A merged table represents different types of objects (different schema) row-wise."""

    def __init__(
        self,
        title: str,
        li_object_data: ty.List[ObjectDataGrid],
        index: str = "",
        modifiers: ty.Optional[ty.List[ty.Callable]] = None,
        ignore_parameters: ty.Optional[list[str]] = None,
        add_type_data: None | list[dict[str, ty.Any]] = None,
    ):
        if modifiers is None:
            self.modifiers = []
        else:
            self.modifiers = modifiers
        if ignore_parameters is None:
            self.ignore_parameters = []
        else:
            self.ignore_parameters = ignore_parameters
        self.title = title
        self.index = index
        self.li_object_data = copy.deepcopy(li_object_data)
        self.file_loader = FileSystemLoader(DIR_TEMPLATES)
        self.env = Environment(loader=self.file_loader)
        self.df = self._build_data_frames_from_properties()
        if self.df.empty:
            self.md = ""
        else:
            self.md = self._build_markdown_from_properties(df=self.df)

    def _build_data_frames_from_properties(self) -> list[pd.DataFrame]:
        li_df_properties = []
        for object_data in self.li_object_data:
            data = object_data.data
            if not data:
                continue
            schema = object_data.schema_.items
            filtered_data = [{k: v for k, v in di.items() if k not in self.ignore_parameters} for di in data]
            data, schema = self._apply_modifiers(filtered_data, schema)
            df = pd.DataFrame.from_records(data)
            ordered_columns = [
                property_.title
                for _, property_ in schema.properties.items()
                if property_.title in df.columns
                if property_.title not in ["Type Mark", "Mark"]
            ]
            if "Type Mark" in df.columns:
                ordered_columns = ["Type Mark", *ordered_columns]
            if "Mark" in df.columns:
                ordered_columns = ["Mark", *ordered_columns]
            df = df[ordered_columns]
            li_df_properties.append(df)
        if not li_df_properties:
            return pd.DataFrame()
        df_merged = pd.concat(li_df_properties, ignore_index=True)
        df_merged.fillna("", inplace=True)
        if self.index:
            if self.index in df.columns:
                df_merged = df_merged.reindex(index_natsorted(df_merged[self.index]))
                df_merged.set_index(self.index, inplace=True)
            else:
                logger.warning(f"Index {self.index} not found in columns")
        df_merged.reset_index(drop=False, inplace=True)
        df_merged.index += 1
        return df_merged


class PageItem:
    """A page represents a single object (type or instance)."""

    def __init__(
        self,
        title: str,
        subtitle: str,
        object_data: ObjectData,
        fdir_img: ty.Optional[pathlib.Path] = None,
        modifiers: ty.Optional[ty.List[ty.Callable]] = None,
        ignore_parameters: ty.Optional[list[str]] = None,
        *,
        include_empty_parameters: bool = False,
    ):
        if modifiers is None:
            self.modifiers = []
        else:
            self.modifiers = modifiers
        if ignore_parameters is None:
            self.ignore_parameters = []
        else:
            self.ignore_parameters = ignore_parameters
        self.title = title
        self.subtitle = subtitle
        self.schema = object_data.schema_
        self.data = object_data.data
        self.fdir_img = fdir_img
        self.include_empty_parameters = include_empty_parameters
        self.file_loader = FileSystemLoader(DIR_TEMPLATES)
        self.env = Environment(loader=self.file_loader)
        self.dfs = self._build_data_frames_from_properties()
        self.md_images = self._build_markdown_from_images()
        self.md_properties = self._build_markdown_from_properties(dfs=self.dfs)

    @property
    def description(self) -> str:
        if "Description" not in self.data.keys():
            logger.warning("'Description' property missing from template")
            return ""
        else:
            return self.data["Description"]

    def _apply_modifiers(self, data: dict, schema: dict) -> tuple[dict, dict]:
        for mod in self.modifiers:
            try:
                data, schema = mod(data=data, schema=schema)
            except Exception as _:
                logger.warning(f"Warning: Error applying mod {mod.__name__}")
                logger.warning(traceback.format_exc())
        return data, schema

    def _build_data_frames_from_properties(self) -> list[pd.DataFrame]:
        """Build data frames from properties that are grouped by section."""
        data = self.data
        schema = self.schema
        data, schema = self._apply_modifiers(data, schema)
        if self.include_empty_parameters:
            df_properties = pd.DataFrame.from_dict(
                [
                    {
                        "section": schema.properties[name].section,
                        "title": schema.properties[name].title,
                        "value": data[name] if name in data else "",
                    }
                    for name in schema.properties.keys()
                    if name not in self.ignore_parameters
                ]
            )
        else:
            df_properties = pd.DataFrame.from_dict(
                [
                    {
                        "section": schema.properties[name].section,
                        "title": schema.properties[name].title,
                        "value": data[name],
                    }
                    for name in schema.properties.keys()
                    if name not in self.ignore_parameters and name in data
                ]
            )
        if "section" not in df_properties.columns:
            return []
        sections = [section for section in UDATA.sections_enum.values() if section in df_properties["section"].unique()]
        li_df_properties_by_section = []
        for section in sections:
            columns = {
                "title": f"**{section}**",
                "value": "",
            }
            df = (
                df_properties.query(f'`section` == "{section}"')[["title", "value"]]
                .rename(columns=columns)
                .set_index(columns["title"])
            )
            li_df_properties_by_section.append(df)
        return li_df_properties_by_section

    def _build_markdown_from_images(self) -> str:
        if self.fdir_img is None:
            return ""
        else:
            image_prefix = ImagePrefix(
                abbreviation=self.data["Abbreviation"], type_reference=self.data["TypeReference"]
            ).image_prefix
            fpths = list(self.fdir_img.glob(f"{image_prefix}__*.png"))
            images = [PdtImage.from_fpth(p) for p in fpths]
            md_images = []
            for i in images:
                # HACK: The layout of the images is not being set correctly
                # when there is no caption so we are setting the caption to a
                # non-breaking space if there is no caption
                if i.caption == "":
                    caption = "&nbsp;"
                else:
                    caption = i.caption
                md = "![%s](%s){height=%s}" % (caption, i.fpth.name, i.height)  # noqa: UP031
                md_images.append(md)
            return "::: {layout-ncol=%d}\n\n" % len(md_images) + "\n\n".join(md_images) + "\n\n:::"  # noqa: UP031

    def _build_markdown_from_properties(self, dfs: list[pd.DataFrame]) -> str:
        if not dfs:
            return ""
        self.md_sections = [
            d.to_markdown(tablefmt="grid", stralign="left") + '\n\n: {tbl-colwidths="[35,65]"}\n' for d in dfs
        ]
        return '\n'.join(self.md_sections)

    def generate_markdown(self) -> str:
        if not self.md_properties:
            return ""
        template = self.env.get_template(PAGE_ITEM_TEMPLATE)
        return template.render(
            title=self.title,
            subtitle=self.subtitle,
            table_images=self.md_images,
            tables_properties=self.md_properties,
        )
