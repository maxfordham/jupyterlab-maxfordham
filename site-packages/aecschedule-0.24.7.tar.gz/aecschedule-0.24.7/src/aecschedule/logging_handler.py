"""Defining loggers"""
import yaml
import logging.config
from pathlib import Path
from aecschedule.utils import get_home
from aecschedule.constants import FPTH_CONFIG_LOG


class Loggers:
    # TODO: pass fdir as argument
    # TODO: split up log files
    # TODO: configure where the logs go
    def __init__(self):
        """Defining log directory and creating folder if necessary."""
        log_dir = Path(get_home()) / ".aecschedule"  # Log directory
        try:
            log_dir.mkdir()
        except FileExistsError:
            pass
        self.log_dir = log_dir

    def get_loggers(self):
        """Read config_logging.yml and get loggers."""
        with open(str(FPTH_CONFIG_LOG), "r") as f:
            config = yaml.safe_load(f.read())
            # Overriding log location.
            config["handlers"]["file_handler"]["filename"] = str(self.log_dir / "ScheduleLog.log")
            logging.config.dictConfig(config)
        self.console_logger = logging.getLogger("console_logger")
        self.file_logger = logging.getLogger("file_logger")


if __name__ == "__main__":
    loggers = Loggers()
    loggers.get_loggers()
    loggers.file_logger.error("Disastrous Error of some sort")
