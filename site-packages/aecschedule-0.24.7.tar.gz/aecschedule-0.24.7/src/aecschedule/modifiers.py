"""This module contains "modifiers". These are functions that modify the data and schema.
This is useful for formatting specification data in any way that is required prior to creating the schedule.

When creating a modifier, the function should accept two arguments:
- data: A dictionary containing the data to be modified.
- schema: An ObjectSchema instance containing the schema of the data.
The output of the function should be a tuple containing the modified data and schema.

Please look at the type hints in the function signature to understand the expected input and output types.
"""

import typing as ty

from aectemplater_schemas.object import ObjectSchema

from aecschedule.utils import (
    encode_url_parentheses,
    get_url_domain,
    round_to_significant_figures,
)


def drop_empty_values(data: ty.Dict[str, ty.Any], schema: ObjectSchema) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    return {key: value for key, value in data.items() if value not in (None, "", [], {}, ())}, schema


def append_unit_to_value(data: ty.Dict[str, ty.Any], schema: ObjectSchema) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    for name, value in data.items():
        if name not in schema.properties:
            continue
        unit = schema.properties[name].unit
        if unit:
            unit = f"_{unit}_"  # Italicise units
            data[name] = f"{value} {unit}"
    return data, schema


def replace_boolean_with_yes_no(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    for name, value in data.items():
        if isinstance(value, bool):
            if value:
                data[name] = "Yes"
            else:
                data[name] = "No"
    return data, schema


def define_url_as_hyperlink(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    for name, value in data.items():
        if name in schema.properties and schema.properties[name].revit_data_type == "URL":
            data[name] = f"[{get_url_domain(value)}]({encode_url_parentheses(value)})"
    return data, schema


def remove_leading_zero_decimal(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    for name, value in data.items():
        if isinstance(value, float) and value.is_integer():
            data[name] = str(int(value))
    return data, schema


def merge_dimensions(data: ty.Dict[str, ty.Any], schema: ObjectSchema) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    schema_ = schema.model_dump()
    #### HOTFIX: OverallLength should be OverallDepth. Remove OverallLength from statement once deprecated.
    if "OverallHeight" in data and "OverallWidth" in data and ("OverallDepth" in data or "OverallLength" in data):
        if "OverallLength" in schema_["properties"] and "OverallLength" in data:
            data["OverallDepth"] = data["OverallLength"]
            schema_["properties"]["OverallDepth"] = schema_["properties"]["OverallLength"]
            data.pop("OverallLength")
        data["OverallDimensions"] = (
            f"H{data['OverallHeight']} _{schema_['properties']['OverallHeight']['unit']}_"  # noqa: ISC003
            + f", W{data['OverallWidth']} _{schema_['properties']['OverallWidth']['unit']}_"
            + f", D{data['OverallDepth']} _{schema_['properties']['OverallDepth']['unit']}_"
        )
        data.pop("OverallHeight")
        data.pop("OverallWidth")
        data.pop("OverallDepth")
        new_schema_properties = {}
        for k, v in schema_["properties"].items():
            if k == "OverallHeight":
                new_schema_properties["OverallDimensions"] = {
                    "name": "OverallDimensions",
                    "title": "Overall Dimensions",
                    "type": "string",
                    "section": schema.properties["OverallHeight"].section,
                }
            new_schema_properties[k] = v
        schema_["properties"] = new_schema_properties
    return data, ObjectSchema(**schema_)


def merge_dimensions_with_newline(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    """New line is added between dimensions. Uses latex newline command."""
    data, schema = merge_dimensions(data, schema)
    data["OverallDimensions"] = data["OverallDimensions"].replace(",", "\\newline")  # TODO: Why blank space?
    return data, schema


# TODO: Generalise merge dimensions to support all dimension properties, not just OverallDimensions.
# So we then can just deprecate merge_door_dimensions and merge_door_dimensions_with_newline.
def merge_door_dimensions(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    """Merge door dimensions into a single string. For example, if there are two properties `Width` and `Height`,
    they will be merged."""
    schema_ = schema.model_dump()  # schema_ is what we will modify and return
    if "DoorWidth" in data and "DoorHeight" in data:
        data["DoorDimensions"] = (
            f"H{data['DoorHeight']} _{schema_['properties']['DoorHeight']['unit']}_"
            f", W{data['DoorWidth']} _{schema_['properties']['DoorWidth']['unit']}_"
        )
        data.pop("DoorHeight", None)
        data.pop("DoorWidth", None)
        new_schema_properties = {}
        for k, v in schema_["properties"].items():
            if k == "DoorWidth":
                new_schema_properties["DoorDimensions"] = {
                    "name": "DoorDimensions",
                    "title": "Door Dimensions",
                    "type": "string",
                    "section": schema_["properties"]["DoorWidth"]["section"],
                }
            new_schema_properties[k] = v
        schema_["properties"] = new_schema_properties
    return data, ObjectSchema(**schema_)


def merge_door_dimensions_with_newline(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    """New line is added between door dimensions. Uses latex newline command."""
    data, schema = merge_door_dimensions(data, schema)
    if "DoorDimensions" in data:
        data["DoorDimensions"] = data["DoorDimensions"].replace(",", "\\newline")
    return data, schema


def merge_range(data: ty.Dict[str, ty.Any], schema: ObjectSchema) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    """Merge ranges into a single string. For example, if there are two properties `SummerTemperatureMin` and
    `SummerTemperatureMax`, they will be merged."""
    schema_ = schema.model_dump()  # schema_ is what we will modify and return
    new_schema_properties = {}
    for property_, v in schema.properties.items():
        if ("Max" in property_ and property_.replace("Max", "Min") in schema.properties) or (
            "Min" in property_ and property_.replace("Min", "Max") in schema.properties
        ):  # Check if there is a corresponding Min or Max property
            if "Max" in property_:
                max_property = property_
                min_property = property_.replace("Max", "Min")
            else:
                max_property = property_.replace("Min", "Max")
                min_property = property_
            combined_property = property_.replace("Max", "").replace("Min", "")
            if property_ == max_property:
                new_schema_properties[combined_property] = {
                    "name": combined_property,
                    "title": schema.properties[property_].title.replace("Max", "").replace("Min", "").strip(),
                    "type": "string",
                    "section": schema.properties[property_].section,
                    "unit": schema.properties[property_].unit,
                }
            if max_property in data and min_property in data:
                if data[max_property] == data[min_property]:
                    data[combined_property] = data[max_property]
                else:
                    data[combined_property] = f"{data[min_property]} - {data[max_property]}"
                data.pop(max_property)
                data.pop(min_property)
            elif max_property in data and min_property not in data:
                data[combined_property] = f"<{data[max_property]}"
                data.pop(max_property)
            elif max_property not in data and min_property in data:
                data[combined_property] = f"≥{data[min_property]}"
                data.pop(min_property)
        else:
            new_schema_properties[property_] = v
    schema_["properties"] = new_schema_properties
    return data, ObjectSchema(**schema_)


def add_hyper_ref_to_type_mark(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    if "TypeMark" not in data:
        return data, schema
    data["TypeMark"] = r"\hyperref[" + data["TypeMark"].lower() + "]{" + data["TypeMark"].replace("_", r"\_") + "}"
    return data, schema


def replace_names_with_titles(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    modified_data = {}
    for name, value in data.items():
        if name in schema.properties:
            modified_data[schema.properties[name].title] = value
        else:
            modified_data[name] = value
    return modified_data, schema


def round_floats_to_two_decimals(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    for name, value in data.items():
        if isinstance(value, float):
            data[name] = round(value, 2)
    return data, schema


def round_area_to_three_significant_figures(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    for name, value in data.items():
        if name == "Area" and isinstance(value, float):
            data[name] = round_to_significant_figures(value, 3)
    return data, schema


def remove_classification_uniclass_space_number(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    if "ClassificationUniclassSpaceNumber" in data:
        data.pop("ClassificationUniclassSpaceNumber")
    return data, schema


def replace_tabs_with_spaces(
    data: ty.Dict[str, ty.Any], schema: ObjectSchema
) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    """Tabs are replaced with spaces due to latex formatting issues."""
    for name, value in data.items():
        if isinstance(value, str):
            data[name] = value.replace("\t", " ")
    return data, schema


## HACK: J7081 hack.
def get_tag_def_7081():
    """Returns the tag definition for ventilation instances."""
    from bdns_plus.models import TagDef

    return TagDef(
        **{
            "name": "Tag Definition for Ventilation Instances",
            "description": "a example tag definition for ventilation instances",
            "fields": [
                {
                    "field_name": "abbreviation",
                    "field_aliases": ["Abbreviation"],
                    "allow_none": False,
                    "prefix": "",
                    "suffix": "",
                    "zfill": None,
                    "regex": None,
                    "validator": None,
                },
                {
                    "field_name": "volume",
                    "field_aliases": ["VolumeReference"],
                    "allow_none": False,
                    "prefix": ".",
                    "suffix": "",
                    "zfill": None,
                    "regex": None,
                    "validator": None,
                },
                {
                    "field_name": "level",
                    "field_aliases": ["LevelReference"],
                    "allow_none": False,
                    "prefix": ".",
                    "suffix": "",
                    "zfill": 2,
                    "regex": None,
                    "validator": None,
                },
                {
                    "field_name": "level_iref",
                    "field_aliases": ["VolumeLevelInstance"],
                    "allow_none": False,
                    "prefix": ".",
                    "suffix": "",
                    "zfill": 2,
                    "regex": None,
                    "validator": None,
                },
            ],
        }
    )


def update_7081_mark(data: ty.Dict[str, ty.Any], schema: ObjectSchema) -> tuple[ty.Dict[str, ty.Any], ObjectSchema]:
    """Tabs are replaced with spaces due to latex formatting issues."""
    from bdns_plus.tag import simple_tag

    data = data.copy()  # Avoid modifying the original data
    mark = data["Mark"]
    abb = mark.split("-")[0]  # Assuming the first part is the abbreviation
    _suffix = mark.split("_")[1]  # Assuming the second part is the volume and level reference
    vol, lev = _suffix.split("-")
    vlr = data["VolumeLevelInstance"]

    tag_string = simple_tag(
        {"Abbreviation": abb, "VolumeReference": vol, "LevelReference": lev, "VolumeLevelInstance": vlr},
        tag=get_tag_def_7081(),
    )
    for name, value in data.items():
        if name == "Mark":
            data[name] = tag_string
    data = {k: v for k, v in data.items() if k in ["Mark", "TypeMark", "Description"]}
    return data, schema
