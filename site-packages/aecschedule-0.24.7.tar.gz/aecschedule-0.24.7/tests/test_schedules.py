import copy
import json
import pathlib
from typing import ClassVar

from aectemplater_schemas.document import DocumentData
from aectemplater_schemas.images import PdtImage
from document_issue.document import FormatConfiguration
from document_issue.document_issue import DocumentIssue
from document_issue.issue import Issue
from document_issue.role import DocumentRole
from document_issue_io.markdown_document_issue import generate_document_issue_pdf
from polyfactory.factories.pydantic_factory import ModelFactory

from aecschedule.schedules import PlantRoomSchedule, ProductDataSchedule, RoomDataSchedule

FDIR_TESTS = pathlib.Path(__file__).parent
FDIR_TESTOUTPUT = FDIR_TESTS / "testoutput"
FDIR_TESTDATA = FDIR_TESTS / "testdata"
FDIR_TEST_IMAGES = FDIR_TESTDATA / "images"

FPTH_AT_DOCUMENT_DATA = FDIR_TESTDATA / "AT" / "document-data.json"
FPTH_AT_DOCUMENT_ISSUE = FDIR_TESTDATA / "AT" / "document-issue.json"
AT_DOCUMENT_DATA = DocumentData(json.loads(FPTH_AT_DOCUMENT_DATA.read_text()))
AT_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_AT_DOCUMENT_ISSUE.read_text()))

FPTH_DB_DOCUMENT_DATA = FDIR_TESTDATA / "DB" / "document-data.json"
FPTH_DB_DOCUMENT_ISSUE = FDIR_TESTDATA / "DB" / "document-issue.json"
DB_DOCUMENT_DATA = DocumentData(json.loads(FPTH_DB_DOCUMENT_DATA.read_text()))
DB_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_DB_DOCUMENT_ISSUE.read_text()))

FPTH_SPC_DOCUMENT_DATA = FDIR_TESTDATA / "SPC" / "document-data.json"
FPTH_SPC_DOCUMENT_ISSUE = FDIR_TESTDATA / "SPC" / "document-issue.json"
SPC_DOCUMENT_DATA = DocumentData(json.loads(FPTH_SPC_DOCUMENT_DATA.read_text()))
SPC_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_SPC_DOCUMENT_ISSUE.read_text()))


class DocumentIssueFactory(ModelFactory[DocumentIssue]):
    project_name: str = "A Max Fordham Project"
    project_number: str = "J4321"
    name_nomenclature: str = "project-originator-volume-level-type-role-number"
    document_code: str = "06667-MXF-XX-XX-SH-M-20003"
    document_description: str = "A description of a Max Fordham Project"
    document_role: ClassVar[list[DocumentRole]] = [
        DocumentRole(initials="OH", role_name="Director in Charge"),
    ]
    issue_history: ClassVar[list[Issue]] = [
        Issue(
            status_revision="S0 - work in progress - P - Preliminary revision - Initial Status",
            revision_number=1,
        )
    ]
    format_configuration: ClassVar[FormatConfiguration] = FormatConfiguration(date_string_format="%d %^b %y")
    notes: ClassVar[list[str]] = [
        "This is a note",
        "This is another note",
        "This is a very long note which states something important about the document issue",
    ]


def test_EDITME():
    """Test for custom edits."""
    FDIR = FDIR_TESTOUTPUT / "test_EDITME"
    FDIR.mkdir(parents=True, exist_ok=True)
    fpth_md = FDIR / "06667-MXF-XX-XX-SH-M-20003.md"
    fpth_pdf = FDIR / "06667-MXF-XX-XX-SH-M-20003.pdf"
    generate_document_issue_pdf(
        document_issue=DocumentIssueFactory.build(), fpth_pdf=fpth_pdf, md_content=fpth_md.read_text()
    )


class TestProductDataSchedule:
    def test_md(self):
        """Test that the markdown is created successfully."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
        )
        md = pds.generate_markdown()
        # Check some type data
        assert "AT-1" in md
        assert "H1000 _mm_, W575 _mm_, D245 _mm_" in md
        assert "www.maxfordham.com" in md
        # Check some instance data
        assert "AT-1-1" in md
        assert "Instances" in md

    def test_md_no_instances(self):
        """Test that the markdown is created successfully and that `include_instances` works."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
            include_instances=False,
        )
        md = pds.generate_markdown()
        assert "AT-1" in md
        assert "H1000 _mm_, W575 _mm_, D245 _mm_" in md
        assert "www.maxfordham.com" in md
        assert "Instances" not in md

    def test_to_file(self):
        """Test that a markdown schedule can be written to file."""
        FPTH_MD = FDIR_TESTOUTPUT / "test_to_file.md"
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
        )
        pds.to_file(FPTH_MD)
        assert FPTH_MD.is_file()

    def test_to_pdf(self):
        """Test that a markdown schedule can be written to PDF."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA, document_issue=AT_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        img = PdtImage.from_fpth(FDIR_TEST_IMAGES / "AT-1__0.png")
        img.height = "200px"  # Set height assigned to image in output PDF
        img.write_exif()
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_no_instances(self):
        """Test that a markdown schedule can be written to PDF without instances."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
            fdir_img=FDIR_TEST_IMAGES,
            include_instances=False,
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_no_instances"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        img = PdtImage.from_fpth(FDIR_TEST_IMAGES / "AT-1__0.png")
        img.height = "200px"  # Set height assigned to image in output PDF
        img.write_exif()
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_from_fdir(self):
        """Test that a markdown schedule can be written to PDF from a directory using the `from_fdir` class method."""
        pds = ProductDataSchedule.from_fdir(
            fdir=FDIR_TESTDATA / "AT",
            fdir_img=FDIR_TEST_IMAGES,
            include_instances=True,
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_from_fdir"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        img = PdtImage.from_fpth(FDIR_TEST_IMAGES / "AT-1__0.png")
        img.height = "200px"  # Set height assigned to image in output PDF
        img.write_exif()
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_multiple_types(self):
        # TODO: ADD INSTANCES
        """Test that a markdown schedule can be written to PDF with multiple types."""
        pds = ProductDataSchedule(
            document_data=DB_DOCUMENT_DATA, document_issue=DB_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_multiple_types"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_j7081(self):
        """Test that a markdown schedule can be written to PDF with J7081 data."""
        FPTH_J7081_DOCUMENT_DATA = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20001" / "document-data.json"
        FPTH_J7081_DOCUMENT_ISSUE = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20001" / "document-issue.json"
        J7081_DOCUMENT_DATA = DocumentData(json.loads(FPTH_J7081_DOCUMENT_DATA.read_text()))
        J7081_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_J7081_DOCUMENT_ISSUE.read_text()))
        FDIR_TEST_IMAGES = FDIR_TESTDATA / "LTFC-images"
        pds = ProductDataSchedule(
            document_data=J7081_DOCUMENT_DATA, document_issue=J7081_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        fdir = FDIR_TESTOUTPUT / "test_to_pdf_j7081"
        fdir.mkdir(exist_ok=True, parents=True)
        fdir_md = fdir / f"{pds.document_issue.document_code}.md"
        fdir_pdf = fdir / f"{pds.document_issue.document_code}.pdf"
        fdir_log = fdir / f"{pds.document_issue.document_code}.log"
        fdir_md.unlink(missing_ok=True)
        fdir_pdf.unlink(missing_ok=True)
        pds.to_pdf(fdir)
        assert fdir_md.is_file()
        assert fdir_pdf.is_file()
        assert not fdir_log.is_file()
        FPTH_J7081_DOCUMENT_DATA = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20002" / "document-data.json"
        FPTH_J7081_DOCUMENT_ISSUE = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20002" / "document-issue.json"
        J7081_DOCUMENT_DATA = DocumentData(json.loads(FPTH_J7081_DOCUMENT_DATA.read_text()))
        J7081_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_J7081_DOCUMENT_ISSUE.read_text()))
        pds = ProductDataSchedule(
            document_data=J7081_DOCUMENT_DATA, document_issue=J7081_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        fdir = FDIR_TESTOUTPUT / "test_to_pdf_j7081"
        fdir.mkdir(exist_ok=True, parents=True)
        fdir_md = fdir / f"{pds.document_issue.document_code}.md"
        fdir_pdf = fdir / f"{pds.document_issue.document_code}.pdf"
        fdir_log = fdir / f"{pds.document_issue.document_code}.log"
        fdir_md.unlink(missing_ok=True)
        fdir_pdf.unlink(missing_ok=True)
        pds.to_pdf(fdir)
        assert fdir_md.is_file()
        assert fdir_pdf.is_file()
        assert not fdir_log.is_file()


        # data = J7081_DOCUMENT_DATA.model_dump()
        # [x for x in data if x["$schema"]["items"]["parameter_type"] == "T"]
        # typs = [x for x in data if x["$schema"]["items"]["parameter_type"] == "T"]
        # typs_data = [x["data"] for x in typs][0]
        # import pandas as pd
        # df = pd.DataFrame(typs_data)
        # df.to_csv(fdir / "j7081_ahu_types.csv", index=False)
        # print("PDF generated successfully for J7081 product data schedule.")

class TestRoomDataSchedule:
    def test_to_pdf_room_data_sheet(self):
        """Test that a room data sheet can be written to PDF."""
        rds = RoomDataSchedule(
            document_data=SPC_DOCUMENT_DATA, document_issue=SPC_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheet"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        rds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_room_data_sheet_j7516(self):
        """Split room data sheet into multiple PDFs by level."""

        def filter_by_level_and_occupancy(document_data: DocumentData, level: int) -> DocumentData:
            """Filter the document data by level and where occupancy > 0.
            Assumes the level is given in the room number e.g. 3-101."""

            document_data_copy = copy.deepcopy(document_data)
            for obj in document_data_copy.root:
                obj.data = [
                    data
                    for data in document_data_copy.root[0].data
                    if data["Number"].split("-")[0] == str(level)
                    # and (data["OccupancyNumber"] if data["OccupancyNumber"] is not None else 0) > 0
                    and data["RoomType"] != "Lift"
                ]
            return document_data_copy

        def set_temperature_to_null_where_zero(document_data: DocumentData) -> DocumentData:
            """Remove temperature values from the document data where the value is zero."""
            parameter_names = [
                "HeatingDryBulb",
                "TemperatureWinterMax",
                "TemperatureWinterMin",
                "CoolingDryBulb",
                "TemperatureSummerMax",
                "TemperatureSummerMin",
            ]
            document_data_copy = copy.deepcopy(document_data)
            for obj in document_data_copy.root:
                for data in obj.data:
                    for param in parameter_names:
                        if param in data.keys() and data[param] == 0:
                            data[param] = None
            return document_data_copy

        def ignore_parameters(document_data: DocumentData, parameter_names: list[str]) -> DocumentData:
            """Remove parameters from the document data."""

            document_data_copy = copy.deepcopy(document_data)
            for obj in document_data_copy.root:
                for data in obj.data:
                    for param in parameter_names:
                        data.pop(param, None)
            return document_data_copy

        # uniclass_space_codes = ["SL_20_15", "SL_25_10", "SL_25_30"]
        parameter_names_to_ignore = [
            "SmallPowerStrategy",
            "NumberOfFusedConnectionUnits",
            "SecurityAndAccessControlStrategy",
        ]
        fpth_spc_j7516_document_data = FDIR_TESTDATA / "SPC-J7516" / "document-data.json"
        fpths_spc_j7516_document_issue = list((FDIR_TESTDATA / "SPC-J7516").glob("document-issue-*.json"))
        spc_document_data = DocumentData(json.loads(fpth_spc_j7516_document_data.read_text()))
        for fpth in fpths_spc_j7516_document_issue:
            level = int(fpth.stem.split("-")[-1])  # Get level from document code
            spc_document_issue = DocumentIssue(**json.loads(fpth.read_text()))
            document_data = filter_by_level_and_occupancy(spc_document_data, level)
            document_data = ignore_parameters(document_data, parameter_names_to_ignore)
            document_data = set_temperature_to_null_where_zero(document_data)
            rds = RoomDataSchedule(
                document_data=document_data,
                document_issue=spc_document_issue,
                # uniclass_codes=uniclass_space_codes,
            )
            FDIR = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheets_J7516" / f"{spc_document_issue.document_code}"
            FDIR.mkdir(exist_ok=True, parents=True)
            FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
            FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
            FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
            FPTH_MD.unlink(missing_ok=True)
            FPTH_PDF.unlink(missing_ok=True)
            rds.to_pdf(FDIR, is_draft=False)
            assert FPTH_MD.is_file()
            assert FPTH_PDF.is_file()
            assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_room_data_sheet_j7716(self):
        """Room data sheet for J7716."""

        def ignore_certain_spaces(document_data: DocumentData) -> DocumentData:
            """Ignore spaces called Space and Loading Area."""

            document_data_copy = copy.deepcopy(document_data)
            for obj in document_data_copy.root:
                obj.data = [
                    data
                    for data in document_data_copy.root[0].data
                    if not any(data["Name"].startswith(prefix) for prefix in ["Space", "Riser"])
                    and data["Name"] not in ["Loading Area-2", "Lobby-2", "AWC"]
                    and data["Number"] not in ["Rm54", "Rm57"]
                ]
            return document_data_copy

        def set_temperature_to_null_where_zero(document_data: DocumentData) -> DocumentData:
            """Remove temperature values from the document data where the value is zero."""
            parameter_names = [
                "HeatingDryBulb",
                "TemperatureWinterMax",
                "TemperatureWinterMin",
                "CoolingDryBulb",
                "TemperatureSummerMax",
                "TemperatureSummerMin",
            ]
            document_data_copy = copy.deepcopy(document_data)
            for obj in document_data_copy.root:
                for data in obj.data:
                    for param in parameter_names:
                        if param in data.keys() and data[param] == 0:
                            data[param] = None
            return document_data_copy

        def ignore_parameters(document_data: DocumentData, parameter_names: list[str]) -> DocumentData:
            """Remove parameters from the document data."""

            document_data_copy = copy.deepcopy(document_data)
            for obj in document_data_copy.root:
                for data in obj.data:
                    for param in parameter_names:
                        data.pop(param, None)
            return document_data_copy

        # uniclass_space_codes = ["SL_20_15", "SL_25_10", "SL_25_30"]
        parameter_names_to_ignore = []
        fpth_spc_j7716_document_data = FDIR_TESTDATA / "SPC-J7716" / "document-data.json"
        fpth_spc_j7716_document_issue = FDIR_TESTDATA / "SPC-J7716" / "document-issue.json"
        spc_document_data = DocumentData(json.loads(fpth_spc_j7716_document_data.read_text()))
        spc_document_issue = DocumentIssue(**json.loads(fpth_spc_j7716_document_issue.read_text()))
        document_data = ignore_parameters(spc_document_data, parameter_names_to_ignore)
        document_data = set_temperature_to_null_where_zero(document_data)
        document_data = ignore_certain_spaces(document_data)
        # Set the Uniclass Space Number to SL_90 for all spaces otherwise pyuniclass fails
        for obj in document_data.root:
            for data in obj.data:
                if not data["ClassificationUniclassSpaceNumber"]:
                    data["ClassificationUniclassSpaceNumber"] = "SL_90"
        rds = RoomDataSchedule(
            document_data=document_data,
            document_issue=spc_document_issue,
            # uniclass_codes=uniclass_space_codes,
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheets_J7716" / f"{spc_document_issue.document_code}"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        rds.to_pdf(FDIR, is_draft=False)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_room_data_sheet_j7227(self):
        """RDS for Rayners Penn."""

        fpth_spc_j7227_document_data = FDIR_TESTDATA / "SPC-J7227" / "document-data.json"
        fpths_spc_j7227_document_issue = FDIR_TESTDATA / "SPC-J7227" / "document-issue.json"
        spc_document_data = DocumentData(json.loads(fpth_spc_j7227_document_data.read_text()))
        spc_document_issue = DocumentIssue(**json.loads(fpths_spc_j7227_document_issue.read_text()))
        rds = RoomDataSchedule(
            document_data=spc_document_data, document_issue=spc_document_issue, include_empty_parameters=True
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheets_J7227" / f"{spc_document_issue.document_code}"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        rds.to_pdf(FDIR, is_draft=True)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_room_data_sheet_empty_values(self):
        """Test that a room data sheet can be written to PDF with the J7516 space data."""
        fpth_spc_document_data = FDIR_TESTDATA / "SPC-EMPTY" / "document-data.json"
        fpth_spc_document_issue = FDIR_TESTDATA / "SPC-EMPTY" / "document-issue.json"
        spc_document_data = DocumentData(json.loads(fpth_spc_document_data.read_text()))
        spc_document_issue = DocumentIssue(**json.loads(fpth_spc_document_issue.read_text()))
        rds = RoomDataSchedule(
            document_data=spc_document_data, document_issue=spc_document_issue, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheet_empty"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        rds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful


class TestPlantRoomSchedule:
    def test_to_pdf_plant_room(self):
        """Test that a plant room schedule can be written to PDF with the engineering standard data."""
        fpth_plant_room_document_data = FDIR_TESTDATA / "PLANTROOM" / "document-data.json"
        fpth_plant_room_document_issue = FDIR_TESTDATA / "PLANTROOM" / "document-issue.json"
        plant_room_document_data = DocumentData(json.loads(fpth_plant_room_document_data.read_text()))
        plant_room_document_issue = DocumentIssue(**json.loads(fpth_plant_room_document_issue.read_text()))
        prs = PlantRoomSchedule(
            document_data=plant_room_document_data, document_issue=plant_room_document_issue, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_plant_room"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{prs.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{prs.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{prs.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        prs.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful
