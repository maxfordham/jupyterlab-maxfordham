---
project: Luton Town Football Club - Power Court Stadium
title: Fan Schedule
author: 
  - Max Fordham LLP
# ^ standard document properties. see: https://quarto.org/docs/reference/formats/pdf.html
project_name: Luton Town Football Club - Power Court Stadium
project_number : 7081
director_in_charge: NS
document_description: Fan Schedule
document_code: LTFC-MXF-XX-XX-SH-M-20002
name_nomenclature: project-originator-volume-level-type-role-number
current_issue:
  date: 2025-06-06
  revision: C01
  status_code: A1
  status_description: Issued for Tender (1st Stage)
footer-logo: footer-logo.png
title-page: title-page.pdf
is_draft: false
---

:::: {layout="[ 26.5, -2.5, 71 ]" fig-pos="H"}

::: {#first-column}
\addcontentsline{toc}{section}{Document Information}

\justifying \noindent \scriptsize __Max Fordham LLP__\                      
\                                         
maxfordham.com\                           
Max Fordham LLP is a Limited Liability\   
Partnership.\                             
\                                         
Registered in England and Wales\          
Number OC300026.\                         
\                                         
Registered office:\                       
42–43 Gloucester Crescent\                
London NW1 7PE\                           
This report is for the private and\       
confidential use of the clients for\      
whom the report is undertaken and\     
should not be reproduced in whole or\
in part or relied upon by third parties\
for any use whatsoever without the\       
express written authority of Max\         
Fordham LLP\                              
\                                         
© Max Fordham LLP\      
:::

::: {#second-column}


### Contributions

+----------------+--------------------+
| **Initials**   | **Role**           |
+================+====================+
| NS             | Director in Charge |
+----------------+--------------------+

: {tbl-colwidths="[30,70]"}

:::

::::

### Issue History

+------------+-----------+--------------+-------------------------------+-----------------------------+
| **Date**   | **Rev**   | **Status**   | **Description**               | **Issue Notes**             |
+============+===========+==============+===============================+=============================+
| 06 JUN 25  | C01       | A1           | Issued for Tender (1st Stage) | Stage 3 - Issued for Tender |
+------------+-----------+--------------+-------------------------------+-----------------------------+
| 31 JAN 25  | P02       | S4           | Suitable for Stage Approval   | Stage 3B - Final Issue      |
+------------+-----------+--------------+-------------------------------+-----------------------------+
| 20 DEC 24  | P01       | S2           | Suitable for Information      | Stage 3B - PCSA Issue       |
+------------+-----------+--------------+-------------------------------+-----------------------------+

: {tbl-colwidths="[12,5,7.5,30,45.5]"}


### Notes

+---+---------------------------------------------------------------------------------------------------+
| 1 | Contractor to ensure that the catalogue number is consistent with the description prior to order. |
+---+---------------------------------------------------------------------------------------------------+
| 2 | This schedule is to be read in conjunction with MFLLP specification.                              |
+---+---------------------------------------------------------------------------------------------------+

: {tbl-colwidths="[4,96]"}


\newpage
\toc
\newpage
## Table of Instances

+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|    | Mark         | Type Mark               | Description                                                                          |
+====+==============+=========================+======================================================================================+
|  0 | EF.E.01.01   | \hyperref[ef-1]{EF-1}   | Extract Fan - General Mechanical Extract Ventilation System                          |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  1 | EF.W.00.01   | \hyperref[ef-3]{EF-3}   | Extract Fan - Chemical Store Mechanical Extract Ventilation System                   |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  2 | EF.W.00.02   | \hyperref[ef-3]{EF-3}   | Extract Fan - Chemical Store Mechanical Extract Ventilation System                   |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  3 | EF.W.03.01   | \hyperref[ef-2]{EF-2}   | Extract Fan - General Mechanical Extract Ventilation System                          |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  4 | EF.W.03.02   | \hyperref[ef-2]{EF-2}   | Extract Fan - General Mechanical Extract Ventilation System                          |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  5 | KEF.E.01.01  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  6 | KEF.E.01.02  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  7 | KEF.E.01.03  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  8 | KEF.E.01.04  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
|  9 | KEF.E.01.05  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 10 | KEF.E.03.01  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 11 | KEF.E.03.02  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 12 | KEF.E.03.03  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 13 | KEF.E.03.04  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 14 | KEF.N.05.01  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 15 | KEF.N.05.02  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 16 | KEF.N.05.03  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 17 | KEF.S.01.01  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 18 | KEF.S.01.02  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 19 | KEF.S.04.01  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 20 | KEF.S.04.02  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 21 | KEF.W.05.01  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 22 | KEF.W.05.02  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 23 | KEF.W.05.03  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 24 | KEF.W.05.04  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 25 | KEF.W.05.05  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 26 | KEF.W.05.06  | \hyperref[kef-3]{KEF-3} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 27 | KEF.W.05.07  | \hyperref[kef-3]{KEF-3} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 28 | KEF.W.05.08  | \hyperref[kef-3]{KEF-3} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 29 | KEF.W.05.09  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 30 | KEF.W.05.10  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 31 | KEF.W.05.11  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 32 | KEF.W.05.12  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 33 | KEF.W.05.13  | \hyperref[kef-2]{KEF-2} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 34 | KEF.W.05.14  | \hyperref[kef-3]{KEF-3} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 35 | KEF.W.05.15  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 36 | KEF.W.05.16  | \hyperref[kef-1]{KEF-1} | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 37 | SEF.CP.00.01 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 38 | SEF.CP.00.02 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 39 | SEF.CP.00.03 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 40 | SEF.CP.00.04 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 41 | SEF.CP.00.05 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 42 | SEF.CP.00.06 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 43 | SEF.CP.00.07 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 44 | SEF.CP.00.08 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 45 | SEF.CP.00.09 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 46 | SEF.CP.00.10 | \hyperref[sef-2]{SEF-2} | Car Park Smoke Extract Fan - Smoke Extract Ventilation System                        |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 47 | SEF.E.00.01  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 48 | SEF.E.00.02  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 49 | SEF.N.00.01  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 50 | SEF.N.00.02  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 51 | SEF.N.00.03  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 52 | SEF.N.00.04  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 53 | SEF.N.00.05  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 54 | SEF.N.00.06  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 55 | SEF.N.00.07  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 56 | SEF.N.00.08  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 57 | SEF.W.00.01  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 58 | SEF.W.00.02  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 59 | SEF.W.B1.01  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 60 | SEF.W.B1.02  | \hyperref[sef-1]{SEF-1} | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System      |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 61 | SF.E.00.01   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 62 | SF.E.00.02   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 63 | SF.N.00.01   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 64 | SF.N.00.02   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 65 | SF.N.00.03   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 66 | SF.N.00.04   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 67 | SF.N.00.05   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 68 | SF.N.00.06   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 69 | SF.N.00.07   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 70 | SF.N.00.08   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 71 | SF.W.00.01   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 72 | SF.W.00.02   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 73 | SF.W.B1.01   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 74 | SF.W.B1.02   | \hyperref[sf-1]{SF-1}   | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System                |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 75 | TEF.E.01.01  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 76 | TEF.E.01.02  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 77 | TEF.E.01.03  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 78 | TEF.E.01.04  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 79 | TEF.E.02.01  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 80 | TEF.E.02.02  | \hyperref[tef-2]{TEF-2} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 81 | TEF.E.02.03  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 82 | TEF.N.03.01  | \hyperref[tef-2]{TEF-2} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 83 | TEF.N.03.02  | \hyperref[tef-2]{TEF-2} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 84 | TEF.S.01.01  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 85 | TEF.S.01.02  | \hyperref[tef-2]{TEF-2} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 86 | TEF.W.05.01  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 87 | TEF.W.05.02  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 88 | TEF.W.05.03  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+
| 89 | TEF.W.05.04  | \hyperref[tef-1]{TEF-1} | Concourse WC Extract Fan - Toilet Extract Ventilation System                         |
+----+--------------+-------------------------+--------------------------------------------------------------------------------------+

: {tbl-colwidths="[2, 20, 12, 66.0]"}

\newpage
## EF-1 - Extract Fan - General Mechanical Extract Ventilation System
\label{ef-1}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](EF-1__eQasGHhorrVDYoKo4tpqvu.png){height=139.53488372093025px}

:::

+----------------------------------------+------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                    |
+========================================+====================================================================================+
| Abbreviation                           | EF                                                                                 |
+----------------------------------------+------------------------------------------------------------------------------------+
| Type Reference                         | 1                                                                                  |
+----------------------------------------+------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                        |
+----------------------------------------+------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_50                                                                     |
+----------------------------------------+------------------------------------------------------------------------------------+
| Notes                                  | General extract only fan serves store and back of house areas.                     |
|                                        |                                                                                    |
|                                        | Total Ventilation Flow Rate: 0 - 50 l/s                                            |
|                                        |                                                                                    |
|                                        | Refer to ventilation schematic for each general extract system serving the spaces. |
+----------------------------------------+------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+-------------------------------------------------------------+
| **Application**   |                                                             |
+===================+=============================================================+
| Description       | Extract Fan - General Mechanical Extract Ventilation System |
+-------------------+-------------------------------------------------------------+
| Air Flow Type     | Extract                                                     |
+-------------------+-------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+------------------------------------------+
| **Manufacturer**     |                                          |
+======================+==========================================+
| Manufacturer         | Nuaire                                   |
+----------------------+------------------------------------------+
| Product Range        | ILMEC - In Line Mixed Flow with EC Motor |
+----------------------+------------------------------------------+
| Product Model Number | ILMEC-200                                |
+----------------------+------------------------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+---------------------------------+
| **Dimensions**     |                                 |
+====================+=================================+
| Overall Dimensions | H296 _mm_, W239 _mm_, D278 _mm_ |
+--------------------+---------------------------------+
| Gross Weight       | 4 _kg_                          |
+--------------------+---------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## EF-2 - Extract Fan - General Mechanical Extract Ventilation System
\label{ef-2}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](EF-2__67qU3R8FLm2d9Jr6uavZgg.png){height=139.53488372093025px}

:::

+----------------------------------------+-------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                           |
+========================================+===========================================================================================+
| Abbreviation                           | EF                                                                                        |
+----------------------------------------+-------------------------------------------------------------------------------------------+
| Type Reference                         | 2                                                                                         |
+----------------------------------------+-------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                               |
+----------------------------------------+-------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_50                                                                            |
+----------------------------------------+-------------------------------------------------------------------------------------------+
| Notes                                  | General extract only fan provides mechanical extract ventilation for the concourse areas. |
|                                        |                                                                                           |
|                                        | Total Ventilation Flow Rate: 4360 l/s                                                     |
|                                        |                                                                                           |
|                                        | Refer to ventilation schematic for each general extract system serving the spaces.        |
+----------------------------------------+-------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+-------------------------------------------------------------+
| **Application**   |                                                             |
+===================+=============================================================+
| Description       | Extract Fan - General Mechanical Extract Ventilation System |
+-------------------+-------------------------------------------------------------+
| Air Flow Type     | Extract                                                     |
+-------------------+-------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+----------+
| **Manufacturer**     |          |
+======================+==========+
| Manufacturer         | Nuaire   |
+----------------------+----------+
| Product Range        | Airmover |
+----------------------+----------+
| Product Model Number | AM46     |
+----------------------+----------+

: {tbl-colwidths="[35,65]"}

+--------------------+------------------------------------+
| **Dimensions**     |                                    |
+====================+====================================+
| Overall Dimensions | H1082 _mm_, W1082 _mm_, D1155 _mm_ |
+--------------------+------------------------------------+
| Gross Weight       | 305 _kg_                           |
+--------------------+------------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## EF-3 - Extract Fan - Chemical Store Mechanical Extract Ventilation System
\label{ef-3}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](EF-3__hWCrydKtU77NUyJYiEoyWD.png){height=139.53488372093025px}

:::

+----------------------------------------+-----------------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                                     |
+========================================+=====================================================================================================+
| Abbreviation                           | EF                                                                                                  |
+----------------------------------------+-----------------------------------------------------------------------------------------------------+
| Type Reference                         | 3                                                                                                   |
+----------------------------------------+-----------------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                                         |
+----------------------------------------+-----------------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_50                                                                                      |
+----------------------------------------+-----------------------------------------------------------------------------------------------------+
| Notes                                  | General extract only fan provides mechanical extract ventilation for the pool chemical store areas. |
|                                        |                                                                                                     |
|                                        | Total Ventilation Flow Rate: 24 l/s                                                                 |
|                                        |                                                                                                     |
|                                        | Refer to ventilation schematic for each general extract system serving the spaces.                  |
+----------------------------------------+-----------------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------------+
| **Application**   |                                                                    |
+===================+====================================================================+
| Description       | Extract Fan - Chemical Store Mechanical Extract Ventilation System |
+-------------------+--------------------------------------------------------------------+
| Air Flow Type     | Extract                                                            |
+-------------------+--------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+--------+
| **Manufacturer**     |        |
+======================+========+
| Manufacturer         | Axair  |
+----------------------+--------+
| Product Range        | ST12   |
+----------------------+--------+
| Product Model Number | ST12/2 |
+----------------------+--------+

: {tbl-colwidths="[35,65]"}

+--------------------+---------------------------------+
| **Dimensions**     |                                 |
+====================+=================================+
| Overall Dimensions | H526 _mm_, W410 _mm_, D380 _mm_ |
+--------------------+---------------------------------+
| Gross Weight       | 18 _kg_                         |
+--------------------+---------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## KEF-1 - Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System
\label{kef-1}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](KEF-1__GGNLdi7GvVvGNWJbE4PZUV.png){height=139.53488372093025px}

:::

+----------------------------------------+----------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                              |
+========================================+==============================================================================================+
| Abbreviation                           | KEF                                                                                          |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Type Reference                         | 1                                                                                            |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                                  |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_45                                                                               |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Notes                                  | Kitchen extract fan serves concourse food and beverage areas, and hospitality kitchen areas. |
|                                        |                                                                                              |
|                                        | Total Ventilation Flow Rate: 0 - 999 l/s                                                     |
|                                        |                                                                                              |
|                                        | Refer to ventilation schematic for each kitchen extract system serving the spaces.           |
+----------------------------------------+----------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------------------------------+
| **Application**   |                                                                                      |
+===================+======================================================================================+
| Description       | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+-------------------+--------------------------------------------------------------------------------------+
| Air Flow Type     | Extract                                                                              |
+-------------------+--------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+--------------------------+
| **Manufacturer**     |                          |
+======================+==========================+
| Manufacturer         | Nuaire                   |
+----------------------+--------------------------+
| Product Range        | Squif Single In-line Fan |
+----------------------+--------------------------+
| Product Model Number | SQFA44                   |
+----------------------+--------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+----------------------------------+
| **Dimensions**     |                                  |
+====================+==================================+
| Overall Dimensions | H1020 _mm_, W830 _mm_, D820 _mm_ |
+--------------------+----------------------------------+
| Gross Weight       | 100 _kg_                         |
+--------------------+----------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## KEF-2 - Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System
\label{kef-2}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](KEF-2__mLqXj846yRz6v73W83iniE.png){height=139.53488372093025px}

:::

+----------------------------------------+----------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                              |
+========================================+==============================================================================================+
| Abbreviation                           | KEF                                                                                          |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Type Reference                         | 2                                                                                            |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                                  |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_45                                                                               |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Notes                                  | Kitchen extract fan serves concourse food and beverage areas, and hospitality kitchen areas. |
|                                        |                                                                                              |
|                                        | Total Ventilation Flow Rate: 1000 - 1999 l/s                                                 |
|                                        |                                                                                              |
|                                        | Refer to ventilation schematic for each kitchen extract system serving the spaces.           |
+----------------------------------------+----------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------------------------------+
| **Application**   |                                                                                      |
+===================+======================================================================================+
| Description       | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+-------------------+--------------------------------------------------------------------------------------+
| Air Flow Type     | Extract                                                                              |
+-------------------+--------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+--------------------------+
| **Manufacturer**     |                          |
+======================+==========================+
| Manufacturer         | Nuaire                   |
+----------------------+--------------------------+
| Product Range        | Squif Single In-line Fan |
+----------------------+--------------------------+
| Product Model Number | SQFA45                   |
+----------------------+--------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+----------------------------------+
| **Dimensions**     |                                  |
+====================+==================================+
| Overall Dimensions | H1120 _mm_, W930 _mm_, D901 _mm_ |
+--------------------+----------------------------------+
| Gross Weight       | 150 _kg_                         |
+--------------------+----------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## KEF-3 - Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System
\label{kef-3}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](KEF-3__EoLxtEj5UMj3Z8iHt5teq6.png){height=139.53488372093025px}

:::

+----------------------------------------+----------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                              |
+========================================+==============================================================================================+
| Abbreviation                           | KEF                                                                                          |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Type Reference                         | 3                                                                                            |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                                  |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_45                                                                               |
+----------------------------------------+----------------------------------------------------------------------------------------------+
| Notes                                  | Kitchen extract fan serves concourse food and beverage areas, and hospitality kitchen areas. |
|                                        |                                                                                              |
|                                        | Total Ventilation Flow Rate: 2000 - 2999 l/s                                                 |
|                                        |                                                                                              |
|                                        | Refer to ventilation schematic for each kitchen extract system serving the spaces.           |
+----------------------------------------+----------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------------------------------+
| **Application**   |                                                                                      |
+===================+======================================================================================+
| Description       | Concourse F&B / Hospitality Kitchen Extract Fan - Kitchen Extract Ventilation System |
+-------------------+--------------------------------------------------------------------------------------+
| Air Flow Type     | Extract                                                                              |
+-------------------+--------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+--------------------------+
| **Manufacturer**     |                          |
+======================+==========================+
| Manufacturer         | Nuaire                   |
+----------------------+--------------------------+
| Product Range        | Squif Single In-line Fan |
+----------------------+--------------------------+
| Product Model Number | SQFA46                   |
+----------------------+--------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+-----------------------------------+
| **Dimensions**     |                                   |
+====================+===================================+
| Overall Dimensions | H1317 _mm_, W1030 _mm_, D994 _mm_ |
+--------------------+-----------------------------------+
| Gross Weight       | 210 _kg_                          |
+--------------------+-----------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## KEF-4 - Pub Kitchen Extract Fan - Kitchen Extract Ventilation System
\label{kef-4}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](KEF-4__bTg78Vh9V5Am4GtKLY2feQ.png){height=139.53488372093025px}

:::

+----------------------------------------+------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                    |
+========================================+====================================================================================+
| Abbreviation                           | KEF                                                                                |
+----------------------------------------+------------------------------------------------------------------------------------+
| Type Reference                         | 4                                                                                  |
+----------------------------------------+------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                        |
+----------------------------------------+------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_45                                                                     |
+----------------------------------------+------------------------------------------------------------------------------------+
| Notes                                  | Kitchen extract fan serves pub kitchen area.                                       |
|                                        |                                                                                    |
|                                        | Total Ventilation Flow Rate: 2110 l/s                                              |
|                                        |                                                                                    |
|                                        | Refer to ventilation schematic for each kitchen extract system serving the spaces. |
+----------------------------------------+------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------+
| **Application**   |                                                              |
+===================+==============================================================+
| Description       | Pub Kitchen Extract Fan - Kitchen Extract Ventilation System |
+-------------------+--------------------------------------------------------------+
| Air Flow Type     | Extract                                                      |
+-------------------+--------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+--------------------------+
| **Manufacturer**     |                          |
+======================+==========================+
| Manufacturer         | Nuaire                   |
+----------------------+--------------------------+
| Product Range        | Squif Single In-line Fan |
+----------------------+--------------------------+
| Product Model Number | SQFA46                   |
+----------------------+--------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+-----------------------------------+
| **Dimensions**     |                                   |
+====================+===================================+
| Overall Dimensions | H1317 _mm_, W1030 _mm_, D994 _mm_ |
+--------------------+-----------------------------------+
| Gross Weight       | 210 _kg_                          |
+--------------------+-----------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## KEF-5 - CPU Kitchen Extract Fan - Kitchen Extract Ventilation System
\label{kef-5}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](KEF-5__2cxFbNbRtG7K45xfBtDA9T.png){height=139.53488372093025px}

:::

+----------------------------------------+------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                    |
+========================================+====================================================================================+
| Abbreviation                           | KEF                                                                                |
+----------------------------------------+------------------------------------------------------------------------------------+
| Type Reference                         | 5                                                                                  |
+----------------------------------------+------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                        |
+----------------------------------------+------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_45                                                                     |
+----------------------------------------+------------------------------------------------------------------------------------+
| Notes                                  | Kitchen extract fan serves main CPU kitchen area.                                  |
|                                        |                                                                                    |
|                                        | Total Ventilation Flow Rate: 4410 l/s                                              |
|                                        |                                                                                    |
|                                        | Refer to ventilation schematic for each kitchen extract system serving the spaces. |
+----------------------------------------+------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------+
| **Application**   |                                                              |
+===================+==============================================================+
| Description       | CPU Kitchen Extract Fan - Kitchen Extract Ventilation System |
+-------------------+--------------------------------------------------------------+
| Air Flow Type     | Extract                                                      |
+-------------------+--------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+--------------------------+
| **Manufacturer**     |                          |
+======================+==========================+
| Manufacturer         | Nuaire                   |
+----------------------+--------------------------+
| Product Range        | Squif Single In-line Fan |
+----------------------+--------------------------+
| Product Model Number | SQFA46                   |
+----------------------+--------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+-----------------------------------+
| **Dimensions**     |                                   |
+====================+===================================+
| Overall Dimensions | H1317 _mm_, W1030 _mm_, D994 _mm_ |
+--------------------+-----------------------------------+
| Gross Weight       | 210 _kg_                          |
+--------------------+-----------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## SEF-1 - Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System
\label{sef-1}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](SEF-1__fqSfi5FNHUj8mpncN9GL5A.png){height=139.53488372093025px}

:::

+----------------------------------------+-------------------------------------------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                                                               |
+========================================+===============================================================================================================================+
| Abbreviation                           | SEF                                                                                                                           |
+----------------------------------------+-------------------------------------------------------------------------------------------------------------------------------+
| Type Reference                         | 1                                                                                                                             |
+----------------------------------------+-------------------------------------------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                                                                   |
+----------------------------------------+-------------------------------------------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_80                                                                                                                   |
+----------------------------------------+-------------------------------------------------------------------------------------------------------------------------------+
| Notes                                  | Smoke extract only fan provides mechanical extract ventilation to Basement and Level 00 plantrooms and high risk store areas. |
|                                        |                                                                                                                               |
|                                        | Smoke ventilation specialist to confirm final fan selection and duty.                                                         |
|                                        |                                                                                                                               |
|                                        | Refer to smoke extract and control schematic for each smoke extract system serving the spaces.                                |
+----------------------------------------+-------------------------------------------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+---------------------------------------------------------------------------------+
| **Application**   |                                                                                 |
+===================+=================================================================================+
| Description       | Basement & High Risk Rooms Smoke Extract Fan - Smoke Extract Ventilation System |
+-------------------+---------------------------------------------------------------------------------+
| Air Flow Type     | Extract                                                                         |
+-------------------+---------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+----------------------------------+
| **Manufacturer**   |                                  |
+====================+==================================+
| Manufacturer       | Nuaire                           |
+--------------------+----------------------------------+
| Product Range      | Axus High Temperature Axial Fans |
+--------------------+----------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## SEF-2 - Car Park Smoke Extract Fan - Smoke Extract Ventilation System
\label{sef-2}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=0}



:::

+----------------------------------------+------------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                                |
+========================================+================================================================================================+
| Abbreviation                           | SEF                                                                                            |
+----------------------------------------+------------------------------------------------------------------------------------------------+
| Type Reference                         | 2                                                                                              |
+----------------------------------------+------------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                                    |
+----------------------------------------+------------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_80                                                                                    |
+----------------------------------------+------------------------------------------------------------------------------------------------+
| Notes                                  | Smoke extract only fan provides mechanical extract ventilation for the car park areas.         |
|                                        |                                                                                                |
|                                        | Car park smoke ventilation specialist to confirm final fan selection and duty.                 |
|                                        |                                                                                                |
|                                        | Refer to smoke extract and control schematic for each smoke extract system serving the spaces. |
+----------------------------------------+------------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+---------------------------------------------------------------+
| **Application**   |                                                               |
+===================+===============================================================+
| Description       | Car Park Smoke Extract Fan - Smoke Extract Ventilation System |
+-------------------+---------------------------------------------------------------+
| Air Flow Type     | Extract                                                       |
+-------------------+---------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## SF-1 - Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System
\label{sf-1}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](SF-1__CWVKkMqzrTNQEkSSAoisY7.png){height=139.53488372093025px}

:::

+----------------------------------------+-----------------------------------------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                                                       |
+========================================+=======================================================================================================================+
| Abbreviation                           | SF                                                                                                                    |
+----------------------------------------+-----------------------------------------------------------------------------------------------------------------------+
| Type Reference                         | 1                                                                                                                     |
+----------------------------------------+-----------------------------------------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                                                           |
+----------------------------------------+-----------------------------------------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_80                                                                                                           |
+----------------------------------------+-----------------------------------------------------------------------------------------------------------------------+
| Notes                                  | Supply only fan provides mechanical supply ventilation to Basement and Level 00 plantrooms and high risk store areas. |
|                                        |                                                                                                                       |
|                                        | Smoke ventilation specialist to confirm final fan selection and duty.                                                 |
|                                        |                                                                                                                       |
|                                        | Refer to smoke extract and control schematic for each smoke extract system serving the spaces.                        |
+----------------------------------------+-----------------------------------------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+-----------------------------------------------------------------------+
| **Application**   |                                                                       |
+===================+=======================================================================+
| Description       | Basement & High Risk Rooms Supply Fan - Supply Air Ventilation System |
+-------------------+-----------------------------------------------------------------------+
| Air Flow Type     | Extract                                                               |
+-------------------+-----------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+--------------------+----------------------------------+
| **Manufacturer**   |                                  |
+====================+==================================+
| Manufacturer       | Nuaire                           |
+--------------------+----------------------------------+
| Product Range      | Axus High Temperature Axial Fans |
+--------------------+----------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## TEF-1 - Concourse WC Extract Fan - Toilet Extract Ventilation System
\label{tef-1}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](TEF-1__fxgUFqab8buEc2maW62SdN.png){height=139.53488372093025px}

:::

+----------------------------------------+-----------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                         |
+========================================+=========================================================================================+
| Abbreviation                           | TEF                                                                                     |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Type Reference                         | 1                                                                                       |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                             |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_90                                                                          |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Notes                                  | Concourse WC extract only fan provides mechanical extract ventilation for the WC areas. |
|                                        |                                                                                         |
|                                        | Total Ventilation Flow Rate: 0 - 499 l/s                                                |
|                                        |                                                                                         |
|                                        | Refer to ventilation schematic for each toilet extract system serving the spaces.       |
+----------------------------------------+-----------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------+
| **Application**   |                                                              |
+===================+==============================================================+
| Description       | Concourse WC Extract Fan - Toilet Extract Ventilation System |
+-------------------+--------------------------------------------------------------+
| Air Flow Type     | Extract                                                      |
+-------------------+--------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+----------+
| **Manufacturer**     |          |
+======================+==========+
| Manufacturer         | Nuaire   |
+----------------------+----------+
| Product Range        | Airmover |
+----------------------+----------+
| Product Model Number | AM22     |
+----------------------+----------+

: {tbl-colwidths="[35,65]"}

+--------------------+---------------------------------+
| **Dimensions**     |                                 |
+====================+=================================+
| Overall Dimensions | H510 _mm_, W510 _mm_, D615 _mm_ |
+--------------------+---------------------------------+
| Gross Weight       | 61 _kg_                         |
+--------------------+---------------------------------+

: {tbl-colwidths="[35,65]"}

\newpage
## TEF-2 - Concourse WC Extract Fan - Toilet Extract Ventilation System
\label{tef-2}


_[\hyperlink{toc}{TOC}]_ Fan - Pr_65_67_29

::: {layout-ncol=1}

![&nbsp;](TEF-2__VDrW9kzKVBEVaC3FNf4rRM.png){height=139.53488372093025px}

:::

+----------------------------------------+-----------------------------------------------------------------------------------------+
| **Identity Data**                      |                                                                                         |
+========================================+=========================================================================================+
| Abbreviation                           | TEF                                                                                     |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Type Reference                         | 2                                                                                       |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Classification Uniclass Product Number | Pr_65_67_29                                                                             |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Classification Uniclass System Number  | Ss_65_40_33_90                                                                          |
+----------------------------------------+-----------------------------------------------------------------------------------------+
| Notes                                  | Concourse WC extract only fan provides mechanical extract ventilation for the WC areas. |
|                                        |                                                                                         |
|                                        | Total Ventilation Flow Rate: 500 - 750 l/s                                              |
|                                        |                                                                                         |
|                                        | Refer to ventilation schematic for each toilet extract system serving the spaces.       |
+----------------------------------------+-----------------------------------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------+--------------------------------------------------------------+
| **Application**   |                                                              |
+===================+==============================================================+
| Description       | Concourse WC Extract Fan - Toilet Extract Ventilation System |
+-------------------+--------------------------------------------------------------+
| Air Flow Type     | Extract                                                      |
+-------------------+--------------------------------------------------------------+

: {tbl-colwidths="[35,65]"}

+----------------------+----------+
| **Manufacturer**     |          |
+======================+==========+
| Manufacturer         | Nuaire   |
+----------------------+----------+
| Product Range        | Airmover |
+----------------------+----------+
| Product Model Number | AM23     |
+----------------------+----------+

: {tbl-colwidths="[35,65]"}

+--------------------+---------------------------------+
| **Dimensions**     |                                 |
+====================+=================================+
| Overall Dimensions | H510 _mm_, W510 _mm_, D615 _mm_ |
+--------------------+---------------------------------+
| Gross Weight       | 61 _kg_                         |
+--------------------+---------------------------------+

: {tbl-colwidths="[35,65]"}
