---
project: University of Portsmouth, Faculty of Technology & Concrete Lab
title: Room Data Schedule
author: 
  - Max Fordham LLP
# ^ standard document properties. see: https://quarto.org/docs/reference/formats/pdf.html
project_name: University of Portsmouth, Faculty of Technology \\& Concrete Lab
project_number : 7516
director_in_charge: MN
document_description: Room Data Schedule
document_code: FOTB-MXF-01-XX-RD-ME-30000
name_nomenclature: project-originator-volume-level-type-role-number
current_issue:
  date: 2024-11-14
  revision: P01
  status_code: S0
  status_description: Initial Status
footer-logo: footer-logo.png
title-page: title-page.pdf
is_draft: false
---

:::: {layout="[ 26.5, -2.5, 71 ]" fig-pos="H"}

::: {#first-column}
\addcontentsline{toc}{section}{Document Information}

\justifying \noindent \scriptsize __Max Fordham LLP__\                      
\                                         
maxfordham.com\                           
Max Fordham LLP is a Limited Liability\   
Partnership.\                             
\                                         
Registered in England and Wales\          
Number OC300026.\                         
\                                         
Registered office:\                       
42–43 Gloucester Crescent\                
London NW1 7PE\                           
This report is for the private and\       
confidential use of the clients for\      
whom the report is undertaken and\     
should not be reproduced in whole or\
in part or relied upon by third parties\
for any use whatsoever without the\       
express written authority of Max\         
Fordham LLP\                              
\                                         
© Max Fordham LLP\      
:::

::: {#second-column}


### Contributions

+----------------+---------------------+
| **Initials**   | **Role**            |
+================+=====================+
| MN             | Director in Charge  |
+----------------+---------------------+
| MP             | Project Leader      |
+----------------+---------------------+
| DM             | Project Engineer    |
+----------------+---------------------+
| CF             | Project Coordinator |
+----------------+---------------------+
| HR             | Project Coordinator |
+----------------+---------------------+
| NM             | Acoustician         |
+----------------+---------------------+

: {tbl-colwidths="[30,70]"}

:::

::::

### Issue History

+------------+-----------+--------------+-------------------+-------------------+
| **Date**   | **Rev**   | **Status**   | **Description**   | **Issue Notes**   |
+============+===========+==============+===================+===================+
| 14 NOV 24  | P01       | S0           | Initial Status    | First issue       |
+------------+-----------+--------------+-------------------+-------------------+

: {tbl-colwidths="[12,5,7.5,30,45.5]"}



\newpage
\toc
\newpage
## 00.062A - Individual Office

_[\hyperlink{toc}{TOC}]_ SL_90 - General spaces



+---------------------+----------------------------------------------+
| **Identity Data**   |                                              |
+=====================+==============================================+
| Occupancy Number    | 20                                           |
+---------------------+----------------------------------------------+
| Typical Room Detail | ...                                          |
+---------------------+----------------------------------------------+
| Notes               | Some notes about the individual office space |
+---------------------+----------------------------------------------+

: {tbl-colwidths="[35,65]"}

+------------------------------+----------------------------------------------+
| **Mechanical**               |                                              |
+==============================+==============================================+
| Heating Strategy             | Chilled beams used to heat the space         |
+------------------------------+----------------------------------------------+
| Heating Control Strategy     | Central BMS control with local user override |
+------------------------------+----------------------------------------------+
| Cooling Strategy             | Chilled beams used to cool the space         |
+------------------------------+----------------------------------------------+
| Cooling Control Strategy     | Central BMS control with local user override |
+------------------------------+----------------------------------------------+
| Ventilation Strategy         | Supply and extract at high level             |
+------------------------------+----------------------------------------------+
| Ventilation Control Strategy | Central BMS                                  |
+------------------------------+----------------------------------------------+
| Space Temperature Summer     | 22 - 26 _°C_                                 |
+------------------------------+----------------------------------------------+
| Space Temperature Winter     | <23 _°C_                                     |
+------------------------------+----------------------------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------------------------------------+-----+
| **Electrical**                                  |     |
+=================================================+=====+
| Electrical Strategy                             | ... |
+-------------------------------------------------+-----+
| Small Power Strategy                            | ... |
+-------------------------------------------------+-----+
| Perimeter Trunking                              | No  |
+-------------------------------------------------+-----+
| Emergency Power Off                             | Yes |
+-------------------------------------------------+-----+
| Number of Floor Boxes                           | 4   |
+-------------------------------------------------+-----+
| Number of Single Power Sockets                  | 0   |
+-------------------------------------------------+-----+
| Number of Twin Power Sockets                    | 0   |
+-------------------------------------------------+-----+
| Number of Fused Connection Units                | 0   |
+-------------------------------------------------+-----+
| Number of Switch Disconnectors                  | 0   |
+-------------------------------------------------+-----+
| Number of Commando Power Sockets - Single Phase | 0   |
+-------------------------------------------------+-----+
| Number of Commando Power Sockets - Three Phase  | 0   |
+-------------------------------------------------+-----+

: {tbl-colwidths="[35,65]"}

+-------------------------------------+-----------------------------+
| **Electrical - Lighting**           |                             |
+=====================================+=============================+
| Lighting Strategy                   | L46 recessed circular light |
+-------------------------------------+-----------------------------+
| Lighting Control Strategy           | Absence Detection           |
+-------------------------------------+-----------------------------+
| Emergency Lighting                  | Yes                         |
+-------------------------------------+-----------------------------+
| Minimum Horizontal/Task Illuminance | 500 _lx_                    |
+-------------------------------------+-----------------------------+

: {tbl-colwidths="[35,65]"}

+-------------------------------------------------------------------------+----------------------------------+
| **Communications, Security, Safety, Control, and Protection Systems**   |                                  |
+=========================================================================+==================================+
| Fire Strategy                                                           | Combined smoke detector/sounders |
+-------------------------------------------------------------------------+----------------------------------+
| Security and Access Control Strategy                                    | ...                              |
+-------------------------------------------------------------------------+----------------------------------+
| Communications Strategy                                                 | ...                              |
+-------------------------------------------------------------------------+----------------------------------+
| Number of Data Points                                                   | 10                               |
+-------------------------------------------------------------------------+----------------------------------+
| Number of WiFi Points                                                   | 2                                |
+-------------------------------------------------------------------------+----------------------------------+

: {tbl-colwidths="[35,65]"}
