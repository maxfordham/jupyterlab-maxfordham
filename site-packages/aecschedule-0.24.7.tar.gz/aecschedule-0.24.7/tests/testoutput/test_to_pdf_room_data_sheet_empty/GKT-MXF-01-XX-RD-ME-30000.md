---
project: Kings Theatre Glasgow
title: Room Data Schedule
author: 
  - Max Fordham LLP
# ^ standard document properties. see: https://quarto.org/docs/reference/formats/pdf.html
project_name: Kings Theatre Glasgow
project_number : 7172
director_in_charge: SK
document_description: Room Data Schedule
document_code: GKT-MXF-01-XX-RD-ME-30000
name_nomenclature: project-originator-volume-level-type-role-number
current_issue:
  date: 2025-01-17
  revision: P01
  status_code: S0
  status_description: Initial Status
footer-logo: footer-logo.png
title-page: title-page.pdf
is_draft: false
---

:::: {layout="[ 26.5, -2.5, 71 ]" fig-pos="H"}

::: {#first-column}
\addcontentsline{toc}{section}{Document Information}

\justifying \noindent \scriptsize __Max Fordham LLP__\                      
\                                         
maxfordham.com\                           
Max Fordham LLP is a Limited Liability\   
Partnership.\                             
\                                         
Registered in England and Wales\          
Number OC300026.\                         
\                                         
Registered office:\                       
42–43 Gloucester Crescent\                
London NW1 7PE\                           
This report is for the private and\       
confidential use of the clients for\      
whom the report is undertaken and\     
should not be reproduced in whole or\
in part or relied upon by third parties\
for any use whatsoever without the\       
express written authority of Max\         
Fordham LLP\                              
\                                         
© Max Fordham LLP\      
:::

::: {#second-column}


### Contributions

+----------------+--------------------+
| **Initials**   | **Role**           |
+================+====================+
| SK             | Director in Charge |
+----------------+--------------------+
| BM             | Project Engineer   |
+----------------+--------------------+

: {tbl-colwidths="[30,70]"}

:::

::::

### Issue History

+------------+-----------+--------------+-------------------+-------------------+
| **Date**   | **Rev**   | **Status**   | **Description**   | **Issue Notes**   |
+============+===========+==============+===================+===================+
| 17 JAN 25  | P01       | S0           | Initial Status    | First issue       |
+------------+-----------+--------------+-------------------+-------------------+

: {tbl-colwidths="[12,5,7.5,30,45.5]"}



\newpage
\toc
\newpage
