---
title: "Plant Room Schedule"
---

::: {.callout-note collapse="true" icon=false}


## code

```py
import json

from aectemplater_schemas.document import DocumentData
from document_issue.document_issue import DocumentIssue

from aecschedule.schedules import PlantRoomSchedule
from tests.common_paths import FDIR_TEST_IMAGES, FDIR_TESTDATA, FDIR_TESTOUTPUT

fpth_plant_room_document_data = FDIR_TESTDATA / "PLANTROOM" / "document-data.json"
fpth_plant_room_document_issue = FDIR_TESTDATA / "PLANTROOM" / "document-issue.json"
plant_room_document_data = DocumentData(
    json.loads(fpth_plant_room_document_data.read_text())
)
plant_room_document_issue = DocumentIssue(
    **json.loads(fpth_plant_room_document_issue.read_text())
)
prs = PlantRoomSchedule(
    document_data=plant_room_document_data,
    document_issue=plant_room_document_issue,
    fdir_img=FDIR_TEST_IMAGES,
)
FDIR = FDIR_TESTOUTPUT / "plant_room_schedule"
FDIR.mkdir(exist_ok=True, parents=True)
FPTH_MD = FDIR / f"{prs.document_issue.document_code}.md"
FPTH_PDF = FDIR / f"{prs.document_issue.document_code}.pdf"
FPTH_LOG = FDIR / f"{prs.document_issue.document_code}.log"
FPTH_MD.unlink(missing_ok=True)
FPTH_PDF.unlink(missing_ok=True)
prs.to_pdf(FDIR)
print(FPTH_PDF.name, FPTH_PDF.is_file())  # noqa: T201
#> XXXX-MXF-01-XX-PR-ME-30000.pdf True
```

:::

::: {.callout-note collapse="true" icon=false}
## generated markdown file
```markdown
{{< include ../../tests/exampleoutputs/plant_room_schedule/XXXX-MXF-01-XX-PR-ME-30000.md >}}
```
:::

```{=html}
<embed src="../exampleoutputs/plant_room_schedule/XXXX-MXF-01-XX-PR-ME-30000.pdf" width="600px" height="1000px" />
```