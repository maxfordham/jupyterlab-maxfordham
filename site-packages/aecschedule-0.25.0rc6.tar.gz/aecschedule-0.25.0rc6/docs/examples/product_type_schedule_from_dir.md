---
title: "Product Type Schedule From Dir"
---

::: {.callout-note collapse="true" icon=false}


## code

```py
from aectemplater_schemas.images import PdtImage

from aecschedule.schedules import ProductDataSchedule
from tests.common_paths import FDIR_TEST_IMAGES, FDIR_TESTDATA, FDIR_TESTOUTPUT

pds = ProductDataSchedule.from_fdir(
    fdir=FDIR_TESTDATA / "AT",
    fdir_img=FDIR_TEST_IMAGES,
    include_instances=True,
)
FDIR = FDIR_TESTOUTPUT / "product_type_schedule_from_dir"
FDIR.mkdir(exist_ok=True, parents=True)
FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
FPTH_MD.unlink(missing_ok=True)
FPTH_PDF.unlink(missing_ok=True)
img = PdtImage.from_fpth(FDIR_TEST_IMAGES / "AT-1__0.png")
img.height = "200px"  # Set height assigned to image in output PDF
img.write_exif()
pds.to_pdf(FDIR)
print(FPTH_PDF.name, FPTH_PDF.is_file())  # noqa: T201
#> 06667-MXF-XX-XX-SH-M-20003.pdf True
```
:::

::: {.callout-note collapse="true" icon=false}
## generated markdown file
```markdown
{{< include ../../tests/exampleoutputs/product_type_schedule_from_dir/06667-MXF-XX-XX-SH-M-20003.md >}}
```
:::

```{=html}
<embed src="../exampleoutputs/product_type_schedule_from_dir/06667-MXF-XX-XX-SH-M-20003.pdf" width="600px" height="1000px" />
```