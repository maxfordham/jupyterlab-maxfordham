---
title: "Product Type Schedule Multiple Types"
---

::: {.callout-note collapse="true" icon=false}


## code

```py
import json

from aectemplater_schemas.document import DocumentData
from document_issue.document_issue import DocumentIssue

from aecschedule.schedules import ProductDataSchedule
from tests.common_paths import FDIR_TEST_IMAGES, FDIR_TESTDATA, FDIR_TESTOUTPUT

FPTH_DB_DOCUMENT_DATA = FDIR_TESTDATA / "DB" / "document-data.json"
FPTH_DB_DOCUMENT_ISSUE = FDIR_TESTDATA / "DB" / "document-issue.json"
DB_DOCUMENT_DATA = DocumentData(json.loads(FPTH_DB_DOCUMENT_DATA.read_text()))
DB_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_DB_DOCUMENT_ISSUE.read_text()))

pds = ProductDataSchedule(
    document_data=DB_DOCUMENT_DATA,
    document_issue=DB_DOCUMENT_ISSUE,
    fdir_img=FDIR_TEST_IMAGES,
)
FDIR = FDIR_TESTOUTPUT / "product_type_schedule_multiple_types"
FDIR.mkdir(exist_ok=True, parents=True)
FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
FPTH_MD.unlink(missing_ok=True)
FPTH_PDF.unlink(missing_ok=True)
pds.to_pdf(FDIR)
print(FPTH_PDF.name, FPTH_PDF.is_file())  # noqa: T201
#> 06667-MXF-XX-XX-SH-M-20003.pdf True
```

:::

::: {.callout-note collapse="true" icon=false}
## generated markdown file
```markdown
{{< include ../../tests/exampleoutputs/tester_editable_markdown/06667-MXF-XX-XX-SH-M-20003.md >}}
```
:::

```{=html}
<embed src="../exampleoutputs/product_type_schedule_multiple_types/06667-MXF-XX-XX-SH-M-20003.pdf" width="600px" height="1000px" />
```