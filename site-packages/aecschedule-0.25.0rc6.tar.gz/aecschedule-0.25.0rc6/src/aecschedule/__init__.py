"""Top-level package for aecschedule."""

__author__ = """Oliver Hensby"""
__email__ = "o.hensby@maxfordham.com"
