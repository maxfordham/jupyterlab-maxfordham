import pathlib
import enum


FDIR_MODULE = pathlib.Path(__file__).parent
DIR_TEMPLATES = FDIR_MODULE / "templates"
PAGE_ITEM_TEMPLATE = "page-item.md.jinja"
TABLE_TEMPLATE = "table.md.jinja"
NAME_IMAGES_DIR = "images"

FDIR_AECSCHEDULE = FDIR_MODULE.parent
FPTH_CONFIG_LOG = FDIR_MODULE / "logging" / "config_logging.yml"


class Source(enum.Enum):
    revit = "revit"
    excel = "excel"
