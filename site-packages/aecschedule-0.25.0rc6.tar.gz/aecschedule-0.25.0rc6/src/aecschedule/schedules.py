"""Generate formatted PDF output schedules."""

import json
import pathlib
import typing as ty
from abc import ABC, abstractmethod

from aectemplater_schemas.document import DocumentData
from aectemplater_schemas.enumerations import ParameterTypeEnum
from aectemplater_schemas.object import ObjectData
from document_issue.document_issue import DocumentIssue
from document_issue_io.markdown_document_issue import (
    MarkdownDocumentIssue,
    Orientation,
    OutputFormat,
    PaperSize,
    generate_document_issue_pdf,
)
from jinja2 import Environment, FileSystemLoader
from natsort import natsort_keygen
from pyuniclass import UT

from aecschedule.components import MergedTable, PageItem
from aecschedule.constants import (
    DIR_TEMPLATES,
)
from aecschedule.logging_handler import Loggers
from aecschedule.modifiers import (
    add_hyper_ref_to_type_mark,
    append_unit_to_value,
    define_url_as_hyperlink,
    drop_empty_values,
    merge_dimensions,
    merge_dimensions_with_newline,
    merge_door_dimensions_with_newline,
    merge_range,
    remove_classification_uniclass_space_number,
    remove_leading_zero_decimal,
    replace_boolean_with_yes_no,
    replace_names_with_titles,
    replace_tabs_with_spaces,
    round_area_to_three_significant_figures,
    round_floats_to_two_decimals,
)

loggers = Loggers()
loggers.get_loggers()
logger = loggers.console_logger


class Schedule(ABC):
    def __init__(
        self,
        document_issue: DocumentIssue,
        document_data: DocumentData = None,
        fdir_img: ty.Optional[pathlib.Path] = None,
        uniclass_codes: ty.Optional[list[str]] = None,
        *,
        include_empty_parameters: bool = False,
    ):
        """Create a markdown schedule from document issue and document data."""
        if document_data is None:
            document_data = []
        self.document_issue = document_issue
        self.document_data = document_data
        self.fdir_img = fdir_img
        self.include_empty_parameters = include_empty_parameters
        if uniclass_codes is None:
            self.uniclass_codes = []
        else:
            self.uniclass_codes = uniclass_codes
        self.markdown_document_issue = MarkdownDocumentIssue(document_issue=self.document_issue)
        self.file_loader = FileSystemLoader(DIR_TEMPLATES)
        self.env = Environment(loader=self.file_loader)

    @classmethod
    def from_fdir(cls, fdir: pathlib.Path, fdir_img: ty.Optional[pathlib.Path] = None, *args, **kwargs) -> "Schedule":
        """Create a markdown schedule from a directory of JSON files."""
        fpth_document_issue = fdir / "document-issue.json"
        fpth_document_data = fdir / "document-data.json"
        if not fpth_document_issue.is_file():
            msg = f"Document issue file not found: {fpth_document_issue}"
            raise FileNotFoundError(msg)
        document_issue = DocumentIssue(**json.loads(fpth_document_issue.read_text()))
        if fpth_document_data.is_file():
            document_data = DocumentData(json.loads(fpth_document_data.read_text()))
        else:
            document_data = []
        return cls(*args, **kwargs, document_issue=document_issue, document_data=document_data, fdir_img=fdir_img)

    @abstractmethod
    def generate_markdown(self, *args, **kwargs) -> str:
        return ""

    def to_file(self, fpth: pathlib.Path) -> str:
        """Write markdown schedule to file."""
        md_content = self.generate_markdown()
        f = open(fpth, "w")
        f.write(md_content)
        f.close()
        return md_content

    def to_pdf(
        self,
        fdir: pathlib.Path,
        output_format: OutputFormat = OutputFormat.DOCUMENT_ISSUE_REPORT,
        orientation: Orientation = Orientation.PORTRAIT,
        paper_size: PaperSize = PaperSize.A4,
        resource_path: list[pathlib.Path] | None = None,
        is_draft: bool = False,
    ) -> pathlib.Path:
        """Create a schedule PDF in a specified file directory."""
        if resource_path:
            resource_path = [self.fdir_img, *resource_path]
        else:
            resource_path = [self.fdir_img]
        fpth_md = fdir / f"{self.document_issue.document_code}.md"
        fpth_pdf = fdir / f"{self.document_issue.document_code}.pdf"
        md_content = self.to_file(fpth_md)
        generate_document_issue_pdf(
            document_issue=self.document_issue,
            fpth_pdf=fpth_pdf,
            md_content=md_content,
            output_format=output_format,
            orientation=orientation,
            paper_size=paper_size,
            resource_path=resource_path,
            is_draft=is_draft,
        )
        return fpth_pdf


class RoomDataSchedule(Schedule):
    """Create a Room Data Schedule from document issue and document data."""

    def generate_markdown(self) -> str:
        """Create markdown schedule from markdown document issue and markdown RDSs."""
        page_items: list[PageItem] = []  # Generate the markdown type objects
        for item in self.document_data.root:
            if item.schema_.items.parameter_type == ParameterTypeEnum.type:
                continue
            schema = item.schema_
            for data in item.data:
                if "Name" not in data.keys():
                    raise ValueError("Room data missing `Name`")
                if "Number" not in data.keys():
                    raise ValueError("Room data missing `Number`")
                room_name = data["Name"]
                room_number = data["Number"]
                title = self._get_title(room_name, room_number)
                if "ClassificationUniclassSpaceNumber" in data.keys():
                    classification_uniclass_space_number = data["ClassificationUniclassSpaceNumber"]
                else:
                    classification_uniclass_space_number = schema.items.classification
                if self.uniclass_codes and classification_uniclass_space_number not in self.uniclass_codes:
                    continue  # Skip if uniclass codes given and classification not in uniclass codes
                if " " in classification_uniclass_space_number:  # TODO: this is a hack... use regex to get uniclass code
                    classification_uniclass_space_number = classification_uniclass_space_number.split(" ")[0]
                classification_uniclass_space_description = UT.get_title(code=classification_uniclass_space_number)
                subtitle = self._get_subtitle(
                    classification_uniclass_space_number, classification_uniclass_space_description
                )
                page_items.append(
                    PageItem(
                        title=title,
                        subtitle=subtitle,
                        object_data=ObjectData(schema_=schema.items, data=data),
                        modifiers=[
                            drop_empty_values,
                            remove_leading_zero_decimal,
                            round_floats_to_two_decimals,
                            round_area_to_three_significant_figures,
                            define_url_as_hyperlink,
                            replace_boolean_with_yes_no,
                            merge_dimensions,
                            merge_range,
                            append_unit_to_value,
                            remove_classification_uniclass_space_number,
                            replace_tabs_with_spaces,
                        ],
                        ignore_parameters=[
                            "Id",
                            "TypeMark",
                            "TypeSpecId",
                            "InstanceReference",
                            "LevelReference",
                            "VolumeReference",
                            "Symbol",
                            "Name",
                            "Number",
                        ],
                        include_empty_parameters=self.include_empty_parameters,
                    )
                )
        natsort_key = natsort_keygen()  # Generate a natural sorting key for room number
        sorted_room_page_items = sorted(
            page_items,
            key=lambda x: (natsort_key(x.data["Number"] or ""),),
        )  # Sort by Room Number
        markdown_rooms = []
        for room_page_item in sorted_room_page_items:
            md = room_page_item.generate_markdown()
            if md:
                markdown_rooms.append(md)
        return "\n\\newpage\n".join(markdown_rooms)

    def _get_title(self, room_name: str, room_number: str) -> str:
        title = room_number + " - " + room_name
        return title

    def _get_subtitle(self, uniclass_code: str, uniclass_description: str) -> str:
        return uniclass_code + " - " + uniclass_description


def get_types_and_instances_from_document_data(document_data: DocumentData) -> ty.Tuple[DocumentData, DocumentData]:
    types: DocumentData = DocumentData([])
    instances: DocumentData = DocumentData([])
    for data in document_data.root:
        if data.schema_.items.parameter_type == "I":
            instances.root.append(data)
        elif data.schema_.items.parameter_type == "T":
            types.root.append(data)
        else:
            logger.warning(f"Document data {data.schema_['title']} not classified as type or instance")

    return types, instances


class ProductDataSchedule(Schedule):
    def __init__(
        self,
        document_issue: DocumentIssue,
        document_data: DocumentData = None,
        fdir_img: ty.Optional[pathlib.Path] = None,
        *,
        include_instances: bool = True,
    ):
        """Create a Product Data Schedule from document issue and document data."""
        self.include_instances = include_instances
        super().__init__(document_issue=document_issue, document_data=document_data, fdir_img=fdir_img)
        self.types, self.instances = get_types_and_instances_from_document_data(self.document_data)

        # ---------------------------------------
        # HACK: J7081 delete when functionality added

        if self.document_issue.document_code in ["LTFC-MXF-XX-XX-SH-M-20001", "LTFC-MXF-XX-XX-SH-M-20002", "CPNSC-MXF-B1-XX-S-M-200000", "CPNSC-MXF-B1-XX-S-M-200010"]:
            import itertools

            map_descriptions = {
                x.get("TypeMark"): x.get("Description")
                for x in list(itertools.chain.from_iterable([x.data for x in self.types.root]))
            }
            for item in self.instances.root:
                for n, x in enumerate(item.data):
                    if x.get("TypeMark") in map_descriptions:
                        item.data[n]["Description"] = map_descriptions[x["TypeMark"]]
                    else:
                        item.data[n]["Description"] = ""
        # ---------------------------------------

    def _generate_markdown_types(self) -> str:
        page_items: list[PageItem] = []
        for item in self.types.root:
            schema = item.schema_
            for data in item.data:
                type_mark = data["TypeMark"]
                if "Description" in data.keys():
                    description = data["Description"]
                else:
                    description = None
                template_name = schema.title
                if "ClassificationUniclassProductNumber" in data.keys():
                    classification = data["ClassificationUniclassProductNumber"]
                else:
                    classification = None
                title = self._get_title(type_mark, description)
                subtitle = self._get_subtitle(template_name, classification)
                page_items.append(
                    PageItem(
                        title=title,
                        subtitle=subtitle,
                        object_data=ObjectData(schema_=schema.items, data=data),
                        fdir_img=self.fdir_img,
                        modifiers=[
                            remove_leading_zero_decimal,
                            define_url_as_hyperlink,
                            replace_boolean_with_yes_no,
                            merge_dimensions,
                            append_unit_to_value,
                            replace_tabs_with_spaces,
                        ],
                        ignore_parameters=["Id", "TypeMark", "Symbol"],
                    )
                )
        natsort_key = natsort_keygen()  # Generate a natural sorting key for type_mark
        sorted_types = sorted(
            page_items,
            key=lambda x: (
                x.data.get("ClassificationUniclassProductNumber", "") or "",
                natsort_key(x.data["TypeMark"] or ""),
            ),
        )  # Sort by Classification first and then by TypeMark within each classification
        return "\n\\newpage\n".join([m.generate_markdown() for m in sorted_types])

    def _generate_markdown_instances(self) -> str:
        if not self.instances:
            return ""
        modifiers = [
            remove_leading_zero_decimal,
            define_url_as_hyperlink,
            add_hyper_ref_to_type_mark,
            replace_boolean_with_yes_no,
            merge_dimensions,
            append_unit_to_value,
            replace_names_with_titles,
            replace_tabs_with_spaces,
        ]
        # ---------------------------------------
        # HACK: J7081 delete when functionality added
        if self.document_issue.document_code in ["LTFC-MXF-XX-XX-SH-M-20001", "LTFC-MXF-XX-XX-SH-M-20002", "CPNSC-MXF-B1-XX-S-M-200000", "CPNSC-MXF-B1-XX-S-M-200010"]:
            from aecschedule.modifiers import update_7081_mark

            modifiers = [update_7081_mark, *modifiers]
        # ---------------------------------------
        merged_table_items = MergedTable(
            title="Table of Instances",
            li_object_data=self.instances.root,
            index="Mark",
            modifiers=modifiers,
            ignore_parameters=[
                "Id",
                "TypeSpecId",
                "Symbol",
                "Abbreviation",
                "InstanceReference",
                "TypeReference",
                "VolumeReference",
                "LevelReference",
                "FunctionReference",
            ],
        )
        return merged_table_items.generate_markdown()

    def _get_title(self, type_mark: str, description: ty.Optional[str]) -> str:
        title = type_mark
        if description:
            title += f" - {description}"
        title += (
            f"\n\\label{{{type_mark.lower()}}}\n"  # Label for each TypeMark to support instances table with hyperlinks
        )
        return title

    def _get_subtitle(self, template_name: str, uniclass_code: ty.Optional[str]) -> str:
        subtitle = template_name
        if uniclass_code:
            subtitle += " - " + uniclass_code
        return subtitle

    def generate_markdown(self) -> str:
        """Create markdown schedule from markdown document issue and markdown PDTs."""
        self.markdown_types = self._generate_markdown_types()
        self.markdown_instances = ""
        if self.include_instances and self.instances.root:
            self.markdown_instances = self._generate_markdown_instances()
            return self.markdown_instances + "\n\\newpage\n" + self.markdown_types
        else:
            return self.markdown_types


class PlantRoomSchedule(Schedule):
    def __init__(
        self,
        document_issue: DocumentIssue,
        document_data: DocumentData = None,
        fdir_img: ty.Optional[pathlib.Path] = None,
    ):
        """Create a Product Data Schedule from document issue and document data."""
        super().__init__(document_issue=document_issue, document_data=document_data, fdir_img=fdir_img)
        self.types, self.instances = get_types_and_instances_from_document_data(self.document_data)

    def generate_markdown(self) -> str:
        if not self.instances:
            return ""
        merged_table_items = MergedTable(
            title="Plant Room",
            li_object_data=self.instances.root,
            index="Mark",
            modifiers=[
                remove_leading_zero_decimal,
                define_url_as_hyperlink,
                replace_boolean_with_yes_no,
                merge_dimensions_with_newline,
                merge_door_dimensions_with_newline,
                append_unit_to_value,
                replace_names_with_titles,
                replace_tabs_with_spaces,
            ],
            ignore_parameters=[
                "Id",
                "TypeMark",
                "TypeSpecId",
                "Symbol",
                "Abbreviation",
                "InstanceReference",
                "TypeReference",
                "VolumeReference",
                "LevelReference",
                "FunctionReference",
            ],
        )
        return merged_table_items.generate_markdown()

    def to_pdf(
        self,
        fdir: pathlib.Path,
    ) -> pathlib.Path:
        return super().to_pdf(
            fdir=fdir,
            output_format=OutputFormat.DOCUMENT_ISSUE_REPORT,
            orientation=Orientation.LANDSCAPE,
            paper_size=PaperSize.A3,
        )
