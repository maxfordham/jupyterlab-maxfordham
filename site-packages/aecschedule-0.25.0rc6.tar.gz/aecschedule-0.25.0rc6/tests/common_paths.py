# tests/common_paths.py
from pathlib import Path

# Base test directory
BASE_DIR = Path(__file__).parent  # points to tests/

FDIR_TESTDATA = (BASE_DIR / "testdata").resolve()
FDIR_TESTOUTPUT = (BASE_DIR / "exampleoutputs").resolve()
FDIR_TEST_IMAGES = FDIR_TESTDATA / "images"

FDIR_TESTOUTPUT.mkdir(exist_ok=True, parents=True)
