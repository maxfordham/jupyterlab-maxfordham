import os
import json
import pathlib

AECTEMPLATER_CNAME = "https://aectemplater.maxfordham.com"
PROJECT_NUMBER = 7516

os.environ["AECTEMPLATER_CNAME"] = AECTEMPLATER_CNAME

from aectemplater_client import (
    get_project_by_project_number,
    get_project_filters_by_project_revision,
    get_documents_by_project_revision,
)

project = get_project_by_project_number(PROJECT_NUMBER)
project_revision_id = project["id"]


documents = get_documents_by_project_revision(project_revision_id)
fdir_docs = {x.stem: x for x in list(pathlib.Path(__file__).parent.glob("*")) if x.is_dir()}
issues = {
    x["issue"]["issue_data"]["document_name"]: x["issue"]["issue_data"]
    for x in documents
    if x["issue"]["issue_data"]["document_name"] in fdir_docs.keys()
}

for k, v in issues.items():
    fpth = fdir_docs[k] / "document-issue.json"
    fpth.write_text(json.dumps(v, indent=4))
    print(f"Wrote issue data for {k}")


filters = get_project_filters_by_project_revision(project_revision_id)
space_filters = [f for f in filters if "Level" in f["name"]]

fpth = pathlib.Path(__file__).parent / "space-filters.json"
fpth.write_text(json.dumps(space_filters, indent=2))


print("wrote: space-filters.json")
