---
title: "J7081 - Fan Schedule"
---

::: {.callout-note collapse="true" icon=false}


## code

```py
import json

from aectemplater_schemas.document import DocumentData
from document_issue.document_issue import DocumentIssue

from aecschedule.schedules import ProductDataSchedule
from tests.common_paths import FDIR_TEST_IMAGES, FDIR_TESTDATA, FDIR_TESTOUTPUT

FPTH_J7081_DOCUMENT_DATA = (
    FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20002" / "document-data.json"
)
FPTH_J7081_DOCUMENT_ISSUE = (
    FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20002" / "document-issue.json"
)
J7081_DOCUMENT_DATA = DocumentData(json.loads(FPTH_J7081_DOCUMENT_DATA.read_text()))
J7081_DOCUMENT_ISSUE = DocumentIssue(
    **json.loads(FPTH_J7081_DOCUMENT_ISSUE.read_text())
)
pds = ProductDataSchedule(
    document_data=J7081_DOCUMENT_DATA,
    document_issue=J7081_DOCUMENT_ISSUE,
    fdir_img=FDIR_TEST_IMAGES,
)
fdir = FDIR_TESTOUTPUT / "j7081_Fan_Schedule"
fdir.mkdir(exist_ok=True, parents=True)
fdir_md = fdir / f"{pds.document_issue.document_code}.md"
fdir_pdf = fdir / f"{pds.document_issue.document_code}.pdf"
fdir_log = fdir / f"{pds.document_issue.document_code}.log"
fdir_md.unlink(missing_ok=True)
fdir_pdf.unlink(missing_ok=True)
pds.to_pdf(fdir)
print(fdir_pdf.name, fdir_pdf.is_file())  # noqa: T201
#> LTFC-MXF-XX-XX-SH-M-20002.pdf True
```
:::

::: {.callout-note collapse="true" icon=false}
## generated markdown file - Fan Schedule
```markdown
{{< include ../../tests/exampleoutputs/j7081_Fan_Schedule/LTFC-MXF-XX-XX-SH-M-20002.md >}}
```
:::

```{=html}
<embed src="../exampleoutputs/j7081_Fan_Schedule/LTFC-MXF-XX-XX-SH-M-20002.pdf" width="600px" height="1000px" />
```