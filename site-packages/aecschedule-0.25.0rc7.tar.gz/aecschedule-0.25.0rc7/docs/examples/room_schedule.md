---
title: "Room Schedule"
---

::: {.callout-note collapse="true" icon=false}


## code

```py
import json

from aectemplater_schemas.document import DocumentData
from document_issue.document_issue import DocumentIssue

from aecschedule.schedules import RoomDataSchedule
from tests.common_paths import FDIR_TEST_IMAGES, FDIR_TESTDATA, FDIR_TESTOUTPUT

FPTH_SPC_DOCUMENT_DATA = FDIR_TESTDATA / "SPC" / "document-data.json"
FPTH_SPC_DOCUMENT_ISSUE = FDIR_TESTDATA / "SPC" / "document-issue.json"
SPC_DOCUMENT_DATA = DocumentData(json.loads(FPTH_SPC_DOCUMENT_DATA.read_text()))
SPC_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_SPC_DOCUMENT_ISSUE.read_text()))

rds = RoomDataSchedule(
    document_data=SPC_DOCUMENT_DATA,
    document_issue=SPC_DOCUMENT_ISSUE,
    fdir_img=FDIR_TEST_IMAGES,
)
FDIR = FDIR_TESTOUTPUT / "room_schedule"
FDIR.mkdir(exist_ok=True, parents=True)
FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
FPTH_MD.unlink(missing_ok=True)
FPTH_PDF.unlink(missing_ok=True)
rds.to_pdf(FDIR)
print(FPTH_PDF.name, FPTH_PDF.is_file())  # noqa: T201
#> FOTB-MXF-01-XX-RD-ME-30000.pdf True
```

:::

::: {.callout-note collapse="true" icon=false}
## generated markdown file
```markdown
{{< include ../../tests/exampleoutputs/room_schedule/FOTB-MXF-01-XX-RD-ME-30000.md >}}
```
:::

```{=html}
<embed src="../exampleoutputs/room_schedule/FOTB-MXF-01-XX-RD-ME-30000.pdf" width="600px" height="1000px" />
```