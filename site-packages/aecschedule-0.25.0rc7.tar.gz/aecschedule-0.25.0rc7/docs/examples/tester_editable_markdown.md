---
title: "Tester Editable Markdown"
---

::: {.callout-note collapse="true" icon=false}


## code

```py
from document_issue_io.markdown_document_issue import generate_document_issue_pdf

from aecschedule.demo_factories.factories import DocumentIssueFactory
from tests.common_paths import FDIR_TESTOUTPUT

FDIR = FDIR_TESTOUTPUT / "tester_editable_markdown"
FDIR.mkdir(parents=True, exist_ok=True)
fpth_md = FDIR / "06667-MXF-XX-XX-SH-M-20003.md"
fpth_pdf = FDIR / "06667-MXF-XX-XX-SH-M-20003.pdf"
generate_document_issue_pdf(
    document_issue=DocumentIssueFactory.build(),
    fpth_pdf=fpth_pdf,
    md_content=fpth_md.read_text() if fpth_md.exists() else "",
)
print(fpth_pdf.name, fpth_pdf.is_file())  # noqa: T201
#> 06667-MXF-XX-XX-SH-M-20003.pdf True
```

:::

::: {.callout-note collapse="true" icon=false}
## generated markdown file
```markdown
{{< include ../../tests/exampleoutputs/tester_editable_markdown/06667-MXF-XX-XX-SH-M-20003.md >}}
```
:::

```{=html}
<embed src="../exampleoutputs/tester_editable_markdown/06667-MXF-XX-XX-SH-M-20003.pdf" width="600px" height="1000px" />
```