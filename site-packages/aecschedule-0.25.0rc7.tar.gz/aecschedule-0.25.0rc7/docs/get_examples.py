import shutil
from pathlib import Path

def copy_dir(source: Path, dest: Path):
    """Delete contents of dest then copy everything from source."""
    dest.mkdir(parents=True, exist_ok=True)

    # Remove everything inside destination
    for item in dest.iterdir():
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()

    # Copy everything from source to destination
    for item in source.iterdir():
        target = dest / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)


def copy_pdfs_only(source: Path, dest: Path, exclude: str = "title-page.pdf"):
    """Delete contents of dest then copy only PDFs from source, excluding a file name."""
    dest.mkdir(parents=True, exist_ok=True)

    # Remove everything inside destination
    for item in dest.iterdir():
        if item.is_dir():
            shutil.rmtree(item)
        else:
            item.unlink()

    # Walk through source directory tree
    for path in source.rglob("*"):
        if path.is_file() and path.suffix.lower() == ".pdf" and path.name != exclude:
            # Recreate relative folder structure
            rel_path = path.relative_to(source)
            target = dest / rel_path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)


# Paths
root = Path(__file__).resolve().parent.parent
source_examples = root / "tests/examples"
source_exampleoutputs = root / "tests/exampleoutputs"
dest_examples = root / "docs/examples"           # ← updated to docs/examples
dest_exampleoutputs = root / "docs/exampleoutputs"  # ← updated to docs/exampleoutputs

# Sync examples folder completely
copy_dir(source_examples, dest_examples)

# Sync exampleoutputs folder but only PDFs excluding title-page.pdf
copy_pdfs_only(source_exampleoutputs, dest_exampleoutputs, exclude="title-page.pdf")
