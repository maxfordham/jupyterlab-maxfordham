from typing import ClassVar

from document_issue.document import FormatConfiguration
from document_issue.document_issue import DocumentIssue
from document_issue.issue import Issue
from document_issue.role import DocumentRole
from polyfactory.factories.pydantic_factory import ModelFactory


class DocumentIssueFactory(ModelFactory[DocumentIssue]):
    project_name: str = "A Max Fordham Project"
    project_number: str = "J4321"
    name_nomenclature: str = "project-originator-volume-level-type-role-number"
    document_code: str = "06667-MXF-XX-XX-SH-M-20003"
    document_description: str = "A description of a Max Fordham Project"
    document_role: ClassVar[list[DocumentRole]] = [
        DocumentRole(initials="OH", role_name="Director in Charge"),
    ]
    issue_history: ClassVar[list[Issue]] = [
        Issue(
            status_revision="S0 - work in progress - P - Preliminary revision - Initial Status",
            revision_number=1,
        )
    ]
    format_configuration: ClassVar[FormatConfiguration] = FormatConfiguration(date_string_format="%d %^b %y")
    notes: ClassVar[list[str]] = [
        "This is a note",
        "This is another note",
        "This is a very long note which states something important about the document issue",
    ]