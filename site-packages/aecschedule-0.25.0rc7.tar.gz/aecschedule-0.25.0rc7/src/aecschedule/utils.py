import math
import os
import sys
from urllib.parse import urlparse


def validate_fnm(pd_ser):
    """
    removes any characters not allowed in a filename from a column
    and replaces with "_"

    Reference:
        https://stackoverflow.com/questions/1976007/what-characters-are-forbidden-in-windows-and-linux-directory-names
    """
    illegal_fnms_char = ["<", ">", ":", '"', "/", "\\", "|", "?", "*"]
    for char in illegal_fnms_char:
        pd_ser = pd_ser.str.replace(char, "_", regex=True)
    return pd_ser


def get_home():
    """generate the home dir.

    Returns:
        fdir [str]: if windows: os.environ['userprofile'], if linux: os.environ['home']
    """
    if sys.platform == "linux":
        return os.environ["HOME"]
    elif sys.platform == "windows":
        return os.environ["userprofile"]
    else:
        return None


def get_url_domain(url: str):
    """Returns domain of URL."""
    if "https://" not in url and "http://" not in url:
        url = "http://" + url
    _ = urlparse(url)
    return _.netloc


def encode_url_parentheses(url: str):
    """Encodes URL following https://"""
    # url_encode = urllib.parse.quote(url, safe='://?+*=')
    url_encode = url.replace("(", "%28").replace(")", "%29")
    return url_encode


def round_to_significant_figures(num: float, sig_figs: int) -> float:
    if num == 0:
        return 0
    else:
        return round(num, sig_figs - int(math.floor(math.log10(abs(num)))) - 1)
