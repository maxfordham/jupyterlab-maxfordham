import pytest
from aectemplater_schemas.object import ObjectSchema

from aecschedule.modifiers import (
    add_hyper_ref_to_type_mark,
    append_unit_to_value,
    define_url_as_hyperlink,
    merge_dimensions,
    merge_range,
    remove_leading_zero_decimal,
    replace_boolean_with_yes_no,
    replace_names_with_titles,
    replace_tabs_with_spaces,
)


@pytest.fixture
def schema():
    return ObjectSchema(
        **{
            "title": "Test",
            "description": "",
            "type": "object",
            "parameter_type": "T",
            "override_units": True,
            "properties": {
                "Boolean": {
                    "enum": [],
                    "type": "boolean",
                    "revit_data_type": "YESNO",
                    "ifc_data_type": "IfcBoolean",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Boolean",
                    "name": "Boolean",
                    "description": "For testing boolean.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "",
                    "unit_code": "",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": True,
                },
                "URL": {
                    "enum": [],
                    "type": "string",
                    "revit_data_type": "URL",
                    "ifc_data_type": "IfcText",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "URL",
                    "name": "URL",
                    "description": "For testing URL.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "",
                    "unit_code": "",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": "https://www.google.com",
                },
                "FloatWithLeadingZeroDecimal": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "NUMBER",
                    "ifc_data_type": "IfcReal",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Float With Leading Zero Decimal",
                    "name": "FloatWithLeadingZeroDecimal",
                    "description": "For testing float.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "m",
                    "unit_code": "m",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 1.0,
                },
                "OverallHeight": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Overall Height",
                    "name": "OverallHeight",
                    "description": "For testing height.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 1000,
                },
                "OverallWidth": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Overall Width",
                    "name": "OverallWidth",
                    "description": "For testing width.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 500,
                },
                "OverallDepth": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Overall Depth",
                    "name": "OverallDepth",
                    "description": "For testing depth.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 250,
                },
                "SummerTemperatureMin": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "NUMBER",
                    "ifc_data_type": "IfcReal",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Summer Temperature Min",
                    "name": "SummerTemperatureMin",
                    "description": "For testing summer temperature min.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "°C",
                    "unit_code": "°C",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "SummerTemperatureMax": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "NUMBER",
                    "ifc_data_type": "IfcReal",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Summer Temperature Max",
                    "name": "SummerTemperatureMax",
                    "description": "For testing summer temperature max.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "°C",
                    "unit_code": "°C",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "MinWinterTemperature": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "NUMBER",
                    "ifc_data_type": "IfcReal",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Min Winter Temperature",
                    "name": "MinWinterTemperature",
                    "description": "For testing min winter temperature.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "°C",
                    "unit_code": "°C",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "MaxWinterTemperature": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "NUMBER",
                    "ifc_data_type": "IfcReal",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Max Winter Temperature",
                    "name": "MaxWinterTemperature",
                    "description": "For testing max winter temperature.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "°C",
                    "unit_code": "°C",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "Illuminance": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "NUMBER",
                    "ifc_data_type": "IfcReal",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Illuminance",
                    "name": "Illuminance",
                    "description": "For testing illuminance.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "lx",
                    "unit_code": "lx",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "TypeMark": {
                    "enum": [],
                    "type": "string",
                    "revit_data_type": "TEXT",
                    "ifc_data_type": "IfcText",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Type Mark",
                    "name": "TypeMark",
                    "description": "For testing type mark.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "",
                    "unit_code": "",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
            },
        }
    )


@pytest.fixture
def data():
    return {
        "Boolean": True,
        "URL": "https://www.google.com",
        "FloatWithLeadingZeroDecimal": 1.0,
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallDepth": 250,
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "TypeMark": "AT-1",
    }


def test_append_unit_to_value(data, schema):
    expected_data = {
        "Boolean": True,
        "URL": "https://www.google.com",
        "FloatWithLeadingZeroDecimal": "1.0 _m_",
        "OverallHeight": "1000 _mm_",
        "OverallWidth": "500 _mm_",
        "OverallDepth": "250 _mm_",
        "SummerTemperatureMin": "20 _°C_",
        "SummerTemperatureMax": "30 _°C_",
        "TypeMark": "AT-1",
    }
    expected_schema = schema
    assert append_unit_to_value(data, schema) == (expected_data, expected_schema)


def test_replace_boolean_with_yes_no(data, schema):
    expected_data = {
        "Boolean": "Yes",
        "URL": "https://www.google.com",
        "FloatWithLeadingZeroDecimal": 1.0,
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallDepth": 250,
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "TypeMark": "AT-1",
    }
    expected_schema = schema
    assert replace_boolean_with_yes_no(data, schema) == (expected_data, expected_schema)


def test_define_url_as_hyperlink(data, schema):
    expected_data = {
        "Boolean": True,
        "URL": "[www.google.com](https://www.google.com)",
        "FloatWithLeadingZeroDecimal": 1.0,
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallDepth": 250,
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "TypeMark": "AT-1",
    }
    expected_schema = schema
    assert define_url_as_hyperlink(data, schema) == (expected_data, expected_schema)


def test_remove_leading_zero_decimal(data, schema):
    expected_data = {
        "Boolean": True,
        "URL": "https://www.google.com",
        "FloatWithLeadingZeroDecimal": "1",
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallDepth": 250,
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "TypeMark": "AT-1",
    }
    expected_schema = schema
    assert remove_leading_zero_decimal(data, schema) == (expected_data, expected_schema)


def test_merge_dimensions(schema):
    data = {
        "Boolean": True,
        "URL": "https://www.google.com",
        "FloatWithLeadingZeroDecimal": 1.0,
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallDepth": 250,
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "MinWinterTemperature": 10,
        "MaxWinterTemperature": 20,
        "Illuminance": 1000,
        "TypeMark": "AT-1",
    }
    expected_data = {
        "Boolean": True,
        "URL": "https://www.google.com",
        "FloatWithLeadingZeroDecimal": 1.0,
        "OverallDimensions": "H1000 _mm_, W500 _mm_, D250 _mm_",
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "MinWinterTemperature": 10,
        "MaxWinterTemperature": 20,
        "Illuminance": 1000,
        "TypeMark": "AT-1",
    }
    data, schema = merge_dimensions(data, schema)
    keys = list(schema.properties.keys())
    assert data == expected_data
    assert "OverallDimensions" in schema.properties
    expected_order = [
        "Boolean",
        "URL",
        "FloatWithLeadingZeroDecimal",
        "OverallDimensions",
        "OverallHeight",
        "OverallWidth",
        "OverallDepth",
        "SummerTemperatureMin",
        "SummerTemperatureMax",
        "MinWinterTemperature",
        "MaxWinterTemperature",
        "Illuminance",
        "TypeMark",
    ]
    for i, key in enumerate(expected_order):
        if keys.index(key) != i:
            msg = f"Key '{key}' is not in the correct order."
            raise ValueError(msg)


def test_merge_dimensions_hotfix():
    schema = ObjectSchema(
        **{
            "title": "Test",
            "description": "",
            "type": "object",
            "parameter_type": "T",
            "override_units": True,
            "properties": {
                "OverallHeight": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Overall Height",
                    "name": "OverallHeight",
                    "description": "For testing height.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 1000,
                },
                "OverallWidth": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Overall Width",
                    "name": "OverallWidth",
                    "description": "For testing width.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 500,
                },
                "OverallLength": {
                    "enum": [],
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Overall Length",
                    "name": "OverallLength",
                    "description": "For testing depth.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 250,
                },
            },
        }
    )
    data = {
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallLength": 250,
    }
    expected_data = {
        "OverallDimensions": "H1000 _mm_, W500 _mm_, D250 _mm_",
    }
    data, schema = merge_dimensions(data, schema)
    assert data == expected_data
    assert "OverallDimensions" in schema.properties


def test_merge_range_min_max(
    schema,
):
    data = {
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "MaxWinterTemperature": 20,
        "MinWinterTemperature": 10,
        "Illuminance": 1000,
    }
    data, schema = merge_range(data, schema)
    expected_data = {
        "SummerTemperature": "20 - 30",
        "WinterTemperature": "10 - 20",
        "Illuminance": 1000,
    }
    assert data == expected_data
    assert "SummerTemperature" in schema.properties


def test_merge_range_min(schema):
    data = {
        "SummerTemperatureMin": 30,
        "MinWinterTemperature": 10,
        "Illuminance": 1000,
    }
    expected_data = {
        "SummerTemperature": "≥30",
        "WinterTemperature": "≥10",
        "Illuminance": 1000,
    }
    data, schema = merge_range(data, schema)
    assert data == expected_data
    assert "SummerTemperature" in schema.properties


def test_merge_range_max(schema):
    data = {
        "SummerTemperatureMax": 40,
        "MaxWinterTemperature": 20,
        "Illuminance": 1000,
    }
    expected_data = {
        "SummerTemperature": "<40",
        "WinterTemperature": "<20",
        "Illuminance": 1000,
    }
    data, schema = merge_range(data, schema)
    assert data == expected_data
    assert "SummerTemperature" in schema.properties


def test_add_hyper_ref_to_type_mark(data, schema):
    expected_data = {
        "Boolean": True,
        "URL": "https://www.google.com",
        "FloatWithLeadingZeroDecimal": 1.0,
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallDepth": 250,
        "SummerTemperatureMin": 20,
        "SummerTemperatureMax": 30,
        "TypeMark": "\\hyperref[at-1]{AT-1}",
    }
    expected_schema = schema
    assert add_hyper_ref_to_type_mark(data, schema) == (expected_data, expected_schema)


def test_replace_names_with_titles(data, schema):
    expected_data = {
        "Boolean": True,
        "URL": "https://www.google.com",
        "Float With Leading Zero Decimal": 1.0,
        "Overall Height": 1000,
        "Overall Width": 500,
        "Overall Depth": 250,
        "Summer Temperature Min": 20,
        "Summer Temperature Max": 30,
        "Type Mark": "AT-1",
    }
    expected_schema = schema
    assert replace_names_with_titles(data, schema) == (expected_data, expected_schema)


def test_merge_dimensions_bug():
    """Test that merge dimensions modifier works if schema contains both OverallDepth and OverallLength.
    Merge dimensions was failing if schema contained both OverallDepth and OverallLength, and the data contains
    OverallDepth.

    Issue was raised by J7588 - Sevenoaks School, Girls’ International House team."""
    schema = ObjectSchema(
        **{
            "title": "Test",
            "description": "",
            "type": "object",
            "parameter_type": "T",
            "override_units": True,
            "properties": {
                "OverallHeight": {
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "title": "Overall Height",
                    "name": "OverallHeight",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 1000,
                },
                "OverallWidth": {
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "title": "Overall Width",
                    "name": "OverallWidth",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": 500,
                },
                "OverallDepth": {
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "title": "Overall Depth",
                    "name": "OverallDepth",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "OverallLength": {
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "title": "Overall Length",
                    "name": "OverallLength",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "AccessClearanceLeft": {
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "title": "Access Clearance Left",
                    "name": "AccessClearanceLeft",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
                "AccessClearanceRight": {
                    "type": "number",
                    "revit_data_type": "LENGTH",
                    "ifc_data_type": "IfcLengthMeasure",
                    "title": "Access Clearance Right",
                    "name": "AccessClearanceRight",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "unit": "mm",
                    "unit_code": "mm",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                },
            },
        }
    )
    data = {
        "OverallHeight": 1000,
        "OverallWidth": 500,
        "OverallDepth": 250,
        "AccessClearanceLeft": 100,
        "AccessClearanceRight": 200,
    }
    expected_data = {
        "OverallDimensions": "H1000 _mm_, W500 _mm_, D250 _mm_",
        "AccessClearanceLeft": 100,
        "AccessClearanceRight": 200,
    }
    data, schema = merge_dimensions(data, schema)
    assert data == expected_data
    assert "OverallDimensions" in schema.properties


def test_replace_tabs_with_spaces():
    schema = ObjectSchema(
        **{
            "title": "Test",
            "description": "",
            "type": "object",
            "parameter_type": "T",
            "override_units": True,
            "properties": {
                "Notes": {
                    "type": "string",
                    "revit_data_type": "TEXT",
                    "ifc_data_type": "IfcText",
                    "title": "Notes",
                    "name": "Notes",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "unit": "",
                    "unit_code": "",
                    "parameter_type": "T",
                    "pset": "Pset_Test",
                    "default": "Test",
                },
            },
        }
    )
    data = {
        "Notes": "note with tab,	...",
    }
    expected_data = {
        "Notes": "note with tab, ...",
    }
    data, schema = replace_tabs_with_spaces(data, schema)
    assert data == expected_data

def test_update_7081_mark():
    from aecschedule.modifiers import update_7081_mark
    schema = ObjectSchema(
        **{
            "title": "Test",
            "description": "",
            "type": "object",
            "parameter_type": "T",
            "override_units": True,
            "properties": {
                "Mark": {
                    "enum": [],
                    "type": "string",
                    "revit_data_type": "TEXT",
                    "ifc_data_type": "IfcText",
                    "namespace_uri": None,
                    "guid": "",
                    "guid_source": "MXF",
                    "title": "Mark",
                    "name": "Mark",
                    "description": "For testing type mark.",
                    "category": "Specifications",
                    "section": "Identity Data",
                    "tooltip": "",
                    "unit": "",
                    "unit_code": "",
                    "parameter_type": "I",
                },
            },
        }
    )
    # data = {"abbreviation": "AHU", "level": "GF", "level_iref": 1, "volume": "N", "Mark": "AHU-1"}
    data = {
        "Mark": "AHU-9-6_W-1",
        "TypeMark": "AHU-9",
        "TypeSpecId": 2814,
        "InstanceReference": 6,
        "LevelReference": "1",
        "VolumeReference": "W",
        "VolumeLevelInstance": 6,
        "Id": 281
    }
    expected_data, schema = update_7081_mark(data, schema)
    expected_data["Mark"] == "AHU.W.01.01"
