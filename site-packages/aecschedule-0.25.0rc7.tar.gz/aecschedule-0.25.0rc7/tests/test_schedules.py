import copy
import json
import pathlib
from typing import ClassVar

from aectemplater_schemas.document import DocumentData
from aectemplater_schemas.images import PdtImage
from document_issue.document import FormatConfiguration
from document_issue.document_issue import DocumentIssue
from document_issue.issue import Issue
from document_issue.role import DocumentRole
from document_issue_io.markdown_document_issue import generate_document_issue_pdf
from polyfactory.factories.pydantic_factory import ModelFactory

from aecschedule.schedules import PlantRoomSchedule, ProductDataSchedule, RoomDataSchedule

FDIR_TESTS = pathlib.Path(__file__).parent
FDIR_TESTOUTPUT = FDIR_TESTS / "testoutput"
FDIR_TESTDATA = FDIR_TESTS / "testdata"
FDIR_TEST_IMAGES = FDIR_TESTDATA / "images"

FPTH_AT_DOCUMENT_DATA = FDIR_TESTDATA / "AT" / "document-data.json"
FPTH_AT_DOCUMENT_ISSUE = FDIR_TESTDATA / "AT" / "document-issue.json"
AT_DOCUMENT_DATA = DocumentData(json.loads(FPTH_AT_DOCUMENT_DATA.read_text()))
AT_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_AT_DOCUMENT_ISSUE.read_text()))

FPTH_DB_DOCUMENT_DATA = FDIR_TESTDATA / "DB" / "document-data.json"
FPTH_DB_DOCUMENT_ISSUE = FDIR_TESTDATA / "DB" / "document-issue.json"
DB_DOCUMENT_DATA = DocumentData(json.loads(FPTH_DB_DOCUMENT_DATA.read_text()))
DB_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_DB_DOCUMENT_ISSUE.read_text()))

FPTH_SPC_DOCUMENT_DATA = FDIR_TESTDATA / "SPC" / "document-data.json"
FPTH_SPC_DOCUMENT_ISSUE = FDIR_TESTDATA / "SPC" / "document-issue.json"
SPC_DOCUMENT_DATA = DocumentData(json.loads(FPTH_SPC_DOCUMENT_DATA.read_text()))
SPC_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_SPC_DOCUMENT_ISSUE.read_text()))


class DocumentIssueFactory(ModelFactory[DocumentIssue]):
    project_name: str = "A Max Fordham Project"
    project_number: str = "J4321"
    name_nomenclature: str = "project-originator-volume-level-type-role-number"
    document_code: str = "06667-MXF-XX-XX-SH-M-20003"
    document_description: str = "A description of a Max Fordham Project"
    document_role: ClassVar[list[DocumentRole]] = [
        DocumentRole(initials="OH", role_name="Director in Charge"),
    ]
    issue_history: ClassVar[list[Issue]] = [
        Issue(
            status_revision="S0 - work in progress - P - Preliminary revision - Initial Status",
            revision_number=1,
        )
    ]
    format_configuration: ClassVar[FormatConfiguration] = FormatConfiguration(date_string_format="%d %^b %y")
    notes: ClassVar[list[str]] = [
        "This is a note",
        "This is another note",
        "This is a very long note which states something important about the document issue",
    ]


def test_EDITME():
    """Test for custom edits."""
    FDIR = FDIR_TESTOUTPUT / "test_EDITME"
    FDIR.mkdir(parents=True, exist_ok=True)
    fpth_md = FDIR / "06667-MXF-XX-XX-SH-M-20003.md"
    fpth_pdf = FDIR / "06667-MXF-XX-XX-SH-M-20003.pdf"
    generate_document_issue_pdf(
        document_issue=DocumentIssueFactory.build(), fpth_pdf=fpth_pdf, md_content=fpth_md.read_text() if fpth_md.exists() else ""
    )

# tester editable markdown

# product schedules
#  - with instances
#  - without instances
#  - from_dir

# room schedules 

# plantroom schedules



class TestProductDataSchedule:
    def test_md(self): # ignore in pytest examples
        """Test that the markdown is created successfully."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
        )
        md = pds.generate_markdown()
        # Check some type data
        assert "AT-1" in md
        assert "H1000 _mm_, W575 _mm_, D245 _mm_" in md
        assert "www.maxfordham.com" in md
        # Check some instance data
        assert "AT-1-1" in md
        assert "Instances" in md

    def test_md_no_instances(self): # ignore in pytest examples
        """Test that the markdown is created successfully and that `include_instances` works."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
            include_instances=False,
        )
        md = pds.generate_markdown()
        assert "AT-1" in md
        assert "H1000 _mm_, W575 _mm_, D245 _mm_" in md
        assert "www.maxfordham.com" in md
        assert "Instances" not in md

    def test_to_file(self): # ignore in pytest examples
        """Test that a markdown schedule can be written to file."""
        FPTH_MD = FDIR_TESTOUTPUT / "test_to_file.md"
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
        )
        pds.to_file(FPTH_MD)
        assert FPTH_MD.is_file()

    def test_to_pdf(self): # product type schedule
        """Test that a markdown schedule can be written to PDF."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA, document_issue=AT_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        img = PdtImage.from_fpth(FDIR_TEST_IMAGES / "AT-1__0.png")
        img.height = "200px"  # Set height assigned to image in output PDF
        img.write_exif()
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_no_instances(self): # product type schedule no instances
        """Test that a markdown schedule can be written to PDF without instances."""
        pds = ProductDataSchedule(
            document_data=AT_DOCUMENT_DATA,
            document_issue=AT_DOCUMENT_ISSUE,
            fdir_img=FDIR_TEST_IMAGES,
            include_instances=False,
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_no_instances"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        img = PdtImage.from_fpth(FDIR_TEST_IMAGES / "AT-1__0.png")
        img.height = "200px"  # Set height assigned to image in output PDF
        img.write_exif()
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_from_fdir(self): # product type and instance schedule from dir
        """Test that a markdown schedule can be written to PDF from a directory using the `from_fdir` class method."""
        pds = ProductDataSchedule.from_fdir(
            fdir=FDIR_TESTDATA / "AT",
            fdir_img=FDIR_TEST_IMAGES,
            include_instances=True,
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_from_fdir"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        img = PdtImage.from_fpth(FDIR_TEST_IMAGES / "AT-1__0.png")
        img.height = "200px"  # Set height assigned to image in output PDF
        img.write_exif()
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_multiple_types(self): # product type schedule multiple types
        # TODO: ADD INSTANCES
        """Test that a markdown schedule can be written to PDF with multiple types."""
        pds = ProductDataSchedule(
            document_data=DB_DOCUMENT_DATA, document_issue=DB_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_multiple_types"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{pds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{pds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{pds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        pds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_j7081(self):
        """Test that a markdown schedule can be written to PDF with J7081 data."""
        FPTH_J7081_DOCUMENT_DATA = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20001" / "document-data.json"
        FPTH_J7081_DOCUMENT_ISSUE = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20001" / "document-issue.json"
        J7081_DOCUMENT_DATA = DocumentData(json.loads(FPTH_J7081_DOCUMENT_DATA.read_text()))
        J7081_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_J7081_DOCUMENT_ISSUE.read_text()))
        FDIR_TEST_IMAGES = FDIR_TESTDATA / "LTFC-images"
        pds = ProductDataSchedule(
            document_data=J7081_DOCUMENT_DATA, document_issue=J7081_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        fdir = FDIR_TESTOUTPUT / "test_to_pdf_j7081"
        fdir.mkdir(exist_ok=True, parents=True)
        fdir_md = fdir / f"{pds.document_issue.document_code}.md"
        fdir_pdf = fdir / f"{pds.document_issue.document_code}.pdf"
        fdir_log = fdir / f"{pds.document_issue.document_code}.log"
        fdir_md.unlink(missing_ok=True)
        fdir_pdf.unlink(missing_ok=True)
        pds.to_pdf(fdir)
        assert fdir_md.is_file()
        assert fdir_pdf.is_file()
        assert not fdir_log.is_file()
        FPTH_J7081_DOCUMENT_DATA = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20002" / "document-data.json"
        FPTH_J7081_DOCUMENT_ISSUE = FDIR_TESTDATA / "LTFC-MXF-XX-XX-SH-M-20002" / "document-issue.json"
        J7081_DOCUMENT_DATA = DocumentData(json.loads(FPTH_J7081_DOCUMENT_DATA.read_text()))
        J7081_DOCUMENT_ISSUE = DocumentIssue(**json.loads(FPTH_J7081_DOCUMENT_ISSUE.read_text()))
        pds = ProductDataSchedule(
            document_data=J7081_DOCUMENT_DATA, document_issue=J7081_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        fdir = FDIR_TESTOUTPUT / "test_to_pdf_j7081"
        fdir.mkdir(exist_ok=True, parents=True)
        fdir_md = fdir / f"{pds.document_issue.document_code}.md"
        fdir_pdf = fdir / f"{pds.document_issue.document_code}.pdf"
        fdir_log = fdir / f"{pds.document_issue.document_code}.log"
        fdir_md.unlink(missing_ok=True)
        fdir_pdf.unlink(missing_ok=True)
        pds.to_pdf(fdir)
        assert fdir_md.is_file()
        assert fdir_pdf.is_file()
        assert not fdir_log.is_file()

    def test_to_pdf_j7763(self):
        fpth_data = FDIR_TESTDATA / "J7763" / "CPNSC-MXF-B1-XX-S-M-200000" / "document-data.json"
        fpth_issue = FDIR_TESTDATA / "J7763" / "CPNSC-MXF-B1-XX-S-M-200000" / "document-issue.json"
        data = DocumentData(json.loads(fpth_data.read_text()))
        docissue = DocumentIssue(**json.loads(fpth_issue.read_text()))
        fdir_images = FDIR_TESTDATA / "LTFC-images"
        pds = ProductDataSchedule(
            document_data=data, document_issue=docissue, fdir_img=FDIR_TEST_IMAGES
        )
        fdir = FDIR_TESTOUTPUT / "test_to_pdf_j7763"
        fdir.mkdir(exist_ok=True, parents=True)
        fdir_md = fdir / f"{pds.document_issue.document_code}.md"
        fdir_pdf = fdir / f"{pds.document_issue.document_code}.pdf"
        fdir_log = fdir / f"{pds.document_issue.document_code}.log"
        fdir_md.unlink(missing_ok=True)
        fdir_pdf.unlink(missing_ok=True)
        pds.to_pdf(fdir)
        assert fdir_md.is_file()
        assert fdir_pdf.is_file()
        assert not fdir_log.is_file()



        fpth_data = FDIR_TESTDATA / "J7763" / "CPNSC-MXF-B1-XX-S-M-200010" / "document-data.json"
        fpth_issue = FDIR_TESTDATA / "J7763" / "CPNSC-MXF-B1-XX-S-M-200010" / "document-issue.json"
        data = DocumentData(json.loads(fpth_data.read_text()))
        docissue = DocumentIssue(**json.loads(fpth_issue.read_text()))
        pds = ProductDataSchedule(
            document_data=data, document_issue=docissue, fdir_img=fdir_images
        )
        fdir = FDIR_TESTOUTPUT / "test_to_pdf_j7763"
        fdir.mkdir(exist_ok=True, parents=True)
        fdir_md = fdir / f"{pds.document_issue.document_code}.md"
        fdir_pdf = fdir / f"{pds.document_issue.document_code}.pdf"
        fdir_log = fdir / f"{pds.document_issue.document_code}.log"
        fdir_md.unlink(missing_ok=True)
        fdir_pdf.unlink(missing_ok=True)
        pds.to_pdf(fdir)
        assert fdir_md.is_file()
        assert fdir_pdf.is_file()
        assert not fdir_log.is_file()

class TestRoomDataSchedule:
    def test_to_pdf_room_data_sheet(self):
        """Test that a room data sheet can be written to PDF."""
        rds = RoomDataSchedule(
            document_data=SPC_DOCUMENT_DATA, document_issue=SPC_DOCUMENT_ISSUE, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheet"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        rds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful

    def test_to_pdf_room_data_sheet_empty_values(self):
        """Test that a room data sheet can be written to PDF with the J7516 space data."""
        fpth_spc_document_data = FDIR_TESTDATA / "SPC-EMPTY" / "document-data.json"
        fpth_spc_document_issue = FDIR_TESTDATA / "SPC-EMPTY" / "document-issue.json"
        spc_document_data = DocumentData(json.loads(fpth_spc_document_data.read_text()))
        spc_document_issue = DocumentIssue(**json.loads(fpth_spc_document_issue.read_text()))
        rds = RoomDataSchedule(
            document_data=spc_document_data, document_issue=spc_document_issue, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheet_empty"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{rds.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{rds.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{rds.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        rds.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful


class TestPlantRoomSchedule:
    def test_to_pdf_plant_room(self):
        """Test that a plant room schedule can be written to PDF with the engineering standard data."""
        fpth_plant_room_document_data = FDIR_TESTDATA / "PLANTROOM" / "document-data.json"
        fpth_plant_room_document_issue = FDIR_TESTDATA / "PLANTROOM" / "document-issue.json"
        plant_room_document_data = DocumentData(json.loads(fpth_plant_room_document_data.read_text()))
        plant_room_document_issue = DocumentIssue(**json.loads(fpth_plant_room_document_issue.read_text()))
        prs = PlantRoomSchedule(
            document_data=plant_room_document_data, document_issue=plant_room_document_issue, fdir_img=FDIR_TEST_IMAGES
        )
        FDIR = FDIR_TESTOUTPUT / "test_to_pdf_plant_room"
        FDIR.mkdir(exist_ok=True, parents=True)
        FPTH_MD = FDIR / f"{prs.document_issue.document_code}.md"
        FPTH_PDF = FDIR / f"{prs.document_issue.document_code}.pdf"
        FPTH_LOG = FDIR / f"{prs.document_issue.document_code}.log"
        FPTH_MD.unlink(missing_ok=True)
        FPTH_PDF.unlink(missing_ok=True)
        prs.to_pdf(FDIR)
        assert FPTH_MD.is_file()
        assert FPTH_PDF.is_file()
        assert not FPTH_LOG.is_file()  # log file should be deleted if Quarto PDF compilation is successful



def test_J7516_space_schedules():
    """Test that a plant room schedule can be written to PDF with the engineering standard data."""
    # NOTE: the `space-data.json` file must be updated from Revit.
    #       the `get_filters.py` and `filter_data.py` scripts must be re-executed
    #       the `document-issue.json` data must be copied over from the server (TODO: retrieve with script)
    fdir = FDIR_TESTDATA / "J7516"
    fdirs = [x for x in list(fdir.glob("*")) if x.is_dir()]
    f = fdirs[0]
    for f in fdirs:
        f_data, f_issue = f / "document-data.json", f / "document-issue.json"
        document_data = DocumentData(json.loads(f_data.read_text()))
        document_issue = DocumentIssue(**json.loads(f_issue.read_text()))
        rds = RoomDataSchedule(
            document_data=document_data, document_issue=document_issue
        )

        fdir = FDIR_TESTOUTPUT / "test_to_pdf_room_data_sheet_J7516" / f.name
        fdir.mkdir(exist_ok=True, parents=True)
        fpth_md = fdir / f"{rds.document_issue.document_code}.md"
        fpth_pdf = fdir / f"{rds.document_issue.document_code}.pdf"
        fpth_log = fdir / f"{rds.document_issue.document_code}.log"
        fpth_md.unlink(missing_ok=True)
        fpth_pdf.unlink(missing_ok=True)
        rds.to_pdf(fdir)
        assert fpth_md.is_file()
        assert fpth_pdf.is_file()
        assert not fpth_log.is_file()  # log file should be deleted if Quarto PDF compilation is successful