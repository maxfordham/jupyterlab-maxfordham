import os
import json
import pathlib

AECTEMPLATER_CNAME = "https://aectemplater.maxfordham.com"
PROJECT_NUMBER = 7516

os.environ["AECTEMPLATER_CNAME"] = AECTEMPLATER_CNAME

from aectemplater_client import get_object_schema, get_object_gridschema
from pyrulefilter.filters import Rule, RuleSet, ruleset_check_dicts

SPC_TEMPLATE_ID = 836
schema = get_object_schema(SPC_TEMPLATE_ID)
grid_schema = get_object_gridschema(SPC_TEMPLATE_ID, parameter_type="I", overide_units=True)
fpth = pathlib.Path(__file__).parent / "space-filters.json"

fdirs = [x for x in list(pathlib.Path(__file__).parent.glob("*")) if x.is_dir()]
map_fdirs = {x.name.split("-")[3]: x for x in fdirs}
filters = json.loads(fpth.read_text())
space_data = json.loads((pathlib.Path(__file__).parent / "space-data.json").read_text())

# DM edits: remove "Cooling Dry Bulb" in cupboards
get_names = ["FOTB-00-039", "FOTB-00-042", "FOTB-00-043"]
indexes = [n for n, d in enumerate(space_data) if d.get("Number") in get_names]
for n in indexes:
    space_data[n]["CoolingDryBulb"] = None


# f = filters[0]
for f in filters:
    level = f["name"].split(" ")[1].zfill(2)
    rule_set = RuleSet.model_validate(f["rule_set"])
    mask = ruleset_check_dicts(space_data, rule_set)
    filtered = [d for d, m in zip(space_data, mask) if m]
    fdir = map_fdirs[level]
    outf = fdir / "document-data.json"
    document_data = [{"$schema": grid_schema, "data": filtered}]
    outf.write_text(json.dumps(document_data, indent=2))
    print(f"Level={level} Filtered {len(filtered)} from {len(space_data)}")
# for f in filters:
#     rs = RuleSet.model_validate(f)
#     for r in rs.rules:
#         assert isinstance(r, Rule)

print("done")