# aectemplater-client

This package is a client used for querying the `aectemplater` API.

This client is generated into pure Python and does not depend on any other packages
Thus it can be used in any python environment (py27 -> py311). (e.g. pyRevit).

Unfortunately, this means it must avoid type-hinting as this is not supported in Python 3.4.

TODO: Add more to README.md