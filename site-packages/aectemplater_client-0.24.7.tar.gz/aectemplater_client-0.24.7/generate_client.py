import re
import os
import glob
import shutil
import requests
import stringcase
import subprocess
import pathlib

# JSON object representing the endpoints
response = requests.get('http://127.0.0.1:8000/endpoints')
endpoints = response.json()

# Base directory for the modules
FDIR_MODULES = pathlib.Path(__file__).parent / "src" / "aectemplater_client"


def remove_files():
    """Remove all generated calls except utils.py."""
    # List all files in the directory
    files = glob.glob(str(FDIR_MODULES / '*'))

    # Delete each file that is not 'utils.py'
    for file in files:
        if os.path.basename(file) != 'utils.py':
            if os.path.isfile(file):
                os.remove(file)
            elif os.path.isdir(file):
                shutil.rmtree(file)


# TODO: Check that the function names are unique
def generate_client():
    """Generate the client based on the endpoints."""
    remove_files()
    for endpoint in endpoints:
        fpth_module = FDIR_MODULES / ((stringcase.snakecase(endpoint['tag'].lower()).replace(" ", "")) + ".py")

        # Extract parameters from the path
        params = re.findall(r'\{(\w+)\}', endpoint['path'])
        params_str = ', '.join(params)

        # Check if params_str exists
        func_args = ""
        if params_str:
            func_args = f"{params_str}"
            func_args += ", value=None, **kwargs"
        else:
            func_args += "value=None, **kwargs"
        request_line = f"response = requests.{endpoint['method'].lower()}(url, json=value, params=kwargs)"
        # Create a function for each endpoint
        if params:
            url = f"AECTEMPLATER_CNAME + '{endpoint['path']}'.format({', '.join([f'{p}={p}' for p in params])})"
        else:
            url = f"AECTEMPLATER_CNAME + '{endpoint['path']}'"
        code = f"""
def {endpoint['name']}({func_args}):
    \"\"\"{endpoint['summary']}\"\"\"
    url = {url}
    {request_line}
    return response_check(response)
    
"""
        # Write the function to a Python file in the corresponding directory
        if fpth_module.exists():
            with open(fpth_module, 'a') as f:
                f.write(code)
                f.write("\n\n")
        else:
            with open(fpth_module, 'w') as f:
                f.write("import requests\n")
                f.write(f"from {FDIR_MODULES.stem}.utils import AECTEMPLATER_CNAME, response_check\n\n")
                f.write(code)
                f.write("\n\n")

    # Generate __init__.py
    unique_tags = set(endpoint['tag'] for endpoint in endpoints)
    with open(FDIR_MODULES / '__init__.py', 'w') as f:
        for tag in sorted(unique_tags):
            f.write(f"from {FDIR_MODULES.stem}.{stringcase.snakecase(tag.lower()).replace(' ', '')} import *\n")
    # Run black formatter
    subprocess.run(["black", FDIR_MODULES])


if __name__ == "__main__":
    generate_client()
