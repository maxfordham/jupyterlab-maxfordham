import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_document_project_filter(document_id, project_filter_id, value=None, **kwargs):
    """Get a Document Project Filter."""
    url = AECTEMPLATER_CNAME + '/document_project_filter/{document_id}/{project_filter_id}'.format(
        document_id=document_id, project_filter_id=project_filter_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_document_project_filter(document_id, project_filter_id, value=None, **kwargs):
    """Post a Document Project Filter."""
    url = AECTEMPLATER_CNAME + '/document_project_filter/{document_id}/{project_filter_id}'.format(
        document_id=document_id, project_filter_id=project_filter_id
    )
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def delete_document_project_filter(document_id, project_filter_id, value=None, **kwargs):
    """Delete a Document Project Filter."""
    url = AECTEMPLATER_CNAME + '/document_project_filter/{document_id}/{project_filter_id}'.format(
        document_id=document_id, project_filter_id=project_filter_id
    )
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)
