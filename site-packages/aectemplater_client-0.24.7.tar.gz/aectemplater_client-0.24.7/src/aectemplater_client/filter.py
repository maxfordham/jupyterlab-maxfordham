import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def post_filter(value=None, **kwargs):
    """Post a Filter. NOTE: Will be associated with the default project too."""
    url = AECTEMPLATER_CNAME + '/filter'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_filters(value=None, **kwargs):
    """Get all Filters."""
    url = AECTEMPLATER_CNAME + '/filters'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_filter_by_id(filter_id, value=None, **kwargs):
    """Get a Filter by its ID."""
    url = AECTEMPLATER_CNAME + '/filter/{filter_id}'.format(filter_id=filter_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_filter(filter_id, value=None, **kwargs):
    """Delete a Filter by its ID."""
    url = AECTEMPLATER_CNAME + '/filter/{filter_id}'.format(filter_id=filter_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_filter(filter_id, value=None, **kwargs):
    """Patch a Filter by its ID."""
    url = AECTEMPLATER_CNAME + '/filter/{filter_id}'.format(filter_id=filter_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
