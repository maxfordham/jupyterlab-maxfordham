import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def post_instance_spec(value=None, **kwargs):
    """Post an Instance Specification."""
    url = AECTEMPLATER_CNAME + '/instance_spec'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_specs(value=None, **kwargs):
    """Get all Instance Specifications."""
    url = AECTEMPLATER_CNAME + '/instance_specs'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_spec_by_id(instance_spec_id, value=None, **kwargs):
    """Get an Instance Specification by its ID."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}'.format(instance_spec_id=instance_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_spec_metadata_by_id(instance_spec_id, value=None, **kwargs):
    """Get the metadata of an Instance Specification."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}/metadata'.format(instance_spec_id=instance_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_tag_data(instance_spec_id, value=None, **kwargs):
    """Get Instance Tag Data for an Instance Specification."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}/tag_data'.format(instance_spec_id=instance_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_spec_mark(instance_spec_id, value=None, **kwargs):
    """Get the mark for an Instance Specification."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}/mark'.format(instance_spec_id=instance_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_specs_marks(value=None, **kwargs):
    """Get a list of mark for a passed list of Instance Specifications."""
    url = AECTEMPLATER_CNAME + '/instance_specs/marks'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_specs_marks_from_type_spec(type_spec_id, value=None, **kwargs):
    """Get the Instance Specification marks for a Type Specification."""
    url = AECTEMPLATER_CNAME + '/instance_specs/type_spec/{type_spec_id}/marks'.format(type_spec_id=type_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_instance_spec(instance_spec_id, value=None, **kwargs):
    """Delete an Instance Specification by its ID."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}'.format(instance_spec_id=instance_spec_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_instance_spec(instance_spec_id, value=None, **kwargs):
    """Patch an Instance Specification by its ID."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}'.format(instance_spec_id=instance_spec_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_spec_object_data(instance_spec_id, value=None, **kwargs):
    """Get the data of a specific Instance Specification object, with an option to use override units."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}/data'.format(instance_spec_id=instance_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_specs_object_data_grid(project_revision_id, object_id, value=None, **kwargs):
    """Get all Instance Specifications for an Object within a Project Revision, with an option to use override units."""
    url = AECTEMPLATER_CNAME + '/instance_specs/project_revision/{project_revision_id}/object/{object_id}/grid'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_instance_spec_data(type_spec_id, value=None, **kwargs):
    """Post data to a Instance Specification object."""
    url = AECTEMPLATER_CNAME + '/instance_spec/type_spec/{type_spec_id}/data'.format(type_spec_id=type_spec_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def patch_instance_spec_data(instance_spec_id, value=None, **kwargs):
    """Patch Instance Specification data."""
    url = AECTEMPLATER_CNAME + '/instance_spec/{instance_spec_id}/data'.format(instance_spec_id=instance_spec_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
