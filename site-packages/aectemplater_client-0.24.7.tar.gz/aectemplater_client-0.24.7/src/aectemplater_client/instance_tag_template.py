import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_instance_tag_templates(value=None, **kwargs):
    """Get all Instance Tag Templates."""
    url = AECTEMPLATER_CNAME + '/instance_tag_templates'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_instance_tag_template(value=None, **kwargs):
    """Post an Instance Tag Template."""
    url = AECTEMPLATER_CNAME + '/instance_tag_template'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_tag_template_by_id(instance_tag_template_id, value=None, **kwargs):
    """Get an Instance Tag Template by its ID."""
    url = AECTEMPLATER_CNAME + '/instance_tag_template/{instance_tag_template_id}'.format(
        instance_tag_template_id=instance_tag_template_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_instance_tag_template_by_id(instance_tag_template_id, value=None, **kwargs):
    """Delete an Instance Tag Template by its ID."""
    url = AECTEMPLATER_CNAME + '/instance_tag_template/{instance_tag_template_id}'.format(
        instance_tag_template_id=instance_tag_template_id
    )
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_instance_tag_template_by_id(instance_tag_template_id, value=None, **kwargs):
    """Patch an Instance Tag Template by its ID."""
    url = AECTEMPLATER_CNAME + '/instance_tag_template/{instance_tag_template_id}'.format(
        instance_tag_template_id=instance_tag_template_id
    )
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
