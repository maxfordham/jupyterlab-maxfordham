import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_objects(value=None, **kwargs):
    """Get all Objects."""
    url = AECTEMPLATER_CNAME + '/objects'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_by_id(object_id, value=None, **kwargs):
    """Get an Object by its ID."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_by_code(code, value=None, **kwargs):
    """Get an Object by its code."""
    url = AECTEMPLATER_CNAME + '/object/code/{code}'.format(code=code)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_object(value=None, **kwargs):
    """Post an Object."""
    url = AECTEMPLATER_CNAME + '/object'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def delete_object_by_id(object_id, value=None, **kwargs):
    """Delete an Object by its ID."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}'.format(object_id=object_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_object_by_id(object_id, value=None, **kwargs):
    """Patch an Object by its ID."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}'.format(object_id=object_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def duplicate_object_by_id(object_id, value=None, **kwargs):
    """Duplicate an Object and its associated Property Sets."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}/duplicate'.format(object_id=object_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_object_unique_name(object_id, value=None, **kwargs):
    """Get the unique name of an Object by its ID."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}/unique_name'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_objects_unique_names(value=None, **kwargs):
    """Get all unique names of Objects. Able to filter by custodian and specify if an abbreviation is assigned."""
    url = AECTEMPLATER_CNAME + '/objects/unique_names'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_objects_names(value=None, **kwargs):
    """Get all unique names of Objects. Able to filter by custodian and specify if an abbreviation is assigned."""
    url = AECTEMPLATER_CNAME + '/objects/names'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_objects_by_custodian(custodian, value=None, **kwargs):
    """Get all Objects for a custodian."""
    url = AECTEMPLATER_CNAME + '/objects/custodian/{custodian}'.format(custodian=custodian)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_schema(object_id, value=None, **kwargs):
    """Get the schema of a specific object. The schema can be filtered based on whether the properties are of 'type' or 'instance', with an option to use override units."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}/schema'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_schema_preview(object_id, value=None, **kwargs):
    """Get the schema preview of a specific object."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}/schema/preview'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_gridschema(object_id, value=None, **kwargs):
    """Get the grid schema of a specific object. The schema can be filtered based on whether the properties are of 'type' or 'instance', with an option to use override units."""
    url = AECTEMPLATER_CNAME + '/object/{object_id}/gridschema'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_property_override(object_id, property_id, value=None, **kwargs):
    """Get the override values for a Property within an Object."""
    url = AECTEMPLATER_CNAME + '/object_property_override/{object_id}/{property_id}'.format(
        object_id=object_id, property_id=property_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_object_property_override(object_id, property_id, value=None, **kwargs):
    """Post override values for a Property within an Object."""
    url = AECTEMPLATER_CNAME + '/object_property_override/{object_id}/{property_id}'.format(
        object_id=object_id, property_id=property_id
    )
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def patch_object_property_override(object_id, property_id, value=None, **kwargs):
    """Patch override values for a Property within an Object."""
    url = AECTEMPLATER_CNAME + '/object_property_override/{object_id}/{property_id}'.format(
        object_id=object_id, property_id=property_id
    )
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def delete_object_property_override(object_id, property_id, value=None, **kwargs):
    """Delete the override values for a Property within an Object."""
    url = AECTEMPLATER_CNAME + '/object_property_override/{object_id}/{property_id}'.format(
        object_id=object_id, property_id=property_id
    )
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def post_and_patch_object_order(object_id, value=None, **kwargs):
    """Define the order of properties in an Object."""
    url = AECTEMPLATER_CNAME + '/object_order/{object_id}'.format(object_id=object_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)
