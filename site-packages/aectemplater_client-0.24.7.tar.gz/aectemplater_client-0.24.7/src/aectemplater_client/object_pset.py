import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_object_psets(value=None, **kwargs):
    """Get all Object Psets."""
    url = AECTEMPLATER_CNAME + '/object_psets'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_pset(object_id, pset_id, value=None, **kwargs):
    """Get an Object Pset."""
    url = AECTEMPLATER_CNAME + '/object_pset/{object_id}/{pset_id}'.format(object_id=object_id, pset_id=pset_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_object_pset(object_id, pset_id, value=None, **kwargs):
    """Post an Object Pset."""
    url = AECTEMPLATER_CNAME + '/object_pset/{object_id}/{pset_id}'.format(object_id=object_id, pset_id=pset_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def delete_object_pset(object_id, pset_id, value=None, **kwargs):
    """Delete an Object Pset."""
    url = AECTEMPLATER_CNAME + '/object_pset/{object_id}/{pset_id}'.format(object_id=object_id, pset_id=pset_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def get_psets_by_object(object_id, value=None, **kwargs):
    """Get Property Sets associated with an Object."""
    url = AECTEMPLATER_CNAME + '/object_psets/object/{object_id}'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_psets_to_object(object_id, value=None, **kwargs):
    """Associate Property Sets to an Object."""
    url = AECTEMPLATER_CNAME + '/object_psets/object/{object_id}'.format(object_id=object_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def delete_psets_from_object(object_id, value=None, **kwargs):
    """Remove Property Sets from an Object."""
    url = AECTEMPLATER_CNAME + '/object_psets/object/{object_id}'.format(object_id=object_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)
