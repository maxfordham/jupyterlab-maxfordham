import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def post_project(value=None, **kwargs):
    """Post a Project."""
    url = AECTEMPLATER_CNAME + '/project'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_projects(value=None, **kwargs):
    """Get all Projects."""
    url = AECTEMPLATER_CNAME + '/projects'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_by_id(project_id, value=None, **kwargs):
    """Get a Project by its ID."""
    url = AECTEMPLATER_CNAME + '/project/{project_id}'.format(project_id=project_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_project(project_id, value=None, **kwargs):
    """Delete a Project by its ID."""
    url = AECTEMPLATER_CNAME + '/project/{project_id}'.format(project_id=project_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_project(project_id, value=None, **kwargs):
    """Patch a Project."""
    url = AECTEMPLATER_CNAME + '/project/{project_id}'.format(project_id=project_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def get_project_by_project_number(project_number, value=None, **kwargs):
    """Get a Project by its project number."""
    url = AECTEMPLATER_CNAME + '/project/project_number/{project_number}'.format(project_number=project_number)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
