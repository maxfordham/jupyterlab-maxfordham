import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_project_filter(project_filter_id, value=None, **kwargs):
    """Get a Project Filter."""
    url = AECTEMPLATER_CNAME + '/project_filter/{project_filter_id}'.format(project_filter_id=project_filter_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_filter_by_project_revision_and_filter(project_revision_id, filter_id, value=None, **kwargs):
    """Get a Project Filter by Project Revision and Filter."""
    url = AECTEMPLATER_CNAME + '/project_filter/project_revision/{project_revision_id}/filter/{filter_id}'.format(
        project_revision_id=project_revision_id, filter_id=filter_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def patch_project_filter(project_filter_id, value=None, **kwargs):
    """Patch a Project Filter."""
    url = AECTEMPLATER_CNAME + '/project_filter/{project_filter_id}'.format(project_filter_id=project_filter_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def post_project_filter(value=None, **kwargs):
    """Post a Project Filter."""
    url = AECTEMPLATER_CNAME + '/project_filter'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def delete_project_filter(project_filter_id, value=None, **kwargs):
    """Delete a Project Filter."""
    url = AECTEMPLATER_CNAME + '/project_filter/{project_filter_id}'.format(project_filter_id=project_filter_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def get_project_filters_by_project_revision(project_revision_id, value=None, **kwargs):
    """Get Project Filters by Project Revision."""
    url = AECTEMPLATER_CNAME + '/project_filters/project_revision/{project_revision_id}'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_filter_names_by_project_revision(project_revision_id, value=None, **kwargs):
    """Get Project Filter names by Project Revision."""
    url = AECTEMPLATER_CNAME + '/project_filters/project_revision/{project_revision_id}/names'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_specs_from_project_filter(project_filter_id, value=None, **kwargs):
    """Get Specifications from a Project Filter."""
    url = AECTEMPLATER_CNAME + '/project_filter/{project_filter_id}/specs'.format(project_filter_id=project_filter_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_spec_tags_from_project_filter(project_filter_id, value=None, **kwargs):
    """Get type or instance tags from a Project Filter."""
    url = AECTEMPLATER_CNAME + '/project_filter/{project_filter_id}/tags'.format(project_filter_id=project_filter_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
