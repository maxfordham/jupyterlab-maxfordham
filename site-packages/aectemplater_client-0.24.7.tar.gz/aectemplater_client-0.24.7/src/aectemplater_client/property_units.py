import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_property_unit(property_id, unit_id, value=None, **kwargs):
    """Get a Property Unit."""
    url = AECTEMPLATER_CNAME + '/property_unit/{property_id}/{unit_id}'.format(property_id=property_id, unit_id=unit_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_property_unit(property_id, unit_id, value=None, **kwargs):
    """Post a Property Unit."""
    url = AECTEMPLATER_CNAME + '/property_unit/{property_id}/{unit_id}'.format(property_id=property_id, unit_id=unit_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def patch_property_unit(property_id, unit_id, value=None, **kwargs):
    """Patch a Property Unit."""
    url = AECTEMPLATER_CNAME + '/property_unit/{property_id}/{unit_id}'.format(property_id=property_id, unit_id=unit_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
