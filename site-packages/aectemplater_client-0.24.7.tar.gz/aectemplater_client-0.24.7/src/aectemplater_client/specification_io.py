import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def post_spec_data_from_xlsx(value=None, **kwargs):
    """Patch Type Specification data from an XLSX file."""
    url = AECTEMPLATER_CNAME + '/xlsx'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_spec_object_data_xlsx(project_revision_id, object_id, value=None, **kwargs):
    """Get Type Specification data to an XLSX file."""
    url = AECTEMPLATER_CNAME + '/xlsx/project_revision/{project_revision_id}/object/{object_id}'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
