import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_spec_tags_not_selected(project_revision_id, value=None, **kwargs):
    """Get tags that are not selected by documents in a project."""
    url = AECTEMPLATER_CNAME + '/documents/project_revision/{project_revision_id}/tags/not_selected'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_type_spec(value=None, **kwargs):
    """Post a Type Specification."""
    url = AECTEMPLATER_CNAME + '/type_spec'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs(value=None, **kwargs):
    """Get all Type Specifications."""
    url = AECTEMPLATER_CNAME + '/type_specs'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_by_id(type_spec_id, value=None, **kwargs):
    """Get a Type Specification by its ID."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}'.format(type_spec_id=type_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_metadata_by_id(type_spec_id, value=None, **kwargs):
    """Get the metadata of a Type Specification."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}/metadata'.format(type_spec_id=type_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_type_spec(type_spec_id, value=None, **kwargs):
    """Delete a Type Specification by its ID."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}'.format(type_spec_id=type_spec_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_type_spec(type_spec_id, value=None, **kwargs):
    """Patch a Type Specification."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}'.format(type_spec_id=type_spec_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs_by_project_revision(project_revision_id, value=None, **kwargs):
    """Get Type Specifications for a Project Revision."""
    url = AECTEMPLATER_CNAME + '/type_specs/project_revision/{project_revision_id}'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_metadata_by_project_revision(project_revision_id, value=None, **kwargs):
    """Get metadata of Type Specifications for a Project Revision."""
    url = AECTEMPLATER_CNAME + '/type_specs/project_revision/{project_revision_id}/metadata'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs_by_project_revision_and_object_id(project_revision_id, object_id, value=None, **kwargs):
    """Get Type Specifications by Project Revision and Object ID."""
    url = AECTEMPLATER_CNAME + '/type_specs/project_revision/{project_revision_id}/object/{object_id}'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_ids_by_project_revision_and_object_id(project_revision_id, object_id, value=None, **kwargs):
    """Get Type Specifications' IDs by Project Revision and Object ID."""
    url = AECTEMPLATER_CNAME + '/type_specs/project_revision/{project_revision_id}/object/{object_id}/ids'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_tag_data(type_spec_id, value=None, **kwargs):
    """Get Type Tag Data for a Type Specification."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}/tag_data'.format(type_spec_id=type_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_type_mark(type_spec_id, value=None, **kwargs):
    """Get the type mark for a Type Specification."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}/type_mark'.format(type_spec_id=type_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs_type_marks(value=None, **kwargs):
    """Get a list of type marks for a passed list of Type Specifications."""
    url = AECTEMPLATER_CNAME + '/type_specs/type_marks'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_id_by_type_mark(project_revision_id, object_id, type_mark, value=None, **kwargs):
    """Get the Type Specification ID by project revision, object, and type mark."""
    url = (
        AECTEMPLATER_CNAME
        + '/type_spec/project_revision/{project_revision_id}/object/{object_id}/type_mark/{type_mark}/id'.format(
            project_revision_id=project_revision_id, object_id=object_id, type_mark=type_mark
        )
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_image_prefix(type_spec_id, value=None, **kwargs):
    """Get the image prefix for a Type Specification."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}/image_prefix'.format(type_spec_id=type_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_type_marks(project_revision_id, object_id, value=None, **kwargs):
    """Get the type marks for a Project Revision and Object ID."""
    url = (
        AECTEMPLATER_CNAME
        + '/type_specs/project_revision/{project_revision_id}/object/{object_id}/type_marks'.format(
            project_revision_id=project_revision_id, object_id=object_id
        )
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_object_data_grid(project_revision_id, object_id, value=None, **kwargs):
    """Get all Type Specifications for an Object within a Project Revision, with an option to use override units."""
    url = AECTEMPLATER_CNAME + '/type_specs/project_revision/{project_revision_id}/object/{object_id}/grid'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_object_data(type_spec_id, value=None, **kwargs):
    """Get the data of a specific Type Specification object, with an option to use override units."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}/data'.format(type_spec_id=type_spec_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_type_spec_data(project_revision_id, object_id, value=None, **kwargs):
    """Post data to a Type Specification object."""
    url = AECTEMPLATER_CNAME + '/type_spec/project_revision/{project_revision_id}/object/{object_id}/data'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def patch_type_spec_data(type_spec_id, value=None, **kwargs):
    """Patch Type Specification data."""
    url = AECTEMPLATER_CNAME + '/type_spec/{type_spec_id}/data'.format(type_spec_id=type_spec_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
