import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_units(value=None, **kwargs):
    """Get all Units."""
    url = AECTEMPLATER_CNAME + '/units'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_unit(unit_id, value=None, **kwargs):
    """Get a Unit by its ID."""
    url = AECTEMPLATER_CNAME + '/unit/{unit_id}'.format(unit_id=unit_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_units_by_physical_quantity(physical_quantity, value=None, **kwargs):
    """Get Units by physical quantity."""
    url = AECTEMPLATER_CNAME + '/unit/physical_quantity/{physical_quantity}'.format(physical_quantity=physical_quantity)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_unit(value=None, **kwargs):
    """Post a Unit."""
    url = AECTEMPLATER_CNAME + '/unit'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def patch_unit(unit_id, value=None, **kwargs):
    """Patch a Unit by its ID."""
    url = AECTEMPLATER_CNAME + '/unit/{unit_id}'.format(unit_id=unit_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def delete_unit(unit_id, value=None, **kwargs):
    """Delete a Unit by its ID."""
    url = AECTEMPLATER_CNAME + '/unit/{unit_id}'.format(unit_id=unit_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)
