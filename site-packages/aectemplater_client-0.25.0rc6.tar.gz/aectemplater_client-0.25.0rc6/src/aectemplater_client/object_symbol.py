import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_object_symbols(value=None, **kwargs):
    """Get all Object Symbols."""
    url = AECTEMPLATER_CNAME + '/object_symbols'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_object_symbol(object_id, symbol_id, value=None, **kwargs):
    """Post an Object Symbol."""
    url = AECTEMPLATER_CNAME + '/object_symbol/{object_id}/{symbol_id}'.format(object_id=object_id, symbol_id=symbol_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_object_symbol(object_id, symbol_id, value=None, **kwargs):
    """Get an Object Symbol."""
    url = AECTEMPLATER_CNAME + '/object_symbol/{object_id}/{symbol_id}'.format(object_id=object_id, symbol_id=symbol_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_object_symbol(object_id, symbol_id, value=None, **kwargs):
    """Delete an Object Symbol."""
    url = AECTEMPLATER_CNAME + '/object_symbol/{object_id}/{symbol_id}'.format(object_id=object_id, symbol_id=symbol_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_object_symbol(object_id, symbol_id, value=None, **kwargs):
    """Patch an Object Symbol."""
    url = AECTEMPLATER_CNAME + '/object_symbol/{object_id}/{symbol_id}'.format(object_id=object_id, symbol_id=symbol_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
