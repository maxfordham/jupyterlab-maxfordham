import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_properties(value=None, **kwargs):
    """Get all Properties."""
    url = AECTEMPLATER_CNAME + '/properties'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_property_names(value=None, **kwargs):
    """Get all Property names."""
    url = AECTEMPLATER_CNAME + '/properties/names'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_property(property_id, value=None, **kwargs):
    """Get a Property by its ID."""
    url = AECTEMPLATER_CNAME + '/property/{property_id}'.format(property_id=property_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_property_by_name(name, value=None, **kwargs):
    """Get a Property by its name."""
    url = AECTEMPLATER_CNAME + '/property/name/{name}'.format(name=name)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_property_by_guid(guid, value=None, **kwargs):
    """Get a Property by its GUID."""
    url = AECTEMPLATER_CNAME + '/property/guid/{guid}'.format(guid=guid)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_property(value=None, **kwargs):
    """Post a Property."""
    url = AECTEMPLATER_CNAME + '/property'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def delete_property(property_id, value=None, **kwargs):
    """Delete a Property by its ID."""
    url = AECTEMPLATER_CNAME + '/property/{property_id}'.format(property_id=property_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_property(property_id, value=None, **kwargs):
    """Patch a Property."""
    url = AECTEMPLATER_CNAME + '/property/{property_id}'.format(property_id=property_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def get_property_default_unit(property_id, value=None, **kwargs):
    """Get the default unit of a Property."""
    url = AECTEMPLATER_CNAME + '/property/{property_id}/default_unit'.format(property_id=property_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
