import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_pset_property(pset_id, property_id, value=None, **kwargs):
    """Get a Pset Property."""
    url = AECTEMPLATER_CNAME + '/pset_property/{pset_id}/{property_id}'.format(pset_id=pset_id, property_id=property_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_pset_property(pset_id, property_id, value=None, **kwargs):
    """Delete a Pset Property."""
    url = AECTEMPLATER_CNAME + '/pset_property/{pset_id}/{property_id}'.format(pset_id=pset_id, property_id=property_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def post_pset_property(pset_id, property_id, value=None, **kwargs):
    """Post a Pset Property."""
    url = AECTEMPLATER_CNAME + '/pset_property/{pset_id}/{property_id}'.format(pset_id=pset_id, property_id=property_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)
