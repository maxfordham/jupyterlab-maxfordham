# -*- coding: utf-8 -*-

import os
import json
import logging

logger = logging.getLogger(__name__)


class EnvVars:
    """A class to manage environment variables in a way that is compatible with both
    pyRevit and standard Python environments. It provides methods to get individual
    environment variables and to retrieve all environment variables as a dictionary."""

    def __init__(self):
        try:
            # Attempt to import pyRevit
            from pyrevit.coreutils import envvars

            self.env = envvars.get_pyrevit_env_vars()
        except ImportError:
            # Fallback to os.environ if not using pyRevit
            import os

            self.env = os.environ

    def get(self, key):
        return self.env[key]

    def all(self):
        return self.env


env_vars = EnvVars()


def get_aectemplater_cname():
    try:
        return env_vars.get("AECTEMPLATER_CNAME")
    except Exception as _:
        return "http://127.0.0.1:8000"  # Default to local development server


def get_template_project_number():
    try:
        return env_vars.get("AECTEMPLATER_PROJECT_NUMBER")
    except Exception as _:
        return 5003


def get_aectemplater_org():
    try:
        return env_vars.get("AECTEMPLATER_ORG")
    except Exception as _:
        return "MXF"


# ^ NOTE: not using pydantic for settings management as its not useable with pyRevit

AECTEMPLATER_CNAME = get_aectemplater_cname()
AECTEMPLATER_PROJECT_NUMBER = get_template_project_number()
TEMPLATE_CUSTODIAN = get_aectemplater_org()


def get_user():
    if "JUPYTERHUB_USER" in env_vars.all():
        return env_vars.get("JUPYTERHUB_USER")  # on jhub
    elif "USERNAME" in env_vars.all():
        return env_vars.get("USERNAME")  # on local machine pyRevit
    else:
        try:
            from getpass import getuser

            return getuser()
        except Exception as _:
            return "unknown"


def response_check(response):
    """Checks if the response failed and, if so, raises an exception
    related to the request made.

    Args:
        response (requests.models.Response): Response object from a request

    Raises:
        Exception: Raises exception related to the API query.
    """
    if response.ok:
        if response.content in ("[]", "{}"):  # NOTE: We do this to support requests 2.13 used in pyRevit
            return eval(response.content)
        else:
            return response.json()
    else:
        try:
            response_detail = json.loads(response.text)["detail"]
        except Exception as _:
            msg = "⛔ - error. No detail given. {response.text}".format(response=response)
            logger.warning(msg)
            raise Exception(msg)

        msg = "⚠️ -> {response_detail}".format(response_detail=response_detail)
        logger.warning(msg)
        raise Exception(msg)
