import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_abbreviations(value=None, **kwargs):
    """Get all abbreviations."""
    url = AECTEMPLATER_CNAME + '/abbreviations'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_abbreviation(value=None, **kwargs):
    """Post an Abbreviation."""
    url = AECTEMPLATER_CNAME + '/abbreviation'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_abbreviation_by_id(abbreviation_id, value=None, **kwargs):
    """Get an Abbreviation by its ID."""
    url = AECTEMPLATER_CNAME + '/abbreviation/{abbreviation_id}'.format(abbreviation_id=abbreviation_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_abbreviation_by_name(abbreviation, value=None, **kwargs):
    """Get an Abbreviation by its name."""
    url = AECTEMPLATER_CNAME + '/abbreviation/name/{abbreviation}'.format(abbreviation=abbreviation)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_abbreviation_by_id(abbreviation_id, value=None, **kwargs):
    """Delete an Abbreviation by its ID."""
    url = AECTEMPLATER_CNAME + '/abbreviation/{abbreviation_id}'.format(abbreviation_id=abbreviation_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_abbreviation_by_id(abbreviation_id, value=None, **kwargs):
    """Patch an Abbreviation by its ID."""
    url = AECTEMPLATER_CNAME + '/abbreviation/{abbreviation_id}'.format(abbreviation_id=abbreviation_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
