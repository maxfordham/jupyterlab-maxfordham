import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def post_document(value=None, **kwargs):
    """Post a Document."""
    url = AECTEMPLATER_CNAME + '/document'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_document_by_id(document_id, value=None, **kwargs):
    """Get a Document by its ID."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}'.format(document_id=document_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_spec_tags_from_document(document_id, value=None, **kwargs):
    """Get the tags related to a Document."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}/tags'.format(document_id=document_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_filters_from_document(document_id, value=None, **kwargs):
    """Get the Project Filters related to a Document."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}/project_filters'.format(document_id=document_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_filter_names_from_document(document_id, value=None, **kwargs):
    """Get the Project Filter names related to a Document."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}/project_filters/names'.format(document_id=document_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_filters_not_in_use(document_id, value=None, **kwargs):
    """Get the Project Filters not related to a Document within a Project Revision.The project filters are filtered by the document's use type."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}/project_filters/not_in_use'.format(document_id=document_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_filter_names_not_in_use(document_id, value=None, **kwargs):
    """Get the Project Filter names not related to a Document within a Project Revision."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}/project_filters/not_in_use/names'.format(
        document_id=document_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_document(document_id, value=None, **kwargs):
    """Delete a Document by its ID."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}'.format(document_id=document_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_document(document_id, value=None, **kwargs):
    """Patch a Document by its ID."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}'.format(document_id=document_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def get_documents_by_project_revision(project_revision_id, value=None, **kwargs):
    """Get Documents by Project Revision."""
    url = AECTEMPLATER_CNAME + '/document/project_revision/{project_revision_id}'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_document_code_by_project_revision(project_revision_id, value=None, **kwargs):
    """Get Document Codes and Descriptions by Project Revision."""
    url = AECTEMPLATER_CNAME + '/document/project_revision/{project_revision_id}/code'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_document_code_and_description_by_project_revision(project_revision_id, value=None, **kwargs):
    """Get Document codes and descriptions by Project Revision."""
    url = AECTEMPLATER_CNAME + '/document/project_revision/{project_revision_id}/code_and_description'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_documents_by_project_revision_only_issue_id(project_revision_id, value=None, **kwargs):
    """Get Documents by Project Revision but only return Issue IDs."""
    url = AECTEMPLATER_CNAME + '/document/project_revision/{project_revision_id}/issue_id'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def copy_document_into_project_revision(document_id, project_revision_id, value=None, **kwargs):
    """Duplicate a Document into a Project Revision."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}/project_revision/{project_revision_id}/duplicate'.format(
        document_id=document_id, project_revision_id=project_revision_id
    )
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_document_object_data(document_id, value=None, **kwargs):
    """Get Document data (list of grid schemas for both types and instances)."""
    url = AECTEMPLATER_CNAME + '/document/{document_id}/data'.format(document_id=document_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
