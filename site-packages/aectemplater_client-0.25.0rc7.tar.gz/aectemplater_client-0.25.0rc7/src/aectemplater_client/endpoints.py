import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_endpoints(value=None, **kwargs):
    """Get endpoints (excluding HEAD methods)"""
    url = AECTEMPLATER_CNAME + '/endpoints'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
