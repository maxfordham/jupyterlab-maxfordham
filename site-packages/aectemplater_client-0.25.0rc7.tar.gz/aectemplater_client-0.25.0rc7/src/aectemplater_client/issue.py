import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def post_issue(value=None, **kwargs):
    """Post an Issue."""
    url = AECTEMPLATER_CNAME + '/issue'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_issue_by_id(issue_id, value=None, **kwargs):
    """Get an Issue by its ID."""
    url = AECTEMPLATER_CNAME + '/issue/{issue_id}'.format(issue_id=issue_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_issue(issue_id, value=None, **kwargs):
    """Delete an Issue by its ID."""
    url = AECTEMPLATER_CNAME + '/issue/{issue_id}'.format(issue_id=issue_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_issue(issue_id, value=None, **kwargs):
    """Patch an Issue by its ID."""
    url = AECTEMPLATER_CNAME + '/issue/{issue_id}'.format(issue_id=issue_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def patch_issue_data(issue_id, value=None, **kwargs):
    """Patch Issue data."""
    url = AECTEMPLATER_CNAME + '/issue/{issue_id}/issue_data'.format(issue_id=issue_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def is_document_code_unique(issue_id, value=None, **kwargs):
    """Check if document name is unique."""
    url = AECTEMPLATER_CNAME + '/issue/{issue_id}/is_document_code_unique'.format(issue_id=issue_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
