import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_object_abbreviations(value=None, **kwargs):
    """Get all Object Abbreviations."""
    url = AECTEMPLATER_CNAME + '/object_abbreviations'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_object_abbreviations_by_object_id(object_id, value=None, **kwargs):
    """Get all Object Abbreviations by Object ID."""
    url = AECTEMPLATER_CNAME + '/object_abbreviations/object/{object_id}'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_object_abbreviation(object_id, abbreviation_id, value=None, **kwargs):
    """Post an Object Abbreviation."""
    url = AECTEMPLATER_CNAME + '/object_abbreviation/{object_id}/{abbreviation_id}'.format(
        object_id=object_id, abbreviation_id=abbreviation_id
    )
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_object_abbreviation(object_id, abbreviation_id, value=None, **kwargs):
    """Get an Object Abbreviation."""
    url = AECTEMPLATER_CNAME + '/object_abbreviation/{object_id}/{abbreviation_id}'.format(
        object_id=object_id, abbreviation_id=abbreviation_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_object_abbreviation(object_id, abbreviation_id, value=None, **kwargs):
    """Delete an Object Abbreviation."""
    url = AECTEMPLATER_CNAME + '/object_abbreviation/{object_id}/{abbreviation_id}'.format(
        object_id=object_id, abbreviation_id=abbreviation_id
    )
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_object_abbreviation(object_id, abbreviation_id, value=None, **kwargs):
    """Patch an Object Abbreviation."""
    url = AECTEMPLATER_CNAME + '/object_abbreviation/{object_id}/{abbreviation_id}'.format(
        object_id=object_id, abbreviation_id=abbreviation_id
    )
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def get_object_abbreviations_treeviz(value=None, **kwargs):
    """Reads all Object Abbreviations and return data for tree viz."""
    url = AECTEMPLATER_CNAME + '/object_abbreviation/treeviz'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
