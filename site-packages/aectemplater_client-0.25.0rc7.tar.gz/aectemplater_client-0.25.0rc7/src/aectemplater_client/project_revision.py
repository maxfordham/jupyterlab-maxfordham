import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def post_project_revision(value=None, **kwargs):
    """Post a Project Revision."""
    url = AECTEMPLATER_CNAME + '/project_revision'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_project_revision_by_id(project_revision_id, value=None, **kwargs):
    """Get a Project Revision by its ID."""
    url = AECTEMPLATER_CNAME + '/project_revision/{project_revision_id}'.format(project_revision_id=project_revision_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_revision_by_project_number_and_revision(project_number, revision, value=None, **kwargs):
    """Get a Project Revision by its project number and revision."""
    url = AECTEMPLATER_CNAME + '/project_revision/project_number/{project_number}/revision/{revision}'.format(
        project_number=project_number, revision=revision
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_project_revision(project_revision_id, value=None, **kwargs):
    """Delete a Project Revision by its ID."""
    url = AECTEMPLATER_CNAME + '/project_revision/{project_revision_id}'.format(project_revision_id=project_revision_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_project_revision(project_revision_id, value=None, **kwargs):
    """Patch a Project Revision."""
    url = AECTEMPLATER_CNAME + '/project_revision/{project_revision_id}'.format(project_revision_id=project_revision_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
