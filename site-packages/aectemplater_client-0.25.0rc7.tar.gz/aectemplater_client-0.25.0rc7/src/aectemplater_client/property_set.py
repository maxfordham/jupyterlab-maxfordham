import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_psets(value=None, **kwargs):
    """Get all Property Sets."""
    url = AECTEMPLATER_CNAME + '/propertysets'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_pset(pset_id, value=None, **kwargs):
    """Get a Property Set by its ID."""
    url = AECTEMPLATER_CNAME + '/propertyset/{pset_id}'.format(pset_id=pset_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_psets_by_code(code, value=None, **kwargs):
    """Get Property Sets by their code."""
    url = AECTEMPLATER_CNAME + '/propertysets/code/{code}'.format(code=code)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_psets_by_custodian(custodian, value=None, **kwargs):
    """Get Property Sets by their template custodian."""
    url = AECTEMPLATER_CNAME + '/propertysets/custodian/{custodian}'.format(custodian=custodian)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_pset_unique_name(pset_id, value=None, **kwargs):
    """Get unique name of Property Set."""
    url = AECTEMPLATER_CNAME + '/propertyset/{pset_id}/unique_name'.format(pset_id=pset_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_psets_unique_names(value=None, **kwargs):
    """Get unique names of all Property Sets."""
    url = AECTEMPLATER_CNAME + '/propertysets/unique_names'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_pset(value=None, **kwargs):
    """Post a Property Set."""
    url = AECTEMPLATER_CNAME + '/propertyset'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def duplicate_pset(pset_id, value=None, **kwargs):
    """Duplicate a Property Set and all its defined relationships"""
    url = AECTEMPLATER_CNAME + '/propertyset/{pset_id}/duplicate'.format(pset_id=pset_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def patch_pset(pset_id, value=None, **kwargs):
    """Patch a Property Set."""
    url = AECTEMPLATER_CNAME + '/propertyset/{pset_id}'.format(pset_id=pset_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def delete_pset(pset_id, value=None, **kwargs):
    """Delete a Property Set by its ID."""
    url = AECTEMPLATER_CNAME + '/propertyset/{pset_id}'.format(pset_id=pset_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def post_properties_to_pset(pset_id, value=None, **kwargs):
    """Associate Properties to a Property Set."""
    url = AECTEMPLATER_CNAME + '/pset_properties/propertyset/{pset_id}'.format(pset_id=pset_id)
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def delete_properties_from_pset(pset_id, value=None, **kwargs):
    """Delete the Properties from a Property Set."""
    url = AECTEMPLATER_CNAME + '/pset_properties/propertyset/{pset_id}'.format(pset_id=pset_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)
