import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_revit_project_units(value=None, **kwargs):
    """Get the project units of the Revit project."""
    url = AECTEMPLATER_CNAME + '/revit/units'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_section_to_revit_parameter_group(value=None, **kwargs):
    """Get map from sections to Revit parameter groups."""
    url = AECTEMPLATER_CNAME + '/revit/section_to_revit_parameter_group'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_family_template_mapping(value=None, **kwargs):
    """Get the family template mapping."""
    url = AECTEMPLATER_CNAME + '/revit/family_template_mapping'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_types_select(project_revision_id, value=None, **kwargs):
    """Get the type specs that can be selected."""
    url = AECTEMPLATER_CNAME + '/revit/type_specs/project_revision/{project_revision_id}'.format(
        project_revision_id=project_revision_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def patch_shared_params(code, value=None, **kwargs):
    """Get the shared parameters of an Object. If existing shared parameter passed as text, it will be merged."""
    url = AECTEMPLATER_CNAME + '/revit/object/code/{code}/shared_params'.format(code=code)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)


def get_type_spec_data_revit(project_revision_id, type_mark, value=None, **kwargs):
    """Get the type spec data for a given type mark."""
    url = AECTEMPLATER_CNAME + '/revit/type_spec/project_revision/{project_revision_id}/type_mark/{type_mark}'.format(
        project_revision_id=project_revision_id, type_mark=type_mark
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs_object_data_revit(project_revision_id, object_id, value=None, **kwargs):
    """Get Type Specification data for Revit."""
    url = AECTEMPLATER_CNAME + '/revit/type_specs/project_revision/{project_revision_id}/object/{object_id}'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_specs_object_data_revit(project_revision_id, object_id, value=None, **kwargs):
    """Get Instance Specification data for Revit."""
    url = AECTEMPLATER_CNAME + '/revit/instance_specs/project_revision/{project_revision_id}/object/{object_id}'.format(
        project_revision_id=project_revision_id, object_id=object_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def patch_post_spaces(project_revision_id, value=None, **kwargs):
    """Post and patch spaces from Revit into API."""
    url = AECTEMPLATER_CNAME + '/revit/spaces/project_revision/{project_revision_id}'.format(
        project_revision_id=project_revision_id
    )
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)
