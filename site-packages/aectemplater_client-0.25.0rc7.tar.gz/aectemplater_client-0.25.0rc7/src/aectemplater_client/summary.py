import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_project_names(value=None, **kwargs):
    """Get all project names."""
    url = AECTEMPLATER_CNAME + '/projects/names'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_count(value=None, **kwargs):
    """Get count of all active projects i.e. ignore Engineering Standards and Test Project."""
    url = AECTEMPLATER_CNAME + '/projects/count'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_projects_object_spec_data(value=None, **kwargs):
    """Get object specification data across all projects."""
    url = AECTEMPLATER_CNAME + '/projects_object_spec_data'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs_summary(value=None, **kwargs):
    """Get summary of all type specifications."""
    url = AECTEMPLATER_CNAME + '/type_specs/summary'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs_count(value=None, **kwargs):
    """Get count of all type specifications (only considers active projects)."""
    url = AECTEMPLATER_CNAME + '/type_specs/count'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_type_specs_project_count(value=None, **kwargs):
    """Get count of all type specifications for each project (only considers active projects)."""
    url = AECTEMPLATER_CNAME + '/type_specs/projects/count'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_instance_spec_summary(value=None, **kwargs):
    """Get summary of all instance specifications."""
    url = AECTEMPLATER_CNAME + '/instance_specs/summary'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def get_project_wktyp_spend_by_wkdes_sum(project_number, wkdes, value=None, **kwargs):
    """Get project work type spend sum by work type description."""
    url = AECTEMPLATER_CNAME + '/project_wktyp_spend_by_wkdes_sum/{project_number}/{wkdes}'.format(
        project_number=project_number, wkdes=wkdes
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
