import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_symbols(value=None, **kwargs):
    """Get all Symbols."""
    url = AECTEMPLATER_CNAME + '/symbols'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_symbol(value=None, **kwargs):
    """Post a Symbol."""
    url = AECTEMPLATER_CNAME + '/symbol'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_symbol_by_id(symbol_id, value=None, **kwargs):
    """Get a Symbol."""
    url = AECTEMPLATER_CNAME + '/symbol/{symbol_id}'.format(symbol_id=symbol_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_symbol_by_id(symbol_id, value=None, **kwargs):
    """Delete a Symbol."""
    url = AECTEMPLATER_CNAME + '/symbol/{symbol_id}'.format(symbol_id=symbol_id)
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_symbol_by_id(symbol_id, value=None, **kwargs):
    """Patch a Symbol."""
    url = AECTEMPLATER_CNAME + '/symbol/{symbol_id}'.format(symbol_id=symbol_id)
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
