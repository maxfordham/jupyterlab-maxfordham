import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def get_type_tag_templates(value=None, **kwargs):
    """Get all Type Tag Templates."""
    url = AECTEMPLATER_CNAME + '/type_tag_templates'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def post_type_tag_template(value=None, **kwargs):
    """Post a Type Tag Template."""
    url = AECTEMPLATER_CNAME + '/type_tag_template'
    response = requests.post(url, json=value, params=kwargs)
    return response_check(response)


def get_type_tag_template_by_id(type_tag_template_id, value=None, **kwargs):
    """Get a Type Tag Template by its ID."""
    url = AECTEMPLATER_CNAME + '/type_tag_template/{type_tag_template_id}'.format(
        type_tag_template_id=type_tag_template_id
    )
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def delete_type_tag_template_by_id(type_tag_template_id, value=None, **kwargs):
    """Delete a Type Tag Template by its ID."""
    url = AECTEMPLATER_CNAME + '/type_tag_template/{type_tag_template_id}'.format(
        type_tag_template_id=type_tag_template_id
    )
    response = requests.delete(url, json=value, params=kwargs)
    return response_check(response)


def patch_type_tag_template_by_id(type_tag_template_id, value=None, **kwargs):
    """Patch a Type Tag Template by its ID."""
    url = AECTEMPLATER_CNAME + '/type_tag_template/{type_tag_template_id}'.format(
        type_tag_template_id=type_tag_template_id
    )
    response = requests.patch(url, json=value, params=kwargs)
    return response_check(response)
