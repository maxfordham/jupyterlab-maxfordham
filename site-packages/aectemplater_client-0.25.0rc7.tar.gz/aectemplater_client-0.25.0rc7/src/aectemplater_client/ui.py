import requests
from aectemplater_client.utils import AECTEMPLATER_CNAME, response_check


def objects_view(value=None, **kwargs):
    """Get the table of objects."""
    url = AECTEMPLATER_CNAME + '/api/'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def object_property_view(object_id, value=None, **kwargs):
    """Get the object profile page."""
    url = AECTEMPLATER_CNAME + '/api/object/{object_id}/view'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def properties_view(value=None, **kwargs):
    """Get the table of properties."""
    url = AECTEMPLATER_CNAME + '/api/properties/view'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def property_view(property_id, value=None, **kwargs):
    """Get the property profile page."""
    url = AECTEMPLATER_CNAME + '/api/property/{property_id}/view'.format(property_id=property_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def html_landing(property_id, value=None, **kwargs):
    """None"""
    url = AECTEMPLATER_CNAME + '/property/{property_id}/view'.format(property_id=property_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def html_landing(object_id, value=None, **kwargs):
    """None"""
    url = AECTEMPLATER_CNAME + '/object/{object_id}/view'.format(object_id=object_id)
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def html_landing(value=None, **kwargs):
    """None"""
    url = AECTEMPLATER_CNAME + '/properties/view'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)


def html_landing(value=None, **kwargs):
    """None"""
    url = AECTEMPLATER_CNAME + '/'
    response = requests.get(url, json=value, params=kwargs)
    return response_check(response)
