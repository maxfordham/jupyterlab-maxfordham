import pathlib

FDIR_ROOT = pathlib.Path(__file__).parents[2]
FPTH_ENV = FDIR_ROOT / ".env"
FPTH_LOCAL_BDNS = (
    pathlib.Path(__file__).parent / "data" / "BDNS_Abbreviations_Register.csv"
)
DEFAULT_ORG = "MXF"
FDIR_SYMBOLS = "/home/jovyan/Jobs/J4321/Data/symbols/"
URL_REF_BSDD_UNITS = "https://github.com/buildingSMART/bSDD/blob/master/Model/Import%20Model/reference-lists/units.csv"
URL_REF_BSDD_REFERENCE_STANDARDS = "https://github.com/buildingSMART/bSDD/blob/master/Model/Import%20Model/reference-lists/reference-documents.csv"
URL_REF_UNYT = "https://unyt.readthedocs.io/en/stable/"
CITE_SI_UNITS_PAPER = (
    "Review of the International Systems of Quantities and Units Usage (Glavič, 2021)"
)
