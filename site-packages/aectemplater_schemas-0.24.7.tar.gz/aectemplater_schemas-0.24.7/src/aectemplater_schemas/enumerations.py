import csv
import requests
import logging
import pathlib
from io import StringIO
from enum import Enum
from document_issue.enums import DocumentTypeEnum
from aectemplater_schemas.env import Env
from aectemplater_schemas.data.utils import (
    UnitsBaseData,
)

logger = logging.getLogger(__name__)
UDATA = UnitsBaseData()
ENV = Env()


class UseTypeEnum(str, Enum):
    equipment: str = "Equipment"
    spaces: str = "Spaces"
    performance: str = "Performance Monitoring"
    ifc: str = "IFC"


class StatusEnum(str, Enum):
    active: str = "active"
    inactive: str = "inactive"
    preview: str = "preview"
    # TODO: add more fields


class ParameterTypeEnum(str, Enum):
    """Whether parameter is an instance or type parameter."""

    instance = "I"
    type = "T"


DOCUMENT_TYPE_TO_USE_TYPE = {
    DocumentTypeEnum.rds: UseTypeEnum.spaces,
    DocumentTypeEnum.prs: UseTypeEnum.equipment,  # TODO: Change plantroom to map to different use type in the future
    DocumentTypeEnum.es: UseTypeEnum.equipment,
    # DocumentTypeEnum.nzc: UseTypeEnum.performance,  # TODO: Implement this later
}


class StrEnum(str, Enum):
    pass


IfcTypeEnum = StrEnum("IfcTypeEnum", UDATA.ifc_types_enum)
IfcTypeEnum.__doc__ = (  # TODO Consider how this maps to json_data_type.
    "The datatype the property is expressed in. Must be one of: Boolean,"
    " Character, Integer, Real, String, Time."
)
# PhysicalQuantityEnum = StrEnum('Physical Quantity', UDATA.physical_quantities_enum)
# PhysicalQuantityEnum.__doc__ = "The unit's physical quantity e.g. length, mass, etc."


RevitDataTypeEnum = StrEnum("RevitDataTypeEnum", UDATA.revit_types_enum)
RevitDataTypeEnum.__doc__ = """
    The complete list of the allowed "datatypes" or "specs" in Revit
    Reference:
        https://www.revitapidocs.com/2022/a93168f7-b52d-e97a-7935-50ddcec7fb54.htm
    """

CategoriesEnum = StrEnum("CategoriesEnum", UDATA.categories_enum)
CategoriesEnum.__doc__ = """
    Categories associated with each property.
    """

SectionsEnum = StrEnum("SectionsEnum", UDATA.sections_enum)
SectionsEnum.__doc__ = """
    The sections associated with each property.
    """


SuitabilityForUseEnum = StrEnum("SuitabilityForUseEnum", UDATA.suitability_enum)
SuitabilityForUseEnum.__doc__ = """
    Defines the suitability for use status of a property set.
    """


class PropertyValueKindEnum(StrEnum):
    """
    Single: (one value, is default),
    Range: (two values),
    List: (multiple values),
    """

    # Complex: (consists of multiple properties, use ConnectedProperties),
    # ComplexList: (list of complex values)

    single: str = "Single"
    range: str = "Range"
    list: str = "List"
    # complex: str = "Complex"
    # complex_list: str = "ComplexList"


class RuleSetType(str, Enum):
    AND: str = "AND"
    OR: str = "OR"


# - Abbreviations --------------------------------------------------------------
def get_bdns_asset_abbreviations():
    try:  #  read from github
        csv_data = StringIO(requests.get(ENV.URL_ABBREVIATIONS).content.decode())
    except:
        from aectemplater_schemas.constants import FPTH_LOCAL_BDNS

        logger.warning(
            "could not retrieve abbreviations from GitHub - using local copy."
        )
        csv_data = FPTH_LOCAL_BDNS.read_text()[:-1].split("\n")
    return list(csv.reader(csv_data))


def get_bdns_asset_abbreviations_enum():
    return {l[1]: l[1] for l in get_bdns_asset_abbreviations()[1:]}


AbbreviationsEnum = StrEnum("AbbreviationsEnum", get_bdns_asset_abbreviations_enum())

# - Symbols --------------------------------------------------------------------


def get_symbols() -> dict[str, str]:
    """Get list of symbols that are in symbols directory."""
    if ENV.FDIR_SYMBOLS is None:
        return {}
    else:
        return {
            file.stem.replace("-", "_"): file.name
            for file in pathlib.Path(ENV.FDIR_SYMBOLS).glob("*.png")
        }


SymbolsEnum = StrEnum("SymbolsEnum", get_symbols())
SymbolsEnum.__doc__ = """
    Enumeration of symbols
    """


class JsonDataTypeEnum(str, Enum):
    string: str = "string"
    number: str = "number"
    integer: str = "integer"
    object: str = "object"
    array: str = "array"
    boolean: str = "boolean"
    null: str = "null"


def get_map_types():
    def make_enum(v):
        if "type" in v:
            v["type"] = getattr(JsonDataTypeEnum, v["type"])
        return v

    return {
        getattr(IfcTypeEnum, k): make_enum(v) for k, v in UDATA.map_schema_types.items()
    }


MAP_TYPES = get_map_types()

if __name__ == "__main__":
    ifc = IfcTypeEnum
    print("done")
