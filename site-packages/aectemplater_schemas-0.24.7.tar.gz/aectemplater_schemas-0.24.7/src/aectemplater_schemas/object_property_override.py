import typing as ty
from pydantic import Field
from aectemplater_schemas.property import _P_allowed_values


class ObjectPropertyOverride(_P_allowed_values):
    title: ty.Optional[str] = Field(
        None,
        title="Title",
        description="Override the title of a property. This is the name that will be used in the template.",
    )
    definition: ty.Optional[str] = Field(
        None,
        title="Definition",
        description="Override the definition of a property.",
    )
    notes: ty.Optional[str] = Field(
        None,
        title="Notes",
        description="Override the notes of a property.",
    )
    example: ty.Optional[str] = Field(
        None,
        title="Example",
        description="Override the example of a property.",
    )
    method_of_measurement: ty.Optional[str] = Field(
        None,
        title="Method of Measurement",
        description="Override the method of measurement of a property.",
    )
    is_instance: ty.Optional[bool] = Field(
        None,
        title="Is Instance",
        description="Override 'is_instance' as defined in property.",
        json_schema_extra=dict(column_width=50),
    )
    output_unit_id: ty.Optional[int] = Field(
        None,
        title="Output Unit ID",
        description="The ID of the unit that the property should be output in.",
    )
