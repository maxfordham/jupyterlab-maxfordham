from pydantic import ConfigDict, Field

from aectemplater_schemas.basemodel import BaseModel


class Project(BaseModel):
    project_number: int = Field()
