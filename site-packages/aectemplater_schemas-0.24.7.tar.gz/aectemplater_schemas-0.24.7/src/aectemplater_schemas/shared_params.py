import typing as ty
from pydantic import RootModel

from aectemplater_schemas.property import SharedParam


class SharedParams(RootModel):
    root: ty.List[SharedParam]

    def __iter__(self):
        return iter(self.root)

    def __getitem__(self, item):
        return self.root[item]
