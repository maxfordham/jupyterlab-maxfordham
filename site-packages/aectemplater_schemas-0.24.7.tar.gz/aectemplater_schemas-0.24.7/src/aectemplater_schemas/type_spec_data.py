import typing as ty
from pydantic import ConfigDict, Field

from aectemplater_schemas.basemodel import BaseModel


class TypeSpecData(BaseModel):
    value: ty.Any = Field(None)
