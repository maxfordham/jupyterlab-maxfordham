from time import strftime
from pydantic import ConfigDict, Field, field_validator, ValidationInfo

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.constants import (
    URL_REF_BSDD_UNITS,
    CITE_SI_UNITS_PAPER,
    URL_REF_UNYT,
)

# from aectemplater_schemas.enumerations import PhysicalQuantityEnum

STR_REFERENCE = f"""
Reference:

    - {URL_REF_UNYT}
    - {CITE_SI_UNITS_PAPER}
"""


class PhysicalQuantity(BaseModel):
    physical_quantity: str = Field(
        default="",
        description="The unit's physical quantity e.g. length, mass, etc.",
        json_schema_extra=dict(
            is_ifc=True, autoui="ipywidgets.Combobox", column_width=135
        ),
    )


class Units(PhysicalQuantity):
    """Units define the physical attributes of a unit. We have aimed to align the fields
    as closely with the Building Smart database which can be seen in the reference link
    below.

    Both the Units table and the Properties table contain the `physical_quantity` field.
    This is defined by the combined `dimension` (i.e. fundamental SI dimension) of the
    unit. This allows allowed units to be automatically mapped to Properties.
    """

    __doc__ += STR_REFERENCE
    code: str = Field(
        "",
        title="Code",
        description=(
            "Unique and valid expression / derivation for a unit."
            " Validated with Unyt."
        ),
        json_schema_extra=dict(column_width=80, is_ifc=True, disabled=True),
    )
    name: str = Field(
        "",
        title="Name",
        description="The full name of the unit.",
        json_schema_extra=dict(column_width=150),
    )
    symbol: str = Field(
        "",
        title="Symbol",
        description="The symbol given to a unit.",
        json_schema_extra=dict(column_width=120),
    )
    base_value: float = Field(
        1,
        title="Base Value",
        description=(
            "Scaling factor to the equivalent SI unit." " value = 1.0 implies S.I unit."
        ),
        json_schema_extra=dict(
            is_ifc=True, column_width=170, global_decimal_places=3, disabled=True
        ),
    )
    dimension_length: int = Field(
        0,
        title="L",
        description=("dimensions for length. SI unit for length is metres."),
        json_schema_extra=dict(is_ifc=True, column_width=55, disabled=True),
    )
    dimension_mass: int = Field(
        0,
        title="M",
        description=("dimensions for mass. SI unit for mass is kilograms."),
        json_schema_extra=dict(is_ifc=True, column_width=55, disabled=True),
    )
    dimension_time: int = Field(
        0,
        title="T",
        description=("dimensions for time. SI unit for time is seconds."),
        json_schema_extra=dict(is_ifc=True, column_width=55, disabled=True),
    )
    dimension_electric_current: int = Field(
        0,
        title="I",
        description=("dimensions for current. SI unit for current is ampere."),
        json_schema_extra=dict(is_ifc=True, column_width=55, disabled=True),
    )
    dimension_thermodynamic_temperature: int = Field(
        0,
        title="Θ",
        description=(
            "dimensions for temperature. SI unit for temperature is" " kelvin."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=55, disabled=True),
    )
    dimension_amount_of_substance: int = Field(
        0,
        title="N",
        description=(
            "dimensions for the amount of substance. SI unit for the"
            " amount of substance is moles."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=55, disabled=True),
    )
    dimension_luminous_intensity: int = Field(
        0,
        title="J",
        description=(
            "dimensions for luminous intensity. SI unit for luminous"
            " intensity is candela."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=55, disabled=True),
    )

    @field_validator("code")
    def _set_dimesionless_code_to_empty_string(cls, v, info: ValidationInfo):
        values = info.data
        if v == "dimensionless":
            v = ""
        return v

    @field_validator("symbol")
    def _create_symbol_if_not_set(cls, v, info: ValidationInfo):
        values = info.data
        if v == "" and values["code"] != "":
            v = values["code"].replace("**", "").replace("*", ".")
        if v == "dimensionless":
            v = ""
        return v
