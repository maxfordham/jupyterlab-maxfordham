import jsonref

from aectemplater_schemas.enumerations import ParameterTypeEnum
from aectemplater_schemas.property import PropertySchema
from aectemplater_schemas.object import (
    ObjectSchema,
    ObjectGridSchema,
    ObjectData,
    ObjectDataGrid,
)


def test_object_schema():
    """Text ObjectSchema works as expected."""
    object_schema = ObjectSchema(
        title="Person",
        description="A person object",
        parameter_type=ParameterTypeEnum.type,
        override_units=True,
        properties={
            "Name": PropertySchema(
                title="Name",
                description="The name of the person",
                type="string",
                parameter_type=ParameterTypeEnum.type,
            ),
            "Height": PropertySchema(
                title="Height",
                description="The height of the person",
                type="number",
                units="mm",
                parameter_type=ParameterTypeEnum.type,
            ),
        },
    )
    assert object_schema


def test_object_grid_schema():
    """Test example and check if the $defs is present in the model_dump.
    Also check that the dumped object is the same as the original."""
    object_grid_schema = ObjectGridSchema(
        title="People",
        items=ObjectSchema(
            title="Person",
            description="A person object",
            parameter_type=ParameterTypeEnum.type,
            override_units=True,
            properties={
                "Name": PropertySchema(
                    title="Name",
                    description="The name of the person",
                    type="string",
                    parameter_type=ParameterTypeEnum.type,
                ),
                "Height": PropertySchema(
                    title="Height",
                    description="The height of the person",
                    type="number",
                    units="mm",
                    parameter_type=ParameterTypeEnum.type,
                ),
            },
        ),
    )
    assert (
        ObjectGridSchema(**object_grid_schema.model_dump()).model_dump()
        == object_grid_schema.model_dump()
    )  # Check if the dumped object is the same as the original


def test_object_data():
    """Test example and check if the $schema is present in the model_dump.
    Also check that the dumped object is the same as the original.
    Check that `replace_refs` makes the API call defined in the schema."""
    object_data = ObjectData(
        schema_={
            "$ref": "https://catfact.ninja/fact"
        },  # Use catfact API as a placeholder
        data={"name": "John", "age": 30},
    )
    assert (
        "$schema" in object_data.model_dump().keys()
    )  # Check if $schema exists when dumping
    assert (
        ObjectData(**object_data.model_dump()) == object_data
    )  # Check if the dumped object is the same as the original
    assert (
        "fact" in jsonref.replace_refs(object_data.model_dump())["$schema"].keys()
    )  # Check if the catfact API call has been made


def test_object_data_grid():
    """Test example and check if the $schema is present in the model_dump.
    Also check that the dumped object is the same as the original.
    Check that `replace_refs` makes the API call defined in the schema."""
    object_data_grid = ObjectDataGrid(
        schema_={
            "$ref": "https://catfact.ninja/fact"
        },  # Use catfact API as a placeholder
        data=[
            {"name": "John", "age": 30},
            {"name": "Jane", "age": 25},
        ],
    )
    assert (
        "$schema" in object_data_grid.model_dump().keys()
    )  # Check if $schema exists when dumping
    assert (
        ObjectDataGrid(**object_data_grid.model_dump()) == object_data_grid
    )  # Check if the dumped object is the same as the original
    assert (
        "fact" in jsonref.replace_refs(object_data_grid.model_dump())["$schema"].keys()
    )  # Check if the catfact API call has been made
