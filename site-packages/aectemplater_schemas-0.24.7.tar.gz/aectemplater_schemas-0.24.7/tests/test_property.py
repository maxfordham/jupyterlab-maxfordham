from pydantic import ValidationError

from aectemplater_schemas.enumerations import ParameterTypeEnum
from aectemplater_schemas.property import Property, PropertySchema


def test_property():
    p = Property(name="test.property_with.chars", title="    Test Property    ")
    assert p.name == "test.property_with.chars"
    assert (
        p.title == "Test Property"
    )  # strip leading and trailing whitespace in basemodel config
    assert Property(title="Test Property").name == "TestProperty"
    try:
        p = Property(name="test.property_with.chars/", title="Test Property")
    except Exception as e:
        assert isinstance(e, ValidationError)


# TODO: Add or remove test
def test_times_are_set_correctly():
    pass


def test_property_schema():
    """Test PropertySchema works as expected."""
    property_schema = PropertySchema(
        title="Length",
        definition="The length of the object",
        ifc_data_type="IfcLengthMeasure",
        units="mm",
        json_schema_extra={"default": 20, "maximum": 100},
        notes="Some note on length",
        parameter_type=ParameterTypeEnum.type,
    )
    # Check type is set correctly by model_validator
    assert property_schema.type == "number"
    # Check that model dump brings json schema fields to the top level
    assert property_schema.model_dump()["default"] == 20
    assert property_schema.model_dump()["maximum"] == 100
    assert "json_schema_extra" not in property_schema.model_dump().keys()
    # Check that fields updated to JSON field names
    assert property_schema.model_dump()["tooltip"] == "Some note on length"
    assert property_schema.model_dump()["description"] == "The length of the object"
    assert "enum" not in property_schema.model_dump().keys()
    # Check computed field "title_with_units" exists when dumped
    property_schema = PropertySchema(
        title="Test",
        ifc_data_type="IfcText",
        json_schema_extra={"default": "test"},
        allowed_values=["test", "test 2"],
        notes="Some note on length",
        parameter_type=ParameterTypeEnum.type,
    )
    assert property_schema.model_dump()["enum"] == ["test", "test 2"]
