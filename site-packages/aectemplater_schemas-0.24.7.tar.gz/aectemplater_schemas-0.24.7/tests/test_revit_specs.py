import unyt as u
from aectemplater_schemas.data.utils import PATH_REVIT_SPECS_MEASURABLE, read_csv


def test_unyt_derivation_si():
    """Check that the UnytDerivationSi column is a valid unyt unit."""
    li_revit_measurable_specs = read_csv(PATH_REVIT_SPECS_MEASURABLE)
    for type in li_revit_measurable_specs:
        if type["UnytDerivationSi"] != "":
            assert u.Unit(type["UnytDerivationSi"]) is not None


def test_check_revit_measurable_spec_unit_dimensions():
    """Check that the unit dimensions of the UnytDerivationSi and DefaultUnit columns are the same."""
    li_revit_measurable_specs = read_csv(PATH_REVIT_SPECS_MEASURABLE)
    for type in li_revit_measurable_specs:
        if type["UnytDerivationSi"] != "" and type["DefaultUnit"] != "":
            assert (
                u.Unit(type["UnytDerivationSi"]).dimensions
                == u.Unit(type["DefaultUnit"]).dimensions
            )
