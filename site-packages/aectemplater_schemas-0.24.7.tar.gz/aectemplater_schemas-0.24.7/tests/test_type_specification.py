from aectemplater_schemas.type_specification import (
    TypeSpecificationBase,
    Abbreviation,
    Symbol,
)
from aectemplater_schemas.type_spec_data import TypeSpecData
from aectemplater_schemas.property import Property
from stringcase import pascalcase


# TODO: Needs fixing
class TestTypeSpecification:
    def test_type_specification(self):
        typespec = TypeSpecificationBase(
            data=[
                TypeSpecData(
                    value="test",
                    property=Property(name="Test"),
                )
            ],
            type_reference=1,
        )
        assert typespec.type_reference == 1
