import logging
from mfdb import get_job_number_to_name, get_user_names


try:
    JOB_NUMBER_TO_NAME = get_job_number_to_name()
    USERS = get_user_names()
except Exception as e:
    JOB_NUMBER_TO_NAME = {5001: "Test Project", 5003: "Engineering Standards"}
    USERS = []
    logging.warning(f"Warning: {e}")
