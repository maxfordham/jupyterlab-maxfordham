import typing as ty
from pydantic import ConfigDict, Field

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.enumerations import AbbreviationsEnum


class AbbreviationBase(BaseModel):
    abbreviation: ty.Union[AbbreviationsEnum, str] = Field(
        title="Abbreviation",
        description=(
            "Alphabetic characters only, variable length, between 2 and 6 characters."
            " The type abbreviation shall be according to the Building Device and Asset"
            " Abbreviation Registry."
        ),
    )
    is_archived: bool = Field(
        title="Is Archived",
        description="Whether or not the abbreviation is archived.",
        default=False,
    )


class Abbreviation(AbbreviationBase):
    pass
