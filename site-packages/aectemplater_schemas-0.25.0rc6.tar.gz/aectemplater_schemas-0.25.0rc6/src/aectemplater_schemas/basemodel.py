import pathlib
import stringcase
import subprocess
import json
from pydantic import ConfigDict, BaseModel, Field, validator
from document_issue.basemodel import BaseModel


class BaseModel(BaseModel):
    model_config = ConfigDict(
        alias_generator=stringcase.snakecase,
        populate_by_name=True,
        str_strip_whitespace=True,
        from_attributes=True,
    )
