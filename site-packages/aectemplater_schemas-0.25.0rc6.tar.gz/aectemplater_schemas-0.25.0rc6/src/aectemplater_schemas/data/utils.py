# - data/utils.py

import pathlib
import csv
import itertools
import stringcase
import aectemplater_schemas
import json

# import unyt as u

DIR_MODULE = pathlib.Path(aectemplater_schemas.__path__[0])
PATH_UNITS_BASE_DATA = DIR_MODULE / "data" / "units-base-data.csv"
PATH_UNITS_EXTENDED_DATA = DIR_MODULE / "data" / "units-extended-data.csv"
PATH_MAP_MEASURE_TO_REVIT_TYPE = (
    DIR_MODULE / "data" / "map-measure-to-revit-types-basic.csv"
)
PATH_MAP_CIBSE_UNITS = DIR_MODULE / "data" / "map-cibse-units.csv"
PATH_MAP_IFCSIMPLE_TO_REVIT = DIR_MODULE / "data" / "map-IfcSimple-to-revit-types.csv"
PATH_REVIT_SPECS_MEASURABLE = DIR_MODULE / "data" / "revit-measurable-specs.csv"
PATH_REVIT_SPECS_NON_MEASURABLE = DIR_MODULE / "data" / "revit-non-measurable-specs.csv"
PATH_REVIT_GROUP_PARAMETERS = DIR_MODULE / "data" / "revit-group-parameters.csv"
PATH_PARAMETER_CATEGORIES = DIR_MODULE / "data" / "parameter-categories.csv"
PATH_CATEGORIES = DIR_MODULE / "data" / "categories.csv"
PATH_SUITABILITY = DIR_MODULE / "data" / "suitability.csv"
PATH_MAP_SCHEMA_TYPES = DIR_MODULE / "data" / "map-IfcMeasure-JsonSchema.csv"


MAP_CIBSE_TO_IFC_DATA_TYPE = {
    "Enumeration": "IfcText",
    "Text": "IfcText",
    "Not defined": "IfcText",
    "URL": "IfcText",
    "Y/N": "IfcBoolean",
    "Number": "IfcReal",
    "Integer": "IfcInteger",
}

MAP_CIBSE_TO_REVIT_DATA_TYPE = {
    "Enumeration": "TEXT",
    "Text": "TEXT",
    "Not defined": "TEXT",
    "URL": "URL",
    "Y/N": "YESNO",
    "Number": "NUMBER",
    "Integer": "INTEGER",
}

MAP_BASEDATA_COLS_TO_AECTEMPLATER_UNITS = {
    "Measure": "physical_quantity",
    "Unit": "name",
    "Symbol": "symbol",
    "UnytDerivation": "code",
}


def read_csv(p: pathlib.Path):
    # NOTE: could use pandas for this but it is a heavy dep for reading a csv
    li = list(csv.reader(p.read_text().split("\n"), delimiter=","))
    return [dict(zip(li[0], li[n])) for n in range(1, len(li)) if li[n] != []]


def get_map_schema_types() -> dict:
    li = list(csv.reader(PATH_MAP_SCHEMA_TYPES.read_text().split("\n"), delimiter=","))
    return {li[n][0]: json.loads(li[n][1]) for n in range(1, len(li)) if li[n] != []}


def eval_is_physical_quantity(li: list) -> list:
    eval_bool = lambda s: eval(stringcase.titlecase(s.lower()))
    for l in li:
        l["IsPhysicalQuantity"] = eval_bool(l["IsPhysicalQuantity"])
    return li


def read_csv_eval_is_physical_quantity(p: pathlib.Path) -> list:
    # NOTE: could use pandas for this but it is a heavy dep for reading a csv
    li = read_csv(p)
    fix = lambda l: l | {"UnytDerivation": ""} if l["UnytDerivation"] == "-" else l
    li = [fix(l) for l in li]
    return eval_is_physical_quantity(li)


def get_units_extended_data() -> list:
    return read_csv_eval_is_physical_quantity(PATH_UNITS_EXTENDED_DATA)


def get_units_base_data() -> list:
    return read_csv_eval_is_physical_quantity(PATH_UNITS_BASE_DATA)


def get_revit_measurable_specs() -> list:
    li = read_csv(PATH_REVIT_SPECS_MEASURABLE)
    return [di["RevitDataType"] for di in li]


def get_revit_non_measurable_specs() -> list:
    li = read_csv(PATH_REVIT_SPECS_NON_MEASURABLE)
    return [di["RevitDataType"] for di in li]


def get_data_revit(base_data=None) -> list:
    li = read_csv(PATH_REVIT_SPECS_MEASURABLE)

    if base_data is not None:  # Append IfcMeasure onto data where mapping exists
        map_ifc_measure = {l["Measure"]: l["IfcMeasure"] for l in base_data}
        for l in li:
            try:
                l["IfcMeasure"] = map_ifc_measure[l["Measure"]]
            except:
                l["IfcMeasure"] = ""

    return li + read_csv(PATH_REVIT_SPECS_NON_MEASURABLE)


def get_revit_group_parameters() -> list:
    return read_csv(PATH_REVIT_GROUP_PARAMETERS)


def list_from_csv(path):
    with open(path, "r") as f:
        reader = csv.reader(f)
        li = [row for row in reader]
    return list(itertools.chain(*li))


def get_parameter_categories() -> list:
    return [
        {
            "Category": di["Category"] if di["Category"] else di["RevitCategory"],
            "RevitGroupParameterName": di["RevitGroupParameterName"],
        }
        for di in read_csv(PATH_PARAMETER_CATEGORIES)
    ]


# TODO: Deprecate: https://github.com/maxfordham/digital-schedules/issues/195
def get_categories() -> list:
    return list_from_csv(PATH_CATEGORIES)


def get_suitability() -> list:
    return list_from_csv(PATH_SUITABILITY)


def get_map_cibse_to_unyt() -> dict:
    return read_csv(PATH_MAP_CIBSE_UNITS)


def get_map_IfcSimple_to_revit() -> dict:
    return {
        l["IfcSimple"]: l["RevitDataType"]
        for l in read_csv(PATH_MAP_IFCSIMPLE_TO_REVIT)
    }


def get_map_physical_quantity_to_revit() -> dict:
    return {
        l["Measure"]: l["RevitDataType"]
        for l in read_csv(PATH_MAP_MEASURE_TO_REVIT_TYPE)
    }


def map_names(data) -> list:
    m = MAP_BASEDATA_COLS_TO_AECTEMPLATER_UNITS
    fn_map = lambda s: m[s] if s in m.keys() else s
    return [{fn_map(k): v for k, v in d.items()} for d in data]


class UnitsBaseData:  # TODO: Rename class. This is not just for Units data.
    def __init__(self):
        self.data = get_units_base_data()
        self.data_extended = get_units_extended_data()
        self.data_ = map_names(self.data + self.data_extended)
        self.data_revit = get_data_revit(base_data=self.data)
        self.map_cibse_to_unyt = get_map_cibse_to_unyt()
        self.map_ifcsimple_to_revit = get_map_IfcSimple_to_revit()
        self.map_physical_quantities_to_revit_type = (
            get_map_physical_quantity_to_revit()
        )
        self.map_schema_types = get_map_schema_types()
        self.revit_measurable_specs = get_revit_measurable_specs()
        self.revit_non_measurable_specs = get_revit_non_measurable_specs()
        self.revit_group_parameters = get_revit_group_parameters()
        self.li_all_revit_specs = (
            self.revit_measurable_specs + self.revit_non_measurable_specs
        )
        self.li_categories = get_categories()
        self.li_parameter_categories = get_parameter_categories()
        self.li_suitability = get_suitability()
        self.measures = [l for l in self.data if l["IsPhysicalQuantity"]]
        self.li_physical_quantities = [l["Measure"] for l in self.measures]
        self.li_revit_simple_datetypes = [
            "TEXT",
            "INTEGER",
            "NUMBER",
            "YESNO",
            "MULTILINETEXT",
            "URL",
        ]

    @property
    def map_cibse_to_unitsbase(self):
        return {
            l["cibse_name"]: {k: v for k, v in l.items() if k != "cibse_name"}
            for l in self.map_cibse_to_unyt
        }

    @property
    def map_unyt_code_to_unit_names(self):
        return {l["UnytDerivation"].replace(" ", ""): l["Measure"] for l in self.data}

    # def map_unyt_to_unitsbase(self):
    #     map_colnm = lambda colnm: MAP_BASEDATA_COLS_TO_AECTEMPLATER_UNITS[colnm]
    #     cols = MAP_BASEDATA_COLS_TO_AECTEMPLATER_UNITS.keys()
    #     return {u.Unit(l['UnytDerivation']): {map_colnm(k):v for k, v in l.items() if k in cols} for l in self.data}

    # @property
    # def map_cibse_to_unitsbase(self):
    #     map_unyt_to_unitsbase = self.map_unyt_to_unitsbase()
    #     def map_units(s):
    #         try:
    #             return map_unyt_to_unitsbase[u.Unit(s)]
    #         except:
    #             pass
    #     return {k : map_units(v) for k, v in self.map_cibse_to_unyt.items()}

    @property
    def map_revit_type_to_physical_quantities(self):
        return {l["RevitDataType"]: l["Measure"] for l in self.data_revit}

    @property
    def map_revit_type_to_ifc(self):
        return {l["RevitDataType"]: l["IfcMeasure"] for l in self.data_revit}

    @property
    def map_revit_type_to_default_unit(self):
        di = {}
        for v in self.data_revit:
            if not v["UnytDerivationSi"]:
                continue
            if not v["DefaultUnit"]:
                default_unit = v["UnytDerivationSi"]
            else:
                default_unit = v["DefaultUnit"]
            di[v["RevitDataType"]] = default_unit
        return di

    @property
    def map_ifc_measure_to_physical_quantities(self):
        return {l["IfcMeasure"]: l["Measure"] for l in self.measures}

    @property
    def map_physical_quantities_to_ifc_measure(self):
        return {l["Measure"]: l["IfcMeasure"] for l in self.measures}

    @property
    def map_simple_measure_to_revit(self):
        _map = {l["IfcMeasure"]: l["Measure"] for l in self.data}
        return {_map[k]: v for k, v in self.map_ifcsimple_to_revit.items()}

    @property
    def map_ifc_measure_to_docs(self):
        return {
            l["IfcMeasure"]: l["IfcType URL"]
            for l in self.data
            if l["IfcType URL"] != ""
        }

    @property
    def map_unyt_to_physical_quantity(self):
        return {l["UnytDerivation"]: l["Measure"] for l in self.data}

    @property
    def map_measure_to_ifc(self):
        return {l["Measure"]: l["IfcMeasure"] for l in self.data}

    @property
    def revit_project_units(self):
        revit_specs_measurable = read_csv(PATH_REVIT_SPECS_MEASURABLE)
        return [
            {
                "RevitSpecType": l["RevitSpecType"],
                "RevitUnitType": l["RevitUnitType"],
                "RevitSymbolType": (
                    l["RevitSymbolType"] if l["RevitSymbolType"] else None
                ),
            }
            for l in revit_specs_measurable
            if l["RevitUnitType"] and l["RevitSpecType"]
        ]

    @property
    def li_revit_types(self):
        return [l["RevitDataType"] for l in self.data_revit]

    @property
    def li_ifc_types(self):
        all_data = self.data + self.data_extended
        return list(set([l["IfcMeasure"] for l in all_data if l["IfcMeasure"] != ""]))

    @property
    def li_ifc_basetypes(self):
        return [l["IfcMeasure"] for l in self.data if not l["IsPhysicalQuantity"]]

    @property
    def li_ifc_physical_quantities(self):
        return [""] + [
            l["Measure"]
            for l in self.data
            if l["IsPhysicalQuantity"] and "Measure" in l["IfcMeasure"]
        ]

    @property
    def li_alltypes(self):
        return [""] + [l["Measure"] for l in self.data]

    @property
    def li_basetypes(self):
        return [l["Measure"] for l in self.data if not l["IsPhysicalQuantity"]]

    @property
    def ifc_types_enum(self):
        _ = self.li_ifc_types
        return dict(zip(_, _))

    @property
    def revit_types_enum(self):
        li_all_revit_specs_lower = [spec.lower() for spec in self.li_all_revit_specs]
        return dict(zip(li_all_revit_specs_lower, self.li_all_revit_specs))

    @property
    def categories_enum(self):
        li_categories_lower = [
            stringcase.snakecase(category.lower()).replace("/", "_")
            for category in self.li_categories
        ]
        return dict(zip(li_categories_lower, self.li_categories))

    @property
    def sections_enum(self):
        li_parameter_categories_lower = [
            stringcase.snakecase(
                di["Category"]
                .lower()
                .replace("-", "")
                .replace("/", "")
                .replace("  ", " ")
                .replace("&", "and")
            )
            for di in self.li_parameter_categories
        ]
        return dict(
            zip(
                li_parameter_categories_lower,
                [di["Category"] for di in self.li_parameter_categories],
            )
        )

    @property
    def suitability_enum(self):
        li_suitability_lower = [
            stringcase.snakecase(l.lower()) for l in self.li_suitability
        ]
        return dict(zip(li_suitability_lower, self.li_suitability))

    @property
    def physical_quantities_enum(self):
        return dict(
            zip(
                [stringcase.snakecase(l) for l in self.li_physical_quantities],
                self.li_physical_quantities,
            )
        )


if __name__ == "__main__":
    UDATA = UnitsBaseData()
    print("done")
