import typing as ty
import pathlib
from pydantic import field_validator, Field
from aectemplater_schemas.constants import FPTH_ENV
from pydantic_settings import BaseSettings, SettingsConfigDict

FDIR_SYMBOLS_TESTING = pathlib.Path(__file__).parents[2] / "tests" / "symbols"


class Env(BaseSettings):
    URL_ABBREVIATIONS: str = Field(
        "https://raw.githubusercontent.com/theodi/BDNS/master/BDNS_Abbreviations_Register.csv",
        description="URL to abbreviations registry",
    )
    URL_ABBREVIATIONS_FOR_USER: str = Field(
        "https://github.com/theodi/BDNS/blob/master/BDNS_Abbreviations_Register.csv",
        description="URL to abbreviations registry for user error explanation",
    )
    DEFAULT_ORG: str = Field("MXF", description="default organization")  #
    FDIR_SYMBOLS: ty.Optional[pathlib.Path] = Field(
        FDIR_SYMBOLS_TESTING, description="path to symbols"
    )

    @field_validator("FDIR_SYMBOLS")
    @classmethod
    def _get_symbols_dir(cls, v):
        if v is not None:
            if v == pathlib.Path("."):
                return None
            elif v.is_absolute():
                return v
            else:
                return v.absolute().resolve()

    model_config = SettingsConfigDict(env_file=FPTH_ENV, env_file_encoding="utf-8")
