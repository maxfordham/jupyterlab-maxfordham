"""filter rules for creating filtered views of geometry and documents"""

from pyrulefilter.schemas import RuleSet

from aectemplater_schemas.basemodel import BaseModel, Field
from aectemplater_schemas.enumerations import ParameterTypeEnum, UseTypeEnum


class Filter(BaseModel):
    name: str = Field(title="Name", description="Name of the filter")
    version: int = Field(
        1,
        title="Version",
        description="Version of the filter",
        json_schema_extra=dict(disabled=True),
    )
    rule_set: RuleSet = Field(
        title="Rule Set",
        json_schema_extra=dict(show_title=False, show_description=False),
    )
    use_type: UseTypeEnum = Field(
        title="Use Type",
        description="The use type of the filter",
        json_schema_extra=dict(column_width=125, disabled=True),
    )
    parameter_type: ParameterTypeEnum = Field(
        title="Parameter Type",
        description="The parameter type of the filter. This will determine whether to filter on type or instance data.",
        json_schema_extra=dict(column_width=115, disabled=True),
    )
