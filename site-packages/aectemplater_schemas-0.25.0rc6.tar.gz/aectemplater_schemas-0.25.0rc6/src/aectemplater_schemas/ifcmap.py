import typing as ty
from pydantic import Field

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.propertyset import IfcMapPset


class IfcMap(BaseModel):
    psets: ty.List[IfcMapPset] = Field(
        [],
        title="Property Sets",
        description="ty.List of PropertySets within the IFC Mapping file.",
    )
