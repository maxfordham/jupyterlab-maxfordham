import re
import pathlib
from typing import Literal
from PIL import Image, ExifTags
from pydantic import model_validator, computed_field, create_model

from document_issue.basemodel import BaseModel

from aectemplater_schemas.tag_template import TypeTagDataBase

PREVIEW_TO_PAGE_RATIO = 800 / 172  # Ratio defined to set images height appropriately
DEFAULT_HEIGHT_PERCENTAGE = 30
DEFAULT_HEIGHT = round(PREVIEW_TO_PAGE_RATIO * DEFAULT_HEIGHT_PERCENTAGE, 2)


TypeTagDataBaseModel = create_model(
    "TypeTagDataBaseModel",
    **{k: (v, ...) for k, v in TypeTagDataBase.__annotations__.items()},
)


class ImagePrefix(TypeTagDataBaseModel):
    @computed_field
    @property
    def image_prefix(self) -> str:
        return f"{self.abbreviation}-{self.type_reference}"


class Exif:
    """Simple python handler for exif data. has read and write functions for editing the data.
    exif tags have a number and description that is expressed as a dict in ExifTags.TAGS.
    in the dict passed to the write method the key can either be the numeric tag or string description.

    Reference:
        https://stackoverflow.com/questions/4764932/in-python-how-do-i-read-the-exif-data-for-an-image
        https://www.exiv2.org/tags.html

        269  : 'DocumentName',
        270  : 'ImageDescription',
        40091: 'XPTitle',
        40092: 'XPComment',
        40093: 'XPAuthor',
        40094: 'XPKeywords',
        40095: 'XPSubject',
        37510: 'UserComment',
        40962: 'ExifImageWidth',
        40963: 'ExifImageHeight',

    Example:
        fpth = 'images/cibseBIMhawk-xml-to-xlsx-icon.png'
        img_exif = Exif(fpth)
        img_exif.write({'ImageDescription':'a description of the iamge'})
    """

    def __init__(self, fpth: pathlib.Path):
        self.fpth = fpth
        self.img = Image.open(fpth)

    @property
    def tag_map(self):
        return {v: k for k, v in ExifTags.TAGS.items()}

    def read(self, astags=True):
        self.img = Image.open(self.fpth)
        exif_data = self.img._getexif()
        if astags:
            try:
                exif = {
                    ExifTags.TAGS[k]: v
                    for k, v in self.img._getexif().items()
                    if k in ExifTags.TAGS
                }
            except:
                exif = {}
        else:
            exif = exif_data
        return exif

    def write(self, exifdata: dict):
        exif = self.img.getexif()
        for k, v in exifdata.items():
            key = k
            if type(k) == str:
                key = self.tag_map[k]
            exif[key] = v
        self.img.save(self.fpth, exif=exif)


class PdtImageExifMap(BaseModel):
    """When saving metadata to images this is how the data maps to image exif data"""

    caption: Literal["UserComment"] = "UserComment"
    width: Literal["ExifImageWidth"] = "ExifImageWidth"
    height: Literal["ExifImageHeight"] = "ExifImageHeight"


class PdtImage(ImagePrefix):
    fpth: pathlib.Path
    caption: str = ""
    width: str = None
    height: str = f"{DEFAULT_HEIGHT}px"

    @model_validator(mode="before")
    @classmethod
    def validate_model(cls, data: dict) -> dict:
        if "fpth" not in data.keys():
            raise ValueError("fpth is a required field")
        if not re.match(r"^.+\-\d+__.+\.png$", data["fpth"].name):
            raise ValueError(
                "fpth must follow the pattern 'STRING-INT__sdsdfkdjfl.png'"
            )
        abbreviation, type_reference = data["fpth"].name.split("__")[0].rsplit("-", 1)
        if "abbreviation" not in data.keys():
            data["abbreviation"] = abbreviation
        if "type_reference" not in data.keys():
            data["type_reference"] = type_reference
        return data

    @classmethod
    def from_fpth(cls, fpth: pathlib.Path):
        img_exif = Exif(str(fpth))
        di_img_exif_data = img_exif.read()
        di_img_exif_data = {
            i: di_img_exif_data[j]
            for i, j in PdtImageExifMap()
            if j in di_img_exif_data.keys()
        }
        return cls(fpth=fpth, **di_img_exif_data)

    def write_exif(self) -> Exif:
        di_exif_data = {
            j: getattr(self, i)
            for i, j in PdtImageExifMap()
            if getattr(self, i) is not None
        }
        img_exif = Exif(self.fpth)
        img_exif.write(di_exif_data)
        return img_exif
