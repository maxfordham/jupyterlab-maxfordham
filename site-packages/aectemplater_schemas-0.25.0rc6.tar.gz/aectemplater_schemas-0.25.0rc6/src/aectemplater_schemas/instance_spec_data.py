import typing as ty
from pydantic import Field

from aectemplater_schemas.basemodel import BaseModel


class InstanceSpecData(BaseModel):
    value: ty.Any = Field(None)
