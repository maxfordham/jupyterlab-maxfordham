from aectemplater_schemas.basemodel import BaseModel
from document_issue.document_issue import DocumentIssue
from pydantic import ConfigDict
import typing as ty


class IssueBase(BaseModel):
    """Stores the docheader for a project/job and therefore links to the project
    and its version."""

    project_revision_id: int
    document_id: int
    issue_data: ty.Optional[DocumentIssue] = None  # TODO: should this be req.?


class Issue(IssueBase):
    pass
