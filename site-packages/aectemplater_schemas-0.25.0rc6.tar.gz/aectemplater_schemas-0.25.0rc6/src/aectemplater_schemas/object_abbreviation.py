from pydantic import ConfigDict, Field
import typing as ty
from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.abbreviation import Abbreviation


class ObjectAbbreviationBase(BaseModel):
    is_default: bool = Field(
        False,
        description=(
            "Define which Abbreviation should be used as default for a given"
            " Property Set."
        ),
    )


class ObjectAbbreviation(ObjectAbbreviationBase):
    """Defines the link between a Property Set and its Abbreviation.
    A default Abbreviation can be defined for a Property Set using (`is_default`).
    """

    abbreviation: ty.Optional[Abbreviation] = Field(
        None,
        title="Abbreviation",
        description="Abbreviations linking to a Property Set",
    )  # TODO: should this be req.?


class ObjectAbbreviationShort(ObjectAbbreviationBase, Abbreviation):
    pass
