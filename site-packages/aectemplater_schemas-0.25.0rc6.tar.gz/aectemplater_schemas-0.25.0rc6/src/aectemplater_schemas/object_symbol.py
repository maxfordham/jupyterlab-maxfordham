from pydantic import ConfigDict, Field
import typing as ty
from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.symbol import Symbol


class ObjectSymbolBase(BaseModel):
    is_default: bool = Field(
        False,
        description=(
            "Define which Symbol should be used as default for a given Property Set."
        ),
    )


class ObjectSymbol(ObjectSymbolBase):
    """Defines the link between a Property Set and its Symbol.
    A default Symbol can be defined for a Property Set using (`is_default`).
    """

    symbol: ty.Optional[Symbol] = Field(
        None,  # TODO: should this be a placeholder svg ?
        title="Symbol",
        description="Symbols linking to a Property Set",
    )


class ObjectSymbolShort(ObjectSymbolBase, Symbol):
    pass
