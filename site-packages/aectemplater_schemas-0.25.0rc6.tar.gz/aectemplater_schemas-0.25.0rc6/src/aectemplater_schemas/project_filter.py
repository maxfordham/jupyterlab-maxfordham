import typing as ty

from pyrulefilter.schemas import RuleSet

from aectemplater_schemas.basemodel import BaseModel, Field
from aectemplater_schemas.enumerations import ParameterTypeEnum, UseTypeEnum
from aectemplater_schemas.filters import Filter
from aectemplater_schemas.project_revision import ProjectRevision


class ProjectFilterBase(BaseModel):
    name: ty.Optional[str] = None
    rule_set: ty.Optional[RuleSet] = Field(
        None, json_schema_extra=dict(show_title=False, show_description=False)
    )
    use_type: UseTypeEnum = Field(
        title="Use Type",
        description="The use type of the filter",
        json_schema_extra=dict(column_width=170),
    )
    parameter_type: ParameterTypeEnum = Field(
        title="Parameter Type",
        description="The parameter type of the filter. This will determine whether is filters on type or instance data.",
        json_schema_extra=dict(column_width=170),
    )


class ProjectFilter(ProjectFilterBase):
    filter: ty.Optional[Filter] = Field(None)
    project_revision: ty.Optional[ProjectRevision] = Field(None)
