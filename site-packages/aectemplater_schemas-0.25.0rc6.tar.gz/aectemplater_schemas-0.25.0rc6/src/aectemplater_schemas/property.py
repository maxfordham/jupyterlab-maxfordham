"""
a core feature of the `aectemplater` is to provide clear mapping between information
management systems (i.e. BSDD, Revit, CIBSE, IFC) that share many, but not all, of the
same terms. This lead us to split the property attributes into abstract bases, where
the main "Property" definition inherits all, while others can inherit subsets.
"""

import uuid
import copy
import stringcase
import typing as ty
from datetime import datetime
from pydantic import (
    Field,
    field_validator,
    BeforeValidator,
    AfterValidator,
    model_validator,
    model_serializer,
    HttpUrl,
    field_serializer,
)
from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.enumerations import (
    RevitDataTypeEnum,
    StatusEnum,
    CategoriesEnum,
    SectionsEnum,
    IfcTypeEnum,
    PropertyValueKindEnum,
    JsonDataTypeEnum,
    MAP_TYPES,
)
from aectemplater_schemas.enumerations import ParameterTypeEnum
from aectemplater_schemas.units import PhysicalQuantity
from aectemplater_schemas.utils import (
    is_guid,
    get_name_from_title,
    is_alphanumeric_with_underscore_and_fullstop,
)
from aectemplater_schemas.env import Env
from aectemplater_schemas.data.utils import UnitsBaseData

UDATA = UnitsBaseData()
ENV = Env()


class _P0(BaseModel):
    """root. used for all parents"""

    title: str = Field(
        "",
        title="Title",
        description=(
            "Title of the Property."
            " Title Case. Include spaces and caps as appropriate."
            " This is the name that will be used in the output document."
        ),
        json_schema_extra=dict(column_width=250),
    )
    name: str = Field(
        "",
        title="Name",
        description=(
            "Unique name of property. PascalCase. Used in Revit."
            " Cannot be modified after the property"
            " has been created and defined as 'active'."
        ),
        json_schema_extra=dict(column_width=250, disabled=True),
    )
    definition: ty.Optional[str] = Field(
        "",
        title="Definition",
        description="Definition of the Property.",
        json_schema_extra=dict(
            is_ifc=True, column_width=100, autoui="ipywidgets.Textarea"
        ),
    )
    json_schema_extra: ty.Optional[dict] = Field(
        None,
        title="JSON Schema Extra",
        description="Extra JSON Schema for the property.",
        json_schema_extra={"autoui": "ipyautoui.custom.JsonableDict"},
    )

    @model_validator(mode="after")
    def check_name_and_title(self) -> "Property":
        """Check name is alphanumeric. If not, generate from title.
        Note: IFC properties are already alphanumeric (with underscore) so they should pass the
        validation. Reference: https://standards.buildingsmart.org/IFC/DEV/IFC4_3/RC1/HTML/schema/ifcmeasureresource/lexical/ifcidentifier.htm
        """
        if self.name == "" or self.name is None:
            self.name = get_name_from_title(self.title)
        elif is_alphanumeric_with_underscore_and_fullstop(self.name):
            if (
                self.title == "" or self.title is None
            ):  # If title is empty, generate from name
                self.title = stringcase.titlecase(self.name)
        else:
            raise ValueError(
                "Name must be alphanumeric. Underscores and fullstops also permitted."
            )
        return self


class _P01(BaseModel):
    guid: str = Field(
        "",
        validate_default=True,
        title="GUID",
        description=(
            "Global unique identifier for property."
            " Cannot be modified after the property has been created."
            " Facilitates sharing across Revit Models."
        ),
        json_schema_extra=dict(column_width=60, disabled=True),
    )
    guid_source: str = Field(
        ENV.DEFAULT_ORG,
        title="GUID Source",
        description=(
            "The source of the GUID e.g. bsDD, BimHawk, MF."
            " If the parameter / GUID doesn't already exist it is created etc."
        ),
        json_schema_extra=dict(column_width=110, disabled=True),
    )

    @field_validator("guid")
    @classmethod
    def check_guid(cls, v):
        if is_guid(v):
            return v
        else:
            return str(uuid.uuid4())


class _P1(_P0, _P01):
    """categories and notes. used in PropertySchema and Property but not
    IfcMapProperty"""

    category: CategoriesEnum = Field(
        CategoriesEnum.undefined,
        title="Category",
        json_schema_extra=dict(
            description="Category of the property e.g. Specifications. Taken from CIBSE.",
            is_cibse=True,
            column_width=200,
        ),
    )
    section: SectionsEnum = Field(
        SectionsEnum.undefined,
        title="Section",
        description=(
            "The section the property belongs in e.g. Sustainability."
            " Taken from CIBSE. Used for formatting output PDF document."
        ),
        json_schema_extra=dict(is_cibse=True, column_width=180),
    )
    notes: ty.Optional[str] = Field(
        None,
        title="Notes",
        description="add contextual notes for the user here",
        json_schema_extra=dict(column_width=400, autoui="ipywidgets.Textarea"),
    )
    property_value_kind: PropertyValueKindEnum = Field(
        PropertyValueKindEnum.single,
        title="Property Value Kind",
        json_schema_extra=dict(is_ifc=True, column_width=150),
    )

    @field_validator("section")
    @classmethod
    def _section(cls, v):
        # NOTE: Needs discussion or investigation -@jovyan at 9/9/2022, 12:16:23 PM
        # fixes bug in "Ducted Fume Cupboard" cibse pdt. I think this is an error
        # as COBie Data is normally listed in the "Category" section.
        if v == "COBie Data":
            v = "Operations & Maintenance"
        return v

    @field_validator("section")
    @classmethod
    def _section_not_in_enum(cls, v):
        # NOTE: Needs discussion or investigation -@jovyan at 9/9/2022, 12:16:23 PM
        # fixes bug in "Ducted Fume Cupboard" cibse pdt
        if v not in list(SectionsEnum) and [l.value for l in list(SectionsEnum)]:
            v = SectionsEnum.undefined
        return v

    @field_validator("category")
    @classmethod
    def _category_not_in_enum(cls, v):
        if v not in list(CategoriesEnum) and [l.value for l in list(CategoriesEnum)]:
            v = CategoriesEnum.undefined
        return v


HttpUrlString = ty.Annotated[HttpUrl, AfterValidator(str)]


class _P_Ifc(BaseModel):
    """used in IfcMapProperty and Property but not
    PropertySchema"""

    ifc_data_type: IfcTypeEnum = Field(
        IfcTypeEnum.IfcText,
        title="IFC Data Type",
        description=(  # TODO Consider how this maps to json_data_type.
            "The datatype the property is expressed in. Must be one of: Boolean,"
            " Character, Integer, Real, String, Time."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=140, disabled=True),
    )
    namespace_uri: ty.Annotated[
        ty.Optional[HttpUrlString], BeforeValidator(lambda x: None if x == "" else x)
    ] = Field(
        None,
        title="Uri",
        description=(
            "Globally unique identifier which is a hyperlink for the building smart"
            " API."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=5),
    )


class _P_JsonSchema(BaseModel):
    # TODO: Potentially use model_config = ConfigDict(extra="allow") once https://github.com/pydantic/pydantic/issues/4840 is resolved
    type: JsonDataTypeEnum = Field(
        JsonDataTypeEnum.string,
        title="JSON Data Type",
        description="JSON Schema type.",
        json_schema_extra=dict(column_width=150),
    )
    format: ty.Optional[str] = Field(None, description="JSON Schema format.")

    # TODO: Update before model_validator to populate json_schema_extra appropriately with extra json fields
    @model_validator(mode="after")
    def _type(self):
        try:
            update = MAP_TYPES[self.ifc_data_type]
            for k, v in update.items():
                setattr(self, k, v)
            return self
        except:
            return self


class _P2(_P0, _P_Ifc):
    """used in IfcMapProperty and Property but not PropertySchema"""

    pass
    # TODO: Tasks pending completion -@jovyan at 8/24/2022, 1:38:56 PM
    # should this be ifc_measure_type ?


class _P_Revit(BaseModel):
    revit_data_type: RevitDataTypeEnum = Field(
        RevitDataTypeEnum.text,
        title="Revit Data Type",
        description=(
            "The data type that will be used in the Shared Parameter file for Revit so"
            " imported shared parameters have the correct data type and unit within"
            " Revit."
        ),
        json_schema_extra=dict(column_width=150, disabled=True),
    )


class _P_allowed_values(BaseModel):
    allowed_values: ty.Optional[ty.List[ty.Union[str, int, float]]] = Field(
        None,
        title="Allowed Values",
        description=(
            "A list of allowed values for the property. If the property is a list,"
            " this should be a list of lists."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=150),
    )

    @field_validator("allowed_values")
    def _allowed_values(cls, v):
        if v == []:
            return None
        else:
            return v


class _P3(_P0, _P01, _P_Revit):
    pass


class PropertySchema(_P1, _P_Ifc, _P_Revit, _P_JsonSchema, _P_allowed_values):
    unit: str = Field(
        "",
        title="Unit Symbol",
        description="The unit symbol assigned to the Property.",
        json_schema_extra={"column_width": 150},
    )
    unit_code: str = Field(
        "",
        title="Unit Code",
        description="The unit code assigned to the Property.",
        json_schema_extra={"column_width": 150},
    )
    parameter_type: ty.Optional[ParameterTypeEnum] = Field(
        None,
        title="Parameter Type",
        description="The type of parameter the Property is.",
        json_schema_extra={"column_width": 150},
    )
    pset: str = Field(
        "",
        title="Property Set",
        description="Property Set code that the Property belongs to within the object.",
        json_schema_extra=dict(is_ifc=True, column_width=200),
    )
    pattern: ty.Optional[str] = Field(
        None,
        title="Pattern",
        description="A regex pattern that the property value must conform to.",
        json_schema_extra={"column_width": 200},
    )

    # TODO: Fix implementation of property_value_kind determining type
    # @model_validator(mode="after")
    # def _type(self):
    #     update = copy.copy(MAP_TYPES[self.ifc_data_type])
    #     if (
    #         self.property_value_kind == PropertyValueKindEnum.range
    #         or self.property_value_kind == PropertyValueKindEnum.list
    #     ):
    #         update["type"] = "array"
    #     for k, v in update.items():
    #         setattr(self, k, v)
    #     return self

    @model_serializer
    def serialise_model(self):
        """When dumping to JSON, change `schema` to `$schema`."""
        from aectemplater_schemas.data.required_properties import REQUIRED_PROPERTIES

        MAP_NAMES = {
            "definition": "description",
            "notes": "tooltip",
            "allowed_values": "enum",
        }
        model_dict = {MAP_NAMES.get(k, k): v for k, v in dict(self).items()}
        if not self.allowed_values:
            model_dict.pop("enum")
        if not self.format:
            model_dict.pop("format")
        if not self.pattern:
            model_dict.pop("pattern", None)
        if self.json_schema_extra is not None:
            model_dict = model_dict | self.json_schema_extra
        model_dict.pop("json_schema_extra")
        if self.name not in REQUIRED_PROPERTIES and self.name != "TypeMark":
            # TODO: Fix implementation of enum determining item type for array
            # NOTE: This links to the TODO in the _type model_validator
            # if "enum" in model_dict.keys() and model_dict["type"] == "array":
            #     model_dict["anyOf"] = [
            #         {"items": {"enum": model_dict["enum"]}, "type": model_dict["type"]},
            #         {"type": "null"},
            #     ]
            #     del model_dict["enum"]
            model_dict["anyOf"] = [{"type": model_dict["type"]}, {"type": "null"}]
            del model_dict["type"]
        return model_dict


class IfcMapProperty(_P2):
    revit_name: str = Field(
        "",
        description="OPTIONAL: Revit parameter name, if different from IFC Property",
        title="Revit Parameter Name",
    )


class SharedParam(_P1, _P3):
    data_category: str = Field(
        "",
        title="Data Category",
        description=(
            "Used when the Datatype is a <Family Type> Parameter Type, identifies the"
            " Family Category for the Family Type. Typically at Max Fordham we do not"
            " use Family parameters so this DATACATEGORY field is blank."
        ),
    )
    hide_when_no_value: bool = Field(
        True,
        title="Hide When No Value",
        description=(
            "Controls whether the parameter will be visible or not in the Properties"
            " palette in a project if the parameter is blank."
        ),
    )
    user_modifiable: bool = Field(
        True,
        title="User Modifiable",
        description=(
            "Identifies whether the parameter is editable by the user within the"
            " Properties palette."
        ),
    )
    visible: bool = Field(
        ...,
        title="Visible",
        description=(
            "Identifies whether the parameter is visible to the user in the Properties"
            " palette."
        ),
    )


class Property(PhysicalQuantity, _P1, _P2, _P3, _P_allowed_values):
    """Explicitly defines a property term such that it can be robustly used for the
    specification of information."""

    status: StatusEnum = Field(
        StatusEnum.active,
        title="Status",
        description="Status of the Property: “Active” (default) or “Inactive”",
        json_schema_extra=dict(is_ifc=True, column_width=90),
    )
    activation_date_utc: ty.Optional[datetime] = Field(
        datetime.now(),
        title="Activation Date UTC",
        description=(
            "The date of the property's activation in Coordinated Universal Time."
        ),
        json_schema_extra=dict(is_ifc=True, disabled=True, column_width=150),
    )
    deactivation_date_utc: ty.Optional[datetime] = Field(
        None,
        title="Deactivation Date UTC",
        description=(
            "The date of the property's deactivation in Coordinated Universal Time."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=150, disabled=True),
    )
    revision_date_utc: ty.Optional[datetime] = Field(
        None,
        title="Revision Date UTC",
        description=(
            "The date of the property's revision in Coordinated Universal Time."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=150, disabled=True),
    )
    revision_number: int = Field(
        1,
        title="Rev",
        description=(
            "The property's revision number. After a property has been made"
            " 'Active' this this can increase incrementally with changes to the other"
            " fields. `GUID` and `name` cannot change after `status` becomes 'Active'"
        ),
        json_schema_extra=dict(is_ifc=True, column_width=10, disabled=True),
    )
    example: str = Field(
        "",
        title="Example",
        description="Example of the Property.",
        json_schema_extra=dict(is_ifc=True, column_width=120),
    )
    connected_property_codes: ty.List[str] = Field(
        [],
        title="Connected Property Codes",
        description="ty.List of codes of connected properties.",
        json_schema_extra=dict(is_ifc=True, column_width=200),
    )
    method_of_measurement: str = Field(
        "",
        title="Method of Measurement",
        description="E.g. “Thermal transmittance according to ISO 10077-1”.",
        json_schema_extra=dict(is_ifc=True, column_width=160),
    )
    is_dynamic: bool = Field(
        False,
        title="Is Dynamic",
        description=(
            "If this is a dynamic property, the value is dependent on the parameters"
            " provided in field Dynamic Parameter Properties."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=100),
    )
    dynamic_parameter_property_codes: str = Field(
        "",
        title="Dynamic Parameter Property Codes",
        description=(
            "ty.List of codes of properties which are parameters of the function for a"
            " dynamic property."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=240),
    )
    is_instance: bool = Field(
        False,
        title="Is Instance",
        description=(
            "If true, property is an instance property, otherwise it is a type property."
        ),
        json_schema_extra=dict(column_width=100),
    )

    @field_validator("activation_date_utc")
    def _activation_date_utc(cls, v):
        if v == "":
            v = None

        if v is None:
            v = datetime.now()
        return v

    @field_validator("deactivation_date_utc")
    def _deactivation_date_utc(cls, v):
        if v == "":
            v = None
        return v

    @field_validator("revision_date_utc")
    def _revision_date_utc(cls, v):
        if v == "":
            v = None
        if v is None:
            v = datetime.now()
        return v
