from pydantic import ConfigDict, Field
from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.units import Units
import typing as ty


class PropertyUnitsBase(BaseModel):
    is_default: bool = Field(
        False,
        description="Define what unit should be used as default for a given Property.",
    )


class PropertyUnits(PropertyUnitsBase):
    """Defines the link between a property and its units based on its physical quantity.
    A default unit can also be defined for a property (`is_default`).
    """

    units: ty.Optional[Units] = Field(
        None, title="Units", description="The units that link to the property"
    )
