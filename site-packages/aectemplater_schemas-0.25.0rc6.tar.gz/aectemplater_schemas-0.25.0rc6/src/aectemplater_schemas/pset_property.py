import typing as ty
from pydantic import Field
from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.property import Property
from aectemplater_schemas.units import Units


class PsetProperty(BaseModel):
    properties: Property = Field(  # TODO: name change ? properties -> property
        title="Properties", description="The properties that link to the Pset."
    )
    output_unit: ty.Optional[Units] = Field(
        None,
        title="Output Unit",
        description="The unit that the property should be output in.",
    )
