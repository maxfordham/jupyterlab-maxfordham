import typing as ty
from pydantic import ConfigDict, Field

from aectemplater_schemas.basemodel import BaseModel


class SymbolBase(BaseModel):
    symbol: ty.Optional[str] = Field(
        title="Symbol", description="Filepath of the PNG file."
    )


class Symbol(SymbolBase):
    pass
