import logging
import typing as ty
from pydantic import ConfigDict, Field, validator

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.abbreviation import Abbreviation
from aectemplater_schemas.symbol import Symbol
from aectemplater_schemas.type_spec_data import TypeSpecData


logger = logging.getLogger(__name__)


class TypeSpecificationBase(BaseModel):
    """Used to store property values with a Property Set.

    Based explicitly off of the BDNS Specification:
    https://github.com/theodi/BDNS

    Will concatenate the `asset_abbreviation` field from PropertySets, the
    `type_reference` and the `optional_label_suffix` from TypeSpecification to
    create the asset role name:

    `<asset_abbreviation>-<type_reference>-<optional_label_suffix>`

    The device or asset role name is a human-generated identifier that is unique
    to the building. It combines a standard abbreviation for device/asset types
    and a numerical ID that is unique to each specific device/asset.
    """

    type_reference: int = Field(
        ...,
        description=(
            "integer number for a given product type and project"
            "there may be multiple instances of the same product type"
        ),
    )
    optional_label_suffix: ty.Optional[str] = Field(
        None,
        description=(
            "a free text alphanumeric sequence without underscores and without"
            " white spaces that adds useful information to the label that can"
            " be immediately seen. Text can be hyphenated (-) to represent"
            " floor information, room information, distribution board or"
            " related equipment."
        ),
    )


class TypeSpecification(TypeSpecificationBase):
    abbreviation: Abbreviation
    symbol: ty.Optional[Symbol]
    data: ty.List[TypeSpecData] = Field(
        [],
        title="Property Data",
        description="Values applied to the properties for a Type Specification.",
    )
