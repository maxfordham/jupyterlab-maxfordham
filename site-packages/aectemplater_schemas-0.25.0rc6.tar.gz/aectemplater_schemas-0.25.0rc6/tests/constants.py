import pathlib
from aectemplater_schemas.images import PdtImage

FDIR_TESTS = pathlib.Path(__file__).parent
FDIR_TESTOUTPUT = FDIR_TESTS / "testoutput"

PDT_IMAGE = PdtImage(
    fpth=FDIR_TESTS / "TEST-1__sklWpkSlqubhgycbxjK.png",
    project_number=5001,
    caption="This is a caption",
    height="100px",
)
