import jsonref

from aectemplater_schemas.object import ObjectDataGrid
from aectemplater_schemas.document import DocumentData


def test_document_data():
    """Test example and check if the $schema is present in the model_dump.
    Also check that the dumped object is the same as the original.
    Check that `replace_refs` makes the API call defined in the schema."""
    document_data = DocumentData(
        [
            ObjectDataGrid(
                schema_={
                    "$ref": "https://catfact.ninja/fact?max_length=40"
                },  # Use catfact API as a placeholder
                data=[
                    {"name": "John", "age": 30},
                    {"name": "Jane", "age": 25},
                ],
            ),
            ObjectDataGrid(
                schema_={
                    "$ref": "https://catfact.ninja/fact?max_length=25"
                },  # Use catfact API as a placeholder
                data=[{"name": "Oscar", "age": 35}],
            ),
        ]
    )
    for object_data_grid in document_data.root:
        assert "$schema" in object_data_grid.model_dump().keys()
    assert (
        DocumentData(document_data.model_dump()) == document_data
    )  # Check if the dumped object is the same as the original
    for object_data_grid in jsonref.replace_refs(document_data.model_dump()):
        assert (
            "fact" in object_data_grid["$schema"].keys()
        )  # Check if the catfact API call has been made
