import aectemplater_schemas.filters as f
from aectemplater_schemas.enumerations import ParameterTypeEnum, UseTypeEnum
from pyrulefilter.schemas import FilterCategoriesEnum, OperatorsEnum, Rule, RuleSet


class TestFilters:
    def test_FilterCategoriesEnum(self):
        assert FilterCategoriesEnum.OST_DuctTerminal == "Air Terminals"

    def test_RevitOperatorsEnum(self):
        assert OperatorsEnum.Equals == "equals"

    def test_Rule(self):
        rule = Rule(
            **{
                "categories": ["Air Terminals"],
                "parameter": "TypeMark",
                "operator": "equals",
                "value": "GR1",
            }
        )
        assert (
            rule.model_dump_json()
            == '{"categories":["Air Terminals"],"parameter":"TypeMark","operator":"equals","value":"GR1"}'
        )

    def test_RuleSet(self):
        rule = Rule(
            **{
                "categories": ["Air Terminals"],
                "parameter": "TypeMark",
                "operator": "equals",
                "value": "GR1",
            }
        )
        set = f.RuleSet(set_type="AND", rule=[rule])
        assert set.set_type.value == "AND"
        try:
            set1 = f.RuleSet(set_type="OR", rule=[rule])
            failed = False
            assert failed
        except:
            failed = True
            assert failed

        try:
            set2 = f.RuleSet(set_type="AND", rule=[rule, set])
            failed = False
            assert failed
        except:
            failed = True
            assert failed

    def test_Filter(self):
        rule = Rule(
            **{
                "categories": ["Air Terminals"],
                "parameter": "TypeMark",
                "operator": "equals",
                "value": "GR1",
            }
        )
        set = RuleSet(rule=[rule])
        filt = f.Filter(
            name="Test",
            rule_set=set,
            use_type=UseTypeEnum.equipment,
            parameter_type=ParameterTypeEnum.type,
        )
        assert filt.name == "Test"
        assert filt.rule_set.rule[0].parameter == "TypeMark"
