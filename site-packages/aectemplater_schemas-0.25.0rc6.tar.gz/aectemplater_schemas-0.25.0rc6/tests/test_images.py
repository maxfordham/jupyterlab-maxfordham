import shutil
import pathlib
import pytest

from aectemplater_schemas.images import ImagePrefix, PdtImage, Exif, DEFAULT_HEIGHT

from .constants import FDIR_TESTOUTPUT, PDT_IMAGE


class TestExif:
    def test_write_to_image(self):
        """Test that the Exif class can write to an image."""
        FPTH_IMG = FDIR_TESTOUTPUT / "test_write_to_image.png"
        shutil.copy(PDT_IMAGE.fpth, FPTH_IMG)
        data = {"ImageDescription": "A thrilling image of grill."}
        img_exif = Exif(FPTH_IMG)
        img_exif.write(data)
        assert "ImageDescription" in img_exif.read().keys()
        assert img_exif.read() == data

    def test_write_pdt_exif(self):
        """Test that the Exif class can write to an image from PdtImage."""
        FPTH_IMG = FDIR_TESTOUTPUT / "TEST-2__sjhAopfjFnas34k.png"
        shutil.copy(PDT_IMAGE.fpth, FPTH_IMG)
        pdt_image = PdtImage(
            fpth=FPTH_IMG,
            caption="A glorious caption!",
        )
        pdt_image.write_exif()
        img_exif = Exif(FPTH_IMG)
        assert img_exif.read() == {
            "ExifImageHeight": f"{DEFAULT_HEIGHT}px",
            "UserComment": "A glorious caption!",
        }


class TestPdtImage:
    def test_pdt_image(self):
        """Test that the PdtImage constructs image prefix correctly."""
        pdt_image = PdtImage(fpth=pathlib.Path("TEST-1__sklWpkSlqubhgycbxjK.png"))
        assert pdt_image.abbreviation == "TEST"
        assert pdt_image.type_reference == 1
        assert pdt_image.image_prefix == "TEST-1"

    def test_pdt_image_custom_abbreviation(self):
        """Test that the PdtImage constructs image prefix correctly."""
        pdt_image = PdtImage(fpth=pathlib.Path("TEST-C-1__sklWpkSlqubhgycbxjK.png"))
        assert pdt_image.abbreviation == "TEST-C"
        assert pdt_image.type_reference == 1
        assert pdt_image.image_prefix == "TEST-C-1"

    def test_pdt_image_incorrect_fpth(self):
        """Test that if the fpth is incorrect, an error is raised."""
        with pytest.raises(ValueError):
            PdtImage(fpth=pathlib.Path("TEST__sklWpkSlqubhgycbxjK.jpg"))


class TestImagePrefix:
    def test_image_prefix(self):
        """Test that the ImagePrefix class constructs image prefix correctly."""
        assert (
            ImagePrefix(abbreviation="TEST", type_reference=1).image_prefix == "TEST-1"
        )

    def test_image_prefix_custom_abbreviations(self):
        """Test that the ImagePrefix class constructs image prefix correctly.
        Checking this as we may create custom abbreviations."""
        assert (
            ImagePrefix(abbreviation="TEST-C", type_reference=1).image_prefix
            == "TEST-C-1"
        )
        assert (
            ImagePrefix(abbreviation="TEST_test-TeSt", type_reference=1).image_prefix
            == "TEST_test-TeSt-1"
        )
