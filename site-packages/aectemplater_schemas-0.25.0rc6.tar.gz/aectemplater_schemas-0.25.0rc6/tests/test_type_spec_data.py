from aectemplater_schemas.type_spec_data import (
    TypeSpecData,
)


def test_type_spec_data():
    type_spec_data = TypeSpecData(
        value="test",
    )
    assert type_spec_data.value == "test"

    type_spec_data = TypeSpecData(
        value=1,
    )
    assert type_spec_data.value == 1

    type_spec_data = TypeSpecData(
        value=[1, 2, 3],
    )
    assert type_spec_data.value == [1, 2, 3]
