# aectemplater schemas

Defines the schemas used in the `aectemplater` package.

**Table of Contents**

- [Installation](#installation)

## Development Installation

Follow the instructions in the [Digital Schedules README.md](../../README.md#development-installation) to install the development environment.

