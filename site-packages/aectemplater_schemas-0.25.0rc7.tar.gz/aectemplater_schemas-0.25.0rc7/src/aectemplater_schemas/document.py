import typing as ty

from pydantic import Field, RootModel

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.document_project_filter import DocumentProjectFilter
from aectemplater_schemas.issue import Issue
from aectemplater_schemas.object import ObjectDataGrid
from aectemplater_schemas.project_revision import ProjectRevision
from aectemplater_schemas.type_specification import TypeSpecification


class Document(BaseModel):
    """Used to store the document information such as the filter to be applied,
    the issue to obtain the docheader, and the project version."""

    project_revision: ProjectRevision
    issue: ty.Optional[Issue] = Field(None)
    document_filter: ty.Optional[ty.List[DocumentProjectFilter]] = Field([])
    type_specs: ty.List[TypeSpecification] = Field([])


class DocumentData(RootModel):
    root: ty.List[ObjectDataGrid]
