import typing as ty
from pydantic import Field
from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.project_filter import ProjectFilter


class DocumentProjectFilter(BaseModel):
    """Defines the link between a Document and a Project Filter."""

    project_filter: ty.Optional[ProjectFilter] = Field(
        None,
        title="Filter",
        description="Project Filter linking to a Document",
    )
