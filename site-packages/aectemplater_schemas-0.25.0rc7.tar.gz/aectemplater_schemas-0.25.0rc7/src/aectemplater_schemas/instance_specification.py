import logging
import typing as ty
from pydantic import Field

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.instance_spec_data import InstanceSpecData


logger = logging.getLogger(__name__)


class InstanceSpecificationBase(BaseModel):
    """Used to store property values with a Property Set for a particular instance."""

    instance_reference: int = Field(
        ...,
        description="integer number for a given product instance.",
    )


class InstanceSpecification(InstanceSpecificationBase):
    data: ty.List[InstanceSpecData] = Field(
        [],
        title="Property Data",
        description="Values applied to the properties for a Instance Specification.",
    )
