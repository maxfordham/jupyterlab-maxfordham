import typing as ty
from datetime import datetime
from pydantic import (
    Field,
    StringConstraints,
    model_validator,
    field_validator,
    model_serializer,
)

from pyuniclass import UT
from pyrulefilter.enums import FilterCategoriesEnum
from aectemplater_schemas import USERS
from aectemplater_schemas.constants import URL_REF_BSDD_REFERENCE_STANDARDS
from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.property import Property, PropertySchema
from aectemplater_schemas.property_units import PropertyUnits
from aectemplater_schemas.tag_template import TypeTagTemplate, InstanceTagTemplate
from aectemplater_schemas.enumerations import StatusEnum, UseTypeEnum, ParameterTypeEnum


class _TagTemplateBase(BaseModel):
    instance_tag_template_id: ty.Optional[int] = (
        None  # review... probs shouldn't be optional
    )
    type_tag_template_id: ty.Optional[int] = (
        None  # review... probs shouldn't be optional
    )


class _TagTemplateOut(BaseModel):
    type_tag_template: ty.Optional[TypeTagTemplate] = Field(
        None,
        title="Type Tag Template",
        description="The Type Tag Template for the PropertySet.",
    )
    instance_tag_template: ty.Optional[InstanceTagTemplate] = Field(
        None,
        title="Instance Tag Template",
        description="The Instance Tag Template for the PropertySet.",
    )


class Object(BaseModel):
    code: str = Field(
        title="Code",
        description="Code used originally by the dictionary",
        json_schema_extra=dict(
            column_width=180,
        ),
    )
    name: str = Field(
        title="Name",
        description="Name",
        json_schema_extra=dict(
            column_width=160,
        ),
    )
    definition: str = Field(
        "",
        title="Definition",
        description="Formal definition",
        json_schema_extra=dict(
            column_width=240,
        ),
    )
    uri: str = Field(
        "",
        title="Uri",
        description="Unique identification of the Classification",
        json_schema_extra=dict(
            column_width=240,
        ),
    )
    status: StatusEnum = Field(
        StatusEnum.inactive,
        title="Status",
        description="Status, can be: Preview, Active or Inactive",
        json_schema_extra=dict(
            column_width=65,
        ),
    )
    classification: ty.Annotated[
        str, StringConstraints(pattern=r"(?:[A-Z][a-z](_[0-9][0-9]){1,4})?")
    ] = Field(  # noqa: F722  # TODO: change name to "uniclass code"
        "",
        title="Classification",
        description=(
            "The classification depending on its system e.g. if"
            " classification system is Uniclass then classification could be"
            " Pr_70_65_04."
        ),
        json_schema_extra=dict(
            column_width=160,
            options=getattr(UT, "Pr").data.set_index("description")["Code"].to_dict()
            | getattr(UT, "SL").data.set_index("description")["Code"].to_dict()
            | {"": ""},
            autoui="ipyautoui.custom.combobox_mapped.ComboboxMapped",
        ),
    )
    classification_system: str = Field(
        "Uniclass",
        title="Classification System",
        description="The classification system used e.g. Uniclass.",
        json_schema_extra=dict(column_width=130, disabled=True),
    )
    category: str = Field(
        "",
        title="Category",
        description="The template category e.g. Air Grille/Diffuser.",
        json_schema_extra=dict(column_width=140),
    )
    custodian: str = Field(
        "MXF",
        title="Custodian",
        description="The governing body responsible for maintenance. e.g. CIBSE, MXF, etc.",
        json_schema_extra=dict(column_width=80, disabled=True),
    )
    version: int = Field(
        1,
        title="Version",
        description="The version given by the custodian.",
        json_schema_extra=dict(column_width=65),
    )
    document_reference: list[str] = Field(
        [],
        title="Document Reference",
        description=(
            "E.g. Manufacturers Data, examples from Projects, Industry Standards,"
            " etc.. See <a"
            f" href={URL_REF_BSDD_REFERENCE_STANDARDS} target='_blank'>BuildingSMART's"
            " list of Reference Standards</a>"
        ),
        json_schema_extra=dict(
            is_ifc=True,
            column_width=200,
            autoui="ipyautoui.custom.fileupload.FilesUploadToDir",
        ),
    )
    # ------------------------------------------------
    # FIXME: Needing refactor or cleanup -@jovyan at 9/3/2022, 7:34:34 AM
    # document_reference should be defined as follows:
    #
    # document_reference: ty.Dict[str, File] = Field(
    # autoui="ipyautoui.custom.fileupload.FileUploadToDir",
    # but this breaks it for some reason
    # ------------------------------------------------
    revit_category: ty.Optional[FilterCategoriesEnum] = Field(
        None,
        title="Revit Category",
        description="BuiltInCategory name from Revit",
        json_schema_extra=dict(
            column_width=145,
        ),
    )
    use_type: UseTypeEnum = Field(
        UseTypeEnum.equipment,
        title="Use Type",
        description="The use type of the object.",
        json_schema_extra=dict(column_width=170),
    )
    author: str = Field(
        "",
        title="Author",
        description="This would typically be the engineer who created the template.",
        json_schema_extra=dict(
            column_width=80,
            options=USERS,
            autoui="ipywidgets.Combobox",
        ),
    )
    checked_by: str = Field(
        "",
        title="Checked By",
        description="The user that checked the template.",
        json_schema_extra=dict(
            column_width=100,
            options=USERS,
            autoui="ipywidgets.Combobox",
        ),
    )
    date_time: ty.Optional[datetime] = Field(
        None,
        title="Date Time",
        description="The datetime of when the template was created.",
        json_schema_extra=dict(column_width=100, disabled=True),
    )

    @field_validator("date_time")
    @classmethod
    def _set_date_time(cls, v: ty.Optional[datetime]):
        if v is None:
            return datetime.now()
        else:
            return v


class ObjectPropertyWithPsets(Property):
    pset: str = Field(
        "",
        title="Property Set",
        description="Property Set code that the Property belongs to within the object.",
        json_schema_extra=dict(is_ifc=True, column_width=200),
    )
    property_units: ty.List[PropertyUnits] = Field(
        [],
        title="Property Units",
        description="Units of the property",
    )


class ObjectWithProperties(Object):
    """Schema for the Object with Properties."""

    properties: ty.List[ObjectPropertyWithPsets] = Field(
        [],
        title="Properties",
        description="Properties of the object",
        json_schema_extra=dict(column_width=300),
    )


class ObjectSchema(BaseModel):
    """Defines Object schema based off JSON schema."""

    title: str
    description: str
    type: str = "object"
    parameter_type: ty.Optional[ParameterTypeEnum]
    override_units: bool
    classification: ty.Annotated[
        str, StringConstraints(pattern=r"(?:[A-Z][a-z](_[0-9][0-9]){1,4})?")
    ] = ""
    properties: ty.Dict[
        str, PropertySchema
    ]  # Map property name (which is unique) property info


class ObjectGridSchema(BaseModel):
    """Schema for the Object Grid."""

    title: str
    type: str = "array"
    format: str = "DataFrame"
    hide_nan: bool = True
    datagrid_index_name: tuple = ("section", "title")
    items: ObjectSchema


class ObjectData(BaseModel):
    schema_: ty.Union[dict[str, str], ObjectSchema]
    data: ty.Dict[str, ty.Any]

    @model_validator(mode="before")
    @classmethod
    def validate_model(cls, data: dict) -> dict:
        """Deal with $schema field."""
        if "$schema" in data.keys():
            data["schema_"] = data.pop("$schema")
        return data

    @model_serializer
    def serialise_model(self):
        """When dumping to JSON, change `schema` to `$schema`."""
        return {"$schema": self.schema_, "data": self.data}


class ObjectDataGrid(BaseModel):
    schema_: ty.Union[dict[str, str], ObjectGridSchema]
    data: ty.List[ty.Dict[str, ty.Any]]

    @model_validator(mode="before")
    @classmethod
    def validate_model(cls, data: dict) -> dict:
        """Deal with $schema field."""
        if "$schema" in data.keys():
            data["schema_"] = data.pop("$schema")
        return data

    @model_serializer
    def serialise_model(self):
        """When dumping to JSON, change `schema` to `$schema`."""
        return {"$schema": self.schema_, "data": self.data}
