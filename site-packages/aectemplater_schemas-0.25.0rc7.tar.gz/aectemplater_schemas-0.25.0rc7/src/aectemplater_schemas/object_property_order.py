import typing as ty
from pydantic import Field
from aectemplater_schemas.basemodel import BaseModel


class ObjectPropertyOrder(BaseModel):
    order: int = Field(
        ...,
        title="Order",
        description="Order of the property in the object.",
    )
