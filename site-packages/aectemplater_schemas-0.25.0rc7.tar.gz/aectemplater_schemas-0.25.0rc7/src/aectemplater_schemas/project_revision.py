from pydantic import Field

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.project import Project


class ProjectRevision(BaseModel):
    revision: str = Field()
    project: Project
