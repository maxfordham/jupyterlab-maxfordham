import logging
import stringcase
import typing as ty
from datetime import datetime
from pydantic import (
    field_validator,
    computed_field,
    Field,
)

from aectemplater_schemas.basemodel import BaseModel
from aectemplater_schemas.enumerations import (
    ParameterTypeEnum,
    StatusEnum,
)
from aectemplater_schemas.property import IfcMapProperty
from aectemplater_schemas.object import Object
from aectemplater_schemas.env import Env

ENV = Env()

logger = logging.getLogger(__name__)


class _Pset0(BaseModel):
    code: str = Field(
        title="Code",
        description="Code used originally by the dictionary.",
        json_schema_extra=dict(column_width=200),
    )
    name: str = Field(
        "",
        title="Name",
        description="Name of the template.",
        json_schema_extra=dict(column_width=250),
        validate_default=True,
    )

    @field_validator("code")
    @classmethod
    def validate_code(cls, v):
        return v.strip()

    @field_validator("name")
    @classmethod
    def validate_name(cls, v, info):
        if v == "":
            if "Pset_" in info.data["code"]:
                return stringcase.titlecase(info.data["code"]).replace(
                    "Pset  ", "Property Set: "
                )
            else:
                return info.data["code"]
        return v.strip()


class PsetSummary(_Pset0):
    definition: str = Field(
        "",
        title="Definition",
        description="Definition of the template.",
        json_schema_extra=dict(column_width=500, autoui="ipywidgets.Textarea"),
    )
    uri: str = Field(
        "", title="Uri", description="Unique identification of the Classification"
    )
    custodian: str = Field(
        "MXF",
        title="Custodian",
        description="The governing body responsible for maintenance. e.g. CIBSE, MXF, etc.",
        json_schema_extra=dict(column_width=80),
        # autoui="ipywidgets.ComboBox",
    )
    version: int = Field(
        1,
        title="Version",
        description="The version given by the custodian.",
        json_schema_extra=dict(column_width=80),
    )
    status: StatusEnum = Field(
        StatusEnum.inactive,
        title="Status",
        description="Status, can be: Preview, Active or Inactive",
    )


class _Pset1(PsetSummary):
    category: str = Field(
        "",
        title="Category",
        description="The template category e.g. Air Grille/Diffuser.",
        json_schema_extra=dict(column_width=140),
    )


class IfcMapPset(_Pset0):
    parameter_type: ParameterTypeEnum = Field(
        ParameterTypeEnum.type,
        title="Parameter Type",
        description="The parameter's type. Whether it is an instance or type parameter.",
    )
    properties: ty.List[IfcMapProperty] = Field(
        [],
        title="Properties",
        description="The properties belonging to the PropertySet.",
    )
    objects: ty.List[Object] = Field(
        [],
        title="Objects",
        description="The objects that the PropertySet is applicable to.",
        exclude=True,
    )
    applicable_classes: ty.List[str] = Field(
        [],
        title="Applicable Classes",
        description=(
            "Applicable classes is used to list the associated IFC classes with the"
            " template. Search <a"
            " href='https://standards.buildingsmart.org/IFC/RELEASE/IFC4/ADD2_TC1/HTML/'"
            " target='_blank'>IfcDomains</a> for IFC classes."
        ),
        json_schema_extra=dict(is_ifc=True, column_width=200),
        validate_default=True,
    )

    @field_validator("applicable_classes")
    @classmethod
    def _applicable_classes(cls, v, info) -> list:
        if not v:
            return [obj.code for obj in info.data["objects"]]
        return v


class PropertySet(_Pset1):
    """A PropertySet is an abstract set of properties. Possible use cases of a PropertySet
    could include:

    - equipment specification: define the properties required for the specification
    of a piece of equipment.
    - space specification: define the design parameters required for specifying
    a space.
    - calculation inputs: define the properties required for a calculation
    - commissioning data: define the required data-fields from a contractor
    """

    date_time: ty.Optional[datetime] = Field(
        default_factory=datetime.now,
        title="Date Time",
        description="The datetime of when the template was created.",
        json_schema_extra=dict(column_width=100, disabled=True),
    )
    # ^ TODO: As Datetime? Or easier to store dates as string or int representation?
    # https://www.sqlite.org/datatype3.html#:~:text=SQLite%20does%20not%20have%20a%20storage%20class%20set%20aside%20for,SSS%22).
    # ^ use "TEXT as ISO8601 strings ("YYYY-MM-DD HH:MM:SS.SSS")""
    # https://www.sqlite.org/lang_datefunc.html
    # do a test like with JSON data type in `model.py` to confirm our understanding of how this works...
