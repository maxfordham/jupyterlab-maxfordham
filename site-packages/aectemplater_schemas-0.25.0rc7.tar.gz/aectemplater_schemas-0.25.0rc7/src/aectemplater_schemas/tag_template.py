import itertools
import enum
import typing as ty
from annotated_types import doc
from typing_extensions import NotRequired, TypedDict, Required, Annotated
from pydantic import (
    BaseModel,
    TypeAdapter,
    ConfigDict,
    Field,
    computed_field,
    model_validator,
    AliasChoices,
)
from stringcase import pascalcase

from pydantic.functional_validators import AfterValidator


def if_empty_set_null(v: ty.Union[str, None]) -> ty.Union[str, None]:
    if v == "":
        return None
    return v


NonEmptyOptionalString = Annotated[
    ty.Union[str, None], AfterValidator(if_empty_set_null)
]

TYPE_MARK_DEFAULT_TAG = {
    "abbreviation": "{abbreviation}",
    "type_reference": "-{type_reference}_",
    "function_reference": "{function_reference}",
}
# e.g. for
# type_mark_data = dict(abbreviation="DB", type_reference=1, function_reference"")
# type_mark = DB-1

MARK_DEFAULT_TAG = {
    "abbreviation": "{abbreviation}",
    "type_reference": "-{type_reference}",
    "instance_reference": "-{instance_reference}_",
    "function_reference": "{function_reference}-",
    "volume_reference": "{volume_reference}-",
    "level_reference": "{level_reference}",
}
# e.g. for
# mark_data = dict(abbreviation="DB", type_reference=1, function_reference= "", instance_reference=1, volume_reference=A, level_reference=2}
# mark = DB-1-1_BlockA-Level2

MARK_INSTANCE_ONLY_TAG = {
    "abbreviation": "{abbreviation}",
    "type_reference": "",
    "instance_reference": "-{instance_reference}_",
    "function_reference": "{function_reference}-",
    "volume_reference": "{volume_reference}-",
    "level_reference": "{level_reference}",
}

# TODO: ^ need to update the following with the changes to BDNS


# TODO: use https://docs.pydantic.dev/latest/concepts/alias/#using-alias-generators
class TypeTagDataBase(BaseModel):
    abbreviation: Annotated[
        str,
        doc(
            "Equipment Abbreviation for a given equipment type. Defined by BDNS. e.g LT = Light"
        ),
    ] = Field(validation_alias=AliasChoices("abbreviation", "Abbreviation"))
    type_reference: int = Field(
        validation_alias=AliasChoices("type_reference", "TypeReference")
    )


class TypeTagData(TypeTagDataBase):
    function_reference: NonEmptyOptionalString = Field(
        None, validation_alias=AliasChoices("function_reference", "FunctionReference")
    )
    # assembly_reference: ty.Optional[str]  #  TODO: add when required...


class InstanceTagData(TypeTagData):
    instance_reference: int = Field(
        validation_alias=AliasChoices("instance_reference", "InstanceReference")
    )
    volume_reference: ty.Optional[str] = Field(
        None, validation_alias=AliasChoices("volume_reference", "VolumeReference")
    )
    level_reference: ty.Optional[str] = Field(
        None, validation_alias=AliasChoices("level_reference", "LevelReference")
    )


class TypeTag(TypedDict):
    abbreviation: str
    type_reference: str
    function_reference: NotRequired[str] = None
    # assembly_reference: NotRequired[str]  #  TODO: add when required...


class InstanceTag(TypeTag):
    instance_reference: str
    volume_reference: NotRequired[str] = None
    level_reference: NotRequired[str] = None


TypeTagItems = enum.Enum(
    "TypeTagItems",
    {x: x for x in list(TypeTag.__annotations__.keys())},
)
InstanceTagItems = enum.Enum(
    "InstanceTagItems",
    {x: x for x in list(InstanceTag.__annotations__.keys())},
)
type_tag_adapter = TypeAdapter(TypeTag)
instance_tag_adapter = TypeAdapter(InstanceTag)


class TypeTagTemplate(BaseModel):
    description: ty.Optional[str] = None
    tag: dict  # ty.Union[InstanceTagTemplate, TypeTagTemplate] # NOTE: validates in model_validator to preserve dict order
    unique_reference: ty.Optional[set[InstanceTagItems]] = None

    @model_validator(mode="after")
    def check_tag(self) -> "TypeTagTemplate":
        _order = self.tag.keys()
        self.tag = type_tag_adapter.validate_python(self.tag)
        self.unique_reference = {
            TypeTagItems.abbreviation.value,
            TypeTagItems.type_reference.value,
        }
        self.tag = {k: self.tag[k] for k in _order if k in self.tag.keys()}
        return self

    model_config = ConfigDict(from_attributes=True)


class InstanceTagTemplate(BaseModel):
    description: ty.Optional[str] = None
    tag: dict  # ty.Union[InstanceTagTemplate, TypeTagTemplate] # NOTE: validates in model_validator to preserve dict order
    unique_reference: ty.Optional[set[InstanceTagItems]] = None

    @model_validator(mode="after")
    def check_tag_template(self) -> "InstanceTagTemplate":
        _order = self.tag.keys()
        self.tag = instance_tag_adapter.validate_python(self.tag)
        if self.unique_reference is None:
            self.unique_reference = {
                TypeTagItems.abbreviation.value,
                TypeTagItems.type_reference.value,
                InstanceTagItems.instance_reference.value,
            }
        self.tag = {k: self.tag[k] for k in _order if k in self.tag.keys()}
        return self

    model_config = ConfigDict(from_attributes=True)


TAG_TEMPLATE_TYPE_DEFAULT = TypeTagTemplate(
    description="MXF standard type tag",
    tag=TYPE_MARK_DEFAULT_TAG,
)
TAG_TEMPLATE_INSTANCE_DEFAULT = InstanceTagTemplate(
    description="MXF standard instance tag",
    tag=MARK_DEFAULT_TAG,
)
TAG_TEMPLATE_INSTANCE_ONLY = InstanceTagTemplate(
    description="MXF instance only tag. Doesn't report TypeReference. Used for some electrical distribution equipment and major plant.",
    tag=MARK_INSTANCE_ONLY_TAG,
)


class TypeMark(BaseModel):
    template: TypeTagTemplate = Field(TAG_TEMPLATE_TYPE_DEFAULT, exclude=True)
    tag_data: TypeTagData

    @computed_field
    @property
    def type_mark_fstring(self) -> str:
        return get_mark_fstring(self.tag_data, di_fstring=self.template.tag)

    @computed_field
    @property
    def type_mark(self) -> str:
        return get_mark(self.tag_data, di_fstring=self.template.tag)


class Mark(BaseModel):
    template: InstanceTagTemplate = Field(TAG_TEMPLATE_INSTANCE_DEFAULT, exclude=True)
    tag_data: InstanceTagData

    @computed_field
    @property
    def mark_fstring(self) -> str:
        return get_mark_fstring(self.tag_data, di_fstring=self.template.tag)

    @computed_field
    @property
    def mark_fstring_pretty(self) -> str:
        return get_mark_fstring(
            self.tag_data, di_fstring=self.template.tag, to_pascalcase=True
        )

    @computed_field
    @property
    def mark(self) -> str:
        return get_mark(self.tag_data, di_fstring=self.template.tag)


def clean(s):
    return s.rstrip("-").rstrip("_").rstrip(" ")


def get_fstring(tag, di_fstring, to_pascalcase=False):
    li = [k for k, v in tag.model_dump().items() if v is not None]
    f_string = "".join([v for k, v in di_fstring.items() if k in li])
    if to_pascalcase:
        for l in li:
            f_string = f_string.replace(l, pascalcase(l))
    return clean(f_string)


def get_mark_fstring(
    tag: InstanceTag,
    di_fstring: TypeTagTemplate = MARK_DEFAULT_TAG,
    to_pascalcase=False,
):
    return get_fstring(tag, di_fstring, to_pascalcase=to_pascalcase)


def get_typemark_fstring(
    tag: TypeTag,
    di_fstring: TypeTagTemplate = TYPE_MARK_DEFAULT_TAG,
    to_pascalcase=False,
):
    return get_fstring(tag, di_fstring, to_pascalcase=to_pascalcase)


def get_type_mark(
    tag: ty.Union[TypeTagData, InstanceTagData],
    di_fstring: ty.Union[TypeTagTemplate, InstanceTagTemplate] = TYPE_MARK_DEFAULT_TAG,
):
    f_string = get_typemark_fstring(tag, di_fstring=di_fstring)
    s_tag = f_string.format(**tag.model_dump())
    return s_tag


def get_mark(
    tag: ty.Union[TypeTagData, InstanceTagData],
    di_fstring: ty.Union[TypeTagTemplate, InstanceTagTemplate] = MARK_DEFAULT_TAG,
):
    return get_type_mark(tag, di_fstring=di_fstring)


def smoosh_lists(*args):
    return [x for x in itertools.chain.from_iterable(itertools.zip_longest(*args)) if x]


def html_mark(tag: ty.Union[TypeMark, Mark]):
    # TODO: maybe this should go in aectemplater_ui...
    from palettable.scientific.sequential import Hawaii_6  #  Davos_9,

    def format_template(type_mark_fstring):
        parts = type_mark_fstring.split("{")[1:]
        parts = ["[" + p for p in parts]
        colors = [
            f'<span style="color: {Hawaii_6.hex_colors[n]}">' for n in range(len(parts))
        ]  # Davos_9, Hawaii_6
        s = "".join(smoosh_lists(colors, parts))
        parts = s.split("}")[:-1]
        parts = [p + "]" for p in parts]
        end = "</FONT>"
        ends = [f"</span>" for n in range(len(parts))]
        s = "".join(smoosh_lists(parts, ends))
        return s

    if isinstance(tag.template, InstanceTagTemplate):
        if "instance_reference" not in tag.tag_data.model_dump().keys():
            return None
        else:
            s = format_template(tag.mark_fstring)
            return f"<b>{tag.mark}</b> | <i>{s}</i>"
    else:
        s = format_template(tag.type_mark_fstring)
        return f"<b>{tag.type_mark}</b> | <i>{s}</i>"
