import ast
import uuid
import re
import stringcase
import ast
import typing as ty
from dataclasses import dataclass
from pydantic import BaseModel, model_serializer

from aectemplater_schemas.enumerations import JsonDataTypeEnum


def is_alphanumeric_with_underscore_and_fullstop(s: str) -> bool:
    """Checks whether string passed is alphanumeric with underscore.

    Args:
        s (str): string to test.

    Returns:
        bool: Whether alphanumeric or not.
    """
    if re.match("^[a-zA-Z0-9_.]*$", s):
        return True
    else:
        return False


def is_guid(s: str) -> bool:
    """Checks whether string passed is a GUID.

    Args:
        s (str): string to test.

    Returns:
        bool: Whether a GUID or not.
    """
    try:
        uuid.UUID(s)
        return True
    except:
        return False


def get_name_from_title(title: str) -> str:
    """convert a user-defined title into a PascalCase name

    Args:
        title (str): property title

    Returns:
        str: property name in PascalCase
    """
    confirm_titlecase = lambda title: (
        title.title() if " " in title else stringcase.titlecase(title)
    )
    title = confirm_titlecase(title)
    name = title.replace(" ", "")
    name = re.sub(r"[^a-zA-Z0-9]", "", name)
    return name


# TODO: Deprecate and use jsonschema in appropriate CRUD in aectemplater
def try_eval(value: ty.Any):
    """Try to evaluate the value as a python literal."""
    if value == "":
        return value
    try:
        value = ast.literal_eval(value)
    except (ValueError, SyntaxError):
        pass
    return value


def stringify_unit_symbol(sym):
    return str(sym).replace("**", "").replace("*", ".").replace(" ", "")


# NOTE: The below code is used for excluding fields from the response model if they are None
# REF: https://github.com/pydantic/pydantic/discussions/5461#discussioncomment-7503283
# REMOVE ONCE PYDANTIC SUPPORTS THIS FEATURE
@dataclass
class OmitIfNone:
    pass


class ResponseOmitNone(BaseModel):
    @model_serializer
    def _serialize(self):
        # omit None --------
        omit_if_none_fields = {
            k
            for k, v in self.model_fields.items()
            if any(isinstance(m, OmitIfNone) for m in v.metadata)
        }
        model_dict = {
            k: v for k, v in self if k not in omit_if_none_fields or v is not None
        }
        return model_dict


MAP_JSON_TO_FUNC_TO_CALL: dict[JsonDataTypeEnum, ty.Callable] = {
    JsonDataTypeEnum.string: str,
    JsonDataTypeEnum.integer: int,
    JsonDataTypeEnum.number: float,
    JsonDataTypeEnum.boolean: ast.literal_eval,
    JsonDataTypeEnum.array: ast.literal_eval,
    JsonDataTypeEnum.object: ast.literal_eval,
}
