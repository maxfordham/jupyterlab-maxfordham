# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
# %run __init__.py
# %load_ext lab_black

import json
import unyt as u
import numpy as np
from sympy import Symbol, Mul, Pow
from sympy.core.numbers import One
from collections import defaultdict

from aectemplater_schemas.data.utils import UnitsBaseData
from aectemplater_schemas.units import Units
from aectemplater_schemas.utils import stringify_unit_symbol

UDATA = UnitsBaseData()

is_sympy = lambda obj: (
    True
    if isinstance(obj, Symbol)
    or isinstance(obj, Mul)
    or isinstance(obj, Pow)
    or isinstance(obj, One)
    else False
)


def get_unyt_dimensions():
    unyt_dimensions = [
        k
        for k, v in u.dimensions.__dict__.items()
        if is_sympy(v) and k not in ["k", "v"]
    ]
    return unyt_dimensions


def get_unyt_symbols():
    return u._unit_lookup_table.default_unit_symbol_lut


def get_unyt_prefixes():
    return u._unit_lookup_table.unit_prefixes


def get_dimensions(s):
    try:
        return u.Unit(s).dimensions
    except:
        return None


def get_map_dimensions_to_physical_quantity(sanitize=True):
    # physical quantities in unyt
    map_dimensions_to_physical_quantity = {
        getattr(u.dimensions, u_): u_ for u_ in unyt_dimensions
    }

    # physical quantities in base data (ifc + cibse)
    map_dimensions_to_physical_quantity_ = UDATA.map_unyt_to_physical_quantity
    map_dimensions_to_physical_quantity_ = {
        get_dimensions(k): v
        for k, v in map_dimensions_to_physical_quantity_.items()
        if get_dimensions(k) is not None
    }
    map_dimensions_to_physical_quantity = (
        map_dimensions_to_physical_quantity | map_dimensions_to_physical_quantity_
    )
    if sanitize:
        map_dimensions_to_physical_quantity = {
            k: v.replace("_cgs", "").replace("_mks", "").replace("_", " ")
            for k, v in map_dimensions_to_physical_quantity.items()
        }
    map_dimensions_to_physical_quantity[1] = "dimensionless"
    return map_dimensions_to_physical_quantity


def get_map_unyt_code_to_unit_names(path):
    li = json.loads(path.read_text())["data"]
    return {l["code"]: l["name"] for l in li}


unyt_dimensions = get_unyt_dimensions()
unyt_symbols = get_unyt_symbols()
unyt_prefixes = get_unyt_prefixes()

map_dimensions_to_physical_quantity = get_map_dimensions_to_physical_quantity()
map_unyt_code_to_unit_names = UDATA.map_unyt_code_to_unit_names

fn_map_dims_and_names = lambda dim: (
    map_dimensions_to_physical_quantity[dim]
    if dim in map_dimensions_to_physical_quantity.keys()
    else ""
)

map_unyt_names_symbols = {
    k: fn_map_dims_and_names(v[1]) for k, v in unyt_symbols.items()
} | {"lx": "illuminance"}

map_unyt_names_symbols_ignore_system = defaultdict(
    lambda: "",
    **{
        k: v.replace("_cgs", "").replace("_mks", "")
        for k, v in map_unyt_names_symbols.items()
    },
)
base_dimensions_unyt = [
    "length",
    "mass",
    "time",
    "current_mks",
    "temperature",
    "dimensionless",
    "luminous_intensity",
]
base_dimension_ifc = [
    "dimension_length",
    "dimension_mass",
    "dimension_time",
    "dimension_electric_current",
    "dimension_thermodynamic_temperature",
    "dimension_amount_of_substance",
    "dimension_luminous_intensity",
    "dimension",
]
base_dimensions_objs_unyt = [getattr(u.dimensions, l) for l in base_dimensions_unyt]
map_ifc_to_unyt = dict(zip(base_dimension_ifc, base_dimensions_unyt))
map_unyt_to_ifc = dict(zip(base_dimensions_objs_unyt, base_dimension_ifc))
update_dimension_keys = lambda di: {map_ifc_to_unyt[k]: v for k, v in di.items()}
make_unyt_dimensions = lambda dims: np.product(
    [getattr(u.dimensions, k) ** v for k, v in dims.items() if v != 0]
)
map_prefix_codes = {v[1]: k for k, v in unyt_prefixes.items()} | {"": ""}
prefix_options = [""] + list(map_prefix_codes.keys())
symbol_options = [""] + list(unyt_symbols.keys())

# ---


def get_unyt_dimensions_args(unyt: u.Unit):
    """
    get a tuple of dimensions and exponents for a given unit

    Reference:
        https://github.com/yt-project/unyt/issues/263
    """
    dim = unyt.dimensions
    if isinstance(dim, Symbol):
        factors = (dim,)
    elif isinstance(dim, Pow):
        factors = (dim,)
    else:
        factors = dim.args
    return factors


def get_unit_dimensional_exponents(unyt: u.Unit) -> dict:
    dims = get_unyt_dimensions_args(unyt)
    return {
        map_unyt_to_ifc[d.as_base_exp()[0]]: d.as_base_exp()[1]
        for d in dims
        if d.as_base_exp()[0] in map_unyt_to_ifc.keys()
    }


def unyt_to_Units(unyt: u.Unit) -> Units:
    """Convert from a unyt.Unit to a Units pydantic model."""
    ifc_dims = get_unit_dimensional_exponents(unyt)
    ifc_dims["base_value"] = unyt.base_value
    if unyt.dimensions in list(map_dimensions_to_physical_quantity.keys()):
        ifc_dims["physical_quantity"] = map_dimensions_to_physical_quantity[
            unyt.dimensions
        ]
    ifc_dims["code"] = str(unyt)
    ifc_dims["symbol"] = stringify_unit_symbol(unyt)
    if ifc_dims["code"] in list(map_unyt_code_to_unit_names.keys()):
        ifc_dims["name"] = map_unyt_code_to_unit_names[ifc_dims["code"]]

    # TODO: Tasks pending completion -@jovyan at 9/9/2022, 10:51:29 AM
    # This should probs include a lookup of stuff already in the database for
    # assigning: code, symbol, name
    return Units(**ifc_dims)


def get_units() -> list:
    units = []
    not_unyts = []
    for _ in UDATA.data_:
        try:
            unyt = u.Unit(_["code"])
        except:
            not_unyts.append(_)
            continue
            # raise ValueError(f"{_['code']} not a valid unyt")
        del _["code"]
        ubase = unyt_to_Units(unyt)  # get unit base from unyt
        ubase = Units(**(ubase.model_dump() | _))  # overide descriptions
        if ubase not in units:
            units.append(ubase)
    return units


def convert_value_unit(value: float, from_: str, to_: str) -> float:
    """Convert a value from one unit to another and round to 6 sig figs.

    Args:
        value (float): value to convert
        from_ (str): unit to convert from (unyt code)
        to_ (str): unit to convert to (unyt code)

    Returns:
        float: converted value"""
    return round((value * u.Unit(from_)).to(to_).value.item(), 6)
