from aectemplater_schemas.data import UnitsBaseData
from aectemplater_schemas.data.utils import get_revit_non_measurable_specs
import unyt as u

UDATA = UnitsBaseData()


class TestData:
    def test_get_revit_non_measurable_specs(self):

        assert get_revit_non_measurable_specs() == [
            "INTEGER",
            "MATERIAL",
            "URL",
            "NOOFPOLES",
            "TEXT",
            "YESNO",
            "LOADCLASSIFICATION",
            "IMAGE",
            "MULTILINETEXT",
        ]

    def test_revit_map_ifc(self):
        assert len(UDATA.map_revit_type_to_ifc) == 158

    def test_unyt(self):
        data = UDATA.data
        for d in data:
            assert d["UnytDerivation"] != "-"
            unit = u.Unit(d["UnytDerivation"])
            assert isinstance(unit, u.Unit)
