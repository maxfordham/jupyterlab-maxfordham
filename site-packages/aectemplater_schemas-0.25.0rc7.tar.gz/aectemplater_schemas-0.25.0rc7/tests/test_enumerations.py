from aectemplater_schemas.enumerations import (
    SymbolsEnum,
    CategoriesEnum,
    RuleSetType,
    PropertyValueKindEnum,
    AbbreviationsEnum,
)
from pyrulefilter.enums import FilterCategoriesEnum, OperatorsEnum


class TestSymbolsEnum:
    def test_symbols_enum(self):
        assert (
            SymbolsEnum.MXF_DIS_J41_ButterflyValve.value
            == "MXF-DIS-J41_ButterflyValve.png"
        )


class TestRevit:
    def test_CategoriesEnum(self):
        assert FilterCategoriesEnum.OST_DuctInsulations == "Duct Insulations"
        print("done")

    def test_OperatorsEnum(self):
        assert OperatorsEnum.Equals == "equals"
        print("done")
