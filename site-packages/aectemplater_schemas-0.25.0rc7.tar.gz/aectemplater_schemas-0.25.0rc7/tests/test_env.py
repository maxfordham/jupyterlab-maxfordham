import os
from importlib import reload

from aectemplater_schemas.constants import FDIR_ROOT
from aectemplater_schemas.env import Env


class TestEnv:
    def test_dev_env(self):
        env = Env()
        assert env.DEFAULT_ORG == "MXF"

    def test_prod_env(self):
        # this validates that when an environment variable is set, it takes precendence
        # for production the environment variables are set using the conda environment.yml file
        os.environ["DEFAULT_ORG"] = "TestOrg"
        env = Env()
        assert env.DEFAULT_ORG == "TestOrg"

    def test_symbols(self):
        env = Env()
        assert str(env.FDIR_SYMBOLS) == str(FDIR_ROOT / "tests" / "symbols")

    def test_symbols_from_environ(self):
        os.environ["FDIR_SYMBOLS"] = ""
        env = Env()
        assert env.FDIR_SYMBOLS is None
        import aectemplater_schemas.enumerations

        reload(aectemplater_schemas.enumerations)
        from aectemplater_schemas.enumerations import SymbolsEnum

        assert list(SymbolsEnum) == []
