from aectemplater_schemas.propertyset import PropertySet
from datetime import datetime


class TestPropertySet:
    def test_propertyset(self):
        ps = PropertySet(
            code="Pset_Test",
            name="Property Set: Test",
            date_time="2023-06-21T11:43:36.459",
        )
        assert ps.name == "Property Set: Test"
        assert ps.date_time == datetime(2023, 6, 21, 11, 43, 36, 459000)
