import csv
from io import StringIO
from pydantic import ValidationError

from aectemplater_schemas.tag_template import (
    TypeTagTemplate,
    InstanceTagTemplate,
    Mark,
    TypeMark,
    MARK_DEFAULT_TAG,
    html_mark,
)

EXAMPLE_TAGS = """abbreviation,type_reference,instance_reference,volume_reference,level_reference,function_reference
LT,1,,,,
LT,1,,,,E
LT,1,1,,,
LT,10,2,,,E
MVHR,1,,,,
MVHR,1,,A1,L5,
DB,1,1,A1,L6,PLANT
DB,2,1,A1,L6,SMPWR
DB,2,1,A1,L6,LIGHTS
DB,2,1,A1,L6,LIGHTS
DB,2,1,A1,L6,LIGHTS
VAV,2,1,,,
SLCR,1,1,,,
BUFF,1,,J,,
"""


def read_example_tags():
    rows = [row for row in csv.reader(StringIO(EXAMPLE_TAGS), delimiter=",")]
    li = [dict(zip(rows[0], r)) for r in rows[1:]]
    fn_none = lambda v: None if v == "" else v
    li = [{k: fn_none(v) for k, v in l.items()} for l in li]
    li = [{k: v for k, v in l.items() if v is not None} for l in li]
    return li


tags_data = read_example_tags()


def test_type_mark():
    tag_data = tags_data[1]
    t = TypeTagTemplate(tag=MARK_DEFAULT_TAG)
    tag = TypeMark(tag_data=tag_data, template=t)
    assert tag.type_mark == "LT-1E"


def get_type_tag_template():
    _ = {
        "abbreviation": "",
        "type_reference": "Type{type_reference}",
        "function_reference": "",
    }
    return TypeTagTemplate(
        description="type tag for electrical distribution equipment",
        tag=_,
        unique_fields=["type_reference"],
    )


def get_instance_tag_template():
    _ = {
        "abbreviation": "{abbreviation}-",
        "type_reference": "",
        "instance_reference": "{instance_reference}_",
        "function_reference": "{function_reference}-",
        "volume_reference": "{volume_reference}-",
        "level_reference": "{level_reference}",
    }
    return InstanceTagTemplate(
        description="instance tag for electrical distribution equipment",
        tag=_,
        unique_fields=["abbreviation", "instance_reference"],
    )


def test_electrical_distribution_equipment_example():
    i_tmplt = get_instance_tag_template()
    t_tmplt = get_type_tag_template()
    tag_data = tags_data[7]  # DB,2,1,A1,L6,PLANT
    tag_t = TypeMark(tag_data=tag_data, template=t_tmplt)
    assert tag_t.type_mark == "Type2"
    try:
        tag_t = TypeMark(tag_data=tag_data, template=i_tmplt)
    except Exception as e:
        assert isinstance(e, ValidationError)

    tag_i = Mark(tag_data=tag_data, template=i_tmplt)
    assert tag_i.mark == "DB-1_SMPWR-A1-L6"


def test_electrical_distribution_equipment_example_alternative():
    i_tmplt = InstanceTagTemplate(
        description="instance tag for electrical distribution equipment",
        tag={
            "abbreviation": "{abbreviation}-",
            "volume_reference": "{volume_reference}-",
            "level_reference": "{level_reference}-",
            "function_reference": "{function_reference}-",
            "type_reference": "",
            "instance_reference": "{instance_reference}",
        },
        unique_fields=["abbreviation", "instance_reference"],
    )
    t_tmplt = get_type_tag_template()
    tag_data = tags_data[7]  # DB,2,1,A1,L6,PLANT
    tag_t = TypeMark(tag_data=tag_data, template=t_tmplt)
    assert tag_t.type_mark == "Type2"
    try:
        tag_t = TypeMark(tag_data=tag_data, template=i_tmplt)
    except Exception as e:
        assert isinstance(e, ValidationError)

    tag_i = Mark(tag_data=tag_data, template=i_tmplt)
    assert tag_i.mark == "DB-A1-L6-SMPWR-1"
    assert (
        tag_i.mark_fstring_pretty
        == "{Abbreviation}-{VolumeReference}-{LevelReference}-{FunctionReference}-{InstanceReference}"
    )


def test_html_mark():
    tag_data = tags_data[7]  # DB,2,1,A1,L6,PLANT
    tag_t = TypeMark(tag_data=tag_data, template=get_type_tag_template())
    html = html_mark(tag_t)
    assert (
        html
        == '<b>Type2</b> | <i><span style="color: #8C0273">[type_reference]</span></i>'
    )
    html = html_mark(Mark(tag_data=tag_data, template=get_instance_tag_template()))
    assert (
        html
        == '<b>DB-1_SMPWR-A1-L6</b> | <i><span style="color: #8C0273">[abbreviation]</span>-<span style="color: #954147">[instance_reference]</span>_<span style="color: #9C7524">[function_reference]</span>-<span style="color: #8FB63C">[volume_reference]</span>-<span style="color: #62DCA9">[level_reference]</span></i>'
    )
