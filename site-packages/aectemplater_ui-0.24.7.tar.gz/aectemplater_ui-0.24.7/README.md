# aectemplater-ui

Graphical user interface for interacting with [aectemplater](https://github.com/maxfordham/aectemplater).

## Developing UI

When developing the UI, the `aectemplater` API must be running.

Refer to the `aectemplater development install` [README.md](../aectemplater/README.md#development-install) for instructions on how to launch the API.

To run the API:

```bash
pixi run dev-api
```

or

```bash
pixi run populated-api
```

NOTE: Run the populated API for testing PoE and Net Zero Metrics apps.

## UI Environment Setup

Refer to the `digital-schedules` [README.md](../../README.md) for instructions on how to install the environment.

The environment variables for the development UI are defined in (ui-dev.env)[ui-dev.sh].
To launch `jupyter lab` with the correct environment variables, run the following command:

```bash
pixi run jlab-ui
```

The following environment variables set:
- `AECTEMPLATER_CNAME` - the exposed IP Address of the aectemplater API. This is what the UI uses to interact with the database. This is also what Revit Plugins use to retrieve data from the database. 
- `AECTEMPLATER_FDIR_APPDATA` - the working directory of the App. The app facilitates loading files (reference data) which are saved relative to this directory.
- `AECTEMPLATER_FDIR_EXPORTS` - the directory of exported data templates
- ...

The pydantic config class which will be populated with the environment variables exists within [`env.py`](./ui/env.py)
