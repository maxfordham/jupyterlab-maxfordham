#!/bin/bash
export AECTEMPLATER_CNAME=http://127.0.0.1:8000
export AECTEMPLATER_FDIR_APPDATA=../aectemplater-appdata
export AECTEMPLATER_FDIR_EXPORTS=../aectemplater-appdata/exports
export AECTEMPLATER_FDIR_SYMBOLS=../aectemplater-appdata/symbols
export AECTEMPLATER_FDIR_PROJECTS_ROOT=../aectemplater-appdata/jobs
export IPYAUTOUI_ROOTDIR=.
export AECTEMPLATER_FPTH_EXTRA_ABBREVIATIONS=../aectemplater-appdata/BDNS_extra_abbreviations.csv
export AECTEMPLATER_ORG=MXF
export JUPYTERHUB_USER=jovyan
export MFDB_USER=readOnly
export MFDB_PASSWORD=readonly
export MFDB_HOST=mfdb.maxfordham.com
export MFDB_DATABASE=mf_jobs
export ACCENT_USER=readOnly
export ACCENT_PASSWORD=readonly
export ACCENT_HOST=accent.maxfordham.com
export ACCENT_DATABASE=mfllp

exec "$@"