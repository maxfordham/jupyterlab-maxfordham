import json
import os
import logging

from aectemplater_ui.env import UiEnv
from mfdb import get_job_description_to_number, get_job_number_to_name

ENV = UiEnv()
FDIR_APP = ENV.AECTEMPLATER_FDIR_APPDATA
os.chdir(FDIR_APP)
# NOTE: After changing directory DO NOT call UiEnv again
# If you need to access the environment variables elsewhere then use:
# from aectemplater_ui import ENV

# ----------------------------------------------------------------

di = json.loads(ENV.model_dump_json())
for k, v in di.items():
    os.environ[k] = str(v)
# ^ this ensures environment variables are passed down
# to other packages also using environment variables
# not required comment out at build time when env vars
# will be set as environ vars
# ----------------------------------------------------------------
# ^ TODO: Comment out at build time

# Try to get job data from mfdb. If it fails, then just use test data.
try:
    JOB_NUMBER_TO_NAME = get_job_number_to_name()
    JOB_DESCRIPTION_TO_NUMBER = get_job_description_to_number()
except Exception as e:
    JOB_NUMBER_TO_NAME = {5001: "Test Project", 5003: "Engineering Standards"}
    JOB_DESCRIPTION_TO_NUMBER = {"5001 - Test Project": 5001, "5003 - Engineering Standards": 5003}
    logging.warning(f"Warning: {e}")
