# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.17.2
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

import ipywidgets as w
import traitlets as tr
from aectemplater_client import get_project_revision_by_id
from aectemplater_schemas.enumerations import ParameterTypeEnum, UseTypeEnum
from ipyautoui.custom.showopenurl import ShowOpenUrl
from IPython.display import display

from aectemplater_ui.apps.aectemplater import get_header_items
from aectemplater_ui.apps.constants import AECSCHEDULE_DOCS_URL
from aectemplater_ui.apps.spaces import SpacesGrid
from aectemplater_ui.filter import ProjectFilter
from aectemplater_ui.load_project import LoadProject
from aectemplater_ui.object_specification import ObjectSpecification
from aectemplater_ui.schedules import ProjectSchedules


class AecScheduleTabs(w.Tab):
    project_revision_id = tr.Integer(default_value=None, allow_none=True)
    use_type = tr.Enum(UseTypeEnum, default_value=None, allow_none=True)

    @tr.observe("project_revision_id")
    def _observe_project_number(self, change):
        get_project_revision_by_id(self.project_revision_id)
        self.schedules.project_revision_id = self.project_revision_id
        self.filters.project_revision_id = self.project_revision_id
        if hasattr(self, "specification"):
            self.specification.project_revision_id = self.project_revision_id

    @tr.observe("use_type")
    def _observe_use_type(self, change):
        self.schedules.use_type = self.use_type
        self.filters.use_type = self.use_type
        if self.use_type == UseTypeEnum.spaces:
            self.specification = SpacesGrid(project_revision_id=self.project_revision_id)
            self.schedules.parameter_type = ParameterTypeEnum.instance
        else:
            self.specification = ObjectSpecification(
                project_revision_id=self.project_revision_id, use_type=self.use_type
            )
            self.schedules.parameter_type = ParameterTypeEnum.type
        self.children = [
            self.schedules,
            self.specification,
            self.filters,
        ]
        self._set_titles()

    def __init__(self, **kwargs):
        self.filters = ProjectFilter()
        self.schedules = ProjectSchedules()
        super().__init__(**kwargs)

    def _set_titles(self):
        titles = (
            "Schedules",
            f"{self.use_type.value}",
            "Filters",
        )
        [self.set_title(i, title) for i, title in enumerate(titles)]


if __name__ == "__main__":
    ui = AecScheduleTabs(project_revision_id=2, use_type=UseTypeEnum.equipment)
    display(ui)

if __name__ == "__main__":
    ui.use_type = UseTypeEnum.spaces


class AecSchedule(w.VBox):
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)

    @tr.observe("use_type")
    def _observe_use_type(self, change):
        self.tab.use_type = self.use_type
        self.url_image_link.description = f"<b>{self.use_type.value} Schedules</b>"

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        self.tab = AecScheduleTabs()
        self.docs = ShowOpenUrl(
            url=AECSCHEDULE_DOCS_URL,
            url_launch=AECSCHEDULE_DOCS_URL,
            description="Open documentation in standalone window",
            description_launch="Open documentation on the Wiki",
            auto_open=True,
        )
        self.bn_help, self.url_image_link = get_header_items(
            url=AECSCHEDULE_DOCS_URL,
            description=f"<b>Schedules</b>",
            path_image="https://raw.githubusercontent.com/maxfordham/visual-design/refs/heads/main/icons/logo-equipment-schedule.png",
        )
        self.header = w.HBox([self.bn_help, self.url_image_link])
        self.select_project = LoadProject()
        self.select_project.select.layout.width = "200px"
        self.html_message = w.HTML()
        self.pr_header = w.HBox(
            [
                self.header,
                self.select_project,
            ],
            layout=w.Layout(justify_content="space-between"),
        )
        super().__init__(*args, **kwargs)
        self.children = [self.html_message, self.pr_header, self.docs, self.tab]
        self.docs.layout.display = "None"  # HOTFIX: Hide docs
        self._init_controls()
        self._init_controls_select_project()
        self._update_project_revision_id()

    def _init_controls_select_project(self):
        self.select_project.observe(self._update_project_revision_id, "project_revision_id")

    def _update_project_revision_id(self, on_change=None):
        self.tab.project_revision_id = self.select_project.project_revision_id

    def _init_controls(self):
        self.bn_help.observe(self._show_hide_help, names="value")

    def _show_hide_help(self, onchange):
        if self.bn_help.value:
            self.docs.layout.display = ""
        else:
            self.docs.layout.display = "None"


# +
class EquipmentSchedules(AecSchedule):
    def __init__(self, *args, **kwargs):
        super().__init__(use_type=UseTypeEnum.equipment, *args, **kwargs)
        self.url_image_link.path_image = 'https://raw.githubusercontent.com/maxfordham/visual-design/refs/heads/main/icons/logo-equipment-schedule.png'


class SpaceSchedules(AecSchedule):
    def __init__(self, *args, **kwargs):
        super().__init__(use_type=UseTypeEnum.spaces, *args, **kwargs)
        self.url_image_link.path_image = (
            'https://raw.githubusercontent.com/maxfordham/visual-design/refs/heads/main/icons/logo-space-schedule.png'
        )


# -

if __name__ == "__main__":
    ui = EquipmentSchedules()
    display(ui)

if __name__ == "__main__":
    ui = SpaceSchedules()
    display(ui)
