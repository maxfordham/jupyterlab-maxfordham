from aecreference import aecdata
from aectemplater_client import (
    get_object_by_code,
    get_project_by_project_number,
    get_project_revision_by_project_number_and_revision,
)

from aectemplater_ui import ENV


# TODO: Move this somewhere else?
def get_object_id_and_abbreviation(object_code="MxfRecordedEnergyUse"):
    object_ = get_object_by_code(code=object_code)
    try:
        object_id = object_["id"]
        try:
            default_abbreviation = [abbr for abbr in object_["abbreviations"] if abbr["is_default"]]
            if len(default_abbreviation) != 1:
                msg = "Default abbreviations not configured correctly."
                raise Exception(msg)
            abbreviation = default_abbreviation[0]["abbreviation"]
        except Exception as err:
            abbreviation = "WIP"
    except Exception as err:
        msg = f"Failed to load {object_code}"
        raise Exception(msg) from err
    return object_id, abbreviation


EUI_DATA = aecdata.energy_use_intensity
ANNUAL_ENERGY_DASHBOARD_URL = "https://wiki.maxfordham.com/engineering-dashboards/netzero/poe"
AECSCHEDULE_DOCS_URL = "https://wiki.maxfordham.com/digital-schedules-docs/aecschedule/index.html"
AECTEMPLATER_DOCS_URL = "https://wiki.maxfordham.com/digital-schedules-docs/aectemplater/index.html"

TEST_PROJECT_REVISION_ID = get_project_by_project_number(ENV.AECSCHEDULE_PROJECT_NUMBER)["id"]
DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
    project_number=ENV.AECTEMPLATER_PROJECT_NUMBER, revision=ENV.DEFAULT_PROJECT_REVISION
)["id"]
OBJECT_ID_BUILDING_AREA = get_object_by_code(code="MxfProjectBuildingArea")["id"]
OBJECT_ID_RECORDED, ABBREVIATION_RECORDED = get_object_id_and_abbreviation(object_code="MxfRecordedEnergyUse")
OBJECT_ID_PREDICTED, ABBREVIATION_PREDICTED = get_object_id_and_abbreviation(object_code="MxfPredictedEnergyUse")
OBJECT_ID_SPACE, ABBREVIATION_SPACE = get_object_id_and_abbreviation(object_code="MxfSpace")
OBJECT_ID_OPERATIONAL_ENERGY_TARGET = get_object_by_code(code="MxfOperationalEnergyTarget")["id"]
