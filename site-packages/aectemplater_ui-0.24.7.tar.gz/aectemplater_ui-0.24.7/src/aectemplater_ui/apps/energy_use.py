import logging

import altair as alt
import ipywidgets as w
import pandas as pd
import traitlets as tr
from aectemplater_client import (
    get_instance_specs_object_data_grid,
    get_object_gridschema,
    get_project_type_marks,
    get_type_spec_object_data_grid,
    post_type_spec_data,
)
from ipyautoui.custom.buttonbars import CrudOptions, CrudView
from ipyautoui.custom.editgrid import DataHandler
from ipydatagrid import VegaExpr
from IPython.display import IFrame, display
from netzero_metrics.plots import plot_energy_consumption

from aectemplater_ui.apps.constants import (
    ABBREVIATION_PREDICTED,
    ABBREVIATION_RECORDED,
    ANNUAL_ENERGY_DASHBOARD_URL,
    OBJECT_ID_PREDICTED,
    OBJECT_ID_RECORDED,
    TEST_PROJECT_REVISION_ID,
)
from aectemplater_ui.instance_specification import InstanceSpecDelete, InstanceSpecGrid

# +
ORDER_RECORDED = [
    "ReportingPeriod",
    "BuildingID",
    "FuelType",
    "EnergyEndUse",
    "EnergyEndUseTags",
    "EnergyConsumption",
    "Notes",
    "InstanceReference",
    "TypeSpecId",
    "Id",
]

ORDER_PREDICTED = ["OperationalEnergyAnalysisType"] + ORDER_RECORDED[1:]
# -


RECORDED_ENERGY_USE_BUTTONBAR_CONFIG = CrudView(
    add=CrudOptions(
        tooltip="""Click to add Recorded Energy Use data.
Input the data and then click save.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Annual Energy Consumption</i>",
    ),
    edit=CrudOptions(
        tooltip="""Select a row from the table and click to edit.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Annual Energy Consumption</i>",
    ),
    copy=CrudOptions(
        tooltip="""Select row(s) from the table and click to duplicate.""",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Duplicate Annual Energy Consumptions</i>",
    ),
    delete=CrudOptions(
        tooltip="""Select row(s) from the table and click to open deletion menu.
Click the red DELETE button to confirm deletion.
Once deleted, click again to close the menu.""",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Annual Energy Consumptions</i>",
    ),
    reload=CrudOptions(
        tooltip="Click to reload.",
        button_style="info",
        message="🔄 <i>Reload Annual Energy Consumptions</i>",
    ),
    support=CrudOptions(
        tooltip="Show Help",
        tooltip_clicked="Go back to table",
        message="❔ <i>Help</i>",
    ),
)

PREDICTED_ENERGY_USE_BUTTONBAR_CONFIG = CrudView(
    add=CrudOptions(
        tooltip="""Click to add Predicted Energy Use data.
Input the data and then click save.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Predicted Energy Consumption</i>",
    ),
    edit=CrudOptions(
        tooltip="""Select a row from the table and click to edit.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Predicted Energy Consumption</i>",
    ),
    copy=CrudOptions(
        tooltip="""Select row(s) from the table and click to duplicate.""",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Duplicate Predicted Energy Consumptions</i>",
    ),
    delete=CrudOptions(
        tooltip="""Select row(s) from the table and click to open deletion menu.
Click the red DELETE button to confirm deletion.
Once deleted, click again to close the menu.""",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Predicted Energy Consumptions</i>",
    ),
    reload=CrudOptions(
        tooltip="Click to reload.",
        button_style="info",
        message="🔄 <i>Reload Predicted Energy Consumptions</i>",
    ),
    support=CrudOptions(
        tooltip="Show Help",
        tooltip_clicked="Go back to table",
        message="❔ <i>Help</i>",
    ),
)


def get_energy_dashboard_iframe():
    return IFrame(src=ANNUAL_ENERGY_DASHBOARD_URL, width=1500, height=1300)


class EnergyDashboard(w.VBox):
    def __init__(self):
        self.out = w.Output()
        super().__init__([self.out])
        self.render()

    def render(self):
        with self.out:
            display(get_energy_dashboard_iframe())

    def reload(self, onchange):
        self.out.clear_output()
        self.render()


# +
def get_energy_use_gridschema(
    project_revision_id: int, object_id: int = OBJECT_ID_RECORDED, override_units: bool = True, order=ORDER_RECORDED
) -> dict:
    """Get the recorded energy use data used in defining the data grid."""
    schema = get_object_gridschema(
        object_id=object_id,
        override_units=override_units,
        project_revision_id=project_revision_id,
        parameter_type="I",
    )
    # HOTFIX: Custom overrides to properties
    # NOTE: We can remove these custom overrides once aectemplater set up to deal with `json_schema_extra`
    # We remove `anyOf` and set to `type`
    for property_ in order:
        if property_ == "BuildingID":
            continue
        if "anyOf" in schema["items"]["properties"][property_]:
            for item in schema["items"]["properties"][property_]["anyOf"]:
                if item["type"] != "null":
                    type_ = item["type"]
            schema["items"]["properties"][property_]["type"] = type_
            schema["items"]["properties"][property_].pop("anyOf")
    # We set `EnergyEndUseTags` to an array property and define appropriately
    schema["items"]["properties"]["EnergyEndUseTags"]["type"] = "array"
    schema["items"]["properties"]["EnergyEndUseTags"]["items"] = {
        "type": "string",
        "enum": schema["items"]["properties"]["EnergyEndUseTags"]["enum"],
    }
    schema["items"]["properties"]["EnergyEndUseTags"]["placeholder"] = "Search Energy End Use Tags"
    schema["items"]["properties"]["EnergyEndUseTags"].pop("enum")
    return schema


if __name__ == "__main__":
    gs = get_energy_use_gridschema(project_revision_id=2, object_id=OBJECT_ID_RECORDED)
# -

if __name__ == "__main__":
    gs = get_energy_use_gridschema(project_revision_id=2, object_id=OBJECT_ID_PREDICTED, order=ORDER_PREDICTED)


if __name__ == "__main__":
    spec = get_instance_specs_object_data_grid(
        project_revision_id=TEST_PROJECT_REVISION_ID,
        object_id=OBJECT_ID_RECORDED,
    )
    df = pd.DataFrame(spec["data"])
    display(plot_energy_consumption(df))

# +
COLUMN_WIDTHS_RECORDED = {
    "('key', '', '')": 120,
    "('Identity Data', 'Type Spec Id', '')": 0.5,
    "('Identity Data', 'Id', '')": 0.5,
    "('Identity Data', 'Building ID', '')": 151,
    "('Identity Data', 'Instance Reference', '')": 0.5,
    "('Identity Data', 'Type Mark', '')": 0.5,
    "('Performance', 'Reporting Period', '')": 151,
    "('Performance', 'Energy Consumption', 'kWh/m²/yr')": 188,
    "('Performance', 'Energy End Use', '')": 160,
    "('Performance', 'Energy End Use Tags', '')": 151,
    "('Application', 'Notes', '')": 396,
    "('Performance', 'Fuel Type', '')": 190,
}

COLUMN_WIDTHS_PREDICTED = {
    "('key', '', '')": 120,
    "('Identity Data', 'Type Spec Id', '')": 0.5,
    "('Identity Data', 'Id', '')": 0.5,
    "('Identity Data', 'Building ID', '')": 151,
    "('Identity Data', 'Instance Reference', '')": 0.5,
    "('Identity Data', 'Type Mark', '')": 0.5,
    "('Identity Data', 'Notes', '')": 396,
    "('Identity Data', 'Operational Energy Analysis Type', '')": 220,
    "('Performance', 'Reporting Period', '')": 150,
    "('Performance', 'Energy Consumption', 'kWh/m²/yr')": 188,
    "('Performance', 'Energy End Use', '')": 160,
    "('Performance', 'Energy End Use Tags', '')": 151,
    "('Performance', 'Fuel Type', '')": 190,
}


# +
class RecordedEnergyUseGrid(InstanceSpecGrid):
    @tr.observe("project_revision_id")
    def _set_project_data(self, onchange):
        if self.project_revision_id is not None:
            self._check_for_type_spec()
            self._set_type_mark()
            self._reload_datahandler()
            self.ui_add.di_widgets["BuildingID"].widget.project_revision_id = self.project_revision_id
            self.ui_edit.di_widgets["BuildingID"].widget.project_revision_id = self.project_revision_id
            self._update_energy_use_plot()
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    @tr.observe("object_id")
    def _set_grid(self, onchange):
        if self.object_id is not None:
            schema = get_energy_use_gridschema(
                project_revision_id=self.project_revision_id,
                object_id=self.object_id,
                order=self.order,
            )
            self.update_from_schema(
                schema=schema,
                datahandler=DataHandler(
                    fn_get_all_data=self.get_instance_specs,
                    fn_post=self.post_instance_spec,
                    fn_patch=self.patch_instance_spec,
                    fn_delete=self.delete_instance_spec,
                    fn_copy=self.copy_instance_spec,
                ),
                ui_delete=InstanceSpecDelete,
            )
            self.grid.order = self.order
            self._remove_show_hide_nulls()
            self._hide_empty_lists_in_datagrid()
            self._set_styling()
            self._set_col_widths()
            self._hide_id_widgets()
        else:
            self.update_from_schema(schema=None)

    def _set_type_mark(self, onchange=None):
        """Set Type Mark."""
        if self.project_revision_id is not None:
            project_type_marks = list(
                get_project_type_marks(project_revision_id=self.project_revision_id, object_id=self.object_id).keys()
            )
            self.ui_add.di_widgets["TypeMark"].options = project_type_marks
            self.ui_add.di_widgets["TypeMark"].value = project_type_marks[0]
            self.ui_edit.di_widgets["TypeMark"].options = project_type_marks
            self.ui_edit.di_widgets["TypeMark"].value = project_type_marks[0]

    def __init__(
        self,
        object_id=OBJECT_ID_RECORDED,
        order: list = ORDER_RECORDED,
        abbreviation=ABBREVIATION_RECORDED,
        x_name="ReportingPeriod",
        **kwargs,
    ):
        self.abbreviation = abbreviation
        self.order = order
        self.x_name = x_name
        self.hbx_plot = w.HBox(layout=dict(width="300px"))
        super().__init__(object_id=object_id, hide_nan=True, **kwargs)
        self.buttonbar_grid.crud_view = RECORDED_ENERGY_USE_BUTTONBAR_CONFIG
        self.ui_delete.layout.display = (
            "flex"  # HOTFIX: Resolves issue where warn_on_delete not appearing following re-instantiation
        )
        self._init_eui_controls()

    def _check_for_type_spec(self):
        """Check for initial type specification for annual energy data.
        An initial type is required so we can add instances (of annual energy data)."""
        object_data_grid = get_type_spec_object_data_grid(
            object_id=self.object_id, project_revision_id=self.project_revision_id
        )
        if not object_data_grid["data"]:
            object_data_grid = post_type_spec_data(
                object_id=self.object_id,
                project_revision_id=self.project_revision_id,
                override_units=True,
                value={"Abbreviation": self.abbreviation, "TypeReference": 1},
            )

    def _init_eui_controls(self):
        self.observe(self._update_energy_use_plot, "_value")

    def _update_energy_use_plot(self, on_change=None):
        spec = get_instance_specs_object_data_grid(
            project_revision_id=self.project_revision_id,
            object_id=self.object_id,
        )
        df = pd.DataFrame(spec["data"])
        try:
            self.hbx_plot.children = [alt.JupyterChart(plot_energy_consumption(df, x_name=self.x_name))]
        except ValueError as err:
            self.hbx_plot.children = []
            logging.warning(err)

    def _set_children(self):
        self.vbx_widget.children = [self.hbx_bar, self.stk_crud, w.HBox([self.grid, self.hbx_plot])]
        self.stk_crud.children = [
            self.ui_add,
            self.ui_edit,
            self.ui_copy,
            self.ui_delete,
        ]
        self.children = [self.hbx_title_description, self.vbx_widget]
        self._hide_id_widgets()
        self._set_controls()
        self.ui_delete.layout.display = (
            "flex"  # HOTFIX: Resolves issue where warn_on_delete not appearing following re-instantiation
        )

    def get_instance_specs(self):
        spec_data = super().get_instance_specs()
        # HOTFIX: Evaluates string repr of list to list
        for di in spec_data:
            if "EnergyEndUseTags" in di and "[" in di["EnergyEndUseTags"]:
                di["EnergyEndUseTags"] = eval(
                    di["EnergyEndUseTags"]
                )  # NOTE: Can remove this once aectemplater deals with `property_value_kind`
            elif "EnergyEndUseTags" not in di:
                di["EnergyEndUseTags"] = []
            else:
                di["EnergyEndUseTags"] = [di["EnergyEndUseTags"]]
        return spec_data

    def _reload_datahandler(self):
        self._reload_all_data()

    def _set_col_widths(self):
        self.grid.column_widths = COLUMN_WIDTHS_RECORDED

    def _hide_id_widgets(self):
        if self.ui_add.properties and self.ui_edit.properties:
            fields_to_hide = ['Id', "InstanceReference", "LevelReference", "VolumeReference", "TypeMark", "TypeSpecId"]
            self.ui_add.order = [property_ for property_ in self.order if property_ not in fields_to_hide]
            self.ui_edit.order = [property_ for property_ in self.order if property_ not in fields_to_hide]

    def _hide_empty_lists_in_datagrid(self):
        # Define the Vega expression
        vega_expr = """
if(
    cell.value == "[object Object]",
    ' ',
    if(
        !isValid(cell.value),
        ' ',
        cell.value
    )
)
"""
        self.grid.default_renderer.text_value = VegaExpr(vega_expr)

    def _remove_show_hide_nulls(self):
        self.ui_add.show_null = True
        self.ui_edit.show_null = True
        self.ui_add.bn_shownull.layout.display = "none"
        self.ui_edit.bn_shownull.layout.display = "none"


if __name__ == "__main__":
    gr = RecordedEnergyUseGrid()
    display(gr)
    gr.project_revision_id = 2


# +
class PredictedEnergyUseGrid(RecordedEnergyUseGrid):
    def __init__(
        self,
        object_id=OBJECT_ID_PREDICTED,
        order=ORDER_PREDICTED,
        abbreviation=ABBREVIATION_PREDICTED,
        x_name="OperationalEnergyAnalysisType",
        **kwargs,
    ):
        super().__init__(object_id=object_id, order=order, abbreviation=abbreviation, x_name=x_name, **kwargs)
        self.buttonbar_grid.crud_view = PREDICTED_ENERGY_USE_BUTTONBAR_CONFIG

    def _set_col_widths(self):
        self.grid.column_widths = COLUMN_WIDTHS_PREDICTED


if __name__ == "__main__":
    gr = PredictedEnergyUseGrid()
    display(gr)
    gr.project_revision_id = 2
