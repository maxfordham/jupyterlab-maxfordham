import ipywidgets as w
from IPython.display import display
from markdown import markdown

from aectemplater_ui.apps.energy_use import ORDER_RECORDED, EnergyDashboard, RecordedEnergyUseGrid
from aectemplater_ui.load_project import LoadProject

DESCRIPTION = """
- Each row in the table below corresponds to a recorded energy use within a project; many rows can be added for a given project and rows with the same reporting period are summed.
- Specify the fuel type of the energy consumption, and where known specify the energy end-use.
- Ad-hoc energy end-use tags and notes can be added where the end-use is unknown or doesn't fit neatly in a category.
"""


class RecordedEnergyUse(w.VBox):
    def __init__(self, **kwargs):
        self.energy_dashboard = EnergyDashboard()
        self.grid = RecordedEnergyUseGrid()
        self.accordion = w.Accordion()
        self.select_project = LoadProject()
        self.description = w.HTML(markdown(DESCRIPTION))
        self.grid.hbx_bar.children = [self.grid.buttonbar_grid, self.select_project]
        self.grid.hbx_bar.layout = w.Layout(justify_content="space-between")
        self.grid.grid.layout.height = "400px"
        self.accordion.children = [w.VBox([self.description, self.grid])]
        self.accordion.titles = ["Input Project Recorded Energy Use"]
        self.grid.grid.observe(self.energy_dashboard.reload, "count_changes")
        super().__init__([self.accordion, self.energy_dashboard], **kwargs)
        self.order = ORDER_RECORDED
        self.select_project.observe(self._update_project_revision_id, "project_revision_id")

    def _update_project_revision_id(self, on_change):
        self.grid.project_revision_id = self.select_project.project_revision_id


if __name__ == "__main__":
    app = RecordedEnergyUse()
    display(app)
