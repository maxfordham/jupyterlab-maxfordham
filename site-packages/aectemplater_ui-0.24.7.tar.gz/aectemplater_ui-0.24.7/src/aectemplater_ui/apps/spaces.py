# +
import traitlets as tr
from aectemplater_client import get_project_type_marks, get_type_spec_object_data_grid, post_type_spec_data
from ipyautoui.custom.buttonbars import CrudOptions, CrudView

from aectemplater_ui.apps.constants import ABBREVIATION_SPACE, OBJECT_ID_SPACE
from aectemplater_ui.instance_specification import InstanceSpecGrid

# -


SPACE_BUTTONBAR_CONFIG = CrudView(
    add=CrudOptions(
        tooltip="""Click to add Space data.
Input the data and then click save.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Space</i>",
    ),
    edit=CrudOptions(
        tooltip="""Select a Space from the table and click to edit.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Space</i>",
    ),
    copy=CrudOptions(
        tooltip="""Select row(s) from the table and click to duplicate.""",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Duplicate Spaces</i>",
    ),
    delete=CrudOptions(
        tooltip="""Select row(s) from the table and click to open deletion menu.
Click the red DELETE button to confirm deletion.
Once deleted, click again to close the menu.""",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Spaces</i>",
    ),
    reload=CrudOptions(
        tooltip="Click to reload.",
        button_style="info",
        message="🔄 <i>Reload Spaces</i>",
    ),
    support=CrudOptions(
        tooltip="Show Help",
        tooltip_clicked="Go back to table",
        message="❔ <i>Help</i>",
    ),
)

COLUMN_WIDTHS = {
    "('key', '', '')": 79,
    "('Identity Data', 'Type Spec Id', '')": 0.5,
    "('Identity Data', 'Id', '')": -169,
    "('Electricity Distribution', 'Number of Switch Disconnectors', '')": 197,
    "('Lighting', 'Emergency Lighting', '')": 130,
    "('Identity Data', 'Occupancy Number', '')": 159,
    "('Identity Data', 'Level Reference', '')": 142,
    "('Identity Data', 'Volume Reference', '')": 137,
    "('Identity Data', 'Name', '')": 119,
    "('Identity Data', 'Room Type', '')": 109,
    "('Identity Data', 'Number', '')": 100,
    "('Identity Data', 'Typical Room Detail', '')": 144,
    "('Identity Data', 'Notes', '')": 174,
    "('Identity Data', 'Classification Uniclass Space Number', '')": 248,
    "('Identity Data', 'Smart Building Requirements', '')": 232,
    "('Dimensions', 'Area', 'm²')": 84,
    "('Performance', 'Colour Rendering Index', '')": 151,
    "('Plumbing', 'Water Strategy', '')": 183,
    "('Plumbing', 'Drainage', '')": 149,
    "('Plumbing', 'Water Supply', '')": 146,
    "('Mechanical', 'Gas Supply', '')": 155,
    "('Space Heating and Cooling', 'Heating Strategy', '')": 243,
    "('Space Heating and Cooling', 'Heating Control Strategy', '')": 233,
    "('Space Heating and Cooling', 'Heating Dry Bulb', '°C')": 165,
    "('Space Heating and Cooling', 'Heating Set Point Max', '°C')": 168,
    "('Space Heating and Cooling', 'Cooling Set Point Max', '°C')": 163,
    "('Space Heating and Cooling', 'Cooling Dry Bulb', '°C')": 166,
    "('Space Heating and Cooling', 'Cooling Set Point Min', '°C')": 164,
    "('Space Heating and Cooling', 'Humidity Control Strategy', '')": 215,
    "('Ventilation', 'Ventilation Strategy', '')": 198,
    "('Ventilation', 'Ventilation Control Strategy', '')": 232,
    "('Identity Data', 'Acoustic Requirements', '')": 187,
    "('Space Heating and Cooling', 'Heating Set Point Min', '°C')": 165,
    "('Space Heating and Cooling', 'Cooling Strategy', '')": 169,
    "('Space Heating and Cooling', 'Cooling Control Strategy', '')": 167,
    "('Electricity Distribution', 'Electrical Strategy', '')": 193,
    "('Electricity Distribution', 'Small Power Strategy', '')": 207,
    "('Electricity Distribution', 'Perimeter Trunking', '')": 136,
    "('Electricity Distribution', 'Emergency Power Off', '')": 135,
    "('Electricity Distribution', 'Number of Floor Boxes', '')": 148,
    "('Electricity Distribution', 'Number of Single Socket Outlets', '')": 197,
    "('Electricity Distribution', 'Number of Double Socket Outlets', '')": 197,
    "('Electricity Distribution', 'Number of Fused Connection Units', '')": 203,
    "('Electricity Distribution', 'Number of Commando Power Sockets - Single Phase', '')": 306,
    "('Electricity Distribution', 'Number of Commando Power Sockets - Three Phase', '')": 300,
    "('Electricity Distribution', 'Number of Suspended Socket Units', '')": 212,
    "('Lighting', 'Lighting Strategy', '')": 169,
    "('Lighting', 'Lighting Control Strategy', '')": 191,
    "('Lighting', 'Minimum Horizontal/Task Illuminance', 'lx')": 220,
    "('Lighting', 'Illuminance Uniformity', '')": 139,
    "('Lighting', 'Unified Glare Rating', '')": 132,
    "('Communications, Security, Safety, Control, and Protection Systems', 'Communications Strategy', '')": 410,
    "('Communications, Security, Safety, Control, and Protection Systems', 'Number of Data Points', '')": 381,
    "('Communications, Security, Safety, Control, and Protection Systems', 'Number of WiFi Points', '')": 380,
    "('Communications, Security, Safety, Control, and Protection Systems', 'Security and Access Control Strategy', '')": 376,
    "('Communications, Security, Safety, Control, and Protection Systems', 'Fire, Smoke Detection, and Alarm Strategy', '')": 379,
}


class SpacesGrid(InstanceSpecGrid):
    @tr.observe("project_revision_id")
    def _set_project_data(self, onchange):
        if self.project_revision_id is not None:
            self._check_for_type_spec()
            self._set_type_mark()
            self._reload_datahandler()
            self.grid.column_widths = COLUMN_WIDTHS
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    def __init__(self, **kwargs):
        self.abbreviation = ABBREVIATION_SPACE
        super().__init__(object_id=OBJECT_ID_SPACE, **kwargs)
        self.grid.column_widths = COLUMN_WIDTHS
        self.buttonbar_grid.crud_view = SPACE_BUTTONBAR_CONFIG
        # Hide buttons to edit grid whilst EXPORT TO REVIT is not implemented
        # Data will be exported from Revit
        self.buttonbar_grid.show_support = False
        self.buttonbar_grid.add.layout.display = "none"
        self.buttonbar_grid.edit.layout.display = "none"
        self.buttonbar_grid.copy.layout.display = "none"
        self.buttonbar_grid.delete.layout.display = "none"

    def _check_for_type_spec(self):
        """Check for initial type specification for spaces.
        An initial type is required so we can add instances (of spaces)."""
        object_data_grid = get_type_spec_object_data_grid(
            object_id=self.object_id, project_revision_id=self.project_revision_id
        )
        if not object_data_grid["data"]:
            object_data_grid = post_type_spec_data(
                object_id=self.object_id,
                project_revision_id=self.project_revision_id,
                override_units=True,
                value={"Abbreviation": self.abbreviation, "TypeReference": 1},
            )

    def _set_type_mark(self, onchange=None):
        """Set Type Mark."""
        if self.project_revision_id is not None:
            project_type_marks = list(
                get_project_type_marks(project_revision_id=self.project_revision_id, object_id=self.object_id).keys()
            )
            self.ui_add.di_widgets["TypeMark"].options = project_type_marks
            self.ui_add.di_widgets["TypeMark"].value = project_type_marks[0]
            self.ui_edit.di_widgets["TypeMark"].options = project_type_marks
            self.ui_edit.di_widgets["TypeMark"].value = project_type_marks[0]
            self.ui_add.di_boxes["TypeMark"].layout.display = "None"
            self.ui_edit.di_boxes["TypeMark"].layout.display = "None"

    def _hide_id_widgets(self):
        ignore = ['TypeMark', 'TypeSpecId']
        self.ui_add.order = [property_ for property_ in self.ui_add.default_order if property_ not in ignore]
        self.ui_edit.order = [property_ for property_ in self.ui_edit.default_order if property_ not in ignore]
        self.grid.order = [name for name in self.schema["items"]["properties"] if name not in ignore]

    @property
    def selected_marks(self):
        pass


if __name__ == "__main__":
    gr = SpacesGrid(project_revision_id=3)
    display(gr)
