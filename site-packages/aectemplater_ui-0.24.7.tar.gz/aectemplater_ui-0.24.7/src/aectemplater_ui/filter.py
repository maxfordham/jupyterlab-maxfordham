# +
import json
import logging
import typing as ty

import ipywidgets as w
import traitlets as tr
import yaml
from aectemplater_client import (
    delete_filter,
    delete_project_filter,
    get_filters,
    get_project_filter_by_project_revision_and_filter,
    get_project_filters_by_project_revision,
    get_project_revision_by_project_number_and_revision,
    get_property_names,
    get_spec_tags_from_project_filter,
    patch_filter,
    patch_project_filter,
    post_filter,
    post_project_filter,
)
from aectemplater_schemas.enumerations import ParameterTypeEnum, RuleSetType, UseTypeEnum
from ipyautoui._utils import html_link
from ipyautoui.autodisplay_renderers import preview_yaml_string
from ipyautoui.autoobject import AutoObject, AutoObjectForm
from ipyautoui.custom.editgrid import DataHandler, EditGrid
from IPython.display import clear_output, display
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    ValidationInfo,
    field_validator,
    model_validator,
)
from pyuniclass import UT

from aectemplater_ui import ENV
from aectemplater_ui.formatting import GRID_STYLE
from aectemplater_ui.schemas import (
    FilterGet,
    Rule,
    RuleSetPatch,
)
from aectemplater_ui.utils import hide_show_null

DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
    project_number=ENV.AECTEMPLATER_PROJECT_NUMBER,
    revision=ENV.DEFAULT_PROJECT_REVISION,
)["id"]
URL_REVIT_FILTERS = "https://help.autodesk.com/view/RVT/2023/ENU/?guid=GUID-400FD74B-00E0-4573-B3AC-3965E65CBBDB"
MAP_PROPERTY_NAME_TO_ID = get_property_names(limit=-1)
MAP_PROPERTY_ID_TO_NAME = {v: k for k, v in MAP_PROPERTY_NAME_TO_ID.items()}


# +
class RuleSchemaUi(Rule):
    property_id: ty.Optional[int]
    value: str = Field(
        description="Value to filter by. Evaluates to the appropriate type. Leave empty if none required (e.g. has value operator)",
        json_schema_extra=dict(autoui="ipyautoui.custom.combobox_mapped.ComboboxMapped"),
    )

    @model_validator(mode="before")
    @classmethod
    def _validate_property_id(cls, values):
        try:
            parameter = values.get("parameter")
            property_id = values.get("property_id")

            if parameter in MAP_PROPERTY_NAME_TO_ID:
                values["property_id"] = MAP_PROPERTY_NAME_TO_ID[parameter]
            elif property_id in MAP_PROPERTY_ID_TO_NAME:
                values["parameter"] = MAP_PROPERTY_ID_TO_NAME[property_id]
            else:
                msg = "Neither Property ID nor Parameter Name in the rule exist in database."
                raise Exception(msg)
            return values
        except Exception as e:
            logging.warning(e)

    model_config = ConfigDict(title="Rule", json_schema_extra=dict(autoui="aectemplater_ui.filter.rule_ui"))


RuleSetSchemaUi = ty.ForwardRef("RuleSetSchemaUi")


class RuleSetSchemaUi(RuleSetPatch):
    set_type: RuleSetType = Field(
        title="Set Type",
        default=RuleSetType.OR,
        json_schema_extra=dict(autoui="ipywidgets.ToggleButtons"),
    )
    rule: ty.List[ty.Union[RuleSchemaUi, RuleSetSchemaUi]] = Field(
        title="Rule",
        description="""
rules return a boolean for the logical evaluation defined below for every item within the categories defined
""",
    )

    model_config = ConfigDict(title="RuleSet", json_schema_extra=dict(open_nested=True))


RuleSetSchemaUi.__doc__ = (
    """A set of rules that defines what equipment specifications will appear in a given schedule.<br>
Rules must evaluate to True for the item to be included in a schedule
Analogous to filter rules in
"""
    + html_link(URL_REVIT_FILTERS, "Revit.")
    + "<br><b>This is the basis of a customised example from the wild!</b>"
    + "<br>---"
)

# +
pr_description_map = UT.Pr.data.set_index("description")["Code"].to_dict() | {"": ""}
pr_code_map = {v: k for k, v in pr_description_map.items()}
ss_description_map = UT.Ss.data.set_index("description")["Code"].to_dict() | {"": ""}
ss_code_map = {v: k for k, v in ss_description_map.items()}
pr_descriptions = UT.Pr.data.Title.values.tolist()
ss_descriptions = UT.Ss.data.Title.values.tolist()


def get_value_options(property_name) -> ty.Union[list, dict]:
    if property_name == "ClassificationUniclassProductNumber":
        return pr_description_map
    elif property_name == "ClassificationUniclassSystemNumber":
        return ss_description_map
    else:
        return {}


class RuleUi(AutoObject):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _post_init(self, *args, **kwargs):
        self.di_widgets["value"].widget.ensure_option = False
        self.di_widgets["parameter"].options = list(MAP_PROPERTY_NAME_TO_ID.keys())
        self._init_RuleUi_controls()
        self.order = ["categories", "parameter", "operator", "value"]

    def _init_RuleUi_controls(self):
        self.di_widgets["parameter"].observe(self._update_rule_value_options, "value")

    def _update_rule_value_options(self, on_change):
        if self.di_widgets["parameter"].value:
            self.di_widgets["value"].options = get_value_options(on_change["new"])
            self.di_widgets["value"].value = ""


def rule_ui(value=None, **kwargs):
    ui = RuleUi.from_pydantic_model(RuleSchemaUi)
    ui.open_nested = True
    if value is not None:
        ui.value = value
    return ui


# -
if __name__ == "__main__":
    from IPython.display import display

    ui = AutoObjectForm.from_pydantic_model(RuleSetSchemaUi, show_validation=False)
    display(ui)


# +
class FilterSchemaUi(FilterGet):
    """Please populate the fields below"""

    id: int = Field(json_schema_extra=dict(column_width=-1, disabled=True))
    rule_set: RuleSetSchemaUi = Field(
        title="Rule Set",
        description="A collection of rules combined with either ANDs or ORs.",
    )
    model_config = ConfigDict(title="Filters", from_attributes=True)


class FilterDataFrame(RootModel):
    root: ty.List[FilterSchemaUi] = Field(format="dataframe")


class FilterGrid(EditGrid):
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)

    @tr.observe("use_type")
    def _observe_use_type(self, change):
        self.value = self.get_filters()
        self._set_add_widget()

    def __init__(self, *args, **kwargs):
        self.post_filter = post_filter
        datahandler = DataHandler(
            fn_get_all_data=self.get_filters,
            fn_post=self.post_filter,
            fn_patch=self.patch_filter,
            fn_delete=self.delete_filter,
            fn_copy=self.copy_filter,
        )
        super().__init__(
            schema=FilterDataFrame,
            datahandler=datahandler,
            order=["name", "version", "rule_set", "use_type", "parameter_type", "id"],
            warn_on_delete=True,
            show_title=True,
            grid_style=GRID_STYLE,
            column_widths={"name": 150, "version": 70, "rule_set": 100},
            *args,
            **kwargs,
        )
        self._init_value()
        hide_show_null(self.ui_edit, self.ui_add)
        self._set_add_widget()

    def _init_value(self):
        self.value = self.datahandler.fn_get_all_data()

    def _set_add_widget(self):
        self.ui_add.di_widgets["use_type"].value = self.use_type
        if self.use_type == UseTypeEnum.equipment:
            self.ui_add.di_widgets["parameter_type"].value = ParameterTypeEnum.type
        else:
            self.ui_add.di_widgets["parameter_type"].value = ParameterTypeEnum.instance

    def get_filters(self):
        return get_filters(limit=-1, use_type=self.use_type)

    def patch_filter(self, value: dict):
        return patch_filter(value["id"], value)

    def delete_filter(self, value: dict):
        return delete_filter(value["id"])

    def copy_filter(self, value: dict):
        value["name"] += " DUPLICATE"
        return self.post_filter(value)


# -
if __name__ == "__main__":
    from IPython.display import display

    ui = FilterGrid()
    display(ui)

# +
# The following classes are used to set the value to the uniclass code and description
# for the preview yaml string in the UI.


class RuleUniclassValueWithDescription(Rule):
    value: str = Field(
        "",
    )

    @field_validator("value")
    @classmethod
    def _set_uniclass_value(cls, v: str, info: ValidationInfo) -> int:
        if info.data.get("parameter") == "ClassificationUniclassProductNumber" and v in pr_code_map.keys():
            return pr_code_map[v]
        elif info.data.get("parameter") == "ClassificationUniclassSystemNumber" and v in ss_code_map.keys():
            return ss_code_map[v]
        else:
            return v


RuleSetUniclassValueWithDescription = ty.ForwardRef("RuleSetUniclassValueWithDescription")


class RuleSetUniclassValueWithDescription(RuleSetPatch):
    set_type: RuleSetType = Field(
        title="Set Type",
        default=RuleSetType.OR,
    )
    rule: ty.List[ty.Union[RuleUniclassValueWithDescription, RuleSetUniclassValueWithDescription]]


# -
class Filter(w.HBox):
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)

    @tr.observe("use_type")
    def _observe_use_type(self, change):
        self.filter_grid.use_type = self.use_type
        self.html_title.value = f"<b>{self.use_type.value} captured by Filter</b>"

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        self.out = w.Output(layout=dict(width="500px"))
        self.html_title = w.HTML("<b>Products captured by Filter</b>")
        self.html_specs = w.HTML()
        self.filter_grid = FilterGrid()
        self.filter_grid.layout.width = "50%"
        super().__init__(
            *args,
            **kwargs,
            layout=dict(justify_content="space-between"),
        )
        self.filter_grid.grid.observe(self.set_yaml_rule_set, "selections")
        self.filter_grid.grid.observe(self.set_specs_selected, "selections")
        self.children = [
            self.filter_grid,
            self.out,
            w.VBox(
                [
                    self.html_title,
                    self.html_specs,
                ],
                layout=dict(width="30%"),
            ),
        ]
        self.filter_grid.buttonbar_grid.add.observe(self.toggle_yaml_rule_set)
        self.filter_grid.buttonbar_grid.edit.observe(self.toggle_yaml_rule_set)

    def set_specs_selected(self, change):
        if self.filter_grid.grid.selections:
            filter_id = self.filter_grid.grid.selected_row["id"]
            project_filter = get_project_filter_by_project_revision_and_filter(
                filter_id=filter_id, project_revision_id=DEFAULT_PROJECT_REVISION_ID
            )
            spec_tags = get_spec_tags_from_project_filter(project_filter["id"])
            self.html_specs.value = "<font color='blue'>" + ", ".join(spec_tags) + "</font>"

    def set_yaml_rule_set(self, change):
        if self.filter_grid.grid.selections:
            with self.out:
                clear_output()
                selected_rule_set = json.loads(
                    RuleSetUniclassValueWithDescription(
                        **self.filter_grid.grid.selected_row["rule_set"]
                    ).model_dump_json()
                )
                display(preview_yaml_string(yaml.dump(selected_rule_set, sort_keys=False)))

    def toggle_yaml_rule_set(self, change):
        if self.filter_grid.buttonbar_grid.add.value or self.filter_grid.buttonbar_grid.edit.value:
            self.out.layout.display = "none"
            self.filter_grid.layout.width = "100%"
        else:
            self.out.layout.display = "flex"
            self.filter_grid.layout.width = "50%"


if __name__ == "__main__":
    from IPython.display import display

    ui = Filter()
    display(ui)


# +
# TODO: Does this schema need to exist? Can we not just extend schema from aectemplater-schemas?
class ProjectFilterSchemaUi(BaseModel):
    """Please populate the fields below"""

    id: int = Field(json_schema_extra=dict(column_width=-1, disabled=True))
    name: str
    rule_set: RuleSetSchemaUi = Field(
        title="Rule Set",
        description="A collection of rules combined with either ANDs or ORs.",
    )
    use_type: UseTypeEnum = Field(
        title="Use Type",
        description="The use type of the filter",
        json_schema_extra=dict(column_width=125, disabled=True),
    )
    parameter_type: ParameterTypeEnum = Field(
        title="Parameter Type",
        description="The parameter type of the filter. This will determine whether to filter on type or instance data.",
        json_schema_extra=dict(column_width=115, disabled=True),
    )
    filter_id: ty.Optional[int] = None

    model_config = ConfigDict(title="Project Filters", from_attributes=True)


class ProjectFilterDataFrame(RootModel):
    root: ty.List[ProjectFilterSchemaUi] = Field(format="dataframe")


class ProjectFilterGrid(EditGrid):
    project_revision_id = tr.Integer(default_value=DEFAULT_PROJECT_REVISION_ID)
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)

    @tr.observe("project_revision_id", "use_type")
    def _observe(self, change):
        self.value = self.get_project_filters()
        self._set_add_widget()

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        super().__init__(
            schema=ProjectFilterDataFrame,
            datahandler=DataHandler(
                fn_get_all_data=self.get_project_filters,
                fn_post=self.post_project_filter,
                fn_patch=self.patch_project_filter,
                fn_delete=self.delete_project_filter,
                fn_copy=self.copy_project_filter,
            ),
            order=["name", "rule_set", "use_type", "parameter_type", "id"],
            warn_on_delete=True,
            show_title=True,
            grid_style=GRID_STYLE,
            hide_nan=True,
            column_widths={"name": 150, "rule_set": 100},
            *args,
            **kwargs,
        )
        hide_show_null(self.ui_edit, self.ui_add)
        self.value = self.get_project_filters()
        self._set_add_widget()

    def _set_add_widget(self):
        self.ui_add.di_widgets["use_type"].value = self.use_type
        if self.use_type == UseTypeEnum.equipment:
            self.ui_add.di_widgets["parameter_type"].value = ParameterTypeEnum.type
        else:
            self.ui_add.di_widgets["parameter_type"].value = ParameterTypeEnum.instance

    def get_project_filters(self):
        return get_project_filters_by_project_revision(self.project_revision_id, use_type=self.use_type)

    def post_project_filter(self, value: dict):
        value["project_revision_id"] = self.project_revision_id
        value.pop("id")
        return post_project_filter(value)

    def patch_project_filter(self, value: dict):
        id = value["id"]
        return patch_project_filter(id, value)

    def delete_project_filter(self, value: dict):
        id = value["id"]
        return delete_project_filter(id)

    def copy_project_filter(self, value: dict):
        value["name"] += " DUPLICATE"
        return self.post_project_filter(value)


# -
if __name__ == "__main__":
    from IPython.display import display

    ui = ProjectFilterGrid()
    display(ui)


def html_filters_warning():
    return w.HTML(
        """
<!DOCTYPE html>
<html>
<head>
    <style>
        .banner {
            background-color: #ff9966; 
            width: 100%;
            height: 35px; /* Adjust the height as per your requirement */
            color: white; /* Change the text color as per your requirement */
            text-align: center;
            padding: 0px 0;
            font-size: 16px; /* Adjust the font size as per your requirement */
        }
    </style>
</head>
<body>
    <div class="banner">
        ⚠ <b>AVOID EDITING PROJECT FILTERS WHERE POSSIBLE</b>. Use the default Project Filters that are added when you create a new Schedule. ⚠
    </div>
</body>
</html>
"""
    )


class ProjectFilter(w.VBox):
    project_revision_id = tr.Integer(default_value=DEFAULT_PROJECT_REVISION_ID)
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)

    @tr.observe("project_revision_id")
    def _observe_project(self, change):
        self.project_filter_grid.project_revision_id = self.project_revision_id

    @tr.observe("use_type")
    def _observe_use_type(self, change):
        self.project_filter_grid.use_type = self.use_type
        self.html_title.value = f"<b>{self.use_type.value} captured by Filter</b>"

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        self.out = w.Output(layout=dict(width="500px"))
        self.html_title = w.HTML()
        self.html_specs = w.HTML()
        self.project_filter_grid = ProjectFilterGrid(use_type=self.use_type)
        self.project_filter_grid.layout.width = "50%"
        super().__init__(
            *args,
            **kwargs,
            layout=dict(justify_content="space-between"),
        )
        self.project_filter_grid.grid.observe(self.set_yaml_rule_set, "selections")
        self.project_filter_grid.grid.observe(self.set_specs_selected, "selections")
        self.children = [
            html_filters_warning(),
            w.HBox(
                [
                    self.project_filter_grid,
                    self.out,
                    w.VBox(
                        [
                            self.html_title,
                            self.html_specs,
                        ],
                        layout=dict(width="30%"),
                    ),
                ]
            ),
        ]
        self.project_filter_grid.buttonbar_grid.add.observe(self.toggle_yaml_rule_set)
        self.project_filter_grid.buttonbar_grid.edit.observe(self.toggle_yaml_rule_set)

    def set_specs_selected(self, change):
        if self.project_filter_grid.grid.selections:
            project_filter_id = self.project_filter_grid.grid.selected_row["id"]
            spec_tags = get_spec_tags_from_project_filter(project_filter_id)
            self.html_specs.value = "<font color='blue'>" + ", ".join(spec_tags) + "</font>"

    def set_yaml_rule_set(self, change):
        if self.project_filter_grid.grid.selections:
            with self.out:
                clear_output()
                selected_rule_set = json.loads(
                    RuleSetUniclassValueWithDescription(
                        **self.project_filter_grid.grid.selected_row["rule_set"]
                    ).model_dump_json()
                )
                display(preview_yaml_string(yaml.dump(selected_rule_set, sort_keys=False)))

    def toggle_yaml_rule_set(self, change):
        if self.project_filter_grid.buttonbar_grid.add.value or self.project_filter_grid.buttonbar_grid.edit.value:
            self.out.layout.display = "none"
            self.project_filter_grid.layout.width = "100%"
        else:
            self.out.layout.display = "flex"
            self.project_filter_grid.layout.width = "50%"


if __name__ == "__main__":
    from IPython.display import display

    ui = ProjectFilter()
    display(ui)

if __name__ == "__main__":
    ui.use_type = UseTypeEnum.spaces
