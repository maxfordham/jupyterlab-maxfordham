# ---
# jupyter:
#   jupytext:
#     formats: py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %%
# %run __init__.py
# %load_ext lab_black

# %%
import io
import re
import PIL
import logging
import pathlib
import ipywidgets as w
import traitlets as tr
import typing as ty
from enum import Enum
from dataclasses import dataclass
from IPython.display import display

from ipyautoui.constants import (
    BUTTON_HEIGHT_MIN,
    BUTTON_WIDTH_MIN,
    FILEUPLD_BUTTON_KWARGS,
)
from ipyautoui.custom.buttonbars import SaveButtonBar
from ipyautoui.custom.iterable import Array
from aectemplater_schemas.images import (
    PdtImage,
    PREVIEW_TO_PAGE_RATIO,
    DEFAULT_HEIGHT_PERCENTAGE,
)

from aectemplater_ui.utils import get_fdir_project_schedule_images, generate_image_fname

try:
    logger = logging.getLogger(__name__)
except:
    from aectemplater_client import logger

PREVIEW_PAGE_WIDTH = "210px"
PREVIEW_PAGE_HEIGHT = "297px"
PREVIEW_PAGE_WIDTH_WITH_PADDING = "172px"  # = 210 -19 -19 (i.e. page of A4 minus padding)
PREVIEW_PAGE_WIDTH_WITH_PADDING_INT = int(re.findall(r"\d+", PREVIEW_PAGE_WIDTH_WITH_PADDING)[0])


# %%
@dataclass
class PdtAppImage:
    pdt_image: PdtImage
    fdir: pathlib.Path
    image: bytes = None  # this is the raw image only.


class ImageArrangement(Enum):
    zero = {"no_images": 0, "image_ratio": "0"}
    one = {"no_images": 1, "image_ratio": "1"}
    two = {"no_images": 2, "image_ratio": "1 1"}
    three = {"no_images": 3, "image_ratio": "1 1 1"}


MAP_IMG_ARRANGEMENT = [
    {**{"name": l}, **ImageArrangement[l].value} for l in list(ImageArrangement.__dict__["_member_map_"].keys())
]
MAP_LEN_ARRANGEMENT = {
    0: ImageArrangement.zero,
    1: ImageArrangement.one,
    2: ImageArrangement.two,
    3: ImageArrangement.three,
}


class ImagesPagePreview(w.VBox):
    """Ui component that shows proxy images demonstrating the size of images in the output schedule."""

    proxy_height_percentage = tr.Integer(min=0, max=100, default_value=DEFAULT_HEIGHT_PERCENTAGE)
    arrangement = tr.UseEnum(ImageArrangement, default_value=ImageArrangement.zero)
    type_mark = tr.Unicode(default_value=None, allow_none=True)

    @tr.observe("proxy_height_percentage")
    def _observe_preview_height_percentage(self, on_change):
        """Set the height of the preview images."""
        for im in self.images.children:
            im.layout.height = f"{self._proxy_height}px"

    @tr.observe("type_mark")
    def _observe_type_mark(self, on_change):
        self._set_type_mark()

    @tr.observe("arrangement")
    def _observe_selected_arrangement(self, on_change):
        self._set_proxy_images()

    @property
    def _proxy_height(self):
        """The height for the proxy images based on the percentage selected in the slider."""
        return 1.35 * self.proxy_height_percentage

    @property
    def _preview_image_widths(self):
        img_ratios = [int(i) for i in re.findall(r"\d+", self.arrangement.value["image_ratio"])]
        n = sum(img_ratios)
        if n == 0:
            return [0]
        return [(PREVIEW_PAGE_WIDTH_WITH_PADDING_INT / n) * i for i in img_ratios]

    def __init__(self, **kwargs):
        self._init_form()
        super().__init__(**kwargs)
        self.height_slider.value = self.proxy_height_percentage
        self._init_controls()
        self.children = [self.page, self.height_slider_message, self.height_slider_box]
        self._set_type_mark()

    def _init_form(self):
        self.button_layout = w.Layout(
            display="flex",
            flex_flow="column",
            border="0.5px solid green",
            width="50px",
            height="60px",
            button_color="blue",
        )
        self.page_layout = w.Layout(
            border="1px solid",
            width=PREVIEW_PAGE_WIDTH,
            height=PREVIEW_PAGE_HEIGHT,
            padding="19px 19px 19px 19px",
        )
        self.title = w.HTML()
        self.images = w.HBox(layout={"justify_content": "space-between"})
        self.page = w.VBox([self.title, self.images], layout=self.page_layout)
        self.height_slider = w.IntSlider(
            min=self.traits()["proxy_height_percentage"].min,
            max=self.traits()["proxy_height_percentage"].max,
            default=self.traits()["proxy_height_percentage"].default_value,
            layout={"width": "150px"},
        )
        self.height_slider_reset = w.Button(
            icon="refresh",
            layout={"width": BUTTON_WIDTH_MIN, "height": BUTTON_HEIGHT_MIN},
            tooltip="restore defaults",
        )
        self.height_slider_message = w.HTML(value="Adjust height of images using the slider:")
        self.height_slider_box = w.HBox(
            [self.height_slider_reset, self.height_slider],
            layout={"width": PREVIEW_PAGE_WIDTH},
        )

    def _init_controls(self):
        self.height_slider.observe(self._update_height, "value")
        self.height_slider_reset.on_click(self._height_slider_reset)

    def _height_slider_reset(self, click):
        self.height_slider.value = self.traits()["proxy_height_percentage"].default_value

    def _update_height(self, change):
        self.proxy_height_percentage = self.height_slider.value

    def _set_type_mark(self):
        bold = lambda s: f"<b>{s}</b>"
        if self.type_mark is not None:
            if self.type_mark == "":
                self.title.value = bold("PDS Type")
            else:
                self.title.value = bold(self.type_mark)
        else:
            self.title.value = bold("PDS Type")

    def _set_proxy_images(self):
        """Set proxy images based on the number of images uploaded."""
        li_proxy_img = []
        for width in self._preview_image_widths:
            button_layout = w.Layout(
                display="flex",
                flex_flow="column",
                border="0.5px solid green",
                width=f"{width}px",
                height=f"{self._proxy_height}px",
                button_color="blue",
            )
            proxy_image = w.Button(disabled=True, layout=button_layout)
            if width != 0:
                li_proxy_img.append(proxy_image)
        self.images.children = li_proxy_img


if __name__ == "__main__":
    img_preview = ImagesPagePreview(arrangement=ImageArrangement.one)
    display(img_preview)


# %%
class ImageUi(w.VBox):
    """Ui component to preview the image and set a caption."""

    value = tr.Instance(klass=PdtAppImage, allow_none=True, default_value=None)

    @tr.observe("value")
    def _obs_value(self, on_change):
        if self.value is not None:
            self.img.value = self.value.image
            self._adjust_image_size()
            self.caption.value = self.value.pdt_image.caption

    def __init__(self, **kwargs):
        self.img = w.Image()
        self.caption = w.Textarea()
        super().__init__(**kwargs)
        self.children = [self.img, self.caption]
        self._init_controls()

    def _init_controls(self):
        self.caption.observe(self._set_pdt_image_caption, "value")

    def _adjust_image_size(self):
        """Adjust the size of the preview image so that the height is 300px.
        This is so that the images are shown appropriately next to one another in the Ui.
        """
        im = PIL.Image.open(io.BytesIO(self.value.image))
        width, height = im.size
        image_ui_height = 300
        height_ratio = image_ui_height / height
        image_ui_width = width * height_ratio
        self.img.layout = dict(height=f"{image_ui_height}px", width=f"{image_ui_width}px")

    def _set_pdt_image_caption(self, on_change):
        """Set the caption of the PdtImage from the Ui."""
        self.value.pdt_image.caption = self.caption.value


class ImageArray(Array):
    project_number = tr.Integer(default_value=None, allow_none=True)
    image_prefix = tr.Unicode(default_value=None, allow_none=True)

    @property
    def fdir_project_schedule_images(self) -> ty.Union[pathlib.Path, None]:
        """Get the file directory where the images are stored for a certain project."""
        if self.project_number is not None:
            fdir_project_schedule_images = get_fdir_project_schedule_images(self.project_number)
            fdir_project_schedule_images.mkdir(parents=True, exist_ok=True)
            return fdir_project_schedule_images
        else:
            return None

    @property
    def fpths_project_schedule_images(self) -> ty.List[pathlib.Path]:
        """Get all the file paths of the images for a certain project."""
        if self.project_number is not None:
            return list(self.fdir_project_schedule_images.glob(f"{self.image_prefix}__*"))
        else:
            return []

    @tr.observe("project_number", "image_prefix")
    def _obs_project_number_and_image_prefix(self, on_change):
        self.value = [
            PdtAppImage(
                fdir=fpth.parent,
                image=fpth.read_bytes(),
                pdt_image=PdtImage.from_fpth(fpth),
            )
            for fpth in self.fpths_project_schedule_images
        ]

    def __init__(self, **kwargs):
        super().__init__(
            orient_rows=False,
            fn_add=ImageUi,
            fn_remove=self._remove_image,
            add_remove_controls="remove_only",
            show_hash=None,
            align_horizontal=True,
            **kwargs,
        )
        self.layout.border = None

    def _remove_image(self, bx):
        self.display_bn_add_from_zero(display=False)

    def _load_image(self, upld_item: tr.Bunch):
        """Load an image from bytes and preview in the Ui."""
        kw = dict(
            fpth=self.fdir_project_schedule_images / generate_image_fname(image_prefix=self.image_prefix),
            project_number=self.project_number,
        )
        pdt_image = PdtImage(**kw)
        pdt_app_image = PdtAppImage(
            fdir=self.fdir_project_schedule_images,
            image=upld_item.content,
            pdt_image=pdt_image,
        )
        self.add_row(add_kwargs={"value": pdt_app_image})

    def _load_images(self, upld_value: ty.List[tr.Bunch]):
        """Load multiple images and preview them."""
        for item in upld_value:
            self._load_image(item)

    def _save_images(self):
        """Save multiple images and write their exif data."""
        for fpth in self.fpths_project_schedule_images:
            if fpth is not None and fpth.is_file():
                fpth.unlink(missing_ok=True)
        for pdt_app_image in self.value:
            img = PIL.Image.open(io.BytesIO(pdt_app_image.image))
            img.save(self.fdir_project_schedule_images / pdt_app_image.pdt_image.fpth.name)
            pdt_app_image.pdt_image.write_exif()  # saves the exif data e.g. caption as UserComment


# %%
# TODO: Refactor so that we only require either type_mark or image_prefix.
# We should not need BOTH as they contain the same data but in different formats.
class PdtImageUi(w.HBox):
    project_number = tr.Int(default_value=None, allow_none=True)
    type_mark = tr.Unicode(default_value=None, allow_none=True)
    image_prefix = tr.Unicode(default_value=None, allow_none=True)

    @tr.observe("image_prefix")
    def observe_image_prefix(self, on_change):
        self.images.image_prefix = self.image_prefix
        self._allow_upload()
        if self.images.value:
            self.preview.height_slider.value = round(
                (float(self.images.value[0].pdt_image.height.replace("px", "")) / PREVIEW_TO_PAGE_RATIO)
            )
        else:
            self.preview.height_slider.value = self.preview.traits()["proxy_height_percentage"].default_value
        self.bbar.unsaved_changes = False

    @tr.observe("type_mark")
    def observe_type_mark(self, on_change):
        self.preview.type_mark = self.type_mark

    @tr.observe("project_number")
    def _observe_project_number(self, on_change):
        self.images.project_number = self.project_number
        self._allow_upload()

    def _show_unsaved_changes(self, on_change):
        self.bbar.unsaved_changes = True

    def _set_arrangenment(self, on_change):
        if len(on_change["new"]) != len(on_change["old"]):
            self.preview.arrangement = MAP_LEN_ARRANGEMENT[self.images.length]
        for image_widget in self.images.widgets:
            image_widget.caption.observe(self._show_unsaved_changes, "value")

    def _disable_upload(self, on_change):
        """Disable upload if three images loaded."""
        if self.preview.arrangement == ImageArrangement.three:
            self.upload.disabled = True
        else:
            self.upload.disabled = False

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._init_form()
        self._init_controls()
        self.bbar.fns_onsave_add_action(self._set_image_height_from_preview_height)
        self.bbar.fns_onsave_add_action(self.images._save_images)
        self.children = [self.vbx_preview, self.images]

    def _init_form(self):
        self.preview = ImagesPagePreview()
        self.images = ImageArray(project_number=self.project_number, image_prefix=self.image_prefix)
        self.upload = w.FileUpload(**dict(FILEUPLD_BUTTON_KWARGS) | {"accept": "image/*", "tooltip": "upload image"})
        self.bbar = SaveButtonBar()
        self.hbx_bbar = w.HBox([self.upload, self.bbar])
        self.vbx_preview = w.VBox([self.hbx_bbar, self.preview], layout=dict(width="300px"))
        self.bbar.bn_revert.layout.display = "None"
        self.bbar.message.layout.display = "None"

    def _init_controls(self):
        self.preview.observe(self._show_unsaved_changes, "proxy_height_percentage")
        self.upload.observe(self._show_unsaved_changes, "value")
        self.images.observe(self._show_unsaved_changes, "_value")
        self.preview.observe(self._disable_upload, "arrangement")
        self.upload.observe(self._upload, "value")
        self.images.observe(self._set_arrangenment, "_value")

    def _set_image_height_from_preview_height(self):
        """Set the image height based on preview height selected.
        This will later be written to its exif data."""
        for pdt_app_image in self.images.value:
            pdt_app_image.pdt_image.height = f"{PREVIEW_TO_PAGE_RATIO * self.preview.proxy_height_percentage}px"

    def _upload(self, on_change):
        self.images._load_images(self.upload.value)
        self.upload.value = []  # Reset load value after uploading image

    def _allow_upload(self):
        if self.project_number is not None and self.image_prefix is not None:
            self.upload.disabled = False
            self.bbar.unsaved_changes = False
        else:
            self.upload.disabled = True


if __name__ == "__main__":
    ui = PdtImageUi()
    display(ui)

# %%
if __name__ == "__main__":
    ui.project_number = 5001
    ui.image_prefix = "AT-1"
    ui.type_mark = "AT-1"
