# +
import traitlets as tr
import typing as ty
from pydantic import Field, ConfigDict
from IPython.display import display

from ipyautoui.autoobject import AutoObjectForm
from ipyautoui.custom.buttonbars import SaveButtonBar
from aectemplater_schemas.object_property_override import ObjectPropertyOverride
from aectemplater_client import (
    get_units_by_physical_quantity,
    get_object_property_override,
    get_property,
    post_object_property_override,
    patch_object_property_override,
)

from aectemplater_ui.propertyrow_select_dtype import make_unit_str


# -
class ObjectPropertyFormSchema(ObjectPropertyOverride):
    """Override Property values for a Template."""

    output_unit_id: ty.Optional[int] = Field(
        None,
        enum={},
        title="Output Unit",
        description="Select an output unit for property if for measurable quantity.",
    )
    model_config = ConfigDict(title="Override Property")


class ObjectPropertyForm(AutoObjectForm):
    object_id = tr.Int()
    property_id = tr.Int()

    @tr.observe("property_id")
    def _set_property(self, onchange):
        self._update_options_from_physical_quantity()
        self._set_values()

    @tr.observe("object_id")
    def _set_object(self, onchange):
        self._set_values()

    def __init__(self, **kwargs):
        self.savebuttonbar = SaveButtonBar(**kwargs)
        super().__init__(**kwargs)
        self.savebuttonbar.fns_onrevert_add_action(self._set_values)
        self.savebuttonbar.fns_onsave_add_action(self._save_changes)
        self.default_value = self.value
        self.show_savebuttonbar = True
        self.align_horizontal = False
        self.di_boxes["allowed_values"].indent = False
        self._init_controls()

    def _update_options_from_physical_quantity(self):
        options = self.get_options_based_on_physical_quantity()
        self.di_widgets.get("output_unit_id").widget.options = options

    def _save_changes(self):
        if self.object_property_override:
            patch_object_property_override(object_id=self.object_id, property_id=self.property_id, value=self.value)
        else:
            post_object_property_override(object_id=self.object_id, property_id=self.property_id, value=self.value)

    def _set_values(self):
        try:
            self.object_property_override = get_object_property_override(
                object_id=self.object_id, property_id=self.property_id
            )
            self.value = self.object_property_override
        except Exception as err:
            self.object_property_override = {}
            self.value = {}
        self.savebuttonbar.unsaved_changes = False

    def get_options_based_on_physical_quantity(self):
        self.physical_quantity = get_property(property_id=self.property_id)["physical_quantity"]
        if self.physical_quantity == "":
            return []
        else:
            li = get_units_by_physical_quantity(self.physical_quantity)
            li_ = [make_unit_str(l["symbol"], l["name"]) for l in li]
            return {l_: l["id"] for l_, l in zip(li_, li)}


if __name__ == "__main__":
    override_form = ObjectPropertyForm.from_pydantic_model(ObjectPropertyFormSchema)
    override_form.object_id = 3
    override_form.property_id = 12
    display(override_form)
