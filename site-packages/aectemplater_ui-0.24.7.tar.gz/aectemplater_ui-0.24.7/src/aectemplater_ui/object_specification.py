# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.17.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
import functools
import logging

import ipywidgets as w
import traitlets as tr
from aectemplater_client import (
    get_object_by_id,
    get_objects_names,
    get_project_revision_by_id,
    get_type_spec_metadata_by_project_revision,
)
from aectemplater_schemas.enumerations import StatusEnum, UseTypeEnum
from ipyautoui.constants import (
    ADD_BUTTON_KWARGS,
    BUTTON_WIDTH_MIN,
)
from ipyautoui.custom.multi_toggle_buttons import MultiToggleButtons
from ipyautoui.custom.svgspinner import SvgSpinner
from IPython.display import display

from aectemplater_ui import ENV
from aectemplater_ui.images import get_fdir_project_schedule_images
from aectemplater_ui.instance_specification import InstanceSpecGrid
from aectemplater_ui.type_specification import TypeSpecGrid
from aectemplater_ui.utils import stretch_tab_widths

stretch_tab_widths()
logging.getLogger().setLevel(logging.ERROR)

RELOAD_BUTTON_KWARGS = dict(
    icon="sync",
    style={},
    button_style="info",
    tooltip="reload",
    layout={"width": BUTTON_WIDTH_MIN},
    disabled=False,
)


# +
class ObjectSpecGrid(w.VBox):
    object_id = tr.Integer(default_value=None, allow_none=True)
    project_revision_id = tr.Integer(default_value=None, allow_none=True)

    @tr.observe("object_id", "project_revision_id")
    def _set_grid(self, onchange):
        if self.object_id is not None and self.project_revision_id is not None:
            self.type_spec_grid.fn_reload = self._reload_instance_specs
            self.instance_spec_grid.project_revision_id = self.project_revision_id
            self.instance_spec_grid.object_id = self.object_id
            self.type_spec_grid.project_revision_id = self.project_revision_id
            self.type_spec_grid.object_id = self.object_id
            self.object = get_object_by_id(self.object_id)
            self._toggle_based_on_use_type()

    def _toggle_based_on_use_type(self):
        """Toggle whether to show types or instances based on the use type."""
        if self.object["use_type"] == UseTypeEnum.spaces:
            self.bn_toggle.value = True
        else:
            self.bn_toggle.value = False

    def __init__(self, *args, **kwargs):
        self.type_spec_grid = TypeSpecGrid()
        self.instance_spec_grid = InstanceSpecGrid()
        self.bn_toggle = w.ToggleButton(
            description="TYPES",
            tooltip="Click to toggle between types and instances",
            button_style="primary",
            layout=w.Layout(width="180px"),
        )
        self._init_bn_toggle()
        self._init_controls()
        self._show_types()
        super().__init__(*args, **kwargs)
        self.children = [self.type_spec_grid, self.instance_spec_grid]

    def _init_bn_toggle(self):
        self.instance_spec_grid.hbx_bar.children = [self.instance_spec_grid.buttonbar_grid, self.bn_toggle]
        self.type_spec_grid.hbx_bar.children = [self.type_spec_grid.buttonbar_grid, self.bn_toggle]
        self.instance_spec_grid.hbx_bar.layout.justify_content = "space-between"
        self.type_spec_grid.hbx_bar.layout.justify_content = "space-between"

    def _init_controls(self):
        self.bn_toggle.observe(self._toggle_types_and_instances)

    def _toggle_types_and_instances(self, on_change):
        if self.bn_toggle.value:
            self._show_instances()
        else:
            self._show_types()

    def _show_types(self):
        self.bn_toggle.description = "SHOW INSTANCES"
        self.bn_toggle.button_style = "primary"
        self.type_spec_grid.layout.display = "flex"
        self.instance_spec_grid.layout.display = "none"

    def _show_instances(self):
        self.bn_toggle.description = "SHOW TYPES"
        self.bn_toggle.button_style = "success"
        self.type_spec_grid.layout.display = "none"
        self.instance_spec_grid.layout.display = "flex"

    def _reload_instance_specs(self, on_change=None):
        self.instance_spec_grid._reload_datahandler()


if __name__ == "__main__":
    ui = ObjectSpecGrid(
        project_revision_id=1,
        object_id=3,
    )
    display(ui)
# -

if __name__ == "__main__":
    ui.object_id = 2


class ObjectSpecification(w.VBox):
    """Used to add, edit, copy, and delete all Object Specification Grids within
    a project.

    We will load the Object Specification as the tabs are clicked on. This way, all the
    grids don't have load upon instantiation. The tabs will be set to an empty
    HTML ipywidgets object until clicked upon.
    """

    project_revision_id = tr.Integer(default_value=None, allow_none=True)
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)
    map_object_id = tr.Dict()  # all templates
    project_type_specs = tr.List(trait=tr.Dict())  # all type specs
    project_objects = tr.Dict()  # active project templates

    @tr.observe("map_object_id")
    def observe_map_object_id(self, on_change):
        self._update_add_options()

    @tr.observe("project_revision_id", "use_type")
    def observe_project_revision(self, on_change):
        self.load_options()
        self.bn_add.tooltip = f"Add {self.use_type.value}"
        self.cmbx_select.placeholder = f"Add {self.use_type.value}"
        self.msg.value = f"<b>Select {self.use_type.value} to Load</b>"

    @tr.observe("project_type_specs")
    def observe_project_type_specs(self, on_change):
        result = {}
        for l in self.project_type_specs:
            if l["object_id"] in result.values():
                continue
            name = l["object"]["name"]
            result[name] = l["object_id"]
        li = list(result.keys())
        li.sort()
        self.project_objects = {i: result[i] for i in li}
        for object_id in self.project_objects.values():
            self._add_spec_grid_callable(object_id)

    @property
    def object_ids(self):
        return list(self.project_objects.values())

    @property
    def object_names(self):
        return list(self.project_objects.keys())

    @property
    def map_unpopulated_object_names(self):
        return {k: v for k, v in self.map_object_id.items() if int(v) not in self.object_ids}

    @property
    def fdir_project_schedule_images(self):
        project_revision = get_project_revision_by_id(project_revision_id=self.project_revision_id)
        return get_fdir_project_schedule_images(project_number=project_revision["project"]["project_number"])

    def __init__(self, *args, **kwargs):
        self._init_ui()
        super().__init__(*args, **kwargs)
        self.children = [
            self.hbx_add,
            self.vbx,
            self.tabs,
        ]

    def _init_ui(self):
        """Initialise UI elements."""
        self.svg = SvgSpinner(layout=dict(display="None"))
        self.vbx = w.VBox()
        self.vbx_active = w.VBox()
        self.tabs = w.Tab()
        self.hbx_add = w.HBox()
        self._init_add_ui()
        self._init_multi_toggle_buttons()
        self._init_tab()
        self._init_controls()

    def _init_add_ui(self):
        self.bn_add = w.Button(**dict(ADD_BUTTON_KWARGS) | {"tooltip": f"Add {self.use_type.value}"})
        self.bn_reload = w.Button(**dict(RELOAD_BUTTON_KWARGS) | {"tooltip": "Reload"})
        self.cmbx_select = w.Combobox(placeholder=f"Add {self.use_type.value}")
        self.hbx_add.children = [
            self.bn_reload,
            self.bn_add,
            self.cmbx_select,
            self.svg,
        ]

    def _init_multi_toggle_buttons(self):
        self.multi_toggle_buttons = MultiToggleButtons()  # TODO: Update to search and load button
        self.msg = w.HTML(f"<b>Select {self.use_type.value} to Load</b>")
        self.vbx.children = [
            self.msg,
            self.multi_toggle_buttons,
        ]

    def _init_tab(self):
        self.di_grid_callables = {}
        self.di_grids = {}
        self.tabs.children = [w.VBox()]

    def _init_controls(self):
        self.multi_toggle_buttons.observe(self._filter_tabs, names="value", type="change")
        self.tabs.observe(self._load_selected_tab, "selected_index")
        self.bn_add.on_click(self._add_spec)
        self.bn_reload.on_click(self._reload)

    def load_options(self):
        self.vbx_active.children = [w.VBox()]
        self.di_grid_callables = {}
        self.di_grids = {}
        self.project_type_specs = []
        self.multi_toggle_buttons.value = ()
        if self.project_revision_id is not None:
            self.project_type_specs = get_type_spec_metadata_by_project_revision(
                self.project_revision_id, use_type=self.use_type
            )  # TODO: build grid callables from this
            self._update_options()

    def _add_spec_grid_callable(self, object_id):
        """Add Object Specification grid callable if it doesn't exist, else, if it does, update its data."""
        if object_id not in self.di_grid_callables.keys():
            self.di_grid_callables[object_id] = functools.partial(
                ObjectSpecGrid,
                project_revision_id=self.project_revision_id,
                object_id=object_id,
                fn_delete_tab=self.load_options,
            )
            return self.di_grid_callables[object_id]

    def _update_map_object_id(self, *args, **kwargs):
        self.map_object_id = {
            name: id_
            for id_, name in sorted(
                get_objects_names(
                    custodian=ENV.AECTEMPLATER_ORG,
                    has_abbreviation=True,
                    use_type=self.use_type,
                    status=StatusEnum.active,
                ).items(),
                key=lambda item: item[1],
            )
        }

    def _update_options(self):
        self._update_map_object_id()
        self._update_add_options()
        self._update_filter_options()

    def _update_add_options(self):
        self.cmbx_select.options = list(self.map_unpopulated_object_names.keys())

    def _update_filter_options(self):
        self.multi_toggle_buttons.options = self.object_names
        self._update_tooltips()

    # HOTFIX: This is a workaround to update the tooltip of the buttons
    # We are going to deprecate the use of MultiToggleButtons anyway in the future
    def _update_tooltips(self):
        for btn in self.multi_toggle_buttons._dict_but_by_option.values():
            btn.tooltip = f"Click to open '{btn.description}'"
        if len(self.tabs.titles) > 0 and self.tabs.titles[0] != "":
            for name in self.tabs.titles:
                self.multi_toggle_buttons._dict_but_by_option[name].tooltip = f"Click to close '{name}'"

    def _reload(self, on_click):
        self.svg.layout.display = ""
        self._update_map_object_id()
        self.svg.layout.display = "none"

    def _filter_tabs(self, onchange):
        """Reload Object Specifications."""

        self.tabs.unobserve(self._load_selected_tab, names="selected_index")
        self.tabs.children = [self.vbx_active] * len(self.multi_toggle_buttons.value)
        li = list(self.multi_toggle_buttons.value)
        li.sort()
        self.tabs.titles = li
        self.tabs.observe(self._load_selected_tab, "selected_index")
        if self.tabs.selected_index == len(self.multi_toggle_buttons.value):
            print(
                "self.tabs.selected_index == len(self.multi_toggle_buttons.value) |"
                f" {self.tabs.selected_index }== {len(self.multi_toggle_buttons.value)}"
            )
            self.tabs.selected_index = None
        self._load_selected_tab()
        self._update_tooltips()

    def _load_spec(self, object_id: int):
        """Load Object Specification and set to tab children"""
        self.svg.layout.display = ""
        self.di_grids[object_id] = self.di_grid_callables[object_id]()
        self.svg.layout.display = "none"

    def _load_selected_tab(self, *args, **kwargs):
        """Load the currently selected tab if not already loaded."""
        i = self.tabs.selected_index
        if i is not None:
            name = self.tabs.titles[i]
            object_id = self.project_objects.get(name)
            if object_id not in self.di_grids.keys():
                self.vbx_active.children = [w.HTML()]  # HOTFIX: Make sure active is empty whilst loading
                self._load_spec(object_id)

            self.vbx_active.children = [self.di_grids[object_id]]

    def _add_spec(self, on_click):
        if self.cmbx_select.value not in self.map_unpopulated_object_names.keys():
            raise ValueError(f"Error adding {self.cmbx_select.value}.")
        object_id = int(self.map_unpopulated_object_names[self.cmbx_select.value])
        name = {int(id_): name for name, id_ in self.map_object_id.items()}[object_id]
        li_options = list(self.multi_toggle_buttons.options) + [name]
        li_value = list(self.multi_toggle_buttons.value) + [name]
        self.project_objects[name] = object_id
        self._add_spec_grid_callable(object_id)
        self.cmbx_select.value = ""
        li_options.sort()
        li_value.sort()
        self.multi_toggle_buttons.options = li_options
        self.multi_toggle_buttons.value = li_value
        idx = list(self.tabs.titles).index(name)
        self.tabs.selected_index = idx


if __name__ == "__main__":
    from aectemplater_client import get_project_revision_by_project_number_and_revision

    DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
        project_number=ENV.AECTEMPLATER_PROJECT_NUMBER, revision=ENV.DEFAULT_PROJECT_REVISION
    )["id"]
    ui = ObjectSpecification(project_revision_id=DEFAULT_PROJECT_REVISION_ID)
    display(ui)

if __name__ == "__main__":
    ui.use_type = UseTypeEnum.spaces
