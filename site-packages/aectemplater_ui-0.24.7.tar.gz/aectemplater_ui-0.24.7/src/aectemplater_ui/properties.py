# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.6
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
import uuid
import logging
import ipywidgets as w
from ipydatagrid import HyperlinkRenderer, Expr
from IPython.display import display

from ipyautoui.custom.editgrid import EditGrid, DataHandler
from ipyautoui.custom.buttonbars import CrudOptions, CrudView
from aectemplater_client import (
    delete_property,
    get_properties,
    get_property,
    patch_property,
    post_property,
    patch_property_unit,
)
from aectemplater_schemas.data.required_properties import REQUIRED_PROPERTIES

from aectemplater_ui.constants import DES_PROPERTIES
from aectemplater_ui.propertyrow import PropertyFormUi
from aectemplater_ui.formatting import get_properties_format
from aectemplater_ui.schemas import PropertyDataFrame
from aectemplater_ui.utils import hide_show_null

logger = logging.getLogger(__name__)

# +
SET_REQUIRED_PROPERTY_NAMES = set(REQUIRED_PROPERTIES.keys())
DI_PROPERTIES_FORMAT = get_properties_format()
ORDER_COLS = (
    "section",
    "category",
    "title",
    "name",
    "definition",
    "notes",
    "allowed_values",
    "guid_source",
    "physical_quantity",
    "revit_data_type",
    "ifc_data_type",
    "json_schema_extra",
    "is_instance",
    "status",
    "revision_number",
    "example",
    # "connected_property_codes",
    # "method_of_measurement",
    "property_value_kind",
    # "is_dynamic",
    # "dynamic_parameter_property_codes",
    "activation_date_utc",
    "deactivation_date_utc",
    "revision_date_utc",
    "namespace_uri",
    "guid",
    "id",
)

UPDATE_COLUMN_WIDTHS = {
    "name": 300,
    "guid": 5,
    'activation_date_utc': 5,
    'deactivation_date_utc': 5,
    'revision_date_utc': 5,
    "physical_quantity": 5,
    "ifc_data_type": 5,
    "id": 10,
    "revision_number": 10,
}


def text_colour(cell):
    return "blue" if str(cell.metadata.data["Uri"]) and "https://" in str(cell.metadata.data["Uri"]) else "black"


def get_link(cell):
    return (
        cell.metadata.data["Uri"]
        if str(cell.metadata.data["Uri"]) and "https://" in str(cell.metadata.data["Uri"])
        else "https://identifier.buildingsmart.org/uri/buildingsmart/ifc/4.3"  # =IFC4X3_URI: py2vega can't access global vars
    )


def get_name(cell):
    return (
        "✅🔗 " + cell.metadata.data["Name"]
        if str(cell.metadata.data["Uri"]) and "https://" in str(cell.metadata.data["Uri"])
        else "🔎🔗 " + str(cell.metadata.data["Name"])
    )


link_renderer = HyperlinkRenderer(
    url=Expr(get_link),
    url_name=Expr(get_name),
    text_color=Expr(text_colour),
    font="bold 14px Arial, sans-serif",
)
# TODO: py2vega(get_link) -> str. can probs move all this into schemas to apply the logic throughout the code-base.

BUTTONBAR_CONFIG_TYPES = CrudView(
    add=CrudOptions(
        tooltip="Add Property",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Property</i>",
    ),
    edit=CrudOptions(
        tooltip="Edit Selected Property",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Property</i>",
    ),
    copy=CrudOptions(
        tooltip="Copy Selected Properties",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Copy Properties</i>",
    ),
    delete=CrudOptions(
        tooltip="Delete Selected Units",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Properties</i>",
    ),
)


class PropertiesGrid(EditGrid):
    def __init__(self, *args, **kwargs):
        properties_datahandler = DataHandler(
            fn_get_all_data=self.get_properties,
            fn_post=self.post_property,
            fn_patch=self.patch_property,
            fn_delete=self.delete_property,
            fn_copy=self.copy_property,
        )
        super().__init__(
            schema=PropertyDataFrame,
            datahandler=properties_datahandler,
            ui_add=PropertyFormUi,
            ui_edit=PropertyFormUi,
            renderers=DI_PROPERTIES_FORMAT["renderers"] | {"name": link_renderer},
            header_renderer=DI_PROPERTIES_FORMAT["header_renderer"],
            grid_style=DI_PROPERTIES_FORMAT["grid_style"],
            warn_on_delete=True,
            *args,
            **kwargs,
            **DES_PROPERTIES,
        )
        self.buttonbar_grid.crud_view = BUTTONBAR_CONFIG_TYPES
        self.grid.order = ORDER_COLS
        self.buttonbar_grid.edit.observe(self._disable_fields, "value")
        self.buttonbar_grid.add.observe(self._generate_guid)
        self.grid.observe(self._disable_fields, "selections")
        self.grid.observe(self._update_wizard, "selections")
        self.value = self.get_properties()
        self.grid.column_widths = self.grid.column_widths | {
            self.grid.map_name_index[k]: v for k, v in UPDATE_COLUMN_WIDTHS.items()
        }
        hide_show_null(self.ui_edit, self.ui_add)

    def get_properties(self):
        return get_properties(skip=0, limit=-1)

    def post_property(self, value: dict):
        property_ = post_property(value)
        if self.ui_add.default_units.value:
            patch_property_unit(property_id=property_["id"], unit_id=self.ui_add.default_units.value, is_default=True)
        return property_

    def patch_property(self, value: dict):
        property_ = patch_property(value["id"], value)
        if self.ui_edit.default_units.value:
            patch_property_unit(property_id=property_["id"], unit_id=self.ui_edit.default_units.value, is_default=True)
        return property_

    def delete_property(self, value: dict):
        return delete_property(value["id"])

    def copy_property(self, value: dict):
        property_ = get_property(value["id"])
        property_["guid"] = str(uuid.uuid4())
        property_["title"] += " - DUPLICATE"
        property_["name"] += "Duplicate"
        di_property = post_property(property_)
        return di_property

    def _update_wizard(self, onchange):
        if self.grid.selected_index is not None:
            self.ui_edit._update_wizard_from_form("change")

    def _disable_fields(self, onchange):
        if self.buttonbar_grid.edit.value and self.grid.selected_index is not None:
            if self.grid.selected_row["name"] in SET_REQUIRED_PROPERTY_NAMES:
                self.ui_edit.show_savebuttonbar = False
                self.ui_edit.disabled = True
                self.buttonbar_grid.message.value = (
                    "🚫 <i>Editing is disabled for required identity data properties.</i>"
                )
            else:
                self.ui_edit.show_savebuttonbar = True
                self.ui_edit.disabled = False
                self.buttonbar_grid.message.value = BUTTONBAR_CONFIG_TYPES["edit"]["message"]

    def _generate_guid(self, onchange):
        """Generates new GUID upon opening add menu for property."""
        if self.buttonbar_grid.add.value:
            self.ui_add.di_widgets.get("guid").value = str(uuid.uuid4())


if __name__ == "__main__":
    gr = PropertiesGrid()
    display(gr)
