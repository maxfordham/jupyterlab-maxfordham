# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %run __init__.py
# # %load_ext lab_black

import ipywidgets as w
import traitlets as tr
import uuid
import logging
from IPython.display import display

from ipyautoui.autoobject import AutoObjectForm
from ipyautoui.custom.showhide import ShowHide
from ipyautoui.autobox import SPACER
from aectemplater_schemas.data.utils import UnitsBaseData
from aectemplater_schemas.utils import get_name_from_title
from aectemplater_client import get_property_default_unit

from aectemplater_ui.propertyrow_select_dtype import Wizard, make_unit_str
from aectemplater_ui.schemas import PropertyGet, UnitsGet

# +
UDATA = UnitsBaseData()
MAP_IFC_TO_MEASURE = {v: k for k, v in UDATA.map_measure_to_ifc.items()}
logger = logging.getLogger(__name__)


# TODO: Review how ifc, revit, and physical quantity are selected.
class PropertyFormUi(AutoObjectForm):
    """Injected a wizard UI to be able to define units to associate
    with property."""

    # HOTFIX: Setting order removes inject default_units and Wizard UI objects
    @tr.observe("order")
    def _obs_order(self, on_change):
        if len(on_change["new"]) < len(self.di_boxes) and not self.order_can_hide_rows:
            logger.warning("order_can_hide_rows == False. set to True to use order to filter")
            self.order = on_change["old"]
        else:
            self.vbx_widget.children = [self.di_boxes[o] for o in self.order]
            self._init_insert_wizard_row()

    def _post_init(self, **kwargs):
        value = kwargs.get("value")
        self.app = kwargs.get("app")
        self.default_units = w.Dropdown(options={}, disabled=True)
        if value is None:
            self.di_widgets["ifc_data_type"].value = "IfcText"  # HOTFIX: Set IfcText as default

        self._set_guid_value()
        self.showhide = ShowHide(title="<b>✨ Select Data Type Wizard ✨</b>")
        self.showhide.btn_display.button_style = "info"
        self.wizard = Wizard(
            dtype=self.di_widgets["physical_quantity"].value,
            fn_on_update=self.update_from_wizard,
        )
        self.showhide.fn_display = lambda: self.wizard
        self._init_insert_wizard_row()
        self._init_observe()
        self.di_widgets["physical_quantity"].disabled = True
        if self.app is not None:
            self.app.datahandler_original = self.app.datahandler
        self._set_default_unit_element()

    def _init_observe(self):
        """Observe widgets"""
        self.di_widgets["id"].observe(self._update_default_unit_element, "value")
        self.di_widgets["title"].observe(self._update_name_from_title, "value")
        self.showhide.btn_display.observe(self._update_wizard_from_form)

    def _init_insert_wizard_row(self):
        """Insert wizard into AutoObject."""
        default_units_row = w.HBox(
            [
                SPACER,  # HOTFIX FORMAT TO MATCH AUTOBOX
                self.default_units,
                w.HTML("<b>Default Units</b>, <i>default units for a given property.</>"),
            ]
        )
        vbx_widget_children = list(self.vbx_widget.children)
        vbx_widget_children.insert(6, self.showhide)
        vbx_widget_children.insert(11, default_units_row)
        self.vbx_widget.children = vbx_widget_children

    def update_from_wizard(self, value=None):
        """Update the default_unit widget in the form
        from the wizard."""
        if value is not None:
            for k, v in value.items():
                if k in self.di_widgets.keys():
                    self.di_widgets[k].value = v
                elif k == "default_units":
                    if v:
                        self.default_units.options, self.default_units.value = (
                            v,
                            list(v.values())[0],
                        )
                    else:
                        self._clear_default_units()

        self.showhide.btn_display.value = False

    def _set_default_unit_element(self):
        """Obtain default unit for a property (if one exists)
        and set default_units.options and default_units.value."""
        if self.value and self.value["id"] != 0:  # If ID is 0 then not a property in DB.
            prop = PropertyGet(**self.value)
            try:
                default_unit = get_property_default_unit(property_id=prop.id)
                unit = UnitsGet(**default_unit)
                options = {make_unit_str(unit.symbol, unit.name): unit.id}
                self.default_units.options, self.default_units.value = options, unit.id
            except Exception as err:
                self._clear_default_units()
        else:
            self._clear_default_units()

    def _update_default_unit_element(self, onchange):
        self._set_default_unit_element()

    def _update_wizard_from_form(self, onchange):
        """Update the data type wizard using value from the Property form."""
        if self.showhide.btn_display.value:
            try:
                if self.di_widgets["physical_quantity"].value == "":
                    self.wizard.dtype_options.value = "not a physical quantity"
                else:
                    self.wizard.dtype_options.value = "all physical quantities"
                    self.wizard.dtype.value = self.di_widgets["physical_quantity"].value
            except Exception as err:
                logging.warning(err)
            try:
                if self.di_widgets["ifc_data_type"].value != "":
                    if self.di_widgets["physical_quantity"].value == "":
                        self.wizard.dtype.value = MAP_IFC_TO_MEASURE[self.di_widgets["ifc_data_type"].value]
                    self.wizard.ifctyp.value = self.di_widgets["ifc_data_type"].value
            except Exception as err:
                logging.warning(err)
            try:
                if self.di_widgets["revit_data_type"].value != "":
                    self.wizard.rvttyp.value = self.di_widgets["revit_data_type"].value
            except Exception as err:
                logging.warning(err)
            try:
                if self.default_units.value != 0:
                    self.wizard.default_units.value = self.default_units.value
            except Exception as err:
                logging.warning(err)

    def _clear_default_units(self):
        self.default_units.options, self.default_units.value = {"": 0}, 0

    def _update_name_from_title(self, onchange):
        self.di_widgets.get("name").value = get_name_from_title(self.di_widgets_value.get("title"))

    def _set_guid_value(self):
        if self.di_widgets_value.get("guid") == "":
            self.di_widgets.get("guid").value = str(uuid.uuid4())


if __name__ == "__main__":
    from IPython.display import display
    from aectemplater_client import get_property

    ui = PropertyFormUi.from_pydantic_model(PropertyGet, value=get_property(1))
    display(ui)
# -
