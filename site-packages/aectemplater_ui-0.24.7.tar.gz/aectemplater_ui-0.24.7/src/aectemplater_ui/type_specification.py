import logging
import shutil
import jsonref
import typing as ty
import ipywidgets as w
import pandas as pd
import traitlets as tr
from ipydatagrid import TextRenderer, Expr
from IPython.display import display, Markdown
from IPython.lib import backgroundjobs as bg


from pyuniclass import UT
from ipyautoui.constants import BUTTON_WIDTH_MIN, IMAGE_BUTTON_KWARGS, HELP_BUTTON_KWARGS
from ipyautoui.custom.autogrid import AutoGrid
from ipyautoui.custom.buttonbars import CrudButtonBar, CrudOptions, CrudView
from ipyautoui.custom.editgrid import EditGrid, DataHandler, UiDelete
from aectemplater_schemas.tag_template import TypeMark, TypeTagData, TypeTagTemplate
from aectemplater_schemas.images import ImagePrefix
from aectemplater_client import (
    delete_type_spec,
    get_type_tag_template_by_id,
    get_object_by_id,
    get_type_spec_type_mark,
    get_type_specs_type_marks,
    get_type_spec_image_prefix,
    get_project_revision_by_project_number_and_revision,
    get_project_revision_by_id,
    get_instance_specs_marks_from_type_spec,
    get_object_gridschema,
    get_type_spec_object_data_grid,
    post_type_spec_data,
    patch_type_spec_data,
)

from aectemplater_ui import ENV
from aectemplater_ui.images import PdtImageUi
from aectemplater_ui.formatting import create_vega_expression, GRID_STYLE
from aectemplater_ui.utils import (
    is_nan,
    generate_image_fname,
    get_fpths_images,
    get_fdir_project_schedule_images,
)


logging.getLogger().setLevel(logging.ERROR)
logger = logging.getLogger(__name__)

RELOAD_BUTTON_KWARGS = dict(
    icon="sync",
    style={},
    button_style="info",
    tooltip="reload",
    layout={"width": BUTTON_WIDTH_MIN},
    disabled=False,
)
UNICLASS_LIST = UT.Pr.data.description.to_list()
OVERRIDE_UNITS = True
DEFAULT_GRID_STYLE = {"header_background_color": "rgb(230, 230, 230)"}
DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
    project_number=ENV.AECTEMPLATER_PROJECT_NUMBER, revision=ENV.DEFAULT_PROJECT_REVISION
)["id"]


# +
def get_image_prefix(value: dict) -> str:
    """Get the image name from the grid value where the keys are the property IDs."""
    value = {k: v for k, v in value.items() if not is_nan(v)}
    return ImagePrefix(abbreviation=value["Abbreviation"], type_reference=value["TypeReference"]).image_prefix


def get_type_mark(type_tag_template: TypeTagTemplate, value: dict) -> str:
    """Get the Type Mark from the grid value where the keys are the property IDs."""
    value = {k: v for k, v in value.items() if not is_nan(v)}
    type_tag_data = TypeTagData(
        abbreviation=value["Abbreviation"],
        type_reference=value["TypeReference"],
    ).model_dump()
    if "FunctionReference" in value.keys() and value["FunctionReference"] is not None:
        type_tag_data["function_reference"] = value["FunctionReference"]
    return TypeMark(
        template=type_tag_template,
        tag_data=type_tag_data,
    ).type_mark


def copy_type_spec_images(
    from_project_revision_id: int, to_project_revision_id: int, image_prefix: str, new_image_prefix: str
):
    """Copy Type Specification images from one project revision to another. The image prefix is used to identify the images.
    E.g. DB-1 would be matched to DB-1__<uuid>.png."""
    to_project_revision = get_project_revision_by_id(project_revision_id=to_project_revision_id)
    to_project_number = to_project_revision["project"]["project_number"]
    delete_type_spec_images(
        project_number=to_project_number, image_prefix=new_image_prefix
    )  # If any left over images from before, delete before copying
    from_project_revision = get_project_revision_by_id(project_revision_id=from_project_revision_id)
    fpths_images = get_fpths_images(
        project_number=from_project_revision["project"]["project_number"], type_mark=image_prefix
    )
    to_fdir_images = get_fdir_project_schedule_images(to_project_number)
    for fpth_image in fpths_images:
        image_new_name = generate_image_fname(image_prefix=new_image_prefix)
        shutil.copy(fpth_image, to_fdir_images / image_new_name)


def delete_type_spec_images(project_number: int, image_prefix: str):
    """Delete Type Specification images from a project. The image prefix is used to identify the images."""
    fpths_images = get_fpths_images(project_number, image_prefix)
    for fpth_image in fpths_images:
        fpth_image.unlink()


def rename_type_spec_images(project_revision_id: int, image_prefix: str, new_image_prefix: str):
    """Rename Type Specification images from a project. The image prefix is used to identify the images."""
    copy_type_spec_images(
        from_project_revision_id=project_revision_id,
        to_project_revision_id=project_revision_id,
        image_prefix=image_prefix,
        new_image_prefix=new_image_prefix,
    )
    project_revision = get_project_revision_by_id(project_revision_id=project_revision_id)
    project_number = project_revision["project"]["project_number"]
    delete_type_spec_images(project_number, image_prefix)


def copy_type_spec(
    value: dict, object_id: int, from_project_revision_id: int, to_project_revision_id: int, override_units: bool
):
    """Duplicates selected Type Specification."""
    value = {k: None if is_nan(v) else v for k, v in value.items()}
    type_spec = post_type_spec_data(
        project_revision_id=to_project_revision_id,
        object_id=object_id,
        value=value,
        override_units=override_units,
    )
    copy_type_spec_images(
        from_project_revision_id=from_project_revision_id,
        to_project_revision_id=to_project_revision_id,
        image_prefix=get_image_prefix(value=value),
        new_image_prefix=ImagePrefix(
            abbreviation=type_spec["data"]["Abbreviation"], type_reference=type_spec["data"]["TypeReference"]
        ).image_prefix,
    )
    return type_spec


# -


class DefaultTypeSpecGrid(AutoGrid):
    _value = tr.Tuple()
    object_id = tr.Integer(default_value=None, allow_none=True)
    project_revision_id = tr.Integer(default_value=DEFAULT_PROJECT_REVISION_ID, allow_none=True)

    @tr.observe("object_id", "project_revision_id")
    def _set_default_grid(self, onchange):
        if self.object_id is not None and self.project_revision_id is not None:

            def deferred_operations():
                schema = get_object_gridschema(
                    project_revision_id=self.project_revision_id,
                    object_id=self.object_id,
                    override_units=self.override_units,
                    parameter_type="T",
                )
                self.update_from_schema(schema=schema)
                self._load_data()
                self._set_col_widths()
                self._set_headers()
                self.observe(self._set_headers, "count_changes")

            # Schedule the deferred operations to run after the current loop
            # Otherwise observers are called and tries to run `update_from_schema` before fully initialised
            jobs = bg.BackgroundJobManager()
            jobs.new(deferred_operations)
        else:
            self.update_from_schema(schema=None)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self._value = value
        data = self._init_data(pd.DataFrame(value))
        data = data.dropna(how="all")
        self.data = data
        # HOTFIX: Setting data creates bugs out transforms currently so reset transform applied
        _transforms = self._transforms
        self.transform([])  # Set to no transforms
        self.transform(_transforms)  # Set to previous transforms

    def __init__(
        self,
        override_units: bool = OVERRIDE_UNITS,
        **kwargs,
    ):
        self.override_units = override_units
        super().__init__(transposed=True, grid_style=DEFAULT_GRID_STYLE, **kwargs)

    def _load_data(self):
        self.value = self._get_data()

    def _get_data(self):
        if self.object_id is not None and self.project_revision_id is not None:
            type_spec = get_type_spec_object_data_grid(
                project_revision_id=self.project_revision_id,
                object_id=self.object_id,
                override_units=self.override_units,
            )
            return type_spec["data"]
        else:
            return []

    def _set_col_widths(self):
        self.auto_fit_columns = True
        self.auto_fit_params = {"area": "body", "padding": 150}
        self.column_widths = {"section": 150, "title": 200, "unit": 80}

    def _set_headers(self, on_change=None):
        type_marks = get_type_specs_type_marks(type_spec_ids=[v["Id"] for v in self.value])
        header_renderer = create_vega_expression(
            di={"section": "Section", "title": "Title", "unit": "Unit"}
            | {idx: type_mark for idx, type_mark in enumerate(type_marks)}
        )
        self.header_renderer = TextRenderer(text_value=Expr(header_renderer))


if __name__ == "__main__":
    default_type_spec_grid = DefaultTypeSpecGrid(object_id=3)
    display(default_type_spec_grid)


class ImportDefaultTypeSpecGrid(w.VBox):
    object_id = tr.Integer(default_value=None, allow_none=True)
    project_revision_id = tr.Integer(default_value=DEFAULT_PROJECT_REVISION_ID, allow_none=True)

    @tr.observe("object_id")
    def _set_object_id(self, onchange):
        if self.object_id is not None and self.project_revision_id is not None:
            self.default_type_specs_grid.object_id = self.object_id
            object_summary = get_object_by_id(self.object_id, override_units=self.override_units)
            self.type_tag_template = get_type_tag_template_by_id(object_summary["type_tag_template_id"])

    @tr.observe("project_revision_id")
    def _set_project_revision_id(self, onchange):
        if self.object_id is not None and self.project_revision_id is not None:
            self.default_type_specs_grid.project_revision_id = self.project_revision_id

    def __init__(
        self,
        override_units: bool = OVERRIDE_UNITS,
        fn_reload: ty.Callable = logger.info("reload"),
        **kwargs,
    ):
        self.override_units = override_units
        self.message = w.HTML()
        self.bn_import = w.Button(
            description="IMPORT SELECTED TYPES",
            tooltip="Click to import selected Type Specifications",
            icon="file-import",
            button_style="success",
            layout=dict(width="250px"),
        )
        self.default_type_specs_grid = DefaultTypeSpecGrid(**kwargs)
        super().__init__([w.HBox([self.bn_import, self.message]), self.default_type_specs_grid], **kwargs)
        self.fn_reload = fn_reload
        self._init_controls()

    def _init_controls(self):
        self.bn_import.on_click(self._import_selected_type_specs)
        self.default_type_specs_grid.observe(self._update_bn_import_message, "selections")

    def _update_bn_import_message(self, change):
        li_type_marks = [
            get_type_mark(type_tag_template=self.type_tag_template, value=value)
            for value in self.default_type_specs_grid.selected_cols
        ]
        self.message.value = f"👈 <i>Click import to add types <b>{', '.join(li_type_marks)}</b> to your project.</i>"

    def _import_selected_type_specs(self, change):
        li_type_specs = []
        for value in self.default_type_specs_grid.selected_cols:
            type_spec = copy_type_spec(
                value=value,
                object_id=self.object_id,
                from_project_revision_id=DEFAULT_PROJECT_REVISION_ID,
                to_project_revision_id=self.project_revision_id,
                override_units=self.override_units,
            )
            li_type_specs.append(type_spec)

        li_type_marks = [get_type_spec_type_mark(type_spec["data"]["Id"]) for type_spec in li_type_specs]
        if li_type_marks:
            self.message.value = (
                f"📥 <i><b>{', '.join(li_type_marks)}</b> created in your project from selection below.</i>"
            )
        else:
            self.message.value = f"👇 <i>Please select some Type Specifications below then press import.</i>"
        self.fn_reload()


if __name__ == "__main__":
    project_revision_id = get_project_revision_by_project_number_and_revision(
        project_number=5001, revision=ENV.DEFAULT_PROJECT_REVISION
    )["id"]
    import_type_specs = ImportDefaultTypeSpecGrid(project_revision_id=project_revision_id, object_id=3)
    display(import_type_specs)

# +
IMPORTS_BUTTON_KWARGS = {'icon': 'file-import', 'tooltip': 'import', 'layout': {'width': '44px'}}

BUTTONBAR_CONFIG_TYPES = CrudView(
    imports=CrudOptions(
        tooltip="Import default Type Specifications into current project",
        tooltip_clicked="Go back to table",
        message="📥 <i>Import Engineering Standards Default Templates into Project</i>",
    ),
    images=CrudOptions(
        tooltip="Add images to selected Type Specification",
        tooltip_clicked="Go back to table",
        button_style="info",
        message="📷 <i>Add Images</i>",
    ),
    add=CrudOptions(
        tooltip="Add Type Specification",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Type Specification</i>",
    ),
    edit=CrudOptions(
        tooltip="Edit Selected Type Specification",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Type Specification</i>",
    ),
    copy=CrudOptions(
        tooltip="Copy Selected Type Specifications",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Copy Type Specification</i>",
    ),
    delete=CrudOptions(
        tooltip="Delete Selected Type Specifications",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Type Specifications</i>",
    ),
    reload=CrudOptions(
        tooltip="Reload Type Specifications",
        button_style="info",
        message="🔄 <i>Reloaded Type Specifications</i>",
    ),
    support=CrudOptions(
        **dict(HELP_BUTTON_KWARGS)
        | dict(
            tooltip="help - click to show description of all buttons in the toolbar",
            tooltip_clicked="Hide help dialogue",
            message="❔ <i>Help Selected</i>",
        )
    ),
)


class CrudButtonBarTypes(CrudButtonBar):
    fn_images = tr.Callable(default_value=lambda: print("images"))
    fn_imports = tr.Callable(default_value=lambda: print("import"))

    def __init__(
        self,
        **kwargs,
    ):
        self._init_form()
        self.imports = w.ToggleButton(**IMPORTS_BUTTON_KWARGS)
        self.imports.observe(self._imports, "value")
        self.images = w.ToggleButton(**IMAGE_BUTTON_KWARGS)
        self.images.observe(self._images, "value")
        super().__init__(**kwargs | {"show_support": True, "crud_view": BUTTONBAR_CONFIG_TYPES})
        self.out = w.Output()
        self.hbx_bbar = w.HBox(
            [
                self.imports,
                self.images,
                self.add,
                self.edit,
                self.copy,
                self.delete,
                self.reload,
                self.support,
                self.message,
            ]
        )
        self.children = [self.hbx_bbar, self.out]
        self._init_controls()

    def _add(self, onchange):
        self._onclick("add")

    def _images(self, onchange):
        self._onclick("images")

    def _imports(self, onchange):
        self._onclick("imports")


if __name__ == "__main__":
    display(CrudButtonBarTypes())


# -


class TypeSpecDelete(UiDelete):
    summary = tr.Dict(allow_none=True)

    @tr.observe("summary")
    def observe_summary(self, on_change):
        self._update_display()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.message.value = (
            "⚠️<b>Are you sure you want to delete the following Types and Instances?</b>⚠️<br><i>Pressing the DELETE button will"
            " permanently delete the selected Types and Instances!</i>"
        )

    @property
    def value_summary(self):
        summary = ""
        for type_mark, instance_marks in self.summary.items():
            summary += f"<b>{type_mark}</b> <i>{', '.join(instance_marks)}</i><br>"
        return Markdown(summary)


class TypeSpecGrid(EditGrid):
    """User Interface component for creating, modifying, duplicating, and removing
    Type Specifications across various templates within Projects. It also supports
    the addition of images to Type Specifications."""

    object_id = tr.Integer(default_value=None, allow_none=True)
    project_revision_id = tr.Integer(default_value=None, allow_none=True)

    @tr.observe("object_id", "project_revision_id")
    def _set_grid(self, onchange):
        if self.object_id is not None and self.project_revision_id is not None:
            schema = get_object_gridschema(
                project_revision_id=self.project_revision_id,
                object_id=self.object_id,
                override_units=self.override_units,
                parameter_type="T",
            )
            self.update_from_schema(
                schema=schema,
                datahandler=DataHandler(
                    fn_get_all_data=self.get_type_specs,
                    fn_post=self.post_type_spec,
                    fn_patch=self.patch_type_spec,
                    fn_delete=self.delete_type_spec,
                    fn_copy=self.copy_type_spec,
                ),
                ui_delete=TypeSpecDelete,
            )
            self._set_styling()
            self._reload_all_data()
            self.observe(self._set_headers, "count_changes")
            project_revision = get_project_revision_by_id(self.project_revision_id)
            self.ui_images.project_number = project_revision["project"]["project_number"]
            self.ui_imports.project_revision_id = self.project_revision_id
            self.ui_imports.object_id = self.object_id
        else:
            self.update_from_schema(schema=None)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        data = self.grid._init_data(pd.DataFrame(value))
        data = data.dropna(how="all", axis=0)
        self.grid.data = data
        # HOTFIX: Setting data creates bugs out transforms currently so reset transform applied
        _transforms = self.grid._transforms
        self.grid.transform([])  # Set to no transforms
        self.grid.transform(_transforms)  # Set to previous transforms

    @property
    def type_marks(self):
        return [get_type_mark(type_tag_template=self.type_tag_template, value=value) for value in self.value]

    @property
    def selected_type_marks(self):
        return [
            get_type_mark(type_tag_template=self.type_tag_template, value=value) for value in self.grid.selected_cols
        ]

    @property
    def selected_image_prefixes(self):
        return [get_image_prefix(value=value) for value in self.grid.selected_cols]

    def __init__(
        self,
        override_units: bool = OVERRIDE_UNITS,
        fn_reload: ty.Callable = lambda: logger.info("reload"),
        **kwargs,
    ):
        self.fn_reload = fn_reload
        self.override_units = override_units
        datahandler = DataHandler(
            fn_get_all_data=self.get_type_specs,
            fn_post=self.post_type_spec,
            fn_patch=self.patch_type_spec,
            fn_delete=self.delete_type_spec,
            fn_copy=self.copy_type_spec,
        )
        self.ui_images = PdtImageUi()
        self.ui_imports = ImportDefaultTypeSpecGrid(
            fn_reload=self._reload_datahandler,
        )
        self.ui_imports.layout.width = "100%"
        super().__init__(
            datahandler=datahandler,
            transposed=True,
            grid_style=GRID_STYLE,
            ui_delete=TypeSpecDelete,
            warn_on_delete=True,
            layout=w.Layout(height="800px"),
            **kwargs,
        )
        self._init_value()

    def _init_value(self):
        self.value = self.get_type_specs()
        self.ui_add_default_value = self.ui_add.value
        self.ui_add.savebuttonbar.fns_onrevert_add_action(self._set_ui_add_default)

    def _init_form(self):
        self.stk_crud = w.Stack(
            children=[self.ui_imports, self.ui_images, self.ui_add, self.ui_edit, self.ui_copy, self.ui_delete]
        )
        self.buttonbar_grid = CrudButtonBarTypes(
            fn_imports=self.ui_imports.default_type_specs_grid._load_data,
            fn_images=self._set_type_mark,
            fn_add=self._add,
            fn_edit=self._edit,
            fn_copy=self._copy,
            fn_delete=self._delete,
        )
        self.hbx_bar = w.HBox([self.buttonbar_grid])

    def _set_children(self):
        self.vbx_widget.children = [
            self.hbx_bar,
            self.stk_crud,
            self.grid,
        ]
        self.stk_crud.children = [
            self.ui_imports,
            self.ui_images,
            self.ui_add,
            self.ui_edit,
            self.ui_copy,
            self.ui_delete,
        ]
        self.children = [self.hbx_title_description, self.vbx_widget]
        self._hide_parameters()
        self._hide_id_widgets()
        self._set_controls()
        self.ui_delete.layout.display = (
            "flex"  # HOTFIX: Resolves issue where warn_on_delete not appearing following re-instantiation
        )

    def _set_styling(self):
        self._set_headers()
        self._set_col_widths()
        self._set_type_tag_template()

    def _set_controls(self):
        self.grid.observe(self._set_type_mark, "selections")
        self.grid.observe(self._set_headers, "count_changes")

    def _reload_datahandler(self):
        schema = get_object_gridschema(
            object_id=self.object_id,
            override_units=self.override_units,
            project_revision_id=self.project_revision_id,
            parameter_type="T",
        )
        # schema = set_notes_to_markdown_widget(schema=schema)
        if schema != self.schema:
            self.update_from_schema(schema=schema, datahandler=self.datahandler, ui_delete=TypeSpecDelete)
            self._set_styling()
        self._reload_all_data()
        self.buttonbar_grid.message.value = "🔄 <i>Reloaded Data</i> "

    def _reload_all_data(self):
        self.value = self.datahandler.fn_get_all_data()
        self.fn_reload()

    def get_type_specs(self):
        if self.object_id is not None and self.project_revision_id is not None:
            type_spec = get_type_spec_object_data_grid(
                project_revision_id=self.project_revision_id,
                object_id=self.object_id,
                override_units=self.override_units,
            )
            return type_spec["data"]
        else:
            return []

    def post_type_spec(self, value: dict):
        return post_type_spec_data(
            project_revision_id=self.project_revision_id,
            object_id=self.object_id,
            value=value,
            override_units=self.override_units,
        )

    def patch_type_spec(self, value: dict):
        try:
            image_prefix_before_patch = get_type_spec_image_prefix(value["Id"])
            value = {k: None if is_nan(v) else v for k, v in value.items()}
            type_spec = patch_type_spec_data(type_spec_id=value["Id"], value=value, override_units=self.override_units)
            # Check whether images need renaming
            image_prefix_after_patch = get_image_prefix(value)
            print("IMAGE PREFIX BEFORE: " + image_prefix_before_patch)
            print("IMAGE PREFIX AFTER: " + image_prefix_after_patch)
            if image_prefix_before_patch != image_prefix_after_patch:
                rename_type_spec_images(
                    project_revision_id=self.project_revision_id,
                    image_prefix=image_prefix_before_patch,
                    new_image_prefix=image_prefix_after_patch,
                )
            return type_spec
        except Exception as err:
            self.buttonbar_grid.message.value = str(err)
            raise Exception(err)

    def delete_type_spec(self, value: dict):
        image_prefix = get_type_spec_image_prefix(type_spec_id=value["Id"])
        project_revision = get_project_revision_by_id(project_revision_id=self.project_revision_id)
        deleted_type_spec = delete_type_spec(type_spec_id=value["Id"])
        delete_type_spec_images(project_number=project_revision["project"]["project_number"], image_prefix=image_prefix)
        return deleted_type_spec

    def copy_type_spec(self, value: dict):
        return copy_type_spec(
            value=value,
            object_id=self.object_id,
            from_project_revision_id=self.project_revision_id,
            to_project_revision_id=self.project_revision_id,
            override_units=self.override_units,
        )

    def _set_col_widths(self):
        self.grid.auto_fit_columns = True
        self.grid.auto_fit_params = {"area": "body", "padding": 150}
        self.grid.column_widths = {"section": 150, "title": 250, "unit": 80}

    def _set_type_mark(self, on_change=None):
        if self.grid.selected_index is not None:
            if self.selected_image_prefixes:
                self.ui_images.image_prefix = self.selected_image_prefixes[0]
                self.ui_images.type_mark = self.selected_type_marks[0]
            self.ui_delete.summary = {
                get_type_mark(
                    type_tag_template=self.type_tag_template, value=value
                ): get_instance_specs_marks_from_type_spec(type_spec_id=value["Id"])
                for value in self.grid.selected_cols
            }

    def _set_type_tag_template(self):
        object_summary = get_object_by_id(self.object_id)
        self.type_tag_template = get_type_tag_template_by_id(object_summary["type_tag_template_id"])

    def _set_headers(self, on_change=None):
        type_marks = get_type_specs_type_marks(type_spec_ids=[v["Id"] for v in self.value])
        header_renderer = create_vega_expression(
            di={"section": "Section", "title": "Title", "unit": "Unit"}
            | {idx: type_mark for idx, type_mark in enumerate(type_marks)}
        )
        self.grid.header_renderer = TextRenderer(text_value=Expr(header_renderer))

    def _set_ui_add_default(self):
        self.ui_add.value = self.ui_add_default_value  # ui_add_default_value defined straight after init

    def _hide_parameters(self, parameters: list[str] | None = None):
        """This only works for rows."""
        if parameters is None:
            parameters = ["Symbol", "Id"]
        self.grid.transform(
            [
                {
                    "type": "filter",
                    "columnIndex": 1,
                    "operator": "in",
                    "value": [
                        property_["title"]
                        for name, property_ in self.grid.schema["items"]["properties"].items()
                        if name not in parameters
                    ],
                }
            ]
        )

    def _hide_id_widgets(self):
        self.ui_add.order = [property_ for property_ in self.ui_add.default_order if property_ not in ['Id']]
        self.ui_edit.order = [property_ for property_ in self.ui_edit.default_order if property_ not in ['Id']]


if __name__ == "__main__":
    gr = TypeSpecGrid(override_units=True, project_revision_id=DEFAULT_PROJECT_REVISION_ID, object_id=3)
    display(gr)

if __name__ == "__main__":
    gr.object_id = 2
