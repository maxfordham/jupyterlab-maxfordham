# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
import traitlets
import numpy as np
import unyt as u
import ipywidgets as w
from IPython.display import clear_output, display

from ipyautoui.custom.iterable import Array
from ipyautoui.constants import BLANK_BUTTON_KWARGS
from ipyautoui.autoobject import AutoObjectForm
from aectemplater_schemas.units import Units
from aectemplater_schemas.utils_unyt import (
    map_prefix_codes,
    unyt_to_Units,
)

from aectemplater_ui.utils import get_all_physical_quantities
from aectemplater_ui.schemas import UnitsGet, ExprItem, Derivation

WIDTH = "100px"


# +
def unyt_from_ExprItem(expr: ExprItem):
    if not expr.symbol:
        return None
    else:
        return getattr(u, map_prefix_codes[expr.prefix] + expr.symbol) ** expr.exponent


def unyt_from_Derivation(der: Derivation):
    return np.prod([unyt_from_ExprItem(d) for d in der.root])


def get_header(blank=False) -> w.HBox:
    if blank:
        border = ""
        styled = lambda text: f""
    else:
        border = "solid green 1px"
        styled = lambda text: f"<center><b>{text}</b></center>"

    hbx_header = w.HBox()
    bn_blank = w.Button(**BLANK_BUTTON_KWARGS)
    prefix = w.HTML(
        styled("prefix"),
        layout={"border": border, "width": WIDTH},
    )
    symbol = w.HTML(styled("symbol"), layout={"border": border, "width": WIDTH})
    exponent = w.HTML(value=styled("exponent"), layout={"border": border, "width": WIDTH})
    hbx_header.children = [
        bn_blank,
        bn_blank,
        # txt_blank,
        prefix,
        symbol,
        exponent,
    ]

    return hbx_header


class ExprItemUi(w.HBox):
    value = traitlets.Dict(allow_none=True)
    unyt = traitlets.Instance(klass=u.Unit, allow_none=True)

    def __init__(self, value=None, schema=None):
        self.schema = ExprItem.model_json_schema()
        self._init_form()
        self._init_controls()

    def _init_form(self):
        super().__init__()
        self.drpn_prefix = w.Dropdown(options=self.schema["properties"]["prefix"]["enum"], layout={"width": WIDTH})
        self.drpn_symbol = w.Dropdown(options=self.schema["properties"]["symbol"]["enum"], layout={"width": WIDTH})
        self.flt_exponent = w.FloatText(1, layout={"width": WIDTH})
        self.out = w.Output()
        self.children = [
            self.drpn_prefix,
            self.drpn_symbol,
            self.flt_exponent,
            self.out,
        ]

    @property
    def prefix(self):
        return self.drpn_prefix.value

    @property
    def symbol(self):
        return self.drpn_symbol.value

    @property
    def exponent(self):
        return self.flt_exponent.value

    @property
    def schema_properties(self):
        return list(self.schema["properties"].keys())

    def _init_controls(self):
        self.drpn_prefix.observe(self._update_value, names=["value"])
        self.drpn_symbol.observe(self._update_value, names=["value"])
        self.flt_exponent.observe(self._update_value, names=["value"])
        # self.observe(self._update_out, names=["value"])

    def _update_value(self, on_change):
        self.value = ExprItem(**{l: getattr(self, l) for l in self.schema_properties}).model_dump()
        self._update_out()

    def _update_out(self):
        self.unyt = unyt_from_ExprItem(ExprItem(**self.value))
        with self.out:
            clear_output()
            try:
                display(self.math_expr)
            except:
                display(w.HTML(str("unit not found")))

    @property
    def math_expr(self):
        # ^ TODO: use latex when fixed in Voila.
        #       : https://github.com/voila-dashboards/voila/issues/516
        return w.HTML(str(self.unyt))


if __name__ == "__main__":
    ui = ExprItemUi()
    display(ui)


# +
class DerivationUi(Array):
    derivation = traitlets.Instance(klass=Derivation, allow_none=True)
    unyt = traitlets.Instance(klass=u.Unit, allow_none=True)
    database_entry = traitlets.Instance(klass=Units, allow_none=True)

    def __init__(self, **kwargs):
        super().__init__(maxlen=10, show_hash=None, fn_add=self.add_unyt)

    def _post_init(self, **kwargs):
        self.title = (
            f'<a href="https://unyt.readthedocs.io/en/stable/unit_listing.html"'
            f' target="_blank"><b>Derviation</b>: <i>powered by unyt 📏⏱️🌡️⚖️</i></a>'
        )
        self._update_form()
        self._init_DerivationUi_controls()

    def _update_form(self):
        self.hbx_header = get_header()
        self._init_equals()
        self._init_base_equivalent()
        self._init_Units()
        # HOTFIX: Add column header
        children = list(self.children)
        children.insert(0, self.hbx_header)
        self.children = children

    def _init_equals(self):
        self.out = w.Output(layout={"width": "300px"})
        self.note_equals = w.HTML("<b>derived Unit</b>")
        self.hbx_equals = get_header(blank=True)
        self.hbx_equals.children = list(self.hbx_equals.children) + [
            self.out,
            self.note_equals,
        ]

    def _init_base_equivalent(self):
        self.base_equivalent = w.Output(layout={"width": "300px"})
        self.note_base_equivalent = w.HTML("<b>base equivalent</b>, <i>SI equivalent of unit</i>")
        self.hbx_base_equivalent = get_header(blank=True)
        self.hbx_base_equivalent.children = list(self.hbx_base_equivalent.children) + [
            self.base_equivalent,
            self.note_base_equivalent,
        ]

    def _init_Units(self):
        self.hbx_unit_base = w.HBox([get_header(blank=True)])

    def _init_DerivationUi_controls(self):
        self.observe(self._update_derivation, names=["_value"])
        self.observe(self._update_unyt, names=["derivation"])
        self.observe(self._update_display, names=["unyt"])

    def _update_derivation(self, on_change):
        if {} not in self.value:
            self.derivation = Derivation(root=self.value)

    def _update_unyt(self, on_change):
        if self.derivation is not None:
            self.unyt = unyt_from_Derivation(self.derivation)

    def add_unyt(self, value=None):
        if value is None:
            return ExprItemUi()
        else:
            return ExprItemUi(**value)

    def _update_display(self, on_change):
        with self.out:
            clear_output()
            display(self.math_expr_derived)

        with self.base_equivalent:
            clear_output()
            display(self.math_expr_base_equivalent)

    @property
    def math_expr_derived(self):
        # return Math(self.unyt.latex_representation())
        # ^ TODO: use latex when fixed in Voila.
        #       : https://github.com/voila-dashboards/voila/issues/516
        return w.HTML(str(self.unyt))

    @property
    def math_expr_base_equivalent(self):
        # return Math(self.unyt.get_base_equivalent().latex_representation())
        # ^ TODO: use latex when fixed in Voila.
        #       : https://github.com/voila-dashboards/voila/issues/516
        if self.unyt:
            return w.HTML(str(self.unyt.get_base_equivalent()))


if __name__ == "__main__":
    ui = DerivationUi()
    display(ui)


# +
class UnitFormUi(AutoObjectForm):
    def _post_init(self, **kwargs):
        self.app = kwargs.get("app")
        self.di_widgets["physical_quantity"].options = get_all_physical_quantities()
        self.layout.width = "70%"
        self.derived = DerivationUi()
        self._update_controls()
        self._init_insert_derived()

    def _update_controls(self):
        self.derived.observe(self._update_units_base, names=["unyt"])

    @property
    def unyt(self):
        return self.derived.unyt

    def _init_insert_derived(self):
        vbx_widget_children = list(self.vbx_widget.children)
        vbx_widget_children.insert(0, self.derived)
        self.vbx_widget.children = vbx_widget_children

    def _update_units_base(self, on_change):
        if self.unyt is not None:
            di = unyt_to_Units(self.unyt).model_dump()
            [di.pop(l) for l in ["name", "symbol"] if di[l] == ""]  # "physical_quantity",
            self.value = self.value | di
        else:
            self.value = {k: v.get("default") for k, v in self.schema.get("properties").items()}


if __name__ == "__main__":
    aui = UnitFormUi.from_pydantic_model(UnitsGet)
    display(aui)
