# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
import io
import json
import math
import pathlib
import typing as ty
import zipfile
from base64 import b64encode
from datetime import datetime

import jsonref
import shortuuid
import traitlets as tr
from aecschedule.schedules import PlantRoomSchedule, ProductDataSchedule, RoomDataSchedule
from aectemplater_client import get_document_by_id, get_document_object_data, get_units
from aectemplater_schemas.data.utils import UnitsBaseData
from aectemplater_schemas.enumerations import DocumentTypeEnum
from IPython.display import HTML, display

from aectemplater_ui import ENV

LI_IFC_PHYSICAL_QUANTITIES = UnitsBaseData().li_ifc_physical_quantities


# +
def get_aectemplater_physical_quantities():
    return list(set([l["physical_quantity"] for l in get_units(limit=-1) if l["physical_quantity"] != ""]))


def is_nan(value):
    try:
        if value is None:
            return False
        else:
            return math.isnan(float(value))
    except Exception as err:
        return False


def spaces_before_capitals(word: str):
    new_text = ""
    for i, letter in enumerate(word):
        if i and letter.isupper():
            new_text += " "
        new_text += letter

    return new_text


def get_all_physical_quantities():
    return list(set(LI_IFC_PHYSICAL_QUANTITIES + get_aectemplater_physical_quantities()))


def path_from_fstring(fstring, **kwargs):
    kwargs = kwargs | {"AECTEMPLATER_FDIR_PROJECTS_ROOT": ENV.AECTEMPLATER_FDIR_PROJECTS_ROOT}
    return pathlib.Path(fstring.format(**kwargs))


def get_fpth_project_schedule(project_number: int, document_code: str):
    return path_from_fstring(
        ENV.AECSCHEDULE_GET_FPTH_PROJECT_SCHEDULE,
        project_number=str(project_number),
        document_code=document_code,
    )


def get_fdir_project(project_number: int):
    return path_from_fstring(
        ENV.AECSCHEDULE_GET_FDIR_PROJECT,
        project_number=str(project_number),
    )


def get_fdir_build_project_schedule(project_number: int, document_code: str):
    return path_from_fstring(
        ENV.AECSCHEDULE_GET_FDIR_BUILD_PROJECT_SCHEDULE,
        project_number=str(project_number),
        document_code=document_code,
    )


def disable_property(ui_edit, ui_add, property_name: str):
    """Disable property in both ui_edit and ui_add."""
    if ui_edit.di_widgets.get(property_name) is not None:
        ui_edit.di_widgets.get(property_name).disabled = True
    if ui_add.di_widgets.get(property_name) is not None:
        ui_add.di_widgets.get(property_name).disabled = True


def hide_show_null(ui_edit, ui_add):
    ui_add.bn_shownull.value = True
    ui_edit.bn_shownull.value = True
    ui_add.bn_shownull.layout.display = "none"
    ui_edit.bn_shownull.layout.display = "none"


def set_map_grid_index_to_id(grid_data: dict):
    """Set map from data grid index to ID."""
    return {n: k for n, k in enumerate(grid_data["data"].keys())}


def transform_to_grid_value(grid_data: dict):
    """Transform the grid_data value from API to grid value format so EditGrid can interpret
    and load the data."""
    return {k: v["data"] for k, v in grid_data["data"].items()}.values()


def zip_files_to_string(fpths: ty.List[pathlib.Path]) -> str:
    # Create a BytesIO object
    zip_buffer = io.BytesIO()

    # Create a ZipFile object with the BytesIO object as the file
    with zipfile.ZipFile(zip_buffer, "w") as zip_file:
        # Loop over each file
        for file in fpths:
            # Add file to the zip
            zip_file.write(file, arcname=file.name)

    # Get the byte content of the zip file
    zip_bytes = zip_buffer.getvalue()

    # Convert the bytes to a base64 string
    zip_string = b64encode(zip_bytes).decode()

    return zip_string


def generate_image_fname(image_prefix: str) -> str:
    return image_prefix + f"__{shortuuid.uuid()}.png"


def get_fdir_project_schedule_images(project_number: int) -> pathlib.Path:
    return path_from_fstring(
        ENV.AECSCHEDULE_GET_FDIR_PROJECT_IMAGES,
        project_number=str(project_number),
    )


def get_fpths_images(project_number: int, type_mark: str) -> ty.List[pathlib.Path]:
    fdir_project_schedule_images = get_fdir_project_schedule_images(project_number)
    # NOTE: the below will break if the type_mark tag has two underscores in it...
    return [fpth for fpth in fdir_project_schedule_images.glob(f"{type_mark}__*.png")]


def build_aecschedule_pdf(document_id: int) -> pathlib.Path:
    """Generates aecschedule PDF document."""
    document_data = jsonref.replace_refs(get_document_object_data(document_id, override_units=True))
    document = get_document_by_id(document_id)
    document_issue = document["issue"]["issue_data"]
    project_number = document["project_revision"]["project"]["project_number"]
    document_code = document_issue["document_name"]
    fdir_build_project_schedule = get_fdir_build_project_schedule(
        project_number,
        document_code=document_code,
    )
    fdir_build_project_schedule.mkdir(parents=True, exist_ok=True)
    with open(fdir_build_project_schedule / "document-data.json", "w") as f:
        json.dump(document_data, f)
    with open(fdir_build_project_schedule / "document-issue.json", "w") as f:
        json.dump(document_issue, f)
    if document_issue["document_type"] == DocumentTypeEnum.es:
        schedule: ProductDataSchedule = ProductDataSchedule.from_fdir(
            fdir=fdir_build_project_schedule,
            fdir_img=get_fdir_project_schedule_images(project_number),
            include_instances=True,
        )
    elif document_issue["document_type"] == DocumentTypeEnum.rds:
        schedule: RoomDataSchedule = RoomDataSchedule.from_fdir(
            fdir=fdir_build_project_schedule,
            fdir_img=get_fdir_project_schedule_images(project_number),
        )
    elif document_issue["document_type"] == DocumentTypeEnum.prs:
        schedule: PlantRoomSchedule = PlantRoomSchedule.from_fdir(
            fdir=fdir_build_project_schedule,
            fdir_img=get_fdir_project_schedule_images(project_number),
        )
    return schedule.to_pdf(fdir=fdir_build_project_schedule)


def stretch_tab_widths():
    """Overrides css class associated to the tab widget to stretch the tabs to the width of text in the tab."""
    display(
        HTML(
            """
    <style>
    .jupyter-widgets.widget-tab > .lm-TabBar .lm-TabBar-tab {
        flex: 0 1 auto
    }
    </style>
    """
        )
    )


def readable_datetime_string_from_fpth(fpth: pathlib.Path) -> str:
    return datetime.fromtimestamp(fpth.stat().st_ctime).strftime("%Y-%m-%d %H:%M:%S")


# TODO: Move to ipyautoui?
class HandleOptions(tr.HasTraits):
    options = tr.Dict(default_value={})

    @property
    def options_(self):
        return {v: k for k, v in self.options.items()}

    def get_item_from_options(self, name):
        try:
            return self.options_[name]
        except:
            return getattr()
