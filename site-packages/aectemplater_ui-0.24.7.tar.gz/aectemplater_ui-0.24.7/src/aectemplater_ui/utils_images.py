# -*- coding: utf-8 -*-
"""
Created on Tue Dec 11 14:15:00 2018

@author: j.gunstone

greyscale, convert .png to ico, image resizing and padding. 

"""
import os
import pathlib
import base64
import io
import numpy as np
import typing as ty
from PIL import Image, ImageOps


def get_img_dims(fpth):
    img = Image.open(fpth)
    return img.size


def rename_fpth(fpth_in, fdir_out=None, fnm_suffix=".png"):
    if type(fpth_in) == str:
        fpth_in = pathlib.Path(fpth_in)
    if fdir_out == None:
        fdir_out = fpth_in.parent
    if type(fdir_out) == str:
        fdir_out = pathlib.Path(fdir_out)
    fnm_out = fpth_in.stem + fnm_suffix
    fdir_out.mkdir(parents=True, exist_ok=True)
    fpth_out = fdir_out / fnm_out
    return str(fpth_out)


def img_greyscale(fpth_in, fdir_out=None, fnm_suffix="_greyscale.png"):
    """
    reads image (PIL supported file formats), converts to greyscale
    and saves image to fpth_out. returns img
    """
    fpth_out = rename_fpth(fpth_in, fdir_out=fdir_out, fnm_suffix=fnm_suffix)
    img = Image.open(fpth_in)  # open colour image
    img = img.convert("L")  # convert image to black and white
    img.save(fpth_out, quality=95)
    return img


def img_blackwhite(fpth_in, fdir_out=None, fnm_suffix="_blackwhite.png", thresh=200):
    fpth_out = rename_fpth(fpth_in, fdir_out=fdir_out, fnm_suffix=fnm_suffix)
    img = Image.open(fpth_in)
    fn = lambda x: 255 if x > thresh else 0
    img_out = img.convert("L").point(fn, mode="1")
    img_out.save(fpth_out, quality=95)
    return img_out


def img_ico(fpth_in, fdir_out=None, fnm_suffix=".ico"):
    """
    reads image (PIL supported file formats), saves as ico
    """
    fpth_out = rename_fpth(fpth_in, fdir_out=fdir_out, fnm_suffix=fnm_suffix)
    img = Image.open(fpth_in)
    img.save(fpth_out, quality=95)


def img_resize(fpth, size=(512, 512), save=True, overwrite=True):
    """
    resize images

    ref:
        https://stackoverflow.com/questions/1386352/pil-thumbnail-and-end-up-with-a-square-image
    """
    image = Image.open(fpth)
    img_sq = ImageOps.fit(image, size)
    if save == True:
        if overwrite == True:
            img_sq.save(fpth, quality=95)
        else:
            try:
                fpth = fpth.replace(".png", "_sq.png")
            except:
                print("not a .png image")
            img_sq.save(fpth, quality=95)
    return img_sq


def make_square(im, min_size=128, fill_color=(0, 0, 0, 0)):
    """
    makes and image sqare and adds a background fill colour
    (default white)
    """
    x, y = im.size
    size = max(min_size, x, y)
    new_im = Image.new("RGBA", (size, size), fill_color)
    new_im.paste(im, (int((size - x) / 2), int((size - y) / 2)))
    return new_im


def img_scale(img, basewidth=56):
    """
    scales image
    Ref:
        https://stackoverflow.com/questions/273946/how-do-i-resize-an-image-using-pil-and-maintain-its-aspect-ratio
    """
    wpercent = basewidth / float(img.size[0])
    hsize = int((float(img.size[1]) * float(wpercent)))
    img = img.resize((basewidth, hsize))
    return img


def img_resize_sq(
    fpth,
    basewidth=128,
    min_size=128,
    fill_color=(0, 0, 0, 0),
    save=True,
    overwrite=True,
    returns="path",
):
    """
    resizes image and makes it square
    """
    img = Image.open(fpth)
    img = make_square(img, min_size=min_size, fill_color=fill_color)
    img = img_scale(img, basewidth=basewidth)
    if save == True:
        fnm, f_ext = os.path.splitext(fpth)
        if overwrite == True:
            newpath = fnm + ".png"
            os.remove(fpth)
            img.save(newpath, quality=95)
        else:
            newpath = fnm + "_sq.png"
            img.save(newpath, quality=95)
    if returns == "path":
        return newpath
    else:
        return img


def make_rectangle(im, size: ty.Tuple[int, int], fill_color=(0, 0, 0, 0)):
    x, y = im.size
    new_im = Image.new("RGBA", size, fill_color)
    new_im.paste(im, (int((size[0] - x) / 2), int((size[1] - y) / 2)))
    return new_im


def img_scale_by_width(img, basewidth=56):
    """
    scales image
    Ref:
        https://stackoverflow.com/questions/273946/how-do-i-resize-an-image-using-pil-and-maintain-its-aspect-ratio
    """
    wpercent = basewidth / float(img.size[0])
    hsize = int((float(img.size[1]) * float(wpercent)))
    img = img.resize((basewidth, hsize))
    return img


def img_scale_by_height(img, baseheight=56):
    hpercent = baseheight / float(img.size[1])
    wsize = int((float(img.size[0]) * float(hpercent)))
    img = img.resize((wsize, baseheight))
    return img


def trim_whitespace(image, padding=10):
    """
    removes whitespace around an image

    Args:
        image (PIL object):
        padding (int): default=10

    Returns:
        cropped (PIL object): of resized image

    Reference:
        https://gist.github.com/thomastweets/c7680e41ed88452d3c63401bb35116ed
    """
    image.load()
    imageSize = image.size

    # remove alpha channel
    invert_im = image.convert("RGB")

    # invert image (so that white is 0)
    invert_im = ImageOps.invert(invert_im)
    imageBox = invert_im.getbbox()
    imageBox = tuple(np.asarray(imageBox) + padding)

    cropped = image.crop(imageBox)
    return cropped


def trim_whitespace_from_fpth(fpth, padding=10, fpth_new=None):
    """
    removes whitespace around an image

    Args:
        fpth (str):
        padding (int): default=10
        fpth_new (str): default=fpth

    Returns:
        fpth_new (str): of resized image

    Reference:
        https://gist.github.com/thomastweets/c7680e41ed88452d3c63401bb35116ed
    """
    image = Image.open(fpth)
    image.load()
    imageSize = image.size

    # remove alpha channel
    invert_im = image.convert("RGB")

    # invert image (so that white is 0)
    invert_im = ImageOps.invert(invert_im)
    imageBox = invert_im.getbbox()
    imageBox = tuple(np.asarray(imageBox) + padding)

    cropped = image.crop(imageBox)
    # print(filePath, "Size:", imageSize, "New Size:", imageBox)
    if fpth_new is None:
        fpth_new = fpth
    cropped.save(fpth_new, quality=95)
    return fpth_new


def img_as_string(fpth_img):
    """read image from file and return encoded string. uses pil, io and base64."""
    image = Image.open(fpth_img)
    output = io.BytesIO()
    image.save(output, format="PNG", quality=95)
    encoded_string = "data:image/png;base64," + base64.b64encode(output.getvalue()).decode()
    return encoded_string
