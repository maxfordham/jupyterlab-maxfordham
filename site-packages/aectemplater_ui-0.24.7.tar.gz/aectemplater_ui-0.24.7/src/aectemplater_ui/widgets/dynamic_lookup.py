# +
"""create a dropdown from TypeMarks of allowed values from objects within the active project."""
import ipywidgets as w
import traitlets as tr

from aectemplater_ui.load_project import get_active_project_revision_id, ENV
from aectemplater_client import get_project_type_marks

class DynamicLookup(tr.HasTraits):
    project_revision_id = tr.Int()
    object_id = tr.Int()

    @property
    def project_type_marks(self):
        type_marks = get_project_type_marks(self.project_revision_id, self.object_id)
        return list(type_marks.keys())
    
    @tr.observe("project_revision_id")
    def obs_project_revision_id(self, on_change):
        self.options = self.project_type_marks

    def __init__(self, **kwargs):
        value = None
        if "value" in kwargs:
            value = kwargs.get("value")
            kwargs.pop("value")
        super().__init__(**kwargs)
        self.project_revision_id = get_active_project_revision_id()
        if value is not None and value in self.options:
            self.value = value 
        
class BuildingId(DynamicLookup, w.Dropdown):
    def __init__(self, **kwargs):
        self.object_id = 835
        super().__init__(**kwargs)
        
if __name__ == "__main__":
    # aectemplater_ui.widgets.dynamic_lookup.BuildingId 
    from IPython.display import display
    bldg = BuildingId(value="BLDG-1")  # value="a"
    display(bldg)
# -


