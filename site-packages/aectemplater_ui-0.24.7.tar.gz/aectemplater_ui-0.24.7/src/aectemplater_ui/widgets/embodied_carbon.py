import pandas as pd
from aecreference import aecdata
from ipyautoui.custom.combobox_mapped import ComboboxMapped


class LifeCycleModule(ComboboxMapped):
    def __init__(self, **kwargs):
        super().__init__(**kwargs|{
            "options": {f"{row.Code} - {row.Title}": row.Code for n, row in aecdata.life_cycle_module.iterrows()}})


class RicsBuildingElementCategory(ComboboxMapped):
    def __init__(self, **kwargs):
        super().__init__(**kwargs|{
            "options": {f"{self.construct_category(x=row.x, y=row.y, z=row.z)} - {row.Title}": row.Title for n, row in aecdata.rics_building_element_category.iterrows()}})

    def construct_category(self, x: int, y: float, z: float) -> str:
        """Construct the category in the format x.y.z.
        y and z are floats because they could be NaN. x is never NaN hence being an integer."""
        str_ = str(x)
        if not pd.isna(y):
            str_ += f".{int(y)}"
        if not pd.isna(z):
            str_ += f".{int(z)}"
        return str_


if __name__ == "__main__":
    from IPython.display import display
    lcm = LifeCycleModule()
    rbec = RicsBuildingElementCategory()
    display(lcm)
    display(rbec)


