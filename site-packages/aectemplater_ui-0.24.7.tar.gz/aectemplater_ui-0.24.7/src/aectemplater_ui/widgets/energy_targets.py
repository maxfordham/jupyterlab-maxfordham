import ipywidgets as w

class EnergyTargetSlider(w.FloatSlider):
    def __init__(self, **kwargs):
        super().__init__(min=0, max=250, **kwargs)


if __name__ == "__main__":
    display(EnergyTargetSlider())


