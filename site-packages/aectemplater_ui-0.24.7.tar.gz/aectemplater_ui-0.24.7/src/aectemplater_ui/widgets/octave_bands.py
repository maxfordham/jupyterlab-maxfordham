# +
import ipywidgets as w
import traitlets as tr

SOUNDPOWER_WIDTH = "60px"


# +
class OctaveBands(w.HBox):
    _value = tr.Unicode()

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        (
            self._63.value,
            self._125.value,
            self._250.value,
            self._500.value,
            self._1000.value,
            self._2000.value,
            self._4000.value,
            self._8000.value,
        ) = eval(value)

    def __init__(self, **kwargs):
        self._63, self._125, self._250, self._500, self._1000, self._2000, self._4000, self._8000 = (
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
            w.IntText(layout=w.Layout(width=SOUNDPOWER_WIDTH)),
        )
        super().__init__(
            [self._63, self._125, self._250, self._500, self._1000, self._2000, self._4000, self._8000], **kwargs
        )
        self._init_controls()
        if "value" in kwargs:
            self.value = kwargs["value"]
        else:
            self._update_value("")

    def _init_controls(self):
        for x in self.sound_powers:
            x.observe(self._update_value, "value")

    @property
    def sound_powers(self):
        return [self._63, self._125, self._250, self._500, self._1000, self._2000, self._4000, self._8000]

    def get_sound_powers(self):
        return str([x.value for x in self.sound_powers])

    def _update_value(self, on_change):
        self._value = self.get_sound_powers()


if __name__ == "__main__":
    from IPython.display import display

    ob = OctaveBands(value='[0, 1, 0, 0, 0, 0, 0, 0]')
    display(ob)
    assert ob.value == '[0, 1, 0, 0, 0, 0, 0, 0]'
