# ---
# jupyter:
#   jupytext:
#     formats: py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.15.2
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +

# TODO: I think that this is probably better created using observable...
#       this would make it easy to embed on the WebApp / Wiki
from aectemplater_client import AECTEMPLATER_CNAME
from aectemplater_client import get_type_spec_metadata_by_project_revision, get_project_typespecs_metadata
from palettable.scientific.sequential import Batlow_20
from palettable.scientific.diverging import Berlin_20
from palettable.lightbartlein.diverging import BlueDarkOrange18_18
import itertools
import ipywidgets as w


def get_type_spec_summary(project_number, project_revision="current"):
    type_specs = get_project_typespecs_metadata(project_number, project_revision)
    types = list(set([f"{t['pset']['classification']} - {t['pset']['name']}" for t in type_specs]))
    types = {l.split(" ")[0]: l for l in types}
    colors = BlueDarkOrange18_18.hex_colors
    if len(types) > len(colors):
        colors = colors * (int(len(types) / len(colors)) + 1)

    colors = dict(zip(list(types.keys()), colors))

    di = {}
    for v in type_specs:
        cls = v["pset"]["classification"]
        tm = f"{v['abbreviation']}-{v['type_reference']}"
        if cls in di.keys():
            di[cls].append(tm)
        else:
            di[cls] = [tm]
    return di, types, colors


def get_ui_long_view(type_specs, types, colors):
    return w.VBox(
        [
            w.VBox(
                [
                    w.HTML(types[k]),
                    w.GridBox(
                        [
                            w.Button(
                                description=_,
                                tooltip=types[k],
                                layout=w.Layout(width="100px"),
                                style=dict(button_color=colors[k]),
                            )
                            for _ in v
                        ],
                        layout=w.Layout(grid_template_columns="repeat(8, 110px)"),
                    ),
                ]
            )
            for k, v in type_specs.items()
        ]
    )


def get_ui_compact_view(type_specs, types, colors):
    bns = [
        [
            w.Button(
                description=_, tooltip=types[k], layout=w.Layout(width="100px"), style=dict(button_color=colors[k])
            )
            for _ in v
        ]
        for k, v in type_specs.items()
    ]
    return w.GridBox(
        list(itertools.chain.from_iterable(bns)), layout=w.Layout(grid_template_columns="repeat(8, 110px)")
    )


type_specs, types, colors = get_type_spec_summary(5003)
# get_ui_long_view(types, colors)  # long view
get_ui_compact_view(type_specs, types, colors)
# -
