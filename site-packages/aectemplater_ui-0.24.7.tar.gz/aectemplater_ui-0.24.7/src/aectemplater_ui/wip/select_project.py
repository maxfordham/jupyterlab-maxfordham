# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.0
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
# %run __init__.py

from pydantic import BaseModel, Field, validator
import pathlib
from ipyautoui.custom.selectdir import SelectDirUi
from ipyautoui.custom.decision_branch import DecisionUi, TreeModel


class Project(BaseModel):
    project_name: str = "In House App Testing"
    project_number: int = 5001


# +
class ProjectDirs(Project):  # ,BaseModel
    fdir_projects_root: pathlib.Path = PATH_JOBS_ROOT
    fdir_project: pathlib.Path = None
    fdir_schedule: pathlib.Path = None
    fdir_revit: pathlib.Path = None

    @validator("fdir_project", always=True)
    def _fdir_project(cls, v, values):
        return values["fdir_projects_root"] / values["project_number"]

    @validator("fdir_schedule", always=True)
    def _fdir_schedule(cls, v, values):
        return values["fdir_project"] / "Schedule"

    @validator("fdir_revit", always=True)
    def _fdir_revit(cls, v, values):
        return values["fdir_project"] / "Cad" / "Revit"


class ScheduleDirs(ProjectDirs):
    """only fdir_app_root and app_name are required"""

    schedule_name: str
    version: str = "current"
    fdir_app_root: pathlib.Path = Field(None, description="where the Voila app is")
    fdir_app: pathlib.Path = Field(pathlib.Path("fdir_app"), description="where the Voila app is")
    fdir_pdts: pathlib.Path = pathlib.Path("fdir_pdts")
    fdir_schedule_img: pathlib.Path = pathlib.Path("fdir_schedule_img")

    @validator("fdir_app", always=True)
    def _fdir_app(cls, v, values):
        return values["fdir_schedule"] / values["schedule_name"] / values["version"]

    @validator("fdir_pdts", always=True)
    def _fdir_pdts(cls, v, values):
        return values["fdir_app"] / "pdts"

    @validator("fdir_schedule_img", always=True)
    def _fdir_schedule_img(cls, v, values):
        return values["fdir_app"] / "images"


# +
CHECK1_STR_EXISTS = "📁👍 - `{}` : folder exists in location. press to load."
CHECK1_STR_NOT_EXISTS = "📁⚠️ - `{}` : folder does not exist in location. It will be created on load"
CHECK2_SCHEDULE_EXISTS = "🔧⚠️ - `{}` : not yet configured for schedules, it will be configured on load."
CHECK2_SCHEDULE_NOT_EXISTS = "🔧👍 - `{}` : already configured for `aecschedule`, press to load folder."
FDIR_PROJECTS_ROOT = pathlib.Path("/home/jovyan/aecschedule/tests/jobs")  # TODO: set this up as a config var
FDIR_LOG_DIRS = FDIR_PROJECTS_ROOT / "J4321" / "Data" / "working_dirs"
FPTH_WORKING_DIRS = FDIR_LOG_DIRS / "working_dirs.json"
PROJECTS = {p.stem for p in list(pathlib.Path(FDIR_PROJECTS_ROOT).glob(pattern="*"))}


def check1(value: dict) -> str:
    if value["fdir"].is_dir():
        return CHECK1_STR_EXISTS.format(make_new_path(value["fdir"]))
    else:
        return CHECK1_STR_NOT_EXISTS.format(make_new_path(value["fdir"]))


def check2(value):
    if len(list(sdir.value["fdir"].glob(pattern=".aecschedule"))) == 0:
        return CHECK2_SCHEDULE_EXISTS.format(make_new_path(value["fdir"]))
    else:
        return CHECK2_SCHEDULE_NOT_EXISTS.format(make_new_path(value["fdir"]))


config = TreeModel(
    **{
        "options": PROJECTS,
        "placeholder": "select Project...",
        "children": {
            "options": ["Schedule"],
            "disabled": True,
            "value": "Schedule",
        },
        "value": "J5001",
    }
)
selectdir_schedules = SelectDirUi(config, fdir_root=FDIR_PROJECTS_ROOT, fdir_log=".", checks=[check1, check2])

if __name__ == "__main__":
    display(selectdir_schedules)
# -
