# +
import ast
import functools
import os
import pathlib
import typing as ty

import ipywidgets as w
from aectemplater_schemas.enumerations import ParameterTypeEnum, UseTypeEnum
from ipyautoui.custom.showopenurl import ShowOpenUrl
from ipyautoui.custom.urlimagelink import UrlImageLink
from IPython.display import display

from aectemplater_ui.apps.constants import (
    AECTEMPLATER_DOCS_URL,
    DEFAULT_PROJECT_REVISION_ID,
)
from aectemplater_ui.apps.spaces import SpacesGrid
from aectemplater_ui.filter import Filter
from aectemplater_ui.object_definition import ObjectDefinition
from aectemplater_ui.object_specification import ObjectSpecification
from aectemplater_ui.object_summary import ObjectSummary
from aectemplater_ui.schedules import ProjectSchedules


# +
class AecTemplaterAccordion(w.Tab):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.summary = ObjectSummary(editable_abbreviations=True)
        self.definition = ObjectDefinition()
        self.definition.object.buttonbar_grid.view.on_click(self._show_object_view)
        self.equipment = ObjectSpecification(
            project_revision_id=DEFAULT_PROJECT_REVISION_ID, use_type=UseTypeEnum.equipment
        )
        self.equipment_schedules = ProjectSchedules(
            project_revision_id=DEFAULT_PROJECT_REVISION_ID, use_type=UseTypeEnum.equipment
        )
        self.equipment_filters = Filter(use_type=UseTypeEnum.equipment)
        self.spaces = SpacesGrid(project_revision_id=DEFAULT_PROJECT_REVISION_ID)
        self.space_schedules = ProjectSchedules(
            project_revision_id=DEFAULT_PROJECT_REVISION_ID,
            use_type=UseTypeEnum.spaces,
            parameter_type=ParameterTypeEnum.instance,
        )
        self.space_filters = Filter(use_type=UseTypeEnum.spaces)
        self.equipment_tab = w.Tab(
            [self.equipment, self.equipment_schedules, self.equipment_filters],
            titles=[
                "Equipment",
                "Equipment Schedules",
                "Equipment Filters",
            ],
        )
        self.spaces_tab = w.Tab(
            [self.spaces, self.space_schedules, self.space_filters],
            titles=[
                "Spaces",
                "Space Schedules",
                "Space Filters",
            ],
        )
        self.children = [
            self.summary,
            self.definition,
            self.equipment_tab,
            self.spaces_tab,
        ]
        titles = (
            "Browse Templates",
            "Edit Templates",
            "Equipment",
            "Spaces",
        )
        [self.set_title(i, title) for i, title in enumerate(titles)]

    def _show_object_view(self, on_change):
        """Loads selected Object in Object Browser."""
        if self.definition.object.grid.selected:
            self.summary.browser.object_select.value = str(
                self.definition.object.grid.selected["id"]
            )  # Set browser to selected template if one selected
        self.summary.selected_index = self.summary.children.index(self.summary.browser)  # Change to template view tab
        self.selected_index = self.children.index(self.summary)  # Change to first accordion


if __name__ == "__main__":
    acc = AecTemplaterAccordion()
    display(acc)


# -


def get_header_items(url: str, description: str, path_image: ty.Union[str, pathlib.Path]):
    url_image_link = UrlImageLink(
        url=url,
        path_image=path_image,
        description=description,
        tooltip="open documentation on Max Fordham Wiki",
        width=40,
        font_size=25,
    )
    bn_help = w.ToggleButton(
        icon="book",
        tooltip="open UI help in the App",
        button_style="info",
        layout={"width": f"{url_image_link.width}px", "height": f"{url_image_link.width}px"},
    )
    return bn_help, url_image_link


# +
class AecTemplater(w.VBox):
    def __init__(self, acc_app=AecTemplaterAccordion):
        super().__init__()
        self.accordion = acc_app()
        self.docs = ShowOpenUrl(
            url=AECTEMPLATER_DOCS_URL,
            url_launch=AECTEMPLATER_DOCS_URL,
            description="open documentation in standalone window",
            description_launch="open documentation on the Wiki",
            auto_open=True,
        )
        self.bn_help, self.url_image_link = get_header_items(
            url=AECTEMPLATER_DOCS_URL,
            description="<b>AEC Templater</b>",
            path_image="https://raw.githubusercontent.com/maxfordham/visual-design/refs/heads/main/icons/logo-aectemplater.png",
        )
        self.header = w.HBox([self.bn_help, self.url_image_link])
        self.children = [self.header, self.docs, self.accordion]
        self._init_controls()
        self.docs.layout.display = "None"

    def _init_controls(self):
        self.bn_help.observe(self._show_hide_help, names="value")

    def _show_hide_help(self, onchange):
        if self.bn_help.value:
            self.docs.layout.display = ""
        else:
            self.docs.layout.display = "None"


if __name__ == "__main__":
    ui = AecTemplater()
    display(ui)


# +
class AecTemplaterViewOnly(AecTemplater):
    def __init__(self):
        app = functools.partial(ObjectSummary, editable_abbreviations=False)
        super().__init__(acc_app=app)


if __name__ == "__main__":
    view_only_ui = AecTemplaterViewOnly()
    display(view_only_ui)


def load_aectemplater():
    """Loads aectemplater with editing capabilities if user has permission, else loads view-only
    application.

    These permissions are set in the Jupyter environment variables."""
    if "JUPYTERHUB_GROUPS" not in os.environ:
        msg = "Failed to locate users with editing permissions."
        raise Exception(msg)
    jupyterhub_groups: list = ast.literal_eval(os.environ.get("JUPYTERHUB_GROUPS"))
    if "aectemplater" in jupyterhub_groups:
        return AecTemplater()
    else:
        return AecTemplaterViewOnly()


if __name__ == "__main__":
    # jovyan has editing permissions
    os.environ["JUPYTERHUB_GROUPS"] = '["aectemplater"]'
    os.environ["JUPYTERHUB_USER"] = "jovyan"
    display(load_aectemplater())

if __name__ == "__main__":
    # Will load view-only app
    os.environ["JUPYTERHUB_USER"] = "not_jovyan"
    display(load_aectemplater())
