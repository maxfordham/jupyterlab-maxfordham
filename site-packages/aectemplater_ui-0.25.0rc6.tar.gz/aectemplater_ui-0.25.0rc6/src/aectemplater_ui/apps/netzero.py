import logging
from datetime import date

import altair as alt
import ipywidgets as w
import pandas as pd
import traitlets as tr
import yaml
from aectemplater_client import (
    get_instance_specs_object_data_grid,
    get_project_by_id,
    get_project_revision_by_id,
    get_project_type_marks,
    get_projects_object_spec_data,
    get_type_spec_object_data_grid,
    get_type_spec_type_mark,
)
from document_issue.document_issue import DocumentIssue, Issue
from document_issue_io.markdown_document_issue import Orientation, OutputFormat, PaperSize, generate_document_issue_pdf
from ipyautoui.autodisplay_renderers import preview_yaml_string
from ipyautoui.custom.buttonbars import RELOAD_BUTTON_KWARGS
from ipyautoui.custom.datagrid import DataGrid
from ipyautoui.custom.filedownload import _FilesDownload
from ipyautoui.custom.svgspinner import SvgSpinner
from IPython.display import display
from markdown import markdown
from mfdb import get_job_description_to_number
from netzero_metrics.calcs import get_area_and_target_summaries
from netzero_metrics.constants import nzdata
from netzero_metrics.plots import plot_building_targets, plot_eui
from netzero_metrics.tables import (
    plot_great_tables_area_summary,
    plot_great_tables_targets,
    render_eui_uknzcb_targets_pivot_with_file_download,
)

from aectemplater_ui.apps.constants import (
    EUI_DATA,
    OBJECT_ID_BUILDING_AREA,
    OBJECT_ID_OPERATIONAL_ENERGY_TARGET,
    OBJECT_ID_PREDICTED,
    OBJECT_ID_RECORDED,
    TEST_PROJECT_REVISION_ID,
)
from aectemplater_ui.apps.energy_use import (
    EnergyDashboard,
    PredictedEnergyUseGrid,
    RecordedEnergyUseGrid,
    plot_energy_consumption,
)
from aectemplater_ui.apps.operational_energy_target import OperationalEnergyTargets
from aectemplater_ui.apps.project_building_area import ProjectBuildings
from aectemplater_ui.formatting import GRID_STYLE
from aectemplater_ui.instance_specification import InstanceSpecIO
from aectemplater_ui.load_project import LoadProject
from aectemplater_ui.utils import get_fdir_build_project_schedule, get_fdir_project_schedule_images, stretch_tab_widths


def str_presenter(dumper, data):
    """configures yaml for dumping multiline strings
    Ref: https://stackoverflow.com/questions/8640959/how-can-i-control-what-scalar-form-pyyaml-uses-for-my-data"""
    if data.count("\n") > 0:  # check for multiline string
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


stretch_tab_widths()


# +
# -----------------------------------------------------------------------------
# get data from the API -------------------------------------------------------
# -----------------------------------------------------------------------------
def get_project_name(project_revision_id) -> dict[int, str]:
    project_number = get_project_by_id(project_revision_id)["project_number"]
    return {int(v): k for k, v in get_job_description_to_number().items()}[project_number]




def get_project_building_data(project_revision_id, object_id=OBJECT_ID_BUILDING_AREA) -> pd.DataFrame:
    data = get_type_spec_object_data_grid(project_revision_id, object_id)["data"]
    df = pd.DataFrame([{"BuildingId": get_type_spec_type_mark(x["Id"])} | x for x in data])
    if df.empty:
        return df
    if "Name" in df.columns:
        df["Name"] = df["Name"].fillna(df["BuildingId"])
    else:
        df["Name"] = df["BuildingId"]
    return df


def get_building_id_to_name_map(project_revision_id: int) -> dict:
    df_project_buildings = get_project_building_data(project_revision_id)
    if "Name" in df_project_buildings.columns:
        return df_project_buildings.set_index("BuildingId").Name.to_dict()
    else:
        return {}


def get_area_data(project_revision_id, object_id=OBJECT_ID_BUILDING_AREA):  # TODO: move
    _ = get_instance_specs_object_data_grid(project_revision_id, object_id)
    data, _ = _["data"], _["$schema"]
    df_area = pd.DataFrame(data)
    if "IsNewBuild" in df_area.columns:
        # TODO: remove once `ConstructionMethod` generally in-use
        del df_area["IsNewBuild"]

    df_area = df_area.rename(columns={"TypeMark": "BuildingId"})
    building_id_to_name_map = get_building_id_to_name_map(project_revision_id)
    if not df_area.empty:
        df_area["BuildingName"] = df_area["BuildingId"].map(building_id_to_name_map)

    return df_area


def get_project_energy_targets(project_revision_id: int) -> pd.DataFrame:
    """Get the custom operational energy targets set by a project."""
    target_types = get_type_spec_object_data_grid(
        object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET,
        project_revision_id=project_revision_id,
    )["data"]
    energy_targets = get_instance_specs_object_data_grid(
        object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET,
        project_revision_id=project_revision_id,
    )["data"]
    if not energy_targets:
        return pd.DataFrame()
    df_targets = pd.DataFrame.from_records(energy_targets)
    df_target_types = pd.DataFrame.from_records(target_types)

    # Merge target_types with df_targets on TypeSpecId and Id
    df = pd.merge(df_targets, df_target_types, left_on="TypeSpecId", right_on="Id", suffixes=("_target_type", "_type"))
    if "GlobalEnergyTarget" in df.columns:
        df = df.drop(
            [
                "GlobalEnergyTarget",
            ],
            axis=1,
        )
    df = df.drop(
        [
            "Abbreviation",
            "TypeReference",
            "TypeMark",
            "TypeSpecId",
            "InstanceReference",
            "Id_target_type",
            "Id_type",
        ],
        axis=1,
    )
    if "ConstructionMethod" not in df.columns and "IsNewBuild" in df.columns:
        # TODO: remove once `ConstructionMethod` generally in-use
        df["ConstructionMethod"] = df["IsNewBuild"].apply(lambda x: "newbuild" if x else "retrofit-in-one-go")
    if "IsNewBuild" in df.columns:
        df = df.drop(["IsNewBuild"], axis=1)
    df = df.rename(columns={"EnergyTarget": "Target"})
    df = df.rename(columns={"Name": "TargetName"})
    return df



# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# -


class NetZeroInputsSummary(w.VBox):
    def _load_grid(self, onchange=None):
        self.svg.layout.display = "flex"
        all_projects_building_areas = get_projects_object_spec_data(code="MxfProjectBuildingArea", parameter_type="I")
        df = pd.DataFrame(all_projects_building_areas["data"])
        if "ConstructionMethod" not in df.columns:
            # TODO: remove once `ConstructionMethod` generally in-use
            df["ConstructionMethod"] = None
            if "IsNewBuild" in df.columns:
                df["ConstructionMethod"] = df["IsNewBuild"].map({True: "newbuild", False: "retrofit-in-one-go"})
        df["ProjectBuildings"] = df["BuildingType"] + " - " + df["ConstructionMethod"]
        df_all_projects_building_areas = df.groupby(["ProjectNumber", "ProjectName"], as_index=False).agg(
            {
                "GrossInternalArea": "sum",
                "ProjectBuildings": lambda x: ", ".join(x.astype(str)),
            }
        )
        all_projects_predicted_energy_use = get_projects_object_spec_data(
            code="MxfPredictedEnergyUse", parameter_type="I"
        )
        df = pd.DataFrame(all_projects_predicted_energy_use["data"])
        df_all_projects_predicted_energy_use = df.groupby(["ProjectNumber", "ProjectName"], as_index=False).agg(
            {
                "EnergyConsumption": "sum",
            }
        )
        all_projects_recorded_energy_use = get_projects_object_spec_data(
            code="MxfRecordedEnergyUse", parameter_type="I"
        )
        df = pd.DataFrame(all_projects_recorded_energy_use["data"])
        df_all_projects_recorded_energy_use = df.groupby(["ProjectNumber", "ProjectName"], as_index=False).agg(
            {
                "EnergyConsumption": "sum",
            }
        )
        df_merged = df_all_projects_building_areas.merge(
            df_all_projects_predicted_energy_use, on="ProjectNumber", how="outer", suffixes=("_building", "_predicted")
        )
        df_merged = df_merged.merge(
            df_all_projects_recorded_energy_use, on="ProjectNumber", how="outer", suffixes=("_predicted", "_recorded")
        )
        # Combine the ProjectName columns
        df_merged["ProjectName"] = (
            df_merged["ProjectName_building"]
            .combine_first(df_merged["ProjectName_predicted"])
            .combine_first(df_merged["ProjectName"])
        )
        # Rename columns to title case
        df_merged = df_merged.rename(
            columns={
                "ProjectNumber": "Project Number",
                "ProjectName": "Project Name",
                "ProjectBuildings": "Project Buildings",
                "GrossInternalArea": "Gross Internal Area (m²)",
                "EnergyConsumption_predicted": "Predicted Energy Use (kWh/m²/yr)",
                "EnergyConsumption_recorded": "Recorded Energy Use (kWh/m²/yr)",
            }
        )
        # Select the required columns
        df_merged = df_merged[
            [
                "Project Number",
                "Project Name",
                "Project Buildings",
                "Gross Internal Area (m²)",
                "Predicted Energy Use (kWh/m²/yr)",
                "Recorded Energy Use (kWh/m²/yr)",
            ]
        ]
        df_merged[
            ["Gross Internal Area (m²)", "Predicted Energy Use (kWh/m²/yr)", "Recorded Energy Use (kWh/m²/yr)"]
        ] = df_merged[
            ["Gross Internal Area (m²)", "Predicted Energy Use (kWh/m²/yr)", "Recorded Energy Use (kWh/m²/yr)"]
        ].round(1)
        self.grid.data = df_merged
        self.grid.column_widths = {
            "Predicted Energy Use (kWh/m²/yr)": 225,
            "Recorded Energy Use (kWh/m²/yr)": 225,
            "Gross Internal Area (m²)": 242,
            "Project Buildings": 204,
            "Project Name": 374,
            "Project Number": 120,
        }
        self.svg.layout.display = "None"

    def __init__(self, **kwargs):
        self.grid = DataGrid(
            pd.DataFrame(),
            grid_style=GRID_STYLE,
            hide_nan=True,
        )
        self.bn_reload = w.Button(**RELOAD_BUTTON_KWARGS)
        self.svg = SvgSpinner(layout=dict(display="None"))
        super().__init__([w.HBox([self.bn_reload, self.svg]), self.grid])
        self._load_grid()
        self.bn_reload.on_click(self._load_grid)


if __name__ == "__main__":
    grid = NetZeroInputsSummary()
    display(grid)


# +
def mdhtml(md):
    return w.HTML(markdown(md))


class ProjectSummary(w.VBox, _FilesDownload):
    """Net-Zero Carbon Project Summary that shows the Project and Building Targets,
    and Predicted and Recorded Energy Use Charts."""

    project_revision_id = tr.Int()
    object_id = tr.Int(default_value=OBJECT_ID_BUILDING_AREA)
    df_eui = tr.Instance(klass=pd.DataFrame, default_value=nzdata.energy_use_intensity)

    @tr.observe("project_revision_id")
    def obs_project_revision_id(self, on_change):
        self.project_name = get_project_name(self.project_revision_id)
        self.project_number = get_project_revision_by_id(self.project_revision_id)["project"]["project_number"]
        self.fdir_images = get_fdir_project_schedule_images(project_number=self.project_number)
        self.fdir_images.mkdir(exist_ok=True, parents=True)
        self.fpth_building_targets_chart = self.fdir_images / "nzc-building-targets.png"
        self.fpth_predicted_energy_use_chart = self.fdir_images / "nzc-predicted-energy-use-chart.png"
        self.fpth_recorded_energy_use_chart = self.fdir_images / "nzc-recorded-energy-use-chart.png"
        self.msg.value = ""
        self._update_summary()

    def __init__(self, **kwargs):
        self.project_name = ""
        self.title = f"## {self.project_name} NZC Summary"
        self.html_h0 = mdhtml(self.title)
        self.h4 = "## Predicted Operational Energy"
        self.h5 = "## In-Use Operational Energy"
        self.bx_gt_target_summary = w.Box(layout=w.Layout(align_items="flex-start", justify_content="flex-start"))
        self.bx_gt_area_summary = w.Box(layout=w.Layout(align_items="flex-start", justify_content="flex-start"))
        self.bx_building_targets_chart = w.HBox()
        self.vbx_predicted_energy = w.VBox()
        self.vbx_in_use_energy = w.VBox()
        self.bn_download = w.Button(
            layout={"width": "250px"},
            icon="download",
            description="Download Project Summary PDF",
            tooltip="Download Selected Schedules",
            button_style="info",
        )
        self.svg = SvgSpinner(layout=dict(display="None"))
        self.output = w.Output()
        self.msg = w.HTML()
        super().__init__(
            [
                w.HBox([self.bn_download, self.svg, self.msg]),
                self.output,
                self.html_h0,
                w.GridBox(
                    children=[
                        w.VBox([self.bx_building_targets_chart, self.bx_gt_target_summary]),
                        self.bx_gt_area_summary,
                        w.VBox([mdhtml(self.h4), self.vbx_predicted_energy]),
                        w.VBox([mdhtml(self.h5), self.vbx_in_use_energy]),
                    ],
                    layout=w.Layout(grid_template_columns="50% 45%", grid_gap="20px 20px"),
                ),
            ],
            **kwargs,
        )
        self.bn_download.on_click(self._download)
        self._update_summary()

    def _update_area_and_target_summaries(self):
        """Update the summary data."""
        self.df_project_buildings = get_project_building_data(self.project_revision_id)
        self.df_area = get_area_data(self.project_revision_id, self.object_id)
        self.df_project_energy_targets = get_project_energy_targets(project_revision_id=self.project_revision_id)
        if not self.df_area.empty:
            (
                self.df_area_summary,
                self.di_area_weights,
                self.di_project_area_weights,
                self.df_nzc_standard_building_year_targets,
                self.df_all_building_targets,
                self.df_all_project_targets,
            ) = get_area_and_target_summaries(
                self.df_project_buildings, self.df_area, self.df_project_energy_targets, self.df_eui
            )
        else:
            self.df_area_summary = pd.DataFrame()
            self.di_area_weights = {}
            self.di_project_area_weights = {}
            self.df_nzc_standard_building_year_targets = pd.DataFrame()
            self.df_all_building_targets = pd.DataFrame()
            self.df_all_project_targets = pd.DataFrame()

    def _update_summary(self, onchange=None):
        """Update the summary i.e. the building targets and energy use plots."""
        self._update_area_and_target_summaries()
        self.title = f"## {self.project_name} NZC Summary"
        self.html_h0.value = markdown(self.title)
        self._update_energy_use_plots()
        self._update_building_targets()

    def _update_building_targets(self):
        """Update the output summary displayed."""
        self.gt_area_summary = plot_great_tables_area_summary(df_area=self.df_area)
        self.gt_target_summary = plot_great_tables_targets(
            df_all_building_targets=self.df_all_building_targets, df_all_project_targets=self.df_all_project_targets
        )  # TODO: update  #  df_all_project_targets=self.df_all_project_targets

        self.bx_gt_area_summary.children = [w.HTML(self.gt_area_summary.as_raw_html())]
        self.bx_gt_target_summary.children = [w.HTML(self.gt_target_summary.as_raw_html())]
        if self.df_all_building_targets.empty:
            self.bx_building_targets_chart.children = []
        else:
            building_targets_chart = plot_building_targets(
                df_nzc_standard_building_year_targets=self.df_nzc_standard_building_year_targets,
                df_all_building_targets=self.df_all_building_targets,
                df_all_project_targets=self.df_all_project_targets,
            )
            building_targets_chart.save(self.fpth_building_targets_chart, ppi=200)
            self.bx_building_targets_chart.children = [alt.JupyterChart(building_targets_chart)]

    def _update_energy_use_plots(self):
        """Update the recorded and predicted energy use plots."""
        spec_predicted = get_instance_specs_object_data_grid(
            project_revision_id=self.project_revision_id,
            object_id=OBJECT_ID_PREDICTED,
        )
        spec_recorded = get_instance_specs_object_data_grid(
            project_revision_id=self.project_revision_id,
            object_id=OBJECT_ID_RECORDED,
        )
        try:
            predicted_energy_chart = plot_energy_consumption(
                pd.DataFrame(spec_predicted["data"]),
                x_name="OperationalEnergyAnalysisType",
                direction="horizontal",
            )
            predicted_energy_chart.save(self.fpth_predicted_energy_use_chart, ppi=200)
            self.vbx_predicted_energy.children = [alt.JupyterChart(predicted_energy_chart)]
        except Exception as err:
            self.vbx_predicted_energy.children = []
            logging.warning(err)
        try:
            recorded_energy_chart = plot_energy_consumption(
                pd.DataFrame(spec_recorded["data"]), x_name="ReportingPeriod", direction="horizontal"
            )
            self.vbx_in_use_energy.children = [alt.JupyterChart(recorded_energy_chart)]
            recorded_energy_chart.save(self.fpth_recorded_energy_use_chart, ppi=200)
        except Exception as err:
            self.vbx_in_use_energy.children = []
            logging.warning(err)

    def to_pdf(self):
        """Output the summary to PDF."""
        # TODO: Move to schedules.py in aecschedule
        net_zero_doc_issue = DocumentIssue(
            project_name="Net Zero Project Summary",
            project_number="J6767",
            document_code="J6767-MXF-XX-XX-DR-Y-20000",
            document_description="Max Fordham Net Zero Carbon Project Tracker",
            name_nomenclature="project-originator-volume-level-type-role-number",
            notes=[
                "Work in progress.",
            ],
            issue=[
                Issue(
                    author="OH",
                    checked_by="JG",
                    revision="P01",
                    status_code="S2",
                    status_description="Suitable for information",
                    issue_notes="This is an issue note",
                    date=date.today(),
                )
            ],
        )
        fdir_build = get_fdir_build_project_schedule(
            project_number=self.project_number, document_code=net_zero_doc_issue.document_code
        )
        fdir_build.mkdir(parents=True, exist_ok=True)  # TODO: Should this be here?
        self.fpth_pdf = fdir_build / "net-zero-metrics-summary.pdf"
        md_content = self.title
        if self.fpth_building_targets_chart.exists():
            md_content += f"\n![&nbsp;]({self.fpth_building_targets_chart.name})\n"
        if self.gt_target_summary:
            md_content += self.gt_target_summary.as_latex(tbl_pos="H")
        if self.gt_area_summary:
            md_content += self.gt_area_summary.as_latex(tbl_pos="H")
        if self.fpth_predicted_energy_use_chart.exists():
            md_content += f"\n{self.h4}\n\n![&nbsp;]({self.fpth_predicted_energy_use_chart.name})\n"
        if self.fpth_recorded_energy_use_chart.exists():
            md_content += f"\n{self.h5}\n\n![&nbsp;]({self.fpth_recorded_energy_use_chart.name})\n"
        return generate_document_issue_pdf(
            document_issue=net_zero_doc_issue,
            fpth_pdf=self.fpth_pdf,
            md_content=md_content,
            output_format=OutputFormat.DOCUMENT_ISSUE_NOTE,
            orientation=Orientation.PORTRAIT,
            paper_size=PaperSize.A4,
            resource_path=[self.fdir_images],
        )

    def _download(self, on_click):
        """Download summary with spinner and message if fails."""
        try:
            self.svg.layout.display = ""
            self.msg.value = ""
            self.to_pdf()
            self.value = [self.fpth_pdf]
            self.trigger_download()
            self.svg.layout.display = "None"
        except FileNotFoundError as err:
            self.svg.layout.display = "None"
            self.msg.value = "❌ Download unsuccessful—content summary is missing."
        except Exception as err:
            self.svg.layout.display = "None"
            self.msg.value = "❌ Download unsuccessful."


if __name__ == "__main__":
    prj_summary = ProjectSummary(project_revision_id=TEST_PROJECT_REVISION_ID)
    display(prj_summary)
# -

if __name__ == "__main__":
    prj_summary = ProjectSummary(project_revision_id=3)  # try with an empty table
    display(prj_summary)


# +
class NetZeroApp(w.VBox):
    project_revision_id = tr.Integer(default_value=None, allow_none=True)

    @tr.observe("project_revision_id")
    def obs_project_revision_id(self, on_change):
        self.svg_spinner.layout.display = "flex"
        self._unobserve_grids()
        self.prj_summary.project_revision_id = self.project_revision_id
        self.project_buildings.project_revision_id = self.project_revision_id
        self.energy_targets.project_revision_id = self.project_revision_id
        self.energy_predicted.project_revision_id = self.project_revision_id
        self.energy_recorded.project_revision_id = self.project_revision_id
        self._observe_grids()
        self.svg_spinner.layout.display = "None"
        self.project_buildings.gr_areas.fn_reload = self.energy_targets.gr_energy_targets._reload_all_data

    def _update_building_id_options(self, onchange=None):
        """Check type marks in buildings grid match dropdown for Building ID."""
        if set(self.project_buildings.gr_bldgs.type_marks) != set(
            self.energy_predicted.ui_add.di_widgets["BuildingID"].widget.options
        ):
            project_building_types = list(
                get_project_type_marks(self.project_revision_id, OBJECT_ID_BUILDING_AREA).keys()
            )
            self.energy_predicted.ui_add.di_widgets["BuildingID"].widget.options = project_building_types
            self.energy_predicted.ui_edit.di_widgets["BuildingID"].widget.options = project_building_types
            self.energy_recorded.ui_add.di_widgets["BuildingID"].widget.options = project_building_types
            self.energy_recorded.ui_edit.di_widgets["BuildingID"].widget.options = project_building_types

    def __init__(self, **kwargs):
        self._init_ui()
        self._observe_grids()
        super().__init__([self.hbx_title, self.tabs], project_revision_id=TEST_PROJECT_REVISION_ID)
        self._set_tab_children("Project Summary", [self.prj_summary])
        self._init_controls()

    def _init_ui(self):
        """Initialise the UI components."""
        self.svg_spinner = SvgSpinner(layout=w.Layout(display="None"))
        self.html_title = w.HTML(markdown("# Net-Zero Carbon Metrics"))
        self.load_project = LoadProject()
        self.hbx_title = w.HBox([self.html_title, self.load_project], layout=w.Layout(justify_content="space-between"))
        self.prj_summary = ProjectSummary()
        self.project_buildings = ProjectBuildings()
        self.energy_targets = OperationalEnergyTargets()
        self.energy_predicted = PredictedEnergyUseGrid(ui_io=InstanceSpecIO)
        self.energy_recorded = RecordedEnergyUseGrid(ui_io=InstanceSpecIO)
        self.energy_dashboard = EnergyDashboard()
        self.inputs_summary = NetZeroInputsSummary()
        self.eui_jchart_bmarks = alt.JupyterChart(plot_eui())
        self.tab_eui = render_eui_uknzcb_targets_pivot_with_file_download(EUI_DATA)
        self.out_bmarks_ref = w.Output()
        with self.out_bmarks_ref:
            display(preview_yaml_string(yaml.dump(nzdata.energy_use_intensity_metadata, indent=2)))
        # Inject svg spinner into load project
        self.load_project.hbx_message.children = [self.svg_spinner] + list(self.load_project.hbx_message.children)
        # Customise tabs
        self.tab_titles = [
            "Project Summary",
            "Project Building Areas",
            "Target Operational Energy",
            "Predicted Operational Energy",
            "In-Use Operational Energy",
            "Embodied Carbon",
            "Reference - EUI Targets",
            "Practice Summary",
        ]
        self.tabs = w.Tab(
            [w.VBox([w.HTML(f"{x} coming soon...".format(x))]) for x in self.tab_titles], titles=self.tab_titles
        )
        self.tabs.children[self.tab_titles.index("Project Building Areas")].children = [
            self.project_buildings,
            self.prj_summary.bx_building_targets_chart,
            self.prj_summary.bx_gt_area_summary,
        ]
        self.tabs.children[self.tab_titles.index("Target Operational Energy")].children = [
            self.energy_targets,
            self.prj_summary.bx_building_targets_chart,
            self.prj_summary.bx_gt_target_summary,
        ]
        self.tabs.children[self.tab_titles.index("Predicted Operational Energy")].children = [self.energy_predicted]
        self.tabs.children[self.tab_titles.index("In-Use Operational Energy")].children = [self.energy_recorded]
        self.tabs.children[self.tab_titles.index("Reference - EUI Targets")].children = [
            self.eui_jchart_bmarks,
            w.HTML("<h2>Browse EUI Data</h2>"),
            self.tab_eui,
            w.HTML("<h2>EUI Data Configuration</h2>"),
            self.out_bmarks_ref,
        ]
        self.tabs.children[self.tab_titles.index("Practice Summary")].children = [
            w.Accordion(
                [self.energy_dashboard, self.inputs_summary],
                titles=["Annual Energy Dashboard", "Net Zero Input Data Summary"],
            )
        ]

    def _init_controls(self):
        self.load_project.observe(self._update_project_revision_id, "project_revision_id")
        self.project_buildings.gr_bldgs.grid.observe(self._update_building_id_options, "count_changes")

    def _observe_grids(self):
        """Observe the grids for changes and update summary if changes to project buildings or areas."""
        self.project_buildings.gr_bldgs.grid.observe(self.prj_summary._update_summary, "count_changes")
        self.project_buildings.gr_areas.grid.observe(self.prj_summary._update_summary, "count_changes")
        self.energy_targets.gr_energy_targets.grid.observe(self.prj_summary._update_summary, "count_changes")
        self.energy_targets.gr_energy_target_type.grid.observe(self.prj_summary._update_summary, "count_changes")
        self.energy_predicted.grid.observe(self.prj_summary._update_summary, "count_changes")
        self.energy_recorded.grid.observe(self.prj_summary._update_summary, "count_changes")

    def _unobserve_grids(self):
        """Unobserve the grids for changes so that the summary is not updated.
        This is useful when the project revision ID is changed as that updates the summary also."""
        self.project_buildings.gr_bldgs.grid.unobserve(self.prj_summary._update_summary, "count_changes")
        self.project_buildings.gr_areas.grid.unobserve(self.prj_summary._update_summary, "count_changes")
        self.energy_targets.gr_energy_targets.grid.unobserve(self.prj_summary._update_summary, "count_changes")
        self.energy_targets.gr_energy_target_type.grid.unobserve(self.prj_summary._update_summary, "count_changes")
        self.energy_predicted.grid.unobserve(self.prj_summary._update_summary, "count_changes")
        self.energy_recorded.grid.unobserve(self.prj_summary._update_summary, "count_changes")

    def _update_project_revision_id(self, on_change):
        """Update project revision ID from load project widget."""
        self.project_revision_id = self.load_project.project_revision_id

    def _set_tab_children(self, tab_name: str, children: list):
        self.tabs.children[self.tab_titles.index(tab_name)].children = children


if __name__ == "__main__":
    netzero = NetZeroApp()
    display(netzero)
# -




