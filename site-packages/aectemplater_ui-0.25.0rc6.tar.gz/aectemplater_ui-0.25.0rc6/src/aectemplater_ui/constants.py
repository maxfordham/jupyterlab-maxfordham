import pathlib

FDIR_ROOT = pathlib.Path(__file__).parents[2]

DES_OBJECTS = {
    "title": "Data Templates",
    "description": (
        "A Data Template consists of multiple Property Sets."
        "Possible use cases include: Product Data Templates, Room Data Templates, Calc Inputs, ..."
    ),
}

DES_PROPERTYSETS = {
    "title": "Property Sets",
    "description": ("A Property Set is an abstract set of properties."),
}

DES_LINKPROPS_ALL = {
    "title": "All Properties",
    "description": ("Browse all properties that exist in the database."),
}

DES_LINKPROPS_TEMPLATE = {
    "title": "Property Set's Properties",
    "description": ("Select a Property Set and add or remove properties."),
}

DES_OBJECT_PSET = {
    "title": "Assign Property Sets to a Template",
    "description": "Select Property Sets to assign to a Template and preview the properties that will be added.",
}


DES_PROPERTIES = {
    "title": "All Properties",
    "description": "Add, Edit, or Delete Properties.",
}

DES_UNITS = {
    "title": "All Units",
    "description": "Add, Edit, or Delete Units.",
}

