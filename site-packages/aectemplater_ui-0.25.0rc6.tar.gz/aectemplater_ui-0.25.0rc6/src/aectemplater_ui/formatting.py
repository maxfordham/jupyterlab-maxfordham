# -*- coding: utf-8 -*-
# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.6
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
import immutables
import matplotlib.colors as mcolors
import seaborn as sns
from aectemplater_schemas.enumerations import CategoriesEnum, SectionsEnum
from aectemplater_schemas.object import Object
from aectemplater_schemas.property import Property
from aectemplater_schemas.propertyset import PropertySet
from aectemplater_schemas.units import Units
from ipydatagrid import Expr, TextRenderer, VegaExpr
from palettable.colorbrewer.qualitative import Accent_7
from palettable.tableau import BlueRed_12, TableauMedium_10

frozenmap = immutables.Map

HEADER_BACKGROUND_COLOUR = "rgb(207, 212, 252)"
GRID_STYLE = {"header_background_color": HEADER_BACKGROUND_COLOUR}


# -
def create_vega_expression(di):
    """creates a vega expression for colouring a DataGrid based on a key(string name): value(hex colour) dict"""
    expr = ""
    for k, v in di.items():
        expr += f'"{v}" if "{k}" == toString(cell.value) else '
    expr += "default_value"
    return expr


def get_units_format():
    get_title = lambda k, v: v["title"] if "title" in v.keys() else k
    columns = [get_title(k, v) for k, v in Units().model_json_schema()["properties"].items()]  # Get column names
    li_dims = ["L", "M", "T", "I", "Θ", "N", "J"]  # Columns we want to add colour too
    di_dims = {k: v for k, v in enumerate(columns) if v in li_dims}

    # Constructing vega expression
    vega_expr = ""
    for i, (k, v) in enumerate(di_dims.items()):
        vega_expr += f"cell === {k} ? '{Accent_7.hex_colors[i]}' : "

    vega_expr += "'#FFFFFF'"  # Else other columns are white.
    custom = {
        "column_background_color": VegaExpr(vega_expr),
        "header_background_color": HEADER_BACKGROUND_COLOUR,
    }  # defining custom theme

    di_format = {
        "grid_style": custom,
        "header_renderer": TextRenderer(
            vertical_alignment="top",
            text_wrap=True,
        ),
    }  # Constructing dict to import into data grid
    return frozenmap(di_format)


# +
def get_section_map_colours():
    num_colors = 60  # Generate a palette with 50 colors using seaborn
    palette = sns.color_palette("Paired", num_colors)
    hex_colors = [mcolors.rgb2hex(color) for color in palette]  # Convert colors to hex
    return {k: v for k, v in zip([i.value for i in SectionsEnum], hex_colors)}


def get_category_map_colours():
    return {k: v for k, v in zip([i.value for i in CategoriesEnum], TableauMedium_10.hex_colors)}


def define_properties_colours():
    vega_expr = create_vega_expression({**get_section_map_colours(), **get_category_map_colours()})
    expr = Expr(vega_expr)
    return {
        "category": TextRenderer(background_color=expr),
        "section": TextRenderer(background_color=expr),
    }


# TODO: Could probably generalise some of the renderers below
def get_properties_renderers():
    def define_datetime_format():
        date_time_cols = [
            k
            for k, v in Property.model_json_schema()["properties"].items()
            if "format" in v and v["format"] == "date-time"
        ]
        text_renderer_date_time_format = TextRenderer(
            format="%Y-%m-%d %H:%M:%S",
            format_type="time",
        )
        return {col: text_renderer_date_time_format for col in date_time_cols}

    di_datetime_cols_renderer = define_datetime_format()
    renderers = {
        **di_datetime_cols_renderer,
        **define_properties_colours(),
    }
    return renderers


def get_properties_format():
    custom = {
        "header_background_color": HEADER_BACKGROUND_COLOUR,
    }  # defining custom theme

    di_format = {
        "grid_style": custom,
        "header_renderer": TextRenderer(
            vertical_alignment="top",
            text_wrap=True,
        ),
        "renderers": get_properties_renderers(),
    }  # Constructing dict to import into data grid
    return frozenmap(di_format)


# +
def get_propertysets_renderers():
    def define_datetime_format():
        date_time_cols = [
            k
            for k, v in PropertySet.model_json_schema()["properties"].items()
            if "format" in v and v["format"] == "date-time"
        ]
        text_renderer_date_time_format = TextRenderer(
            format="%Y-%m-%d %H:%M:%S",
            format_type="time",
        )
        return {col: text_renderer_date_time_format for col in date_time_cols}

    di_datetime_cols_renderer = define_datetime_format()
    renderers = {
        **di_datetime_cols_renderer,
    }
    return renderers


def get_propertysets_format():
    custom = {
        "header_background_color": HEADER_BACKGROUND_COLOUR,
    }  # defining custom theme

    di_format = {
        "grid_style": custom,
        "header_renderer": TextRenderer(
            vertical_alignment="top",
            text_wrap=True,
        ),
        "renderers": get_propertysets_renderers(),
    }  # Constructing dict to import into data grid
    return frozenmap(di_format)


# +
def get_object_renderers():
    def define_datetime_format():
        date_time_cols = [
            k
            for k, v in Object.model_json_schema()["properties"].items()
            if "format" in v and v["format"] == "date-time"
        ]
        text_renderer_date_time_format = TextRenderer(
            format="%Y-%m-%d %H:%M:%S",
            format_type="time",
        )
        return {col: text_renderer_date_time_format for col in date_time_cols}

    di_datetime_cols_renderer = define_datetime_format()
    renderers = {
        **di_datetime_cols_renderer,
    }
    return renderers


def get_object_format():
    custom = {
        "header_background_color": HEADER_BACKGROUND_COLOUR,
    }  # defining custom theme

    di_format = {
        "grid_style": custom,
        "header_renderer": TextRenderer(
            vertical_alignment="top",
            text_wrap=True,
        ),
        "renderers": get_object_renderers(),
    }  # Constructing dict to import into data grid
    return frozenmap(di_format)
