# ---
# jupyter:
#   jupytext:
#     formats: py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %%
# %run __init__.py
# %load_ext lab_black

# %%
import traitlets as tr
import ipywidgets as w
from IPython.display import Javascript, display
from ipyautoui.constants import BUTTON_WIDTH_MIN
import time
from bsdd import Client


def get_ifc_classes():
    fn = lambda i: client.get_classes(
        IFC4X3_URI,
        use_nested_classes=False,
        class_type="Class",
        offset=i[0],
        limit=i[1],
    )["classes"]
    _ = {}
    for i in [(0, 1000), (1000, 2000)]:
        _ = _ | {l["code"]: l for l in fn(i)}
    return _


client = Client()
# IFC4X3_URI = [
#     l["uri"] for l in client.get_dictionary()["dictionaries"] if "4.3" in l["uri"]
# ][0]
IFC4X3_URI = "https://identifier.buildingsmart.org/uri/buildingsmart/ifc/4.3"
URL_IFCDOCS_DOMAIN_SCHEMAS = "https://ifc43-docs.standards.buildingsmart.org/IFC/RELEASE/IFC4x3/HTML/chapter-7/"
MAP_IFC_CODE_DICT = get_ifc_classes()
KWARGS_LINK = {
    "layout": {"width": BUTTON_WIDTH_MIN, "border": "solid 2px grey"},
    "icon": "link",
}


class SelectIfcClass(w.HBox):
    _value = tr.Unicode()
    apply_mxf_filter = tr.Bool()
    ifc_dict = tr.Dict()
    url = tr.Unicode(URL_IFCDOCS_DOMAIN_SCHEMAS)

    @tr.observe("_value")
    def obs_value(self, on_change):
        self.bn_link.layout.border = "solid 2px yellow"
        self.url = MAP_IFC_CODE_DICT[self._value]["uri"]
        self.ifc_dict = MAP_IFC_CODE_DICT[self._value]
        self.html_ifc.value = (lambda di: f"{di['parentClassCode']} --> {di['code']} : {di['name']}")(self.ifc_dict)
        time.sleep(0.2)
        self.bn_link.layout.border = "solid 2px grey"

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self.cmbx_ifc.value = value

    def __init__(self, **kwargs):
        self.cmbx_ifc = w.Combobox(ensure_option=True, options=list(MAP_IFC_CODE_DICT.keys()))
        self.bn_link = w.Button(**KWARGS_LINK)
        self.html_ifc = w.HTML()
        self.out = w.Output()
        super().__init__(**kwargs)
        self.children = [self.cmbx_ifc, self.bn_link, self.html_ifc, self.out]
        self._init_controls()

    def _init_controls(self):
        self.bn_link.on_click(self._bn_link)
        self.cmbx_ifc.observe(self._cmbx_ifc, "value")

    def _cmbx_ifc(self, on_change):
        self._value = self.cmbx_ifc.value

    def _bn_link(self, on_click):
        self.window_open_button()

    def window_open_button(self):
        with self.out:
            display(Javascript(f'window.open("{self.url}");'))


if __name__ == "__main__":
    select_ifc = SelectIfcClass()
    select_ifc.value = "IfcLightFixture"
    display(select_ifc)

# %%
