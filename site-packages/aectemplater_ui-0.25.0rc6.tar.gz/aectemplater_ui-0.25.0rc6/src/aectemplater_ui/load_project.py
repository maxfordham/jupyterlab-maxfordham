# +
import logging
import os

import ipywidgets as w
import traitlets as tr
from aectemplater_client import (
    get_project_by_project_number,
    get_project_revision_by_project_number_and_revision,
    post_project,
    post_project_revision,
)
from ipyautoui.custom.combobox_mapped import ComboboxMapped
from ipyautoui.custom.selectandclick import Load, SelectAndClickFormLayouts
from IPython.display import display

from aectemplater_ui import ENV, JOB_DESCRIPTION_TO_NUMBER

logger = logging.getLogger(__name__)
DEFAULT_PROJECT_NAME = f"J{ENV.AECSCHEDULE_PROJECT_NUMBER} - Test Project"


# -


def get_active_project_revision_id():
    try:
        return int(os.environ["ACTIVE_PROJECT_REVISION_ID"])
    except:
        return get_project_by_project_number(ENV.AECSCHEDULE_PROJECT_NUMBER)['id']


def set_active_project_revision_id(project_revision_id: int):
    os.environ["ACTIVE_PROJECT_REVISION_ID"] = str(project_revision_id)
    return project_revision_id


def check_project(project_number: int) -> bool:
    try:
        get_project_by_project_number(project_number)
        return True
    except Exception as err:
        return False


class LoadProject(Load):
    project_revision_id = tr.Int(None, allow_None=True)

    def __init__(self, *args, **kwargs):
        self.html_message = w.HTML()
        super().__init__(
            fn_onclick=self.fn_onclick_load,
            fn_get_options=self.get_project_options,
            title="<b> | Select Project</b>",
            fn_format_value=lambda app=None: f"J{app.select.value}",
            fn_layout_form=SelectAndClickFormLayouts.align_horizontal_right,
            selector_widget=ComboboxMapped,
            *args,
            **kwargs,
        )
        self._init_controls()
        self.children = [self.html_message] + list(self.children)
        self.fn_onclick = self.fn_onclick_load
        self._init_controls_LoadProject()
        self.value = str(ENV.AECSCHEDULE_PROJECT_NUMBER)
        self.fn_onclick_load(self.value)
        self.warn_project()

    def _init_controls_LoadProject(self):
        self.observe(self.warn_project_on_change, "_value")

    def get_project_options(self):
        self.options_map = {}
        options = {}
        for job_description, job_number in JOB_DESCRIPTION_TO_NUMBER.items():
            if job_number == ENV.AECTEMPLATER_PROJECT_NUMBER:
                continue  # Ignore job 5003 as we should use aectemplater to edit this default job
            options[job_description] = str(job_number)
        return options

    def warn_project_on_change(self, on_change):
        self.observe(self.warn_project_on_change, "_value")
        self.warn_project()

    def warn_project(self):
        if self.value == str(ENV.AECSCHEDULE_PROJECT_NUMBER):
            self.html_message.value = (
                '<span style="color:red;"><b>WARNING</b>: You currently have the test project loaded</span>'
            )
            self.html_message.layout.padding = "2px"
        else:
            self.html_message.value = ""
            self.html_message.layout.padding = None

    def check_project_exists_in_db(self, project_number: int):
        # TODO: Check against MXF database
        if not check_project(project_number):
            project_id = post_project(project_number=project_number)["id"]
            post_project_revision(project_id=project_id, revision=ENV.DEFAULT_PROJECT_REVISION)
        return project_number

    def set_project(self, value):
        project_number = self.check_project_exists_in_db(project_number=int(value))
        project_revision_id = get_project_revision_by_project_number_and_revision(
            project_number=project_number, revision=ENV.DEFAULT_PROJECT_REVISION
        )["id"]
        self.project_revision_id = project_revision_id
        set_active_project_revision_id(self.project_revision_id)

    def fn_onclick_load(self, value):
        self.html_message.value = ""
        self.set_project(value)
        logger.info(f"Loaded Project: {value}")


if __name__ == "__main__":
    ui = LoadProject()
    display(ui)
