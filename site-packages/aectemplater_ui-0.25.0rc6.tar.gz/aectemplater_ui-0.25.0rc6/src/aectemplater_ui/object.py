# +
import typing as ty
import pandas as pd
import traitlets as tr
import ipywidgets as w
from pydantic import RootModel, Field
from palettable.scientific.sequential import Davos_14
from IPython.display import display

from ipyautoui.custom.autogrid import AutoGrid
from ipyautoui.custom.fileupload import FilesUploadToDir
from ipyautoui.custom.editgrid import EditGrid, DataHandler
from ipyautoui.custom.buttonbars import CrudButtonBar, CrudOptions, CrudView
from ipyautoui.custom.combobox_mapped import ComboboxMapped
from ipyautoui.constants import BUTTON_WIDTH_MIN

from aectemplater_schemas.object import Object
from aectemplater_schemas.property import PropertySchema
from aectemplater_client import (
    get_objects,
    post_object,
    delete_object_by_id,
    patch_object_by_id,
    duplicate_object_by_id,
    get_object_schema,
    get_object_by_id,
    get_object_unique_name,
    get_objects_unique_names,
)

from aectemplater_ui.constants import DES_OBJECTS
from aectemplater_ui.properties import link_renderer
from aectemplater_ui.formatting import (
    get_object_format,
    get_properties_format,
    create_vega_expression,
    Expr,
    TextRenderer,
)
from aectemplater_ui.abbreviation_and_symbol import AbbreviationsInput
from aectemplater_ui.schemas import ObjectDataFrame, ObjectGet
from aectemplater_ui import ENV
from aectemplater_ui.utils import hide_show_null


DI_OBJECT_FORMAT = get_object_format()
DI_PROPERTY_FORMAT = get_properties_format()
# -

ORDER_COLS = (
    "custodian",
    "code",
    "name",
    "version",
    "definition",
    "classification",
    "classification_system",
    "uri",
    "use_type",
    "category",
    "revit_category",
    "status",
    "author",
    "checked_by",
    # "document_reference",  # TODO: Add back in once widget fixed
    "date_time",
    "instance_tag_template_id",
    "type_tag_template_id",
    "id",
)

# +
BUTTONBAR_CONFIG_TYPES = CrudView(
    add=CrudOptions(
        tooltip="Add Template",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Template</i>",
    ),
    edit=CrudOptions(
        tooltip="Edit Selected Template",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Template</i>",
    ),
    edit_psets=CrudOptions(
        tooltip="Assign Property Sets to Template",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Assign Property Sets to Template</i>",
    ),
    add_abbreviations=CrudOptions(
        tooltip="Add Abbreviations to Template",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="➕ <i>Add Abbreviations</i>",
    ),
    copy=CrudOptions(
        tooltip="Copy Selected Templates",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Copy Template</i>",
    ),
    delete=CrudOptions(
        tooltip="Delete Selected Templates",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Templates</i>",
    ),
    view=CrudOptions(
        tooltip="View Template",
        button_style="primary",
        message="👁 <i>View Template</i>",
    ),
)


class CrudButtonBarObjects(CrudButtonBar):
    fn_add_abbreviations = tr.Callable(default_value=lambda: print("add_abbreviations"))
    fn_edit_psets = tr.Callable(default_value=lambda: print("edit_psets"))

    def __init__(
        self,
        **kwargs,
    ):
        self._init_form()
        self.edit_psets = w.Button(
            icon="cubes",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        self.add_abbreviations = w.ToggleButton(
            icon="tag",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        self.view = w.Button(
            icon="eye",
            style={"font_weight": "bold"},
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        self.add_abbreviations.observe(self._add_abbreviations, "value")
        self.edit_psets.observe(self._edit_psets, "value")
        super().__init__(**kwargs | {"crud_view": BUTTONBAR_CONFIG_TYPES})
        self.fn_support = self._fn_support
        self.out = w.Output()
        self.hbx_bbar = w.HBox(
            [
                self.add,
                self.edit,
                self.edit_psets,
                self.add_abbreviations,
                self.view,
                self.copy,
                self.delete,
                self.reload,
                self.support,
                self.message,
            ]
        )
        self.children = [self.hbx_bbar, self.out]
        self._init_controls()

    def _edit_psets(self, onchange):
        self._onclick("edit_psets")

    def _add_abbreviations(self, onchange):
        self._onclick("add_abbreviations")


if __name__ == "__main__":
    buttonbar = CrudButtonBarObjects()
    display(buttonbar)


class ObjectsGrid(EditGrid):
    """Objects Ui which inherits from EditGrid and applies a wrapper for the value setter and custom formatting."""

    @property
    def selected_unique_name(self):
        if self.grid.selected:
            return get_object_unique_name(self.grid.selected["id"])

    def __init__(
        self,
        fn_edit_psets: ty.Callable = lambda: print("EDIT PSETS"),
        fn_add_abbreviations: ty.Callable = lambda: print("ADD ABBREVIATIONS"),
        *args,
        **kwargs,
    ):
        schema = ObjectDataFrame
        self.post_object = post_object
        datahandler = DataHandler(
            fn_get_all_data=self.get_objects,
            fn_post=self.post_object,
            fn_patch=self.patch_object,
            fn_delete=self.delete_object,
            fn_copy=self.copy_object,
        )
        self.ui_add_abbreviations = AbbreviationsInput()
        super().__init__(
            schema=schema,
            datahandler=datahandler,
            renderers=DI_OBJECT_FORMAT["renderers"],
            header_renderer=DI_OBJECT_FORMAT["header_renderer"],
            grid_style=DI_OBJECT_FORMAT["grid_style"],
            warn_on_delete=True,
            order=ORDER_COLS,
            base_column_header_size=35,
            *args,
            **kwargs,
            **DES_OBJECTS,
        )
        self.fn_edit_psets = fn_edit_psets
        self.fn_add_abbreviations = fn_add_abbreviations
        self.ui_add.nested_widgets = self.ui_add.nested_widgets + [FilesUploadToDir]
        self.ui_edit.nested_widgets = self.ui_add.nested_widgets + [FilesUploadToDir]
        self.value = self.get_objects()
        hide_show_null(self.ui_edit, self.ui_add)

    def _init_form(self):
        self.stk_crud = w.Stack(
            children=[
                self.ui_add,
                self.ui_edit,
                w.VBox(layout=w.Layout(display=None)),  # VBox exists as stack order must align with button order
                self.ui_add_abbreviations,
                self.ui_copy,
                self.ui_delete,
                w.VBox(layout=w.Layout(display=None)),
            ]
        )
        self.buttonbar_grid = CrudButtonBarObjects(
            fn_add=self._add,
            fn_edit=self._edit_and_disable_fields,
            fn_copy=self._copy,
            fn_delete=self._delete,
            fn_reload=self._reload_datahandler,
        )

    def _set_children(self):
        self.vbx_widget.children = [
            self.buttonbar_grid,
            self.stk_crud,
            self.grid,
        ]
        self.stk_crud.children = [
            self.ui_add,
            self.ui_edit,
            w.VBox(layout=w.Layout(display=None)),
            self.ui_add_abbreviations,
            self.ui_copy,
            self.ui_delete,
            w.VBox(layout=w.Layout(display=None)),
        ]
        self.children = [self.hbx_title_description, self.vbx_widget]
        self.grid.observe(self._disable_fields, "selections")
        self.grid.observe(self._update_abbreviations, "selections")

    def get_objects(self):
        return [ObjectGet(**object_).model_dump() for object_ in get_objects(limit=-1)]

    def patch_object(self, value: dict):
        return patch_object_by_id(value["id"], value)

    def delete_object(self, value: dict):
        return delete_object_by_id(value["id"])

    def copy_object(self, value: dict):
        return duplicate_object_by_id(value["id"])

    def _edit_and_disable_fields(self):
        self._edit()
        self._disable_fields("change")

    def _disable_fields(self, on_change):
        if self.buttonbar_grid.edit.value:
            if self.grid.selected_row is not None:
                if self.grid.selected_row["custodian"] == ENV.AECTEMPLATER_ORG:
                    self.ui_edit.show_savebuttonbar = True
                    self.ui_edit.disabled = False
                    self.buttonbar_grid.message.value = BUTTONBAR_CONFIG_TYPES["edit"]["message"]
                else:
                    self.ui_edit.show_savebuttonbar = False
                    self.ui_edit.disabled = True
                    self.buttonbar_grid.message.value = (
                        f"🚫 <i>Editing is disabled for non-{ENV.AECTEMPLATER_ORG} templates</i>"
                    )

    def _update_abbreviations(self, on_change):
        if self.grid.selected is not None:
            self.ui_add_abbreviations.object_id = self.grid.selected["id"]


# -

if __name__ == "__main__":
    gr = ObjectsGrid()
    display(gr)


# +
class PropertySchemaGet(PropertySchema):
    allowed_values: list = Field([], title="Enumeration")
    definition: str = Field("", title="Description")
    id: int


class ObjectPropertiesDataFrame(RootModel):
    root: ty.List[PropertySchemaGet] = Field(format="dataframe")


class ObjectHeaderDataFrame(RootModel):
    root: ty.List[Object] = Field(format="dataframe")


# +
# Construct the column names and widths from existing schema
# There is a bit of manipulation to map "allowed_values" -> "enum" and "definition" -> "description"
# This is to follow JSON schema convention
column_order = [
    'pset',
    'section',
    'category',
    'name',
    'title',
    'allowed_values',
    'unit',
    'definition',
    'notes',
    'parameter_type',
    'type',
    'revit_data_type',
    'ifc_data_type',
    'namespace_uri',
    'guid',
    'guid_source',
    'id',
]

column_names = {
    ("enum" if k == "allowed_values" else "description" if k == "definition" else k): (
        "Enumeration"
        if k == "allowed_values"
        else "Description" if k == "definition" else PropertySchema.model_fields[k].title
    )
    for k in column_order
    if k in PropertySchema.model_fields
}
column_names["id"] = "Id"

column_widths = {
    "Enumeration" if k == "allowed_values" else "Description" if k == "definition" else v.title: v.json_schema_extra[
        "column_width"
    ]
    for k, v in PropertySchema.model_fields.items()
    if v.json_schema_extra is not None and "column_width" in v.json_schema_extra
}


class ObjectHeaderGrid(AutoGrid):
    object_id = tr.Integer()

    @tr.observe("object_id")
    def _set_object(self, on_change):
        self._load()

    def __init__(self, **kwargs):
        super().__init__(
            schema=ObjectHeaderDataFrame,
            layout={"height": "350px"},
            hide_nan=True,
            transposed=True,
            **DI_OBJECT_FORMAT,
            **kwargs,
        )
        self.column_widths = {"key": 400, "": 400}
        self._load()

    def get_data(self) -> pd.DataFrame:
        """Get the Object header dataframe."""
        index = {v.title: k for k, v in Object.model_fields.items()}
        if self.object_id == 0:
            df = pd.DataFrame([""] * len(index), index=index)
        else:
            object_header = Object(**get_object_by_id(self.object_id))
            df = pd.DataFrame(object_header, index=index)
            df = df.drop(0, axis=1)
        df.columns = [""]
        return df

    def _load(self):
        self.data = self.get_data()


if __name__ == "__main__":
    header = ObjectHeaderGrid()
    display(header)

if __name__ == "__main__":
    header.object_id = 3


# +
class ObjectPropertiesGrid(AutoGrid):
    object_id = tr.Integer()

    @tr.observe("object_id")
    def _set_object(self, on_change):
        self._load()
        self._set_pset_formatting()

    def __init__(self, **kwargs):
        super().__init__(
            schema=ObjectPropertiesDataFrame,
            header_renderer=DI_PROPERTY_FORMAT["header_renderer"],
            grid_style=DI_PROPERTY_FORMAT["grid_style"],
            hide_nan=True,
            **kwargs,
        )
        self.column_widths = column_widths
        self.renderers = {column_names.get(k): v for k, v in DI_PROPERTY_FORMAT["renderers"].items()} | {
            "Name": link_renderer
        }
        self._load()

    def get_data(self) -> pd.DataFrame:
        """Get the Object properties dataframe."""
        if self.object_id == 0:
            df = pd.DataFrame([""] * len(column_names), index=column_names)
        else:
            object_schema = get_object_schema(self.object_id, override_units=True)
            df = pd.DataFrame(object_schema["properties"])
        df = df.rename(index=column_names)
        df = df.reindex(column_names.values())
        df = df.T  # Transpose so each property is a row
        df = df.reset_index(drop=True)  # Remove property names from index
        return df

    def _load(self):
        self.data = self.get_data()

    def _set_pset_formatting(self):
        unique_psets = set(self.data.loc[:, "Property Set"])
        colours_unique_psets = {k: v for k, v in zip(unique_psets, Davos_14.hex_colors[5:][::-1])}
        vega_expr = create_vega_expression(colours_unique_psets)
        expr = Expr(vega_expr)
        self.renderers = self.renderers | {"Property Set": TextRenderer(background_color=expr)}


if __name__ == "__main__":
    properties = ObjectPropertiesGrid()
    display(properties)

if __name__ == "__main__":
    properties.object_id = 3


# +
class ObjectView(w.VBox):
    object_id = tr.Integer()

    @tr.observe("object_id")
    def _set_object(self, on_change):
        self.object_header.object_id = self.object_id
        self.object_properties.object_id = self.object_id

    def __init__(self, **kwargs):
        self.object_header = ObjectHeaderGrid()
        self.object_properties = ObjectPropertiesGrid()
        super().__init__([self.object_header, self.object_properties], **kwargs)


if __name__ == "__main__":
    object_view = ObjectView()
    display(object_view)

if __name__ == "__main__":
    object_view.object_id = 3


# -


class ObjectBrowser(w.VBox):
    def __init__(self, **kwargs):
        self.object_select = ComboboxMapped()
        self.object_view = ObjectView()
        super().__init__([self.object_select, self.object_view], **kwargs)
        self.object_select.options = self.get_object_unique_names()
        self.object_select.observe(self._set_object_id)

    def _set_object_id(self, onchange):
        self.object_view.object_id = int(self.object_select.value)

    def get_object_unique_names(self):
        return {name: id_ for id_, name in get_objects_unique_names(limit=-1).items()}


if __name__ == "__main__":
    object_browser = ObjectBrowser()
    display(object_browser)
