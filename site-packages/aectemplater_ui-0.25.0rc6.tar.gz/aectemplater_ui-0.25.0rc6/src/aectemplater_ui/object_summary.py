# +
import logging
import typing as ty

import ipywidgets as w
import pandas as pd
import traitlets as tr
from aectemplater_client import (
    get_object_schema,
    get_objects_by_custodian,
)
from ipyautoui.custom.autogrid import AutoGrid
from ipydatagrid import Expr, TextRenderer
from IPython.display import clear_output, display
from pydantic import Field, RootModel, model_validator
from pyuniclass import UniclassTables

from aectemplater_ui.abbreviation_and_symbol import AbbreviationsInput
from aectemplater_ui.formatting import GRID_STYLE, get_section_map_colours
from aectemplater_ui.object import ObjectBrowser
from aectemplater_ui.schemas import ObjectGet

ut = UniclassTables()
logger = logging.getLogger(__name__)

# +
map_color = get_section_map_colours()
map_color["Undefined"] = "black"


def get_object_summary_dataframe(object_id: int) -> pd.DataFrame:
    """Returns styled pandas dataframe of the Object's properties."""
    object_schema = get_object_schema(object_id, override_units=True)
    summary = [
        [
            p["section"],
            p["title"],
            p["unit"],
        ]
        for p in object_schema["properties"].values()
    ]
    format_line = lambda l: [
        '<font color="{}">{} </font>'.format(map_color[l[0]], l[1]),
        "<i>{}</i>".format(l[2]),
    ]  # TODO: apply colour styling to row not text: https://pandas.pydata.org/docs/user_guide/style.html#Styler-Functions
    table = [format_line(l) for l in summary]
    headers = ["name", "unit"]
    df = pd.DataFrame(table, columns=headers)
    df.rename(columns={'name': 'Name', 'unit': 'Unit'}, inplace=True)
    return df.set_index(["Name", "Unit"]).style


# +
def format_null_abbreviations(cell) -> str:
    return "chartreuse" if cell.metadata.data["Abbreviations"] else "tomato"


abbreviations_formatting = TextRenderer(
    text_color="black",
    background_color=Expr(format_null_abbreviations),
)

column_widths = {
    "classification": 400,
    "name": 400,
    "abbreviations": 200,
    "definition": 600,
    "id": 20,
}


class ObjectGetSummary(ObjectGet):
    abbreviations: ty.List[str] = []

    @model_validator(mode="before")
    @classmethod
    def flatten_abbreviations(cls, data) -> "ObjectGetSummary":
        data["abbreviations"] = [abbr["abbreviation"] for abbr in data["abbreviations"]]
        return data


class ObjectSummaryDataFrame(RootModel):
    root: ty.List[ObjectGetSummary] = Field(format="dataframe")


class ObjectSummaryGrid(w.VBox):
    editable_abbreviations = tr.Bool(default_value=False)

    @tr.observe("editable_abbreviations")
    def obs_editable_abbreviations(self, on_change):
        if self.editable_abbreviations:
            self.ab.layout.display = ""
        else:
            self.ab.layout.display = "None"

    @property
    def object_id(self):
        if self.gr.selected_row:
            return self.gr.selected_row["id"]

    def __init__(self, **kwargs):
        self.gr = AutoGrid(
            schema=ObjectSummaryDataFrame,
            column_widths=column_widths,
            renderers={"abbreviations": abbreviations_formatting},
            layout=dict(height="800px"),
            grid_style=GRID_STYLE,
            order=[
                "classification",
                "name",
                "abbreviations",
                "definition",
                "version",
                "id",
            ],
        )
        self.ab = AbbreviationsInput()
        self.ab.layout.display = "None"
        self.ab_summary = w.HTML()
        self.hbx_header = w.HBox(
            [
                w.HTML(
                    "<b>Max Fordham Product Data Templates</b>",
                    layout=w.Layout(width="300px"),
                ),
                self.ab_summary,
            ]
        )
        self.vbx_gr = w.VBox(
            [
                self.hbx_header,
                self.gr,
            ],
            layout=dict(height="800px", width="80%"),
        )

        self.hbx_main = w.HBox()
        self.out_pset = w.Output()
        self.vbx_pset = w.VBox(
            layout=dict(height="800px", width="20%"),
        )
        self.vbx_pset.children = [w.HTML("<b>Properties of Template</b>"), self.out_pset]
        self.hbx_main.children = [self.vbx_gr, self.vbx_pset]
        super().__init__(**kwargs)
        self.children = [self.ab, self.hbx_main]
        self._init_controls()
        self._set_data()
        self.ab.bbar.fns_onsave.append(self._set_data)

    def _init_controls(self):
        self.gr.observe(self._set_abbreviations, "selections")
        self.gr.observe(self._set_summary, "selections")

    def _set_abbreviations(self, on_change):
        if self.object_id is not None:
            self.ab.object_id = self.object_id

    def _set_summary(self, on_change):
        self.ab_summary.value = self.ab.html_allowed_summary
        if self.object_id is not None:
            with self.out_pset:
                clear_output()
                display(get_object_summary_dataframe(self.object_id))

    def _set_data(self):
        objects = [ObjectGetSummary(**object_).model_dump() for object_ in get_objects_by_custodian("MXF")]
        for object_ in objects:
            try:
                object_["classification"] = ut.get_description(object_["classification"])
            except ValueError as err:
                pass
        df = pd.DataFrame(objects)
        df = df.sort_values("classification").reset_index(drop=True)
        df = df.map(
            lambda x: "" if isinstance(x, list) and not x else x
        )  # HOTFIX: Set empty list to empty string for format_null_abbreviations to work
        self.gr.data = self.gr._init_data(df)


# -

if __name__ == "__main__":
    summ = ObjectSummaryGrid()
    display(summ)


class ObjectSummary(w.Tab):
    @property
    def map_object_id_to_unique_name(self):
        return {int(v): k for k, v in self.browser.object_select.options}

    def __init__(self, editable_abbreviations: bool = False, **kwargs):
        self.summary = ObjectSummaryGrid(editable_abbreviations=editable_abbreviations)
        self.browser = ObjectBrowser()
        super().__init__([self.summary, self.browser], titles=["Template Summary", "Template View"])
        self.summary.gr.observe(self._load_object, "selections")

    def _load_object(self, onchange=None):
        if self.summary.gr.selected:
            self.browser.object_select.value = self.map_object_id_to_unique_name[self.summary.object_id]


if __name__ == "__main__":
    summary = ObjectSummary()
    display(summary)
