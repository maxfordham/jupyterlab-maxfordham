# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %run __init__.py
# # %load_ext lab_black

# +
import logging
import ipywidgets as w
import traitlets as t
from unyt import Unit
from IPython.display import display

from ipyautoui.custom.urlimagelink import UrlImageLink
from aectemplater_schemas.data.utils import UnitsBaseData
from aectemplater_schemas.enumerations import RevitDataTypeEnum
from aectemplater_client import (
    get_units_by_physical_quantity,
    get_units,
)
from aectemplater_ui.schemas import UnitsGet
from aectemplater_ui.utils import get_all_physical_quantities


UDATA = UnitsBaseData()
make_unit_str = lambda symbol, name: symbol if not name else f"{symbol} - {name}"
logger = logging.getLogger(__name__)


# -


def get_default_unit_id(revit_data_type: str, physical_quantity: str) -> int:
    """Pass a Revit Data Type and get the default unit ID."""
    if revit_data_type not in [i.value for i in RevitDataTypeEnum]:
        raise Exception("Value passed as revit_data_type does not exist in the enumeration.")
    unit_code = UDATA.map_revit_type_to_default_unit.get(revit_data_type)
    unyt_code = Unit(unit_code)
    li_unit = [
        u
        for u in get_units(limit=-1)
        if u["physical_quantity"] == physical_quantity and str(Unit(u["code"])) == str(unyt_code)
    ]
    if len(li_unit) > 1:
        pass
        logger.warning("Two or more default units defined with the same code and physical quantity.")
    elif len(li_unit) == 0:
        raise Exception("No default unit found.")
    di_unit = li_unit[0]
    unit = UnitsGet(**di_unit)
    return unit.id


# +
def physical_quantity_to_ifc_widget_kwargs() -> dict:
    di = {}
    for l in UDATA.li_alltypes:
        options = [m["IfcMeasure"] for m in UDATA.data if m["Measure"] == l]
        if len(options) == 1:
            value = options[0]
            disabled = True
        elif len(options) > 1:
            value = None
            disabled = False
        elif len(options) == 0:
            value = None
            disabled = False
            options = UDATA.li_ifc_physical_quantities
        else:
            raise ValueError("ValueError")

        di[l] = {"options": options, "value": value, "disabled": disabled}
    return di


def physical_quantity_to_revit_widget_kwargs() -> dict:
    di = {}
    for l in set(UDATA.li_alltypes):
        options = [m["RevitDataType"] for m in UDATA.data_revit if m["Measure"] == l]
        if len(options) == 1:
            value = options[0]
            disabled = True
        elif len(options) == 0 and l in UDATA.map_simple_measure_to_revit.keys():
            options = [UDATA.map_simple_measure_to_revit[l]]
            value = UDATA.map_simple_measure_to_revit[l]
            disabled = True
        elif len(options) > 1:
            value = None
            disabled = False
        else:
            options = ["NUMBER"]
            value = "NUMBER"
            disabled = False

        if value == "ELECTRICAL_DEMAND_FACTOR":
            options = options + ["NUMBER"]
            disabled = False
        di[l] = {"options": options, "value": value, "disabled": disabled}
    return di


MAP_PHYSICAL_QUANTITY_TO_IFC_WIDGET_KWARGS = physical_quantity_to_ifc_widget_kwargs()
MAP_PHYSICAL_QUANTITY_TO_REVIT_WIDGET_KWARGS = physical_quantity_to_revit_widget_kwargs()

del MAP_PHYSICAL_QUANTITY_TO_REVIT_WIDGET_KWARGS[""]


# +
class Wizard(w.VBox):
    value = t.Dict(allow_none=True)

    @property
    def is_physical_quantity(self):
        return self.map_is_physical_quantity[self.dtype_options.value]

    @property
    def physical_quantity(self):
        if self.is_physical_quantity:
            return self.dtype.value
        else:
            return ""

    def __init__(self, dtype="", options={}, fn_on_update=None):
        if fn_on_update is None:
            fn_on_update = lambda value: print(value)

        self.fn_on_update = fn_on_update
        self.map_dtype_options = {
            "all physical quantities": get_all_physical_quantities(),
            "ifc physical quantities only": UDATA.li_ifc_physical_quantities,
            "not a physical quantity": UDATA.li_basetypes,
        }
        self.map_is_physical_quantity = {
            "all physical quantities": True,
            "ifc physical quantities only": True,
            "not a physical quantity": False,
        }
        super().__init__()
        self._init_form(options=options)
        self._init_controls()
        self.dtype.value = dtype

    def _init_form(self, options=None):
        # select data type options
        self.dtype_options = w.ToggleButtons(
            options=[
                "all physical quantities",
                "ifc physical quantities only",
                "not a physical quantity",
            ],
            disabled=False,
            button_style="",  # 'success', 'info', 'warning', 'danger' or ''
            tooltips=[
                "Description of slow",
                "Description of regular",
                "Description of fast",
            ],
            style={"button_width": "280px"},
            layout=w.Layout(width="300px"),
        )
        self.html_dtype_options = w.HTML(
            "<b>Data Quantity Type</b>, <i>select if the parameter is a measurable physical quantity or not."
        )
        self.hbx_dtype_options = w.HBox([self.dtype_options, self.html_dtype_options])

        # Try get dtype options from database
        try:
            options = sorted(list(set(di["physical_quantity"] for di in get_units(limit=-1))))
        except:
            options = UDATA.li_alltypes
        # select data type
        self.dtype = w.Combobox(options=options, ensure_option=True)
        self.html_dtype = w.HTML(
            "<b>Data Type</b>, <i>base data type or if applicable physical quantity."
            " select then match Revit and IFC types"
        )
        self.hbx_dtype = w.HBox([self.dtype, self.html_dtype])

        # physical quantity
        self.show_physical_quantity = w.Text(placeholder="not a physical quantity", disabled=True)

        # select ifc type
        self.ifctyp = w.Dropdown()
        self.ifc_doc_link = UrlImageLink(
            url="https://standards.buildingsmart.org/IFC/RELEASE/IFC4_3/HTML/ifcmeasureresource/content.html",
            path_image="images/ifc-icon.png",
            description="IFC Measure",
            width=25,
            font_size=15,
            whitespace=10,
        )
        self.hbx_ifctyp = w.HBox([self.ifctyp, self.ifc_doc_link])

        # select revit type
        self.rvttyp = w.Dropdown(value=None)
        self.hbx_rvttyp = w.HBox([self.rvttyp, w.HTML("<b>Revit Types</b>")])

        # select default units
        self.default_units = w.RadioButtons(options={}, disabled=True)
        self.default_units.layout = w.Layout(width="auto", min_width="300px")
        self.hbx_default_units = w.HBox(
            [self.default_units, w.HTML("<b>Select Default Units</b>")],
            layout={"border": "solid yellow 3px"},
        )

        self.update = w.Button(
            description="update",
            button_style="success",
            icon="upload",
            layout={"width": "300px"},
        )
        self.message = w.HTML("")
        self.vbx_wizard = w.VBox(layout={"border": "solid green 5px"})
        self.vbx_wizard.children = [
            self.hbx_dtype_options,
            self.hbx_dtype,
            self.show_physical_quantity,
            self.hbx_ifctyp,
            self.hbx_rvttyp,
            self.hbx_default_units,
        ]
        self.children = [
            w.HBox([self.update, self.message], layout={"border": "solid white 5px"}),
            self.vbx_wizard,
        ]

    def _init_controls(self):
        self.rvttyp.observe(self._update_default_units, names=["value"])
        self.dtype_options.observe(self._dtype_options, names=["value"])
        self.dtype.observe(self._update_ifctyp, names=["value"])
        self.dtype.observe(self._update_rvttyp, names=["value"])
        self.dtype.observe(self._update_show_physical_quantity, names=["value"])
        self.update.on_click(self._update)

    def _update_value(self):
        default_units_value = {k: v for k, v in self.default_units.options.items() if v == self.default_units.value}
        self.value = {
            "physical_quantity": self.physical_quantity,
            "ifc_data_type": self.ifctyp.value,
            "revit_data_type": self.rvttyp.value,
            "default_units": default_units_value,
        }

    def _update(self, onclick):
        if self.rvttyp.value is None:
            msg = "👇 Please select a Revit Data Type."
            self.message.value = msg
            raise Exception("Please select a Revit Data Type.")
        else:
            self.message.value = ""

        self._update_value()
        self.fn_on_update(value=self.value)

    def set_dtype_options(self, options):
        if self.dtype.value not in options:
            self.dtype.value = ""
        self.dtype.options = options

    def _dtype_options(self, onchange):
        options = self.map_dtype_options[self.dtype_options.value]
        self.set_dtype_options(options)

    def _update_show_physical_quantity(self, onchange):
        self.show_physical_quantity.value = self.physical_quantity

    def _update_default_units(self, onchange):
        self.default_units.disabled = True
        self.default_units.value = None
        self.default_units.options = {}

        if self.is_physical_quantity and self.dtype.value != "":
            li = get_units_by_physical_quantity(self.dtype.value)
            li_ = [make_unit_str(di["symbol"], di["name"]) for di in li]
            self.map_units = {l_: l["id"] for l_, l in zip(li_, li)}
            self.default_units.options = self.map_units
            if self.rvttyp.value == "NUMBER":
                self.default_units.disabled = False
                if len(self.map_units) == 1:
                    self.default_units.value = list(self.default_units.options.values())[0]
            elif self.rvttyp.value != "NUMBER":
                if len(self.map_units) == 1:
                    self.default_units.value = list(self.default_units.options.values())[0]
                elif len(self.map_units) > 1:
                    if self.rvttyp.value not in [i.value for i in RevitDataTypeEnum]:
                        self.default_units.value = None
                    else:
                        self.default_units.value = get_default_unit_id(
                            revit_data_type=self.rvttyp.value,
                            physical_quantity=self.dtype.value,
                        )

    def _update_ifctyp(self, onchange):
        try:
            match = MAP_PHYSICAL_QUANTITY_TO_IFC_WIDGET_KWARGS[self.dtype.value]
        except:
            match = None
        if match is not None:
            for k, v in match.items():
                setattr(self.ifctyp, k, v)
        else:
            self.ifctyp.options = UDATA.li_ifc_types
            self.ifctyp.disabled = False
            if self.is_physical_quantity:
                self.ifctyp.value = "IfcReal"
            else:
                self.ifctyp.value = "IfcText"
        if self.ifctyp.value is not None:
            self.ifc_doc_link.url = UDATA.map_ifc_measure_to_docs[self.ifctyp.value]
        else:
            self.ifc_doc_link.url = ""

    def _update_rvttyp(self, onchange):
        self.rvttyp.value = None
        try:
            match = MAP_PHYSICAL_QUANTITY_TO_REVIT_WIDGET_KWARGS[self.dtype.value]
        except:
            match = None
        if match is not None:
            for k, v in match.items():
                setattr(self.rvttyp, k, v)
        else:
            if self.ifctyp.value in UDATA.map_ifcsimple_to_revit.keys():
                self.rvttyp.options = UDATA.li_all_revit_specs
                self.rvttyp.disabled = True
                self.rvttyp.value = UDATA.map_ifcsimple_to_revit[self.ifctyp.value]
            else:
                self.rvttyp.options = UDATA.li_all_revit_specs
                self.rvttyp.disabled = False
                if self.is_physical_quantity:
                    self.rvttyp.value = "NUMBER"
                else:
                    self.rvttyp.value = "TEXT"


if __name__ == "__main__":
    ui = Wizard()
    display(ui)
# -
