# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.6
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %%
import typing as ty
import ipywidgets as w
from IPython.display import display

from ipyautoui.constants import BUTTON_WIDTH_MIN
from ipyautoui.custom.fileupload import FilesUploadToDir
from ipyautoui.custom.editgrid import EditGrid, DataHandler
from ipyautoui.custom.buttonbars import CrudButtonBar, CrudOptions, CrudView
from aectemplater_client import (
    get_psets,
    delete_pset,
    duplicate_pset,
    patch_pset,
    post_pset,
    get_pset_unique_name,
)

from aectemplater_ui.constants import DES_PROPERTYSETS
from aectemplater_ui.formatting import get_propertysets_format
from aectemplater_ui.schemas import PropertySetDataFrame
from aectemplater_ui import ENV
from aectemplater_ui.utils import hide_show_null

DI_PROPERTYSETS_FORMAT = get_propertysets_format()

ORDER_COLS = (
    "custodian",
    "code",
    "name",
    "version",
    "uri",
    "definition",
    "category",
    "status",
    "date_time",
    "id",
)

# %%
BUTTONBAR_CONFIG_TYPES = CrudView(
    add=CrudOptions(
        tooltip="Add Property Set",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Property Set</i>",
    ),
    edit=CrudOptions(
        tooltip="Edit Selected Property Set",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Property Set</i>",
    ),
    edit_properties=CrudOptions(
        tooltip="Add Properties to Property Set",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Add Properties to Property Set</i>",
    ),
    copy=CrudOptions(
        tooltip="Copy Selected Property Sets",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Copy Property Set</i>",
    ),
    delete=CrudOptions(
        tooltip="Delete Selected Property Sets",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Property Sets</i>",
    ),
)


class CrudButtonBarPropertySets(CrudButtonBar):
    def __init__(self, **kwargs):
        self._init_form()
        self.edit_properties = w.Button(
            icon="cubes",
            style={"font_weight": "bold"},
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        super().__init__(**kwargs | {"crud_view": BUTTONBAR_CONFIG_TYPES})
        self.out = w.Output()
        self.hbx_bbar = w.HBox(
            [
                self.add,
                self.edit,
                self.edit_properties,
                self.copy,
                self.delete,
                self.reload,
                self.support,
                self.message,
            ]
        )
        self.children = [self.hbx_bbar, self.out]
        self._init_controls()


if __name__ == "__main__":
    buttonbar = CrudButtonBarPropertySets()
    display(buttonbar)


# %%
class PropertySetsGrid(EditGrid):
    """Property Sets Ui which inherits from EditGrid and applies a wrapper for the value setter and custom formatting."""

    @property
    def selected_unique_name(self):
        if self.grid.selected:
            return get_pset_unique_name(self.grid.selected["id"])

    def __init__(
        self,
        fn_edit_properties: ty.Callable = lambda: print("EDIT PROPERTIES"),
        *args,
        **kwargs,
    ):
        schema = PropertySetDataFrame
        self.post_pset = post_pset
        propertyset_datahandler = DataHandler(
            fn_get_all_data=self.get_psets,
            fn_post=self.post_pset,
            fn_patch=self.patch_pset,
            fn_delete=self.delete_pset,
            fn_copy=self.copy_pset,
        )
        super().__init__(
            schema=schema,
            datahandler=propertyset_datahandler,
            renderers=DI_PROPERTYSETS_FORMAT["renderers"],
            header_renderer=DI_PROPERTYSETS_FORMAT["header_renderer"],
            grid_style=DI_PROPERTYSETS_FORMAT["grid_style"],
            warn_on_delete=True,
            order=ORDER_COLS,
            base_column_header_size=35,
            *args,
            **kwargs,
            **DES_PROPERTYSETS,
        )
        self.fn_edit_properties = fn_edit_properties
        self.ui_add.nested_widgets = self.ui_add.nested_widgets + [FilesUploadToDir]
        self.ui_edit.nested_widgets = self.ui_add.nested_widgets + [FilesUploadToDir]
        self.value = self.get_psets()
        hide_show_null(self.ui_edit, self.ui_add)

    def _init_form(self):
        self.stk_crud = w.Stack(
            children=[
                self.ui_add,
                self.ui_edit,
                w.VBox(),  # VBox exists as stack order must align with button order
                self.ui_copy,
                self.ui_delete,
                w.VBox(),
            ]
        )
        self.buttonbar_grid = CrudButtonBarPropertySets(
            fn_add=self._add,
            fn_edit=self._edit_and_disable_fields,
            fn_copy=self._copy,
            fn_delete=self._delete,
            fn_reload=self._reload_datahandler,
        )

    def _set_children(self):
        self.vbx_widget.children = [
            self.buttonbar_grid,
            self.stk_crud,
            self.grid,
        ]
        self.stk_crud.children = [
            self.ui_add,
            self.ui_edit,
            w.VBox(),  # VBox exists as stack order must align with button order
            self.ui_copy,
            self.ui_delete,
            w.VBox(),
        ]
        self.children = [self.hbx_title_description, self.vbx_widget]
        self.grid.observe(self._disable_fields, "selections")

    def get_psets(self):
        return get_psets(limit=-1)

    def patch_pset(self, value: dict):
        return patch_pset(value["id"], value)

    def delete_pset(self, value: dict):
        return delete_pset(value["id"])

    def copy_pset(self, value: dict):
        return duplicate_pset(value["id"])

    def _edit_and_disable_fields(self):
        self._edit()
        self._disable_fields("change")

    def _disable_fields(self, on_change):
        if self.buttonbar_grid.edit.value:
            if self.grid.selected_row is not None:
                if self.grid.selected_row["custodian"] == ENV.AECTEMPLATER_ORG:
                    self.ui_edit.show_savebuttonbar = True
                    self.ui_edit.disabled = False
                    self.buttonbar_grid.message.value = BUTTONBAR_CONFIG_TYPES["edit"]["message"]
                else:
                    self.ui_edit.show_savebuttonbar = False
                    self.ui_edit.disabled = True
                    self.buttonbar_grid.message.value = (
                        f"🚫 <i>Editing is disabled for non-{ENV.AECTEMPLATER_ORG} Property Sets</i>"
                    )


# %%
if __name__ == "__main__":
    gr = PropertySetsGrid()
    display(gr)
