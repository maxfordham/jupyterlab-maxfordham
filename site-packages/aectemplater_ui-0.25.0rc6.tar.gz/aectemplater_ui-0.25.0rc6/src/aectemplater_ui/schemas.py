import typing as ty
from pydantic import ConfigDict, Field, RootModel, BaseModel, model_validator

from pyuniclass import UT
from pyrulefilter.schemas import Rule, RuleSet
from aectemplater_schemas.filters import Filter
from aectemplater_schemas.units import Units
from aectemplater_schemas.property import Property
from aectemplater_schemas.propertyset import PropertySet
from aectemplater_schemas.object import Object
from aectemplater_schemas.pset_property import PsetProperty
from aectemplater_schemas.utils_unyt import symbol_options, prefix_options


class ExprItem(BaseModel):
    symbol: str = Field(enum=symbol_options)
    exponent: float = Field(1)
    prefix: str = Field(None, enum=prefix_options)


class Derivation(RootModel):
    root: ty.List[ExprItem] = []


class UnitsGet(Units):
    """Please populate the fields below"""

    id: int = Field(
        json_schema_extra=dict(disabled=True),
    )
    __doc__ += Units.__doc__
    model_config = ConfigDict(title="Unit", from_attributes=True)


class UnitsDataFrame(RootModel):
    root: ty.List[UnitsGet] = Field(format="dataframe")


class PropertyGet(Property):
    """Please populate the fields below"""

    id: int = Field(
        json_schema_extra=dict(disabled=True),
    )
    model_config = ConfigDict(title="Property", from_attributes=True)


class PropertyGetFlattenUnit(PropertyGet):
    unit: str = ""
    namespace_uri: ty.Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def flatten_units(cls, data):
        """Flatten unit to use symbol."""
        if "unit" in data.keys() and data["unit"]:
            return data | {"unit": data["unit"]["symbol"]}
        return data


class PropertyDataFrame(RootModel):
    root: ty.List[PropertyGet] = Field(format="dataframe")


class IfcString(RootModel):
    root: str = Field(json_schema_extra=dict(autoui="aectemplater_ui.ifc_classes.SelectIfcClass"))


class PropertySetGet(PropertySet):
    """Please populate the fields below"""

    id: int = Field(
        json_schema_extra=dict(disabled=True),
    )
    model_config = ConfigDict(title="Property Set", from_attributes=True)


class PropertySetDataFrame(RootModel):
    root: ty.List[PropertySetGet] = Field(format="dataframe")


class ObjectGet(Object):
    id: int = Field(
        json_schema_extra=dict(column_width=0.5, disabled=True),
    )
    instance_tag_template_id: int = Field(
        1,
        json_schema_extra=dict(column_width=0.5, disabled=True),
    )
    type_tag_template_id: int = Field(
        1,
        json_schema_extra=dict(column_width=0.5, disabled=True),
    )
    model_config = ConfigDict(title="Data Template", from_attributes=True)


class ObjectDataFrame(RootModel):
    root: ty.List[ObjectGet] = Field(format="dataframe")


class PsetPropertyPost(PsetProperty):
    property_id: int = Field(title="Property ID", description="ID from the properties table.")
    pset_id: int = Field(title="Pset ID", description="ID from the Pset table.")


class RuleGet(Rule):
    property_id: int


class RulePost(Rule):
    property_id: int


class RulePatch(Rule):
    property_id: int


RuleSetGet = ty.ForwardRef("RuleSetGet")


class RuleSetGet(RuleSet):
    rule: ty.List[ty.Union[RuleGet, RuleSetGet]] = Field(
        description="""
rules return a boolean for the logical evaluation defined below for every item within the categories defined
"""
    )


RuleSetPost = ty.ForwardRef("RuleSetPost")


class RuleSetPost(RuleSet):
    rule: ty.List[ty.Union[RulePost, RuleSetPost]] = Field(
        description="""
rules return a boolean for the logical evaluation defined below for every item within the categories defined
"""
    )


RuleSetPatch = ty.ForwardRef("RuleSetPatch")


class RuleSetPatch(RuleSet):
    rule: ty.List[ty.Union[RulePatch, RuleSetPatch]] = Field(
        description="""
rules return a boolean for the logical evaluation defined below for every item within the categories defined
"""
    )


class FilterGet(Filter):
    id: int
    rule_set: RuleSetGet = Field(json_schema_extra=dict(show_title=False, show_description=False))
    model_config = ConfigDict(from_attributes=True)


class FilterPost(Filter):
    rule_set: RuleSetPost = Field(json_schema_extra=dict(show_title=False, show_description=False))
    model_config = ConfigDict(from_attributes=True)


class FilterPatch(Filter):
    rule_set: RuleSetPatch = Field(json_schema_extra=dict(show_title=False, show_description=False))
    model_config = ConfigDict(from_attributes=True)
