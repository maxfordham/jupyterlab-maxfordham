import ipywidgets as w
import traitlets as tr
from aectemplater_client import get_property_by_name

PROPERTY_NAME="energyendusetags"


# +
class EnergyUseTags(w.HBox):
    """
    A widget wrapper around TagsInput that syncs its values into a string traitlet.
    """

    _value = tr.Unicode()
    property_id = tr.Int(default_value=2, const=True)

    @tr.observe("property_id")
    def _load_energy_use_tags(self, onchange):
        self.allowed_energy_tags = get_property_by_name(PROPERTY_NAME)

    @property
    def value(self):
        """Return Python list representation of the tags."""
        return self._value

    @value.setter
    def value(self, value):
        """Set tags by passing value as a string that evaluates to a list."""
        self.tags.value = eval(value)

    def __init__(self, **kwargs):
        self.allowed_energy_tags = get_property_by_name(PROPERTY_NAME)["allowed_values"]
        self.tags = w.TagsInput(allowed_tags=self.allowed_energy_tags, allow_duplicates=False)
        super().__init__(children=[self.tags])
        self._init_controls()

    def _init_controls(self):
        self.tags.observe(self._update, "value")

    def _update(self, change):
        self._value = str(self.tags.value)


if __name__ == "__main__":
    tags = EnergyUseTags()
    display(tags)

# -

if __name__ == "__main__":
    display(tags.value)

if __name__ == "__main__":
    tags.value = "['Domestic Hot Water']"


