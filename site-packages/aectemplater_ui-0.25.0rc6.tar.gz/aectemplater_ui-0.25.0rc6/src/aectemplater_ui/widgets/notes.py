from ipyautoui.custom.markdown_widget import MarkdownWidget

class Notes(MarkdownWidget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bn_header.disabled = True
        self.bn_image.disabled = True
