# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.15.2
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %run __init__.py
# %load_ext lab_black

# NOT IN USE
import json
import ipywidgets as w
from enum import Enum
from stringcase import pascalcase
from IPython.display import clear_output, display, Markdown
from ipyautoui.autoobject import AutoObject
from aectemplater_schemas.assetreference import (
    AssetReferenceInputs,
    AssetReference,
)


def get_pascal(tag: AssetReference):
    return {pascalcase(k): v for k, v in tag.model_dump().items() if k != "config"}


def short_summary(
    tag: AssetReference,
):
    def get_str(s):
        if s == "":
            return "None"
        elif isinstance(s, Enum):
            return s._name_
        else:
            return s

    def get_tag(k, v):
        return f"*{k}* = **{get_str(v)}**"

    di = get_pascal(tag)
    li = [get_tag(k, v) for k, v in di.items()]

    join_with = "\n- "

    return "- " + f"{join_with}".join(li)


def long_summary(tag: AssetReference):
    di = get_pascal(tag)
    s = "`" * 3
    return f"{s}json\n{json.dumps(di, indent=4)}\n{s}"


def get_markdown_tag(
    tag,
    title="title",
    description="",
    use_short_summary=True,
    use_long_summary=False,
    n=1,
):
    di = get_pascal(tag)
    js = json.dumps(di, indent=4)

    out = f"""
### Example{str(n)} - {title}

{description}

**{tag.tag}**




"""
    if use_short_summary:
        out += "\n\n"
        out += f"{short_summary(tag)}"

    if use_long_summary:
        out += "\n\n"
        out += f"{long_summary(tag)}"

    out += "\n\n---"
    return out


class TagUi(w.VBox):
    def __init__(self, value=None, validator=AssetReference):
        super().__init__()
        type_instance_delimiter = "-"
        self.tagui = AutoObject.from_pydantic_model(AssetReferenceInputs, value=None)
        self.validator = validator
        self.tagui.show_raw = False
        self.tagui.show_savebuttonbar = False
        self.out = w.Output()
        self.children = [self.tagui, self.out]
        self._init_controls()
        self._update("")

    def _init_controls(self):
        self.tagui.observe(self._update, "_value")

    def _update(self, on_change):
        self.tag = self.validator(**self.tagui.value)
        with self.out:
            clear_output()
            display(Markdown(get_markdown_tag(self.tag, title="title")))


if __name__ == "__main__":
    ui = TagUi()
    display(ui)
