# ---
# jupyter:
#   jupytext:
#     formats: py:light
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.7
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %run __init__.py

# +
import itertools
import ipywidgets as w
import traitlets as tr
import typing as ty

from pyuniclass import UT
from pyrulefilter.schemas import Rule
from pyrulefilter.enums import OperatorsEnum
from ipyautoui.constants import BUTTON_MIN_SIZE

# +
INCLUDE_EXCLUDE_OPERATORS = {
    OperatorsEnum.Equals: "include",
    OperatorsEnum.NotEquals: "exclude",
    OperatorsEnum.Contains: "include",
    OperatorsEnum.NotContains: "exclude",
    OperatorsEnum.BeginsWith: "include",
    OperatorsEnum.NotBeginsWith: "exclude",
    OperatorsEnum.EndsWith: "include",
    OperatorsEnum.NotEndsWith: "exclude",
}  # TODO: is this req. ? maybe just map to tick or cross if thats the point of the enum...
HTML_MAP_ICONS = {
    "Ss": '<i class="fa fa-cogs" aria-hidden="true"></i>',
    "Pr": '<i class="fa fa-archive" aria-hidden="true"></i>',
}
HTML_INCLUDE = {
    "include": '<i class="fa fa-check" style="width:20px; color:green;" aria-hidden="true"></i>',
    "exclude": '<i class="fa fa-times" style="width:20px; color:red;" aria-hidden="true"></i>',
}
HTML_OPERATORS = {
    OperatorsEnum.Equals: '<i style="width:150px; color:green;" aria-hidden="true">EQUALS</i>',
    OperatorsEnum.NotEquals: '<i style="width:150px; color:red;" aria-hidden="true">DOES NOT EQUAL</i>',
    OperatorsEnum.Contains: '<i style="width:150px; color:green;" aria-hidden="true">CONTAINS</i>',
    OperatorsEnum.NotContains: '<i style="width:150px; color:red;" aria-hidden="true">DOES NOT CONTAIN</i>',
    OperatorsEnum.BeginsWith: '<i style="width:150px; color:green;" aria-hidden="true">BEGINS WITH</i>',
    OperatorsEnum.NotBeginsWith: '<i style="width:150px; color:red;" aria-hidden="true">DOES NOT BEGIN WITH</i>',
    OperatorsEnum.EndsWith: '<i style="width:150px; color:green;" aria-hidden="true">ENDS WITH</i>',
    OperatorsEnum.NotEndsWith: '<i style="width:150px; color:red;" aria-hidden="true">DOES NOT END WITH</i>',
}

KEY_SIMPLE = (
    '<b>Key</b>: <i class="fa fa-check" style="color:green" aria-hidden="true"></i> ='
    ' <i>include</i>, <i class="fa fa-times" style="color:red" aria-hidden="true"></i>'
    ' = <i>exclude</i>, <i class="fa fa-cogs" aria-hidden="true"></i> = <i>Uniclass'
    ' System</i>, <i class="fa fa-archive" aria-hidden="true"></i> = <i>Uniclass'
    ' Product</i>, '
)

KEY_ADVANCED = (
    "<b>Key</b>: "
    "<i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> = <i>Uniclass System</i>, "
    "<i class=\"fa fa-archive\" aria-hidden=\"true\"></i> = <i>Uniclass Product</i>, "
)

STR_HELP = """
<!DOCTYPE html>
<html>
<head>
<style>
.help {
    padding: 1px;
    background-color: #ededed;
}
</style>
</head>
<div class="help">
    <h1>Using Uniclass Product and Systems Codes to Define Schedules</h1>

    <ul>
        <li>A Classification Uniclass Product Number defines a product or product family.</li>
        <li>A Classification Uniclass System Number defines a system or system family.</li>
        <li>Every product specified requires a single Classification Uniclass Product Number, and must belong to a single system, defined by the Classification Uniclass System Number.</li>
        <li>Given that this is true, we can search through all products in the Revit model and generate a schedule by matching the products to the codes.</li>
        <li>We can also use the codes to only show you Product Data Templates (PDTs) that match with the schedule definition created here.</li>
    </ul>
</div>
</html>
"""


# -


class UniclassView(w.VBox):
    value = tr.List(trait=tr.Instance(klass=Rule))

    @tr.validate("value")
    def _validate_rules(self, proposal):
        """Only allow rules where the value prefix is either 'Pr' or 'Ss'"""
        return [rule for rule in proposal["value"] if rule.value[0:2] in ["Pr", "Ss"]]

    @tr.observe("value")
    def _rules(self, on_change):
        self._set_view()

    def __init__(self, value: ty.List[Rule] = [], **kwargs):
        super().__init__(**kwargs)
        self.btn_help = w.ToggleButton(
            icon="question",
            tooltip="Help",
            layout=dict(BUTTON_MIN_SIZE),
        )
        self.btn_preview = w.ToggleButton(
            icon="search",
            button_style="primary",
            tooltip="Show All Uniclass Codes Included",
            layout=dict(BUTTON_MIN_SIZE),
        )
        self.hbx_btns = w.HBox(
            [self.btn_help, self.btn_preview],
        )
        self.view = w.HTML()
        self.value = value
        self.help = w.HTML()
        self.children = [self.hbx_btns, self.help, self.view]
        self._init_controls()

    def _init_controls(self):
        self.btn_preview.observe(self._toggle_view)
        self.btn_help.observe(self._toggle_help)

    def _toggle_help(self, on_change):
        if self.btn_help.value:
            self.help.value = STR_HELP
        else:
            self.help.value = ""

    def _toggle_view(self, on_change):
        self._set_view()

    def _set_view(self):
        if self.btn_preview.value:
            self.view.value = self.create_uniclass_simple_view(self.value) + self.create_uniclass_advanced_view(
                self.value
            )
        else:
            self.view.value = self.create_uniclass_simple_view(self.value)

    def get_parent_uniclass_html(self, code: str, include: str, operator: OperatorsEnum):
        """Get the HTML for a parent Uniclass code.

        Args:
            code (str): The Uniclass code.
            include (str): Whether the code is included or excluded.
            operator (OperatorsEnum): The operator used to filter the code.

        Returns:
            str: The HTML for the Uniclass code."""
        return (
            HTML_OPERATORS[operator]
            + " "
            + HTML_INCLUDE[include]
            + " "
            + HTML_MAP_ICONS[code[0:2]]
            + " "
            + UT.get_description(code)
        )

    def get_child_uniclass_html(self, code: str):
        """Get the HTML for a child Uniclass code.

        Args:
            code (str): The Uniclass code.

        Returns:
            str: The HTML for the Uniclass code."""
        return HTML_MAP_ICONS[code[0:2]] + " " + UT.get_description(code)

    def get_codes_from_rule(self, rule: Rule) -> list:
        """Get the Uniclass codes from a rule.

        Args:
            rule (Rule): The rule to get the Uniclass codes from.

        Returns:
            list: The Uniclass codes from the rule."""
        if rule.parameter in [
            "ClassificationUniclassProductNumber",
            "ClassificationUniclassSystemNumber",
        ]:
            map_operator_to_func = {
                OperatorsEnum.Equals: UT.get_code_equal,
                OperatorsEnum.NotEquals: UT.get_code_equal,
                OperatorsEnum.Contains: UT.get_codes_contains,
                OperatorsEnum.NotContains: UT.get_codes_contains,
                OperatorsEnum.BeginsWith: UT.get_codes_begins_with,
                OperatorsEnum.NotBeginsWith: UT.get_codes_begins_with,
                OperatorsEnum.EndsWith: UT.get_codes_ends_with,
                OperatorsEnum.NotEndsWith: UT.get_codes_ends_with,
            }
            if rule.operator in map_operator_to_func.keys():
                return map_operator_to_func[rule.operator](rule.value)
            else:
                raise ValueError(f"Operator '{rule.operator}' is not supported.")
        else:
            raise ValueError(
                f"Parameter '{rule.parameter}' is not supported. Must be either"
                " 'ClassificationUniclassProductNumber' or"
                " 'ClassificationUniclassSystemNumber'."
            )

    def create_uniclass_simple_view(self, value: ty.List[Rule]) -> str:
        """Create the HTML for the simple Uniclass view.

        Args:
            value (ty.List[Rule]): The rules to create the view from.

        Returns:
            str: The HTML for the simple Uniclass view."""
        li = [KEY_SIMPLE]
        di_rules = {
            "Ss": {
                "include": [],
                "exclude": [],
            },
            "Pr": {
                "include": [],
                "exclude": [],
            },
        }
        for rule in value:
            html = self.get_parent_uniclass_html(
                code=rule.value,
                include=INCLUDE_EXCLUDE_OPERATORS[rule.operator],
                operator=rule.operator,
            )
            code_prefix = rule.value[0:2]
            di_rules[code_prefix][INCLUDE_EXCLUDE_OPERATORS[rule.operator]].append(
                '<div class="row">' + html + "</div>"
            )

        li += itertools.chain.from_iterable(
            [
                ["<hr>"],
                di_rules["Ss"]["include"],
                di_rules["Ss"]["exclude"],
                ["<hr>"],
                di_rules["Pr"]["include"],
                di_rules["Pr"]["exclude"],
            ]
        )
        return (
            """<style>
        .container i {
          display: inline-block;
        }
        </style>
        <div class="container">
        """
            + "".join(li)
            + """
        </div>"""
        )

    def create_uniclass_advanced_view(self, value: ty.List[Rule]) -> str:
        """Create the HTML for the advanced Uniclass view.

        Args:
            value (ty.List[Rule]): The rules to create the view from.

        Returns:
            str: The HTML for the advanced Uniclass view."""
        HEADER = """<b>Uniclass Codes to be included based on rules above:</b>"""
        li = [HEADER]
        codes = set()
        di_rules = {
            "Ss": {
                "include": [],
                "exclude": [],
            },
            "Pr": {
                "include": [],
                "exclude": [],
            },
        }

        for rule in value:
            code_prefix = rule.value[0:2]
            di_rules[code_prefix][INCLUDE_EXCLUDE_OPERATORS[rule.operator]].append(rule)

        codes = {
            "Ss": set(),
            "Pr": set(),
        }
        for uniclass_type in di_rules:
            for rule in di_rules[uniclass_type]["include"]:
                codes[uniclass_type] = codes[uniclass_type].union(set(self.get_codes_from_rule(rule)))
            for rule in di_rules[uniclass_type]["exclude"]:
                codes[uniclass_type] -= set(self.get_codes_from_rule(rule))

        for uniclass_type in codes:
            li += ["<hr>"] + [
                f'<div class="row">{self.get_child_uniclass_html(code)}</div>' for code in sorted(codes[uniclass_type])
            ]
        return "".join(li)


if __name__ == "__main__":
    ui = UniclassView()
    display(ui)

if __name__ == "__main__":
    test_rule_set = {
        "name": "test",
        "description": "",
        "set_type": "AND",
        "rules": [
            {
                "categories": ["Analytical Spaces"],
                "operator": "begins with",
                "value": "Ps_60_45_01_11",
                "id": 2,
                "property_id": 4,
                "parameter": "ClassificationUniclassProductNumber",
            },
            {
                "categories": None,
                "operator": "contains",
                "value": "Pr_15_31_12",
                "id": 3,
                "property_id": 4,
                "parameter": "ClassificationUniclassProductNumber",
            },
            {
                "categories": None,
                "operator": "does not begin with",
                "value": "Pr_15_31_12_42",
                "id": 4,
                "property_id": 4,
                "parameter": "ClassificationUniclassProductNumber",
            },
            {
                "categories": None,
                "operator": "begins with",
                "value": "Ss_15_10",
                "id": 5,
                "property_id": 6,
                "parameter": "ClassificationUniclassSystemNumber",
            },
        ],
        "id": 1,
    }
    ui.value = [Rule(**rule) for rule in test_rule_set["rules"]]
