# TODO: Fix these tests
# The issue currently is that the CI on GitHub does NOT have access to the internal API.
# We can try use unittest.mock to mock the internal API calls and test the UI components.

import importlib
import pkgutil
import pytest


@pytest.mark.skip(reason="Skipping import tests for now.")
def test_imports():
    package_name = "aectemplater_ui"
    package = importlib.import_module(package_name)

    for _, module_name, _ in pkgutil.iter_modules(package.__path__, package_name + '.'):
        try:
            importlib.import_module(module_name)
        except ImportError as e:
            pytest.fail(f"Import failed for module {module_name}: {e}")


@pytest.mark.skip(reason="Skipping aecschedule instantiation tests temporarily.")
def test_aecschedule_app():
    from aectemplater_ui.aecschedule_main import AecSchedule, AecScheduleAccordion

    AecSchedule(acc_app=AecScheduleAccordion)


@pytest.mark.skip(reason="Skipping aectemplater instantiation tests temporarily.")
def test_aectemplater_app():
    from aectemplater_ui.aectemplater_main import AecTemplater, AecTemplaterViewOnly

    AecTemplater()
    AecTemplaterViewOnly()
