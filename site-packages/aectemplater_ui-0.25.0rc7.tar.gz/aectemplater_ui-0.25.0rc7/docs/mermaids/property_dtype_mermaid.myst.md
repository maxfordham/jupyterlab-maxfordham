```mermaid
graph TD
    A{Select From<br>Data Quantity<br>Type Options} -->|Is Physical Quantity| A1{Select from <br>all physical <br>quantities in DB}
    A1 -->|Not IFC type<br>Not Revit Type<br>Set to IfcReal| B2(fa:fa-check IfcDataType<br>fa:fa-times RevitDataType<br>fa:fa-times DefaultUnits)

    A1 -->|Is IFC type<br>Set to matching IFC type| B1(fa:fa-check IfcDataType<br>fa:fa-times RevitDataType<br>fa:fa-times DefaultUnits)
    A1 -->|Not IFC type<br>Revit Matches Found<br>Set to IfcReal| B5(fa:fa-check IfcDataType<br>fa:fa-times RevitDataType<br>fa:fa-times DefaultUnits)
    B5 -->|Many Revit Types| C10{Select from<br> list of matching<br> Revit types}
    C10 -->|map to Revit<br>config units| E10(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType<br>fa:fa-check DefaultUnits)
    B1 -->|No mapped Revit Type<br>Set Revit Type to Number| C1(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType<br>fa:fa-times DefaultUnits)
    C1 -->|Show Default<br> Unit Options| D3{Select<br> Default<br> Unit}
    D3 --> E2(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType<br>fa:fa-check DefaultUnits)
    B1 -->|One Revit Type<br>Set to matching Revit Type| C2(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType<br>fa:fa-check DefaultUnits)
    B1 -->|Many Revit Types| C3{Select from<br> list of matching<br> Revit types}
    C3 --> D2(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType<br>fa:fa-check DefaultUnits)
    B2 -->|One Revit Type<br>Set Revit Type to Number| C4(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType<br>fa:fa-times DefaultUnits)
    C4 -->|Show Default<br> Unit Options| D1{Select <br>Default<br> Unit}
    D1 --> E1(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType<br>fa:fa-check DefaultUnits)

    A -->|Is IFC Physical Quantity| A2{Select<br> physical quantity,<br> IFC types only}
    A2 --> B1

    A -->|Not a Physical Quantity| A3{Select not physical <br>quantity data types}
    A3 -->|Is IFC Type<br>All Non Physical Quantities<br> have IFC Types| B3(fa:fa-check IfcDataType<br>fa:fa-times RevitDataType)
    B3 -->|Is Revit type<br>Set to matching Revit type| C5(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType)
    B3 -->|No Matching Revit type<br>Set Revit Type to Text| C6(fa:fa-check IfcDataType<br>fa:fa-check RevitDataType)
```
