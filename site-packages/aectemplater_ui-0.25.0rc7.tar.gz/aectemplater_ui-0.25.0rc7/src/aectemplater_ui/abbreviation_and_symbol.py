# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.6
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
import pathlib
import logging
import csv
import ipywidgets as w
import traitlets as tr
import typing as ty
from enum import Enum
from pyuniclass import UniclassTables
from IPython.display import display, Javascript

from ipyautoui.custom.buttonbars import SaveButtonBar
from aectemplater_schemas.enumerations import ENV as AECTEMPLATER_SCHEMAS_ENV
from aectemplater_schemas.enumerations import (
    get_bdns_asset_abbreviations,
    get_symbols,
)
from aectemplater_client import (
    get_abbreviations,
    delete_object_abbreviation,
    get_object_by_id,
    get_object_abbreviations_by_object_id,
    patch_object_abbreviation,
    post_abbreviation,
    post_object_abbreviation,
)

from aectemplater_ui import ENV
from aectemplater_ui.utils import HandleOptions

ut = UniclassTables()

logger = logging.getLogger(__name__)
URL_BDNS_ABBREVATIONS = AECTEMPLATER_SCHEMAS_ENV.URL_ABBREVIATIONS


# +
# TODO: Move to API?
def get_abbreviations_map() -> dict:
    li = get_abbreviations(skip=0, limit=-1)
    return {r["abbreviation"]: r["id"] for r in li}


def post_abbreviations(abbreviations: ty.List[str]) -> dict:
    existing_abbreviations = get_abbreviations_map()
    exist = {abbr: existing_abbreviations[abbr] for abbr in abbreviations if abbr in existing_abbreviations.keys()}
    added = {
        abbr: post_abbreviation({"abbreviation": abbr})["id"]
        for abbr in abbreviations
        if abbr not in existing_abbreviations.keys()
    }
    return {**exist, **added}


# -
# HOTFIX: Getting BDNS abbreviations from GitHub Repo and extra abbreviations internally
def get_extra_bdns_asset_abbreviations() -> list:
    """Obtain extra BDNS asset abbreviations based on environment
    variable AECTEMPLATER_FPTH_EXTRA_ABBREVIATIONS."""
    if ENV.AECTEMPLATER_FPTH_EXTRA_ABBREVIATIONS is None:
        return []
    fpth = pathlib.Path(ENV.AECTEMPLATER_FPTH_EXTRA_ABBREVIATIONS)
    if fpth.exists():
        with open(fpth) as file:
            read = csv.reader(file, delimiter=",")
            return [row for row in read]
    else:
        return []


def get_all_bdns_asset_abbreviations() -> list:
    """Get all BDNS abbreviations with extra abbreviations defined internally."""
    return get_bdns_asset_abbreviations() + get_extra_bdns_asset_abbreviations()[1:]


ENUM_ABBR = Enum(
    "Abbreviations",
    {"invalid": ""} | {l[1]: l[1] + " - " + l[0] for l in get_all_bdns_asset_abbreviations()[1:]},
)
ERROR_WARNING_ABBR = (
    "{value}" + f"not found in abbreviations enum. see: {AECTEMPLATER_SCHEMAS_ENV.URL_ABBREVIATIONS}"
)  # TODO: URL_ABBREVIATIONS_FOR_USER
ENUM_SYMBOLS = Enum("Symbols", {"invalid": ""} | get_symbols())
ERROR_WARNING_SYMBOLS = "{value}" + " not found in symbols enum."


class BDNSDocsButton(w.HBox):
    def __init__(self):
        super().__init__()
        self.bdns_url = URL_BDNS_ABBREVATIONS
        self.btn_bdns = w.Button(
            icon="question",
            description="Explore BDNS Abbreviations",
            button_style="primary",
            tooltip="Explore the 'Building Device and Asset Naming Standards' abbreviation register",
            layout={"width": "220px"},
        )
        self.out = w.Output()
        self._init_controls()
        self.children = [self.btn_bdns, self.out]

    def _init_controls(self):
        self.btn_bdns.on_click(self.window_open_button)

    def window_open_button(self, onchange):
        with self.out:
            display(Javascript(f'window.open("{self.bdns_url}");'))


# +
def enum_to_dict(enum):
    return {e: getattr(enum, e).value for e in enum.__members__.keys()}


def get_object_description(object: dict) -> str:
    return f"{object['custodian']} - {object['name']} - {object['version']}"


def load_value(object_id: int) -> dict:
    di = {}
    li = get_object_abbreviations_by_object_id(object_id)
    if li == []:
        return {"allowed_values": [], "default_value": ""}
    di["allowed_values"] = [l["abbreviation"]["abbreviation"] for l in li]
    try:
        default_value = [l["abbreviation"]["abbreviation"] for l in li if l["is_default"]][0]
    except:
        default_value = di["allowed_values"][0]
    di["default_value"] = default_value
    return di


class AbbreviationsInput(HandleOptions, w.VBox):
    description = tr.Unicode()
    _value = tr.Dict(
        per_key_traits={"allowed_values": tr.List(), "default_value": tr.Unicode()},
        default_value={"allowed_values": [], "default_value": ""},
    )
    object_id = tr.Int()

    @tr.observe("description")
    def _description(self, on_change):
        self.html_description.value = self.description

    @tr.observe("object_id")
    def _object_id_get_description(self, on_change):
        self.object = get_object_by_id(self.object_id)
        self.html_selected_object.value = (
            f"{self.object['custodian']} - {self.object['name']} - {self.object['version']}"
        )

    @tr.observe("object_id")
    def _object_id_load_value(self, on_change):
        self.load_from_api()

    def load_from_api(self):
        self.value = load_value(self.object_id)
        self.bbar.unsaved_changes = False
        self._update_html_selected()

    def __init__(self, **kwargs):
        super().__init__()
        WIDTH = "200px"

        self.bbar = SaveButtonBar()
        self.bbar.fns_onrevert_add_action(self.load_from_api)
        self.bbar.fns_onsave_add_action(self.save_changes)
        self.allowed_values = w.TagsInput(**kwargs)
        self.allowed_values.allow_duplicates = False
        self.hbx_select_allowed = w.HBox(
            [
                w.HTML("Select Allowed Abbreviations:", layout={"width": WIDTH}),
                self.allowed_values,
            ]
        )
        self.html_description = w.HTML()
        self.html_selected_object = w.HTML()
        self.hbx_select_default = w.HBox()
        self.default = w.Dropdown(layout={"width": "100px"})
        self.hbx_select_default.children = [
            w.HTML("Select Default Abbreviation:", layout={"width": WIDTH}),
            self.default,
        ]

        self.html_default = w.HTML()

        self.html_selected = w.HTML()
        self.hbx_selected = w.HBox(
            [
                w.HTML("Allowed Abbreviations: ", layout={"width": WIDTH}),
                self.html_selected,
            ]
        )
        self.hbx_selected_object = w.HBox(
            [
                w.HTML("Selected Data Template: ", layout={"width": WIDTH}),
                self.html_selected_object,
            ]
        )
        self.children = [
            self.bbar,
            self.html_description,
            BDNSDocsButton(),
            self.html_default,
            self.hbx_selected,
            self.hbx_selected_object,
            self.hbx_select_default,
            self.hbx_select_allowed,
        ]
        self._init_controls()
        self._update_allowed_values(None)
        self.options = enum_to_dict(ENUM_ABBR)
        self.description = "<b>Add Allowed Abbreviations and Default Abbreviation to a Data Template</b>"
        {setattr(self, k, v) for k, v in kwargs.items()}

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self.allowed_values.value = [self.options[v] for v in value["allowed_values"]]
        if value["default_value"] == "":
            self.default.value = None
        else:
            self.default.value = value["default_value"]

    def _update_allowed_values(self, on_change):
        self.allowed_values.allowed_tags = list(self.options.values())

    def _init_controls(self):
        self.observe(self._update_allowed_values, "options")
        self.allowed_values.observe(self._update_allowed, "value")
        self.default.observe(self._update_default, "value")

    def _update_allowed(self, on_change):
        self.value["allowed_values"] = [self.get_item_from_options(v) for v in on_change["new"]]
        self.default.options = self.value["allowed_values"]
        if self.default.value is None and len(self.value["allowed_values"]) >= 1:
            self.default.value = self.value["allowed_values"][0]
        self._update_value()

    def _update_default(self, on_change):
        self._update_value()

    def _update_html_selected(self):
        if self.value["default_value"] == "":
            if self.object["custodian"] == ENV.AECTEMPLATER_ORG:
                self.html_selected.value = (
                    "⚠️ <b>WARNING</b> ⚠️: ABBREVIATION REQUIRED FOR :"
                    f" <i>{get_object_description(self.object)}</i>. ➕ Please Add ➕. "
                )
        else:
            s = f"<b>{self.value['default_value']}</b>, "
            s_ = f"{', '.join([l for l in self.value['allowed_values'] if l != self.value['default_value']])}"
            self.html_selected.value = s + s_

    def _update_value(self):
        get_default = lambda default: "" if default.value is None else default.value
        self._value = {
            "allowed_values": self.value["allowed_values"],
            "default_value": get_default(self.default),
        }
        self._update_html_selected()
        self.bbar.unsaved_changes = True

    def save_changes(self):
        abb = post_abbreviations(self.value["allowed_values"])
        is_default = lambda abb: True if abb == self.value["default_value"] else False
        drop = lambda di, key: {k: v for k, v in di.items() if k != "is_default"}

        li_new = [
            {
                "object_id": self.object_id,
                "is_default": is_default(k),
                "abbreviation_id": v,
            }
            for k, v in abb.items()
        ]

        li_new_map = [drop(l, "is_default") for l in li_new]

        li_old = [drop(l, "abbreviation") for l in get_object_abbreviations_by_object_id(self.object_id)]

        li_old_map = [drop(l, "is_default") for l in li_old]

        for l in li_old_map:
            if l not in li_new_map:
                delete_object_abbreviation(l["object_id"], l["abbreviation_id"])
                # delete

        for l in li_new:
            if l in li_old:
                # exists - do nothing
                pass
            elif drop(l, "is_default") in li_old_map:
                # patch
                patch_object_abbreviation(
                    object_id=l["object_id"], abbreviation_id=l["abbreviation_id"], is_default=l["is_default"]
                )
            elif l not in li_old:
                # post
                post_object_abbreviation(
                    object_id=l["object_id"], abbreviation_id=l["abbreviation_id"], is_default=l["is_default"]
                )
            else:
                raise ValueError("save abbreviation changes error. should post, patch or delete.")

        self.bbar.unsaved_changes = False

    @property
    def allowed_summary(self):
        li = [self.value["default_value"]] + [
            l for l in self.value["allowed_values"] if l != self.value["default_value"]
        ]
        if li == [""]:
            li = []
        return [self.options[l] for l in li]

    @property
    def html_allowed_summary(self):
        li = []
        for n, l in enumerate(self.allowed_summary):
            if n == 0:
                li.append(f"<b>{l}</b>")
            else:
                li.append(f"{l}")
        return ", ".join(li)


if __name__ == "__main__":
    abbr = AbbreviationsInput(
        object_id=1,
    )
    display(abbr)
# -

if __name__ == "__main__":
    display(abbr.value)


class ImageTagsInput(w.VBox):
    fdir = tr.Instance(klass=pathlib.Path)
    options = tr.List()
    description = tr.Unicode()

    @tr.observe("description")
    def _description(self, on_change):
        self.html_description.value = self.description

    def __init__(self, kwargs_image={"layout": {"width": "100px"}}, **kwargs):
        super().__init__()
        self.allowed_values = w.TagsInput(**kwargs)
        self.kwargs_image = kwargs_image
        self.html_description = w.HTML()
        {setattr(self, k, v) for k, v in kwargs.items()}
        self.gbx_selected = w.HBox()
        self.children = [self.html_description, self.gbx_selected, self.allowed_values]
        self._init_controls()
        self._update_allowed_values(None)

    def _update_allowed_values(self, on_change):
        self.allowed_values.allowed_tags = self.options

    def _init_controls(self):
        self.observe(self._update_allowed_values, "options")
        self.allowed_values.observe(self._update_value, "value")

    def _update_value(self, on_change):
        self.value = [v for v in on_change["new"]]
        self.gbx_selected.children = [w.Image.from_file(self.fdir / v, **self.kwargs_image) for v in self.value]


if __name__ == "__main__":
    LI_SYMBOLS = []
    im = ImageTagsInput(fdir=ENV.AECTEMPLATER_FDIR_SYMBOLS, options=LI_SYMBOLS, description="asdfasd")
    display(im)
