"""This module contains the Operational Energy Target app.
A user can add many target types and assign energy targets to each type by project building type.
The building types are defined in the Project Building Area app and are automatically added to an energy type target
upon creation.
There is also a global energy target setter in the energy type target to allow a user to set all the energy targets
for a specific type to the same value.
NOTE: This is set up so that the TypeMark is replaced with the Target name so the user selects the name instead of
its TypeMark. This is clearer for the user but has lead to some complex logic below to ensure this works.
"""

# +
import copy

import ipywidgets as w
import traitlets as tr
from aectemplater_client import (
    get_instance_specs_object_data_grid,
    get_object_gridschema,
    get_type_spec_id_by_type_mark,
    get_type_spec_object_data,
    get_type_spec_object_data_grid,
    get_type_spec_type_mark,
    patch_instance_spec_data,
    patch_type_spec_data,
    post_instance_spec_data,
)
from aectemplater_schemas.enumerations import ParameterTypeEnum
from ipyautoui.custom.buttonbars import CrudOptions, CrudView
from ipyautoui.custom.editgrid import DataHandler
from IPython.display import display

from aectemplater_ui.apps.constants import OBJECT_ID_BUILDING_AREA, OBJECT_ID_OPERATIONAL_ENERGY_TARGET
from aectemplater_ui.instance_specification import InstanceSpecDelete, InstanceSpecGrid
from aectemplater_ui.type_specification import TypeSpecDelete, TypeSpecGrid, TypeSpecIO

# +
ORDER_ENERGY_TARGET_TYPES = [
    "Name",
    "Description",
    "GlobalEnergyTarget",
    "Abbreviation",
    "TypeReference",
    "Id",
]

ORDER_ENERGY_TARGETS = [
    "TypeMark",
    "BuildingType",
    "ConstructionMethod",
    "EnergyTarget",
    "InstanceReference",
    "TypeSpecId",
    "Id",
]
# -

COLUMN_WIDTHS_ENERGY_TARGETS = {
    "('key', '', '')": 120,
    "('Identity Data', 'Target Type', '')": 100,
    "('Identity Data', 'Type Spec Id', '')": 0.5,
    "('Identity Data', 'Id', '')": 0.5,
    "('Identity Data', 'Instance Reference', '')": 0.5,
    "('Application', 'Construction Method', '')": 140,
    "('Application', 'Building Type', '')": 300,
    "('Performance', 'Energy Target', 'kWh/m²/yr')": 100,
}


def get_operational_energy_target_gridschema(
    project_revision_id: int, parameter_type: ParameterTypeEnum, override_units: bool = True
) -> dict:
    """Get the recorded energy use data used in defining the data grid."""
    schema = get_object_gridschema(
        object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET,
        override_units=override_units,
        project_revision_id=project_revision_id,
        parameter_type=parameter_type,
    )
    if "IsNewBuild" in schema["items"]["properties"]:
        del schema["items"]["properties"]["IsNewBuild"]
    # TODO: delete once IsNewBuild removed from Aectemplater

    assert "IsNewBuild" not in schema["items"]["properties"]  # noqa: S101
    if parameter_type == parameter_type.type:
        schema["datagrid_index_name"] = ["section", "title"]
    elif parameter_type == parameter_type.instance:
        schema["items"]["properties"]["TypeMark"]["title"] = "Target Type"
        if project_revision_id is not None:
            operational_energy_target_data = get_type_spec_object_data_grid(
                object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET, project_revision_id=project_revision_id
            )["data"]
            schema["items"]["properties"]["TypeMark"]["enum"] = [v["Name"] for v in operational_energy_target_data]
    # HOTFIX: Custom overrides to properties
    # NOTE: We can remove these custom overrides once aectemplater set up to deal with `json_schema_extra`
    # We remove `anyOf` and set to `type`
    for _, property_ in schema["items"]["properties"].items():
        if "anyOf" in property_:
            if property_["name"] == "GlobalEnergyTarget":
                continue
            for item in property_["anyOf"]:
                if item["type"] != "null":
                    type_ = item["type"]
            property_["type"] = type_
            property_.pop("anyOf")
    return schema


def get_map_target_type_to_type_mark(project_revision_id: int) -> dict[str, str]:
    """Get the mapping of target type to type mark."""
    type_spec_data = get_type_spec_object_data_grid(
        project_revision_id=project_revision_id,
        object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET,
        override_units=True,
    )["data"]
    return {v["Name"]: get_type_spec_type_mark(v["Id"]) for v in type_spec_data}


def get_energy_targets_data(project_revision_id: int, override_units: bool) -> list[dict]:
    """Get the energy targets data."""
    instance_spec = get_instance_specs_object_data_grid(
        project_revision_id=project_revision_id,
        object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET,
        override_units=override_units,
    )
    instance_spec["data"] = [{k: v for k, v in x.items() if k != "IsNewBuild"} for x in instance_spec["data"]]
    # TODO: ^ delete once IsNewBuild removed from Aectemplater
    map_target_type_to_type_mark = get_map_target_type_to_type_mark(project_revision_id=project_revision_id)
    map_type_mark_to_type_target = {v: k for k, v in map_target_type_to_type_mark.items()}
    for v in instance_spec["data"]:
        v["TypeMark"] = map_type_mark_to_type_target[v["TypeMark"]]
    return instance_spec["data"]


def post_missing_building_types(project_revision_id: int, override_units: bool):
    """Get the unique building areas defined in the Project Building Area app and ensure those areas exist in the targets."""
    energy_targets = get_type_spec_object_data_grid(
        project_revision_id=project_revision_id,
        object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET,
        override_units=override_units,
    )
    map_target_name_to_id = {v["Name"]: v["Id"] for v in energy_targets["data"] if "Name" in v}
    map_target_id_to_global_energy_target = {
        v["Id"]: v["GlobalEnergyTarget"] for v in energy_targets["data"] if "GlobalEnergyTarget" in v
    }
    building_areas = get_instance_specs_object_data_grid(
        project_revision_id=project_revision_id, object_id=OBJECT_ID_BUILDING_AREA
    )["data"]

    unique_building_areas = []
    for area in building_areas:
        building_type = area.get("BuildingType")
        construction_method = area.get("ConstructionMethod")

        if building_type is not None and construction_method is not None:
            di = {"BuildingType": building_type, "ConstructionMethod": construction_method}
            if di not in unique_building_areas:
                unique_building_areas.append(di)

    building_areas_in_targets = get_energy_targets_data(
        project_revision_id=project_revision_id, override_units=override_units
    )
    building_areas_in_targets = [
        {"TypeMark": v["TypeMark"], "BuildingType": v["BuildingType"], "ConstructionMethod": v["ConstructionMethod"]}
        for v in building_areas_in_targets
        if "ConstructionMethod" in v and "BuildingType" in v
    ]

    for target_name, type_spec_id in map_target_name_to_id.items():
        for area in unique_building_areas:
            area["TypeMark"] = target_name
            if area not in building_areas_in_targets:
                area["EnergyTarget"] = map_target_id_to_global_energy_target.get(type_spec_id, None)
                post_instance_spec_data(
                    type_spec_id=type_spec_id,
                    value=area,
                    override_units=override_units,
                )


# +
ENERGY_TARGET_TYPE_BUTTONBAR_CONFIG = CrudView(
    add=CrudOptions(
        tooltip="""Click to add Energy Type Target.
Input the data and then click save.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Energy Type Target</i>",
    ),
    edit=CrudOptions(
        tooltip="""Select a row from the table and click to edit.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Energy Type Target</i>",
    ),
    delete=CrudOptions(
        tooltip="""Select row(s) from the table and click to open deletion menu.
Click the red DELETE button to confirm deletion.
Once deleted, click again to close the menu.""",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Energy Type Target</i>",
    ),
    io=CrudOptions(
        tooltip="import/export",
        tooltip_clicked="Go back to table",
        message="🔄 <i>Import / Export</i>",
    ),
    reload=CrudOptions(
        tooltip="Click to reload.",
        button_style="info",
        message="🔄 <i>Reload Energy Type Target</i>",
    ),
    support=CrudOptions(
        tooltip="Show Help",
        tooltip_clicked="Go back to table",
        message="❔ <i>Help</i>",
    ),
)

ENERGY_TARGETS_BUTTONBAR_CONFIG = CrudView(
    edit=CrudOptions(
        tooltip="""Select a row from the table and click to edit.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Energy Target</i>",
    ),
    reload=CrudOptions(
        tooltip="Click to reload.",
        button_style="info",
        message="🔄 <i>Reload Energy Target</i>",
    ),
    support=CrudOptions(
        tooltip="Show Help",
        tooltip_clicked="Go back to table",
        message="❔ <i>Help</i>",
    ),
)


class EnergyTargetTypesGrid(TypeSpecGrid):
    @tr.observe("project_revision_id")
    def _set_project_data(self, onchange):
        if self.project_revision_id is not None:
            self._reload_datahandler()
            post_missing_building_types(
                project_revision_id=self.project_revision_id, override_units=self.override_units
            )
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    @tr.observe("object_id")
    def _set_grid(self, onchange):
        if self.object_id is not None:
            schema = get_operational_energy_target_gridschema(
                project_revision_id=self.project_revision_id,
                parameter_type=ParameterTypeEnum.type,
            )
            self.update_from_schema(
                schema=schema,
                datahandler=DataHandler(
                    fn_get_all_data=self.get_type_specs,
                    fn_post=self.post_type_spec,
                    fn_patch=self.patch_type_spec,
                    fn_delete=self.delete_type_spec,
                    fn_copy=self.copy_type_spec,
                    fn_io=self.handle_crud,
                ),
                ui_delete=TypeSpecDelete,
                ui_io=self.ui_io_class,
            )
            self._set_styling()
            self._set_col_widths()
            self._hide_id_widgets()
        else:
            self.update_from_schema(schema=None)

    def __init__(self, **kwargs):
        self.order = ORDER_ENERGY_TARGET_TYPES
        super().__init__(object_id=OBJECT_ID_OPERATIONAL_ENERGY_TARGET, **kwargs)
        self.buttonbar_grid.crud_view = ENERGY_TARGET_TYPE_BUTTONBAR_CONFIG
        self.buttonbar_grid.imports.layout.display = "none"
        self.buttonbar_grid.images.layout.display = "none"
        self.buttonbar_grid.copy.layout.display = "none"
        self.grid.layout.height = "140px"
        self.fn_reload_energy_targets = lambda: print("Reload Energy Targets")

    def _set_children(self):
        super()._set_children()
        self.stk_crud.children = [
            self.ui_add,
            self.ui_edit,
            self.ui_delete,
        ]
        if self.show_ui_io and self.ui_io is not None:
            self.stk_crud.children = (*self.stk_crud.children, self.ui_io)
        self.children = [self.hbx_title_description, self.vbx_widget]
        self._remove_show_hide_nulls()

    def _remove_show_hide_nulls(self):
        self.ui_add.show_null = True
        self.ui_edit.show_null = True
        self.ui_add.bn_shownull.layout.display = "none"
        self.ui_edit.bn_shownull.layout.display = "none"

    def _hide_id_widgets(self):
        if self.ui_add.properties and self.ui_edit.properties:
            fields_to_hide = ["Id", "Abbreviation", "TypeReference"]
            self.grid.order = self.order
            self.ui_add.order = [property_ for property_ in self.order if property_ not in fields_to_hide]
            self.ui_edit.order = [property_ for property_ in self.order if property_ not in fields_to_hide]

    def _check_duplicate_target_name(self, value: dict):
        """Check if the target name already exists in the grid.
        We want to ensure that these names are unique."""
        value_id = value.get("Id", 0)
        target_names = [
            v[("Identity Data", "Name")]
            for _, v in self.grid.data.to_dict().items()
            if v[("Identity Data", "Id")] != value_id
        ]  # Get target names target name if same type spec ID
        # This is so we can patch without duplicate error being raised
        if value["Name"] in target_names:
            msg = f"❌ {value['Name']} already exists. Please use a different target name."
            self.buttonbar_grid.message.value = msg
            raise ValueError(msg)
        else:
            self.buttonbar_grid.message.value = ""

    def _set_global_energy_target(self, value: dict):
        """Set the energy target instances via the global energy target setter."""
        if value["GlobalEnergyTarget"] is not None:
            energy_targets = get_energy_targets_data(
                project_revision_id=self.project_revision_id, override_units=self.override_units
            )
            map_target_type_to_type_mark = get_map_target_type_to_type_mark(
                project_revision_id=self.project_revision_id
            )
            for target in energy_targets:
                target_name = target["TypeMark"]
                if target_name == value["Name"]:
                    target["EnergyTarget"] = value["GlobalEnergyTarget"]
                    target["TypeMark"] = map_target_type_to_type_mark[target["TypeMark"]]
                    patch_instance_spec_data(
                        instance_spec_id=target["Id"], value=target, override_units=self.override_units
                    )

    def copy_type_spec(self, value: dict):
        raise Exception("Duplicating Energy Target Types not allowed.")

    def patch_type_spec(self, value: dict):
        self._check_duplicate_target_name(value)
        type_spec = super().patch_type_spec(value)
        self._set_global_energy_target(value)
        self.fn_reload_energy_targets()
        return type_spec

    def post_type_spec(self, value: dict):
        self._check_duplicate_target_name(value)
        type_spec = super().post_type_spec(value)
        post_missing_building_types(project_revision_id=self.project_revision_id, override_units=self.override_units)
        self._set_global_energy_target(value)
        self.fn_reload_energy_targets()
        return type_spec

    def _reload_datahandler(self):
        self._reload_all_data()


if __name__ == "__main__":
    gr_energy_target_types = EnergyTargetTypesGrid(ui_io=TypeSpecIO, show_ui_io=True, by_alias=True)
    gr_energy_target_types.project_revision_id = 2
    display(gr_energy_target_types)


# +
class EnergyTargetsGrid(InstanceSpecGrid):
    @tr.observe("project_revision_id")
    def _set_project_data(self, onchange):
        if self.project_revision_id is not None:
            self._reload_datahandler()
            post_missing_building_types(
                project_revision_id=self.project_revision_id, override_units=self.override_units
            )
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    @tr.observe("object_id")
    def _set_grid(self, onchange):
        if self.object_id is not None:
            schema = get_operational_energy_target_gridschema(
                project_revision_id=self.project_revision_id,
                parameter_type=ParameterTypeEnum.instance,
            )
            self.update_from_schema(
                schema=schema,
                datahandler=DataHandler(
                    fn_get_all_data=self.get_instance_specs,
                    fn_post=self.post_instance_spec,
                    fn_patch=self.patch_instance_spec,
                    fn_delete=self.delete_instance_spec,
                    fn_copy=self.copy_instance_spec,
                    fn_io=self.handle_crud,
                ),
                ui_delete=InstanceSpecDelete,
            )
            self._set_styling()
            self._set_col_widths()
            self._hide_id_widgets()
            self._set_children()
        else:
            self.update_from_schema(schema=None)

    def _hide_id_widgets(self):
        if self.ui_add.properties and self.ui_edit.properties:
            fields_to_hide = ["InstanceReference", "Id", "TypeSpecId"]
            self.grid.order = self.order
            self.ui_add.order = [property_ for property_ in self.order if property_ not in fields_to_hide]
            self.ui_edit.order = [property_ for property_ in self.order if property_ not in fields_to_hide]

    def _remove_show_hide_nulls(self):
        self.ui_add.show_null = True
        self.ui_edit.show_null = True
        self.ui_add.bn_shownull.layout.display = "none"
        self.ui_edit.bn_shownull.layout.display = "none"

    def _set_col_widths(self):
        self.grid.column_widths = COLUMN_WIDTHS_ENERGY_TARGETS

    def _set_children(self):
        # Hide the add, copy, and delete buttons
        self.buttonbar_grid.add.layout.display = "none"
        self.buttonbar_grid.copy.layout.display = "none"
        self.buttonbar_grid.delete.layout.display = "none"
        self.buttonbar_grid.io.layout.display = "none"
        # Setting tooltips to None for add, copy, and delete so don't appear in support
        self.buttonbar_grid.add.tooltip = None
        self.buttonbar_grid.copy.tooltip = None
        self.buttonbar_grid.delete.tooltip = None
        self.buttonbar_grid.io.tooltip = None
        super()._set_children()
        self.stk_crud.children = [
            self.ui_edit,
        ]
        self.children = [self.hbx_title_description, self.vbx_widget]
        self._remove_show_hide_nulls()

    def __init__(self, **kwargs):
        self.order = ORDER_ENERGY_TARGETS
        super().__init__(**kwargs)
        self.object_id = OBJECT_ID_OPERATIONAL_ENERGY_TARGET
        self.buttonbar_grid.crud_view = ENERGY_TARGETS_BUTTONBAR_CONFIG
        self.grid.layout.height = "300px"
        self.fn_reload_energy_target_types = lambda: print("Reload Energy Target Types")

    def get_instance_specs(self):
        if self.object_id is not None and self.project_revision_id is not None:
            self.map_type_target_to_type_mark = get_map_target_type_to_type_mark(
                project_revision_id=self.project_revision_id
            )
            instance_spec_data = get_energy_targets_data(
                project_revision_id=self.project_revision_id, override_units=self.override_units
            )
            return instance_spec_data
        else:
            return []

    def post_instance_spec(self, value: dict):
        value = copy.deepcopy(value)
        if value["TypeMark"] not in self.map_type_target_to_type_mark:
            raise ValueError(f"{value['TypeMark']} does not exist. Not able to save Energy Target data.")
        value["TypeMark"] = self.map_type_target_to_type_mark[value["TypeMark"]]
        try:
            type_spec_id = get_type_spec_id_by_type_mark(
                project_revision_id=self.project_revision_id, object_id=self.object_id, type_mark=value["TypeMark"]
            )
        except Exception as err:
            self.buttonbar_grid.message.value = str(err)
            raise Exception(err)
        try:
            return post_instance_spec_data(
                type_spec_id=type_spec_id,
                value=value,
                override_units=self.override_units,
            )
        except Exception as err:
            self.buttonbar_grid.message.value = str(err)
            raise Exception(err)

    def patch_instance_spec(self, value: dict):
        value = copy.deepcopy(value)
        if value["TypeMark"] not in self.map_type_target_to_type_mark:
            raise ValueError(f"{value['TypeMark']} does not exist. Not able to save Energy Target data.")
        value["TypeMark"] = self.map_type_target_to_type_mark[value["TypeMark"]]
        super().patch_instance_spec(value)
        self._check_global_energy_target(value)
        self.fn_reload_energy_target_types()

    def _check_global_energy_target(self, value: dict):
        """Check whether the global energy target can be set to None.
        This will happen if one of the energy targets varies from the global energy target value."""
        type_spec_id = get_type_spec_id_by_type_mark(
            project_revision_id=self.project_revision_id,
            object_id=self.object_id,
            type_mark=value["TypeMark"],
        )
        type_spec = get_type_spec_object_data(type_spec_id)
        type_spec_data = type_spec["data"]
        if "GlobalEnergyTarget" in type_spec["data"] and "EnergyTarget" in value:
            if value["EnergyTarget"] != type_spec_data["GlobalEnergyTarget"]:
                type_spec_data["GlobalEnergyTarget"] = None
                patch_type_spec_data(
                    type_spec_id=type_spec_id, value=type_spec_data, override_units=self.override_units
                )

    def _update_target_options(self, onchange=None):
        """Check type marks in buildings grid match dropdown for Building ID."""
        if self.project_revision_id is not None:
            project_target_types = list(get_map_target_type_to_type_mark(self.project_revision_id).keys())
            self.ui_add.di_widgets["TypeMark"].options = project_target_types
            self.ui_edit.di_widgets["TypeMark"].options = project_target_types

    def _reload_datahandler(self, onchange=None):
        self._update_target_options()
        self._reload_all_data()


if __name__ == "__main__":
    project_revision_id = 2
    gr_energy_targets = EnergyTargetsGrid()
    gr_energy_targets.project_revision_id = project_revision_id
    display(gr_energy_targets)


# +
class OperationalEnergyTargets(w.VBox):
    project_revision_id = tr.Integer(default_value=None, allow_none=True)

    @tr.observe("project_revision_id")
    def _set_grids(self, onchange):
        self.gr_energy_target_type.project_revision_id = self.project_revision_id
        self.gr_energy_targets.project_revision_id = self.project_revision_id
        self.gr_energy_target_type.fn_reload = self.gr_energy_targets._reload_datahandler

    def __init__(self, **kwargs):
        self.gr_energy_target_type = EnergyTargetTypesGrid(ui_io=TypeSpecIO, show_ui_io=True, by_alias=True)  # noqa: E501
        self.gr_energy_targets = EnergyTargetsGrid()
        self.gr_energy_target_type.fn_reload_energy_targets = self.gr_energy_targets._reload_datahandler
        self.gr_energy_targets.fn_reload_energy_target_types = self.gr_energy_target_type._reload_datahandler
        super().__init__(
            [
                w.HTML("<h2>Add Operational Energy Target Type</h2>"),
                self.gr_energy_target_type,
                w.HTML("<h2>Add Operational Energy Targets for Project Building Types</h2>"),
                w.HTML("Select a target type above to load the associated energy target data"),
                self.gr_energy_targets,
            ]
        )


if __name__ == "__main__":
    project_revision_id = 2
    op_energy_targets = OperationalEnergyTargets()
    op_energy_targets.project_revision_id = project_revision_id
    display(op_energy_targets)
# -
