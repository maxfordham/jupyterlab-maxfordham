import ipywidgets as w
import traitlets as tr
from aectemplater_client import (
    get_object_gridschema,
    get_project_revision_by_id,
    get_project_type_marks,
)
from aectemplater_schemas.enumerations import ParameterTypeEnum
from ipyautoui.custom.buttonbars import CrudOptions, CrudView
from ipyautoui.custom.editgrid import DataHandler
from IPython.display import display

from aectemplater_ui.apps.constants import OBJECT_ID_BUILDING_AREA
from aectemplater_ui.instance_specification import InstanceSpecDelete, InstanceSpecGrid, InstanceSpecIO
from aectemplater_ui.type_specification import TypeSpecDelete, TypeSpecGrid, TypeSpecIO

ORDER_AREAS_GRID = ["TypeMark", "ConstructionMethod", "BuildingType", "GrossInternalArea", "InstanceReference", "TypeSpecId", "Id"]
ORDER_BLDGS_GRID = ["TargetYear", "Name", "Abbreviation", "TypeReference", "Id"]

def get_project_building_area_gridschema(
    project_revision_id: int,
    parameter_type: ParameterTypeEnum,
    override_units: bool = True,
) -> dict:
    """Get the recorded energy use data used in defining the data grid."""
    schema = get_object_gridschema(
        object_id=OBJECT_ID_BUILDING_AREA,
        project_revision_id=project_revision_id,
        override_units=override_units,
        parameter_type=parameter_type,
    )
    # HOTFIX: Custom overrides to properties
    if parameter_type == ParameterTypeEnum.instance:
        # PATCH: Override Type Mark to say Building ID
        schema["items"]["properties"]["TypeMark"]["name"] = "BuildingID"
        schema["items"]["properties"]["TypeMark"]["title"] = "Building ID"
        schema["items"]["properties"]["TypeMark"]["description"] = "Select the building to link the area to"
    if parameter_type == ParameterTypeEnum.type:
        # PATCH: Override template title for Project Building
        schema["items"]["title"] = "Project Buildings"
        schema["items"]["description"] = "Add any buildings that exist within the project"
        schema["datagrid_index_name"] = ("section", "title")
    # NOTE: We can remove these custom overrides once aectemplater set up to deal with `json_schema_extra`
    # We remove `anyOf` and set to `type`
    for _, property_ in schema["items"]["properties"].items():
        if "anyOf" in property_:
            for item in property_["anyOf"]:
                if item["type"] != "null":
                    type_ = item["type"]
            property_["type"] = type_
            property_.pop("anyOf")
    return schema



if __name__ == "__main__":
    gs = get_project_building_area_gridschema(project_revision_id=2, parameter_type=ParameterTypeEnum.type)
    print("types")
    print([k for k in gs["items"]["properties"].keys()])


if __name__ == "__main__":
    gs = get_project_building_area_gridschema(project_revision_id=2, parameter_type=ParameterTypeEnum.instance)
    print("instances")
    print([k for k in gs["items"]["properties"].keys()])


# +
BUILDING_BUTTONBAR_CONFIG = CrudView(
    images=CrudOptions(
        tooltip="Add images to selected Type Specification",
        tooltip_clicked="Go back to table",
        button_style="info",
        message="📷 <i>Add Images</i>",
    ),
    add=CrudOptions(
        tooltip="""Click to add Building data.
Input the data and then click save.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Building</i>",
    ),
    edit=CrudOptions(
        tooltip="""Select a row from the table and click to edit.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Building</i>",
    ),
    delete=CrudOptions(
        tooltip="""Select row(s) from the table and click to open deletion menu.
Click the red DELETE button to confirm deletion.
Once deleted, click again to close the menu.""",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Building</i>",
    ),
    io=CrudOptions(
            tooltip="import/export",
            tooltip_clicked="Go back to table",
            message="🔄 <i>Import / Export</i>",
    ),
    reload=CrudOptions(
        tooltip="Click to reload.",
        button_style="info",
        message="🔄 <i>Reload Building</i>",
    ),
    support=CrudOptions(
        tooltip="Show Help",
        tooltip_clicked="Go back to table",
        message="❔ <i>Help</i>",
    ),
)

BUILDING_AREA_BUTTONBAR_CONFIG = CrudView(
    add=CrudOptions(
        tooltip="""Click to add Building Area data.
Input the data and then click save.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Building Area</i>",
    ),
    edit=CrudOptions(
        tooltip="""Select a row from the table and click to edit.
Once saved, click again to close the menu.
""",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Building Area</i>",
    ),
    copy=CrudOptions(
        tooltip="""Select row(s) from the table and click to duplicate.""",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Duplicate Building Area</i>",
    ),
    delete=CrudOptions(
        tooltip="""Select row(s) from the table and click to open deletion menu.
Click the red DELETE button to confirm deletion.
Once deleted, click again to close the menu.""",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Building Area</i>",
    ),
    io=CrudOptions(
            tooltip="import/export",
            tooltip_clicked="Go back to table",
            message="🔄 <i>Import / Export</i>",
    ),
    reload=CrudOptions(
        tooltip="Click to reload.",
        button_style="info",
        message="🔄 <i>Reload Building Area</i>",
    ),
    support=CrudOptions(
        tooltip="Show Help",
        tooltip_clicked="Go back to table",
        message="❔ <i>Help</i>",
    ),
)
# -

COLUMN_WIDTHS_AREAS = {
    "('key', '', '')": 120,
    "('Identity Data', 'Type Spec Id', '')": 0.5,
    "('Identity Data', 'Id', '')": 0.5,
    "('Identity Data', 'Instance Reference', '')": 0.5,
    "('Identity Data', 'Construction Method', '')": 140,
    "('Dimensions', 'Gross Internal Area', 'm²')": 120,
    "('Application', 'Building Type', '')": 260,
    "('Identity Data', 'Building ID', '')": 90,
}


class BldgsGrid(TypeSpecGrid):
    @tr.observe("project_revision_id")
    def _set_project_data(self, onchange):
        if self.project_revision_id is not None:
            self._reload_datahandler()
            project_revision = get_project_revision_by_id(self.project_revision_id)
            self.ui_images.project_number = project_revision["project"]["project_number"]
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    @tr.observe("object_id")
    def _set_grid(self, onchange):
        if self.object_id is not None:
            schema = get_project_building_area_gridschema(
                project_revision_id=self.project_revision_id,
                override_units=self.override_units,
                parameter_type=ParameterTypeEnum.type,
            )
            self.update_from_schema(
                schema=schema,
                datahandler=DataHandler(
                    fn_get_all_data=self.get_type_specs,
                    fn_post=self.post_type_spec,
                    fn_patch=self.patch_type_spec,
                    fn_delete=self.delete_type_spec,
                    fn_copy=self.copy_type_spec,
                    fn_io=self.handle_crud
                ),
                ui_delete=TypeSpecDelete,
                ui_io=self.ui_io_class
            )
            self._set_styling()
            self._reload_all_data()
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    def __init__(self, order=ORDER_BLDGS_GRID, **kwargs):
        self.order = order
        kwargs = kwargs | {"object_id": OBJECT_ID_BUILDING_AREA}
        super().__init__(**kwargs)
        self.buttonbar_grid.crud_view = BUILDING_BUTTONBAR_CONFIG
        self.buttonbar_grid.imports.layout.display = "none"
        self.buttonbar_grid.copy.layout.display = "none"
        self.grid.layout.height = "120px"

    def _set_children(self):
        super()._set_children()
        self.stk_crud.children = [
            self.ui_images,
            self.ui_add,
            self.ui_edit,
            self.ui_delete,
        ]
        if self.show_ui_io and self.ui_io is not None:
            self.stk_crud.children = self.stk_crud.children + (self.ui_io,)
        self.children = [self.hbx_title_description, self.vbx_widget]
        self._remove_show_hide_nulls()

    def _remove_show_hide_nulls(self):
        self.ui_add.show_null = True
        self.ui_edit.show_null = True
        self.ui_add.bn_shownull.layout.display = "none"
        self.ui_edit.bn_shownull.layout.display = "none"

    def _hide_id_widgets(self):
        if self.ui_add.properties and self.ui_edit.properties:
            fields_to_hide = ["Id", "TypeReference", "Abbreviation"]
            # self.grid.order = self.order
            self.ui_add.order = [property_ for property_ in self.order if property_ not in fields_to_hide]
            self.ui_edit.order = [property_ for property_ in self.order if property_ not in fields_to_hide]

    def _reload_datahandler(self):
        self._reload_all_data()


# +
class AreasGrid(InstanceSpecGrid):
    @tr.observe("project_revision_id")
    def _set_project_data(self, onchange):
        if self.project_revision_id is not None:
            self._reload_datahandler()
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    @tr.observe("object_id")
    def _set_grid(self, onchange):
        if self.object_id is not None:
            schema = get_project_building_area_gridschema(
                project_revision_id=self.project_revision_id,
                override_units=self.override_units,
                parameter_type=ParameterTypeEnum.instance,
            )
            self.update_from_schema(
                schema=schema,
                datahandler=DataHandler(
                    fn_get_all_data=self.get_instance_specs,
                    fn_post=self.post_instance_spec,
                    fn_patch=self.patch_instance_spec,
                    fn_delete=self.delete_instance_spec,
                    fn_copy=self.copy_instance_spec,
                    fn_io=self.handle_crud
                ),
                ui_delete=InstanceSpecDelete,
                ui_io=self.ui_io_class
            )
            self._set_styling()
            self._set_col_widths()
            self._reload_all_data()
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    def __init__(
        self,
        order=ORDER_AREAS_GRID,
        **kwargs,
    ):
        self.order = order
        kwargs = kwargs | {"object_id": OBJECT_ID_BUILDING_AREA}
        super().__init__(**kwargs)
        self.buttonbar_grid.crud_view = BUILDING_AREA_BUTTONBAR_CONFIG
        self._remove_show_hide_nulls()
        self._hide_id_widgets()
        self.grid.layout.height = "300px"

    def _hide_id_widgets(self):
        if self.ui_add.properties and self.ui_edit.properties:
            fields_to_hide = ["InstanceReference", "Id", "TypeSpecId"]
            self.grid.order = self.order
            self.ui_add.order = [property_ for property_ in self.order if property_ not in fields_to_hide]
            self.ui_edit.order = [property_ for property_ in self.order if property_ not in fields_to_hide]

    def _set_children(self):
        super()._set_children()
        self._remove_show_hide_nulls()

    def _set_col_widths(self):
        self.grid.column_widths = COLUMN_WIDTHS_AREAS

    def _remove_show_hide_nulls(self):
        self.ui_add.show_null = True
        self.ui_edit.show_null = True
        self.ui_add.bn_shownull.layout.display = "none"
        self.ui_edit.bn_shownull.layout.display = "none"

    def _update_building_options(self, onchange=None):
        """Check type marks in buildings grid match dropdown for Building ID."""
        if self.project_revision_id is not None:
            project_building_types = list(
                get_project_type_marks(self.project_revision_id, OBJECT_ID_BUILDING_AREA).keys()
            )
            self.ui_add.di_widgets["TypeMark"].options = project_building_types
            self.ui_edit.di_widgets["TypeMark"].options = project_building_types

    def _reload_datahandler(self, onchange=None):
        self._update_building_options()
        self._reload_all_data()

    def post_instance_spec(self, value: dict):
        from aectemplater_ui.apps.operational_energy_target import post_missing_building_types

        super().post_instance_spec(value)
        post_missing_building_types(project_revision_id=self.project_revision_id, override_units=self.override_units)

if __name__ == "__main__":
    agr = AreasGrid()
    display(agr)
    agr.project_revision_id = 2


# -
class ProjectBuildings(w.VBox):
    project_revision_id = tr.Integer(default_value=None, allow_none=True)

    @tr.observe("project_revision_id")
    def _set_grids(self, onchange):
        self.gr_bldgs.project_revision_id = self.project_revision_id
        self.gr_areas.project_revision_id = self.project_revision_id
        self.gr_bldgs.fn_reload = self.gr_areas._reload_datahandler

    def __init__(self, **kwargs):
        self.gr_bldgs = BldgsGrid(show_ui_io=True, ui_io=TypeSpecIO, by_alias=True)
        self.gr_areas = AreasGrid(show_ui_io=True, ui_io=InstanceSpecIO, by_alias=True)
        super().__init__(
            [
                w.HTML("<h2>Add Project Buildings</h2>"),
                self.gr_bldgs,
                w.HTML("<h2>Add Project Building Use Type Areas</h2>"),
                w.HTML("Select a building above to load the associated area data"),
                self.gr_areas,
            ]
        )
        self.gr_bldgs.grid.observe(self.gr_areas._reload_datahandler, "count_changes")


if __name__ == "__main__":
    project_buildings = ProjectBuildings()
    display(project_buildings)
    project_buildings.project_revision_id = 2






