"""Pydantic environment config class for the user interface.

Reference:
    https://pydantic-docs.helpmanual.io/usage/settings/#dotenv-env-support
"""

import logging
import pathlib
import typing as ty

from pydantic import Field, ValidationInfo, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from aectemplater_ui.constants import FDIR_ROOT

FPTH_UI_DEV_ENV = FDIR_ROOT / "ui-dev.env"
FDIR_AECTEMPLATER_UI = pathlib.Path(__file__).parent


class UiEnv(BaseSettings):
    AECTEMPLATER_CNAME: str = Field(..., description="tells UI where to query the API")
    AECTEMPLATER_PROJECT_NUMBER: int = 5003
    AECSCHEDULE_PROJECT_NUMBER: int = 5001
    DEFAULT_PROJECT_REVISION: str = "current"
    AECTEMPLATER_FDIR_APPDATA: pathlib.Path = Field(
        ...,
        description=(
            "output dir for template files. This can be on the J:\\drive as it used by the UI rather than the API."
        ),
    )
    AECTEMPLATER_FDIR_EXPORTS: pathlib.Path = Field(
        ...,
        description=(
            "output dir for exported files. This can be on the J:\\drive as it used by the UI rather than the API."
        ),
    )
    AECTEMPLATER_FDIR_SYMBOLS: pathlib.Path = Field(..., description="file path to symbols directory")
    AECTEMPLATER_FDIR_PROJECTS_ROOT: pathlib.Path = Field(..., description="file path to projects root directory")
    AECTEMPLATER_FPTH_EXTRA_ABBREVIATIONS: ty.Optional[pathlib.Path] = Field(
        description="File path to extra abbreviations"
    )
    AECTEMPLATER_ORG: str = Field(..., description="Organisation abbreviation")
    AECSCHEDULE_GET_FDIR_PROJECT: ty.Literal["{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}"] = Field(
        "{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}",
        description="Function to get project directory",
    )
    AECSCHEDULE_GET_FDIR_PROJECT_IMAGES: ty.Literal[
        "{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}/Schedule/images"
    ] = Field(
        "{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}/Schedule/images",
        description="Function to get project images directory",
    )  # TODO: Update this environment variable when we move away from J Drive
    AECSCHEDULE_GET_FPTH_PROJECT_SCHEDULE: ty.Literal[
        "{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}/Schedule/{document_code}.pdf"
    ] = Field(
        "{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}/Schedule/{document_code}.pdf",
        description="Function to get project schedule file path",
    )
    AECSCHEDULE_GET_FDIR_BUILD_PROJECT_SCHEDULE: ty.Literal[
        "{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}/Schedule/build/{document_code}"
    ] = Field(
        "{AECTEMPLATER_FDIR_PROJECTS_ROOT}/J{project_number}/Schedule/build/{document_code}",
        description="Function to get project directory for building schedule",
    )
    IPYAUTOUI_ROOTDIR: ty.Optional[pathlib.Path]
    JUPYTERHUB_USER: ty.Optional[str]

    @model_validator(mode="after")
    def _model_validator(self):
        # Any relative paths will be set to absolute paths
        for k, v in self.__dict__.items():
            if isinstance(v, pathlib.Path):
                setattr(self, k, v.resolve())
        return self

    @field_validator("AECTEMPLATER_FDIR_APPDATA")
    @classmethod
    def _AECTEMPLATER_FDIR_APPDATA(cls, v):
        try:
            if not v.is_dir():
                v.mkdir(exist_ok=True)
        except Exception as err:
            logging.warning(err)
        return v

    @field_validator("AECTEMPLATER_FDIR_EXPORTS")
    @classmethod
    def _AECTEMPLATER_FDIR_EXPORTS(cls, v):
        try:
            if not v.is_dir():
                v.mkdir(exist_ok=True)
        except Exception as err:
            logging.warning(err)
        return v

    @field_validator("AECTEMPLATER_FDIR_PROJECTS_ROOT")
    def _AECTEMPLATER_FDIR_PROJECTS_ROOT(cls, v, info: ValidationInfo):
        values = info.data
        try:
            if not v.is_dir():
                v.mkdir(exist_ok=True)
            # Ensure that the project directories exist
            FDIR_AECTEMPLATER_PROJECT = v / f"J{values['AECTEMPLATER_PROJECT_NUMBER']}"
            FDIR_AECSCHEDULE_PROJECT = v / f"J{values['AECSCHEDULE_PROJECT_NUMBER']}"
            if not FDIR_AECTEMPLATER_PROJECT.exists():
                FDIR_AECTEMPLATER_PROJECT.mkdir(exist_ok=True)
            if not FDIR_AECSCHEDULE_PROJECT.exists():
                FDIR_AECSCHEDULE_PROJECT.mkdir(exist_ok=True)
        except Exception as err:
            logging.warning(err)
        return v.resolve()

    model_config = SettingsConfigDict(env_file=FPTH_UI_DEV_ENV, env_file_encoding="utf-8")


if __name__ == "__main__":
    env = UiEnv()
