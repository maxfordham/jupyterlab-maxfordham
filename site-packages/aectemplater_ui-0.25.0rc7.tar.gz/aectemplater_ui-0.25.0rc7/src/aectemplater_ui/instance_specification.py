import logging
import ipywidgets as w
import pandas as pd
import typing as ty
import traitlets as tr
from IPython.display import display, Markdown
from ipydatagrid import TextRenderer, Expr
import numpy as np

from pyuniclass import UT
from ipyautoui.constants import (
    BUTTON_WIDTH_MIN,
    HELP_BUTTON_KWARGS,
)
from ipyautoui.custom.buttonbars import CrudButtonBar, CrudOptions, CrudView
from ipyautoui.custom.editgrid import EditGrid, DataHandler, UiDelete
from ipyautoui.custom.edittsv import Changes
from ipyautoui.custom.edittsv_with_diff_and_key_mapping import EditTsvWithDiffAndKeyMapping
from aectemplater_schemas.tag_template import (
    Mark,
    InstanceTagTemplate,
    InstanceTagData,
    TypeTagData,
)
from aectemplater_client import (
    delete_instance_spec,
    get_instance_tag_template_by_id,
    get_object_by_id,
    get_project_revision_by_project_number_and_revision,
    get_type_tag_data,
    get_type_spec_id_by_type_mark,
    get_instance_specs_marks,
    get_instance_specs_object_data_grid,
    post_instance_spec_data,
    patch_instance_spec_data,
    get_object_gridschema,
)

from aectemplater_ui import ENV
from aectemplater_ui.formatting import HEADER_BACKGROUND_COLOUR, GRID_STYLE, create_vega_expression
from aectemplater_ui.utils import (
    is_nan,
)

logger = logging.getLogger(__name__)
logging.getLogger().setLevel(logging.ERROR)

DEFAULT_GRID_STYLE = {"header_background_color": "rgb(230, 230, 230)"}
RELOAD_BUTTON_KWARGS = dict(
    icon="sync",
    style={},
    button_style="info",
    tooltip="reload",
    layout={"width": BUTTON_WIDTH_MIN},
    disabled=False,
)
UNICLASS_LIST = UT.Pr.data.description.to_list()
OVERRIDE_UNITS = True


# +
def get_mark_from_grid(instance_tag_template: InstanceTagTemplate, type_tag_data: TypeTagData, value: dict) -> str:
    """Get Marks from the grid value where the keys are the property IDs."""
    value = {k: i for k, i in value.items() if not is_nan(i)}
    instance_tag_data = InstanceTagData(**type_tag_data, instance_reference=value["InstanceReference"]).model_dump()
    if "VolumeReference" in value.keys() and value["VolumeReference"] is not None:
        instance_tag_data["volume_reference"] = value["VolumeReference"]
    if str("LevelReference") in value.keys() and value["LevelReference"] is not None:
        instance_tag_data["level_reference"] = value["LevelReference"]
    return Mark(
        template=instance_tag_template,
        tag_data=instance_tag_data,
    ).mark


def get_marks_from_grid_selected_cols(
    instance_tag_template: InstanceTagTemplate, selected_cols: list[dict]
) -> list[str]:
    """Get the Marks from the grid selected columns."""
    unique_type_spec_ids = set([col["TypeSpecId"] for col in selected_cols])
    map_type_tag_data = {type_spec_id: get_type_tag_data(type_spec_id) for type_spec_id in unique_type_spec_ids}
    return [
        get_mark_from_grid(
            instance_tag_template=instance_tag_template, type_tag_data=map_type_tag_data[col["TypeSpecId"]], value=col
        )
        for col in selected_cols
    ]


# +
BUTTONBAR_CONFIG_INSTANCES = CrudView(
    add=CrudOptions(
        tooltip="Add Instance Specification",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Instance Specification</i>",
    ),
    edit=CrudOptions(
        tooltip="Edit Selected Instance Specification",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Instance Specification</i>",
    ),
    copy=CrudOptions(
        tooltip="Copy Selected Instance Specifications",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="📝 <i>Copy Instance Specification</i>",
    ),
    delete=CrudOptions(
        tooltip="Delete Selected Instance Specifications",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Instance Specifications</i>",
    ),
    io=CrudOptions(
            tooltip="import/export",
            tooltip_clicked="Go back to table",
            message="🔄 <i>Import / Export</i>",
    ),
    reload=CrudOptions(
        tooltip="Reload Instance Specifications",
        button_style="info",
        message="🔄 <i>Reloaded Instance Specifications</i>",
    ),
    support=CrudOptions(
        **dict(HELP_BUTTON_KWARGS)
        | dict(
            tooltip="help - click to show description of all buttons in the toolbar",
            tooltip_clicked="Hide help dialogue",
            message="❔ <i>Help Selected</i>",
        )
    ),
)


class CrudButtonBarInstances(CrudButtonBar):
    def __init__(
        self,
        show_io: bool = False,
        **kwargs,
    ):

        self._init_form()
        super().__init__(
            **kwargs
            | {
                "show_support": True,
                "crud_view": BUTTONBAR_CONFIG_INSTANCES,
                "show_io": show_io,
            }
        )
        self.out = w.Output()
        self.hbx_bbar = w.HBox(
            [
                self.add,
                self.edit,
                self.copy,
                self.delete,
                self.io,
                self.reload,
                self.support,
                self.message,
            ]
        )
        self.children = [self.hbx_bbar, self.out]
        self._init_controls()

    def _add(self, onchange):
        self._onclick("add")


if __name__ == "__main__":
    display(CrudButtonBarInstances())


# -


class InstanceSpecDelete(UiDelete):
    marks = tr.List(tr.Unicode(), allow_none=True)

    @tr.observe("marks")
    def observe_marks(self, on_change):
        self._update_display()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.message.value = (
            "⚠️<b>Are you sure you want to delete the following Instances?</b>⚠️<br><i>Pressing the DELETE button will"
            " permanently delete the selected Instances!</i>"
        )

    @property
    def value_summary(self):
        """Get the summary of the selected Instance Specifications."""
        summary = f"<i>{', '.join(self.marks)}</i>"
        return Markdown(summary)


class InstanceSpecGrid(EditGrid):
    """UI element to add, edit, copy, and delete Instance Specifications."""

    object_id = tr.Integer(default_value=None, allow_none=True)
    project_revision_id = tr.Integer(default_value=None, allow_none=True)
    exclude_fields_from_model = tr.List(
        default_value=["Id", "TypeSpecId"],
    )

    @tr.observe("object_id", "project_revision_id")
    def _set_grid(self, onchange):
        if self.object_id is not None and self.project_revision_id is not None:
            schema = get_object_gridschema(
                project_revision_id=self.project_revision_id,
                object_id=self.object_id,
                override_units=self.override_units,
                parameter_type="I",
            )
            self.update_from_schema(
                schema=schema,
                datahandler=DataHandler(
                    fn_get_all_data=self.get_instance_specs,
                    fn_post=self.post_instance_spec,
                    fn_patch=self.patch_instance_spec,
                    fn_delete=self.delete_instance_spec,
                    fn_copy=self.copy_instance_spec,
                    fn_io=self.handle_crud,
                ),
                ui_delete=InstanceSpecDelete,
                ui_io=self.ui_io_class
            )
            self._set_styling()
            self._reload_all_data()
            self.observe(self._set_headers, "count_changes")
        else:
            self.update_from_schema(schema=None)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        df = pd.DataFrame(value).replace({np.nan: None})
        data = self.grid._init_data(df)
        if len(data) > 0:
            data = data.dropna(how="all", axis=1)
        # ^ show only data that is populated by at least 1 item
        self.grid.data = data

        # HOTFIX: Setting data creates bugs out transforms currently so reset transform applied
        _transforms = self.grid._transforms
        self.grid.transform([])  # Set to no transforms
        self.grid.transform(_transforms)  # Set to previous transforms

    @property
    def selected_marks(self):
        return get_marks_from_grid_selected_cols(
            instance_tag_template=self.instance_tag_template,
            selected_cols=self.grid.selected_cols,
        )

    def delete_rows(self, deletions: list[int | str]) -> None:
        for id_ in deletions:
            id_dict = {
                "Id": int(id_)
            }
            self.delete_instance_spec(id_dict)

    def edit_rows(self, edits: dict[str | int, dict]) -> None:
        for key, value in edits.items():
            value_dict = {
                "Id": key
            }
            value_dict.update(value)
            self.patch_instance_spec(value_dict)

    def add_rows(self, additions: list[dict]) -> None:
        for addition in additions:
            addition.pop("TypeSpecId", None)
            self.post_instance_spec(addition)

    def handle_crud(self, changes: Changes):
        resolved_changes = self.ui_io._resolve_composite_to_ids(changes, self.key_to_id_map)
        if resolved_changes.deletions:
            self.delete_rows(resolved_changes.deletions)
        if resolved_changes.additions:
            self.add_rows(resolved_changes.additions)
        if resolved_changes.edits:
            self.edit_rows(resolved_changes.edits)
        self._reload_all_data()

    def __init__(
        self,
        override_units: bool = OVERRIDE_UNITS,
        fn_reload: ty.Callable = lambda: logger.info("reload"),
        **kwargs,
    ):
        self.fn_reload = fn_reload
        self.override_units = override_units
        datahandler = DataHandler(
            fn_get_all_data=self.get_instance_specs,
            fn_post=self.post_instance_spec,
            fn_patch=self.patch_instance_spec,
            fn_delete=self.delete_instance_spec,
            fn_copy=self.copy_instance_spec,
            fn_io=self.handle_crud,
        )
        self.ui_io_class = kwargs.get("ui_io")
        super().__init__(
            datahandler=datahandler,
            transposed=False,
            grid_style=GRID_STYLE,
            ui_delete=InstanceSpecDelete,
            warn_on_delete=True,
            layout=w.Layout(height="800px"),
            **kwargs,
        )

        self._init_value()
        self._set_controls()

    def _refresh_io_widget(self):
        if not hasattr(self, "ui_io") or self.ui_io is None:
            return
        if hasattr(self.ui_io, "value") and type(self.ui_io.value) is list:
            self.ui_io.value = [
                {k: v for k, v in d.items() if k not in ("Id", "TypeSpecId")}
                for d in (self.value or [])
            ]
            self.ui_io.upload_status = "None"

    def fn_upload(self, value):
        if self.ui_io is not None:
            self.datahandler.fn_io(self.ui_io.changes)

    def _io(self):
        ui_io = self._ensure_ui_io_initialised()
        if ui_io is None:
            return
        ui_io.value = [
            {k: v for k, v in d.items() if k not in ("Id", "TypeSpecId")}
            for d in (self.value or [])
        ]
        ui_io.upload_status = "None"

    def _init_value(self):
        self.value = self.get_instance_specs()
        self.ui_add_default_value = self.ui_add.value
        self.ui_add.savebuttonbar.fns_onrevert_add_action(self._set_ui_add_default)

    def _init_form(self):
        self.stk_crud = w.Stack(children=[self.ui_add, self.ui_edit, self.ui_copy, self.ui_delete])
        self.buttonbar_grid = CrudButtonBarInstances(
            fn_add=self._add,
            fn_edit=self._edit,
            fn_copy=self._copy,
            fn_delete=self._delete,
            fn_io=self._io,
            show_io=self.show_ui_io,
        )
        self.hbx_bar = w.HBox([self.buttonbar_grid])

    def _set_children(self):
        self.vbx_widget.children = [
            self.hbx_bar,
            self.stk_crud,
            self.grid,
        ]
        self.stk_crud.children = [
            self.ui_add,
            self.ui_edit,
            self.ui_copy,
            self.ui_delete,
        ]
        if self.show_ui_io and self.ui_io is not None:
            self.stk_crud.children = self.stk_crud.children + (self.ui_io,)
        self.children = [self.hbx_title_description, self.vbx_widget]
        self._hide_id_widgets()
        self._set_controls()
        self.ui_delete.layout.display = (
            "flex"  # HOTFIX: Resolves issue where warn_on_delete not appearing following re-instantiation
        )

    def _set_controls(self):
        self.grid.observe(self._set_headers, "count_changes")
        self.grid.observe(self._set_mark, "selections")

    def _set_styling(self):
        self._set_headers()
        self._set_col_widths()
        self._set_instance_tag_template()

    def _reload_datahandler(self):
        schema = get_object_gridschema(
            object_id=self.object_id,
            override_units=self.override_units,
            project_revision_id=self.project_revision_id,
            parameter_type="I",
        )
        if schema != self.schema:
            self.update_from_schema(
                schema=schema,
                datahandler=self.datahandler,
                ui_delete=InstanceSpecDelete,
                ui_io=self.ui_io_class,
            )
            self._set_styling()
        self._reload_all_data()

    def _reload_all_data(self):
        self.value = self.datahandler.fn_get_all_data()
        # Build mapping for CRUD translation
        if getattr(self, "ui_io", None) and hasattr(self.ui_io, "_build_composite_key_to_id_map"):
            self.key_to_id_map = self.ui_io._build_composite_key_to_id_map(self.value)
        self.fn_reload()
        self._refresh_io_widget()

    def _setview(self, onchange):
        super()._setview(onchange)
        if self.buttonbar_grid.active == "io":
            ui_io = self._ensure_ui_io_initialised()
            if ui_io:
                self.key_to_id_map = self.ui_io._build_composite_key_to_id_map(self.value)

    def get_instance_specs(self):
        if self.object_id is not None and self.project_revision_id is not None:
            instance_spec = get_instance_specs_object_data_grid(
                project_revision_id=self.project_revision_id,
                object_id=self.object_id,
                override_units=self.override_units,
            )
            return instance_spec["data"]
        else:
            return []

    def post_instance_spec(self, value: dict):
        try:
            type_spec_id = get_type_spec_id_by_type_mark(
                project_revision_id=self.project_revision_id, object_id=self.object_id, type_mark=value["TypeMark"]
            )
        except Exception as err:
            self.buttonbar_grid.message.value = str(err)
            raise Exception(err)
        try:
            return post_instance_spec_data(
                type_spec_id=type_spec_id,
                value=value,
                override_units=self.override_units,
            )
        except Exception as err:
            self.buttonbar_grid.message.value = str(err)
            raise Exception(err)

    def patch_instance_spec(self, value: dict):
        try:
            value = {k: None if is_nan(v) else v for k, v in value.items()}
            return patch_instance_spec_data(
                instance_spec_id=value["Id"], value=value, override_units=self.override_units
            )
        except Exception as err:
            self.buttonbar_grid.message.value = str(err)
            raise Exception(err)

    def delete_instance_spec(self, value: dict):
        return delete_instance_spec(instance_spec_id=value["Id"])

    def copy_instance_spec(self, value: dict):
        value = {k: None if is_nan(v) else v for k, v in value.items()}
        return post_instance_spec_data(
            type_spec_id=value["TypeSpecId"],
            value=value,
            override_units=self.override_units,
        )

    def _set_col_widths(self):
        self.grid.base_column_size = 120
        self.grid.column_widths = {
            "('key', '', '')": 120,
            "('Identity Data', 'Type Spec Id', '')": 0.5,
            "('Identity Data', 'Id', '')": 0.5,
        }

    def _set_mark(self, on_change=None):
        if self.grid.selected_index is not None:
            self.ui_delete.marks = self.selected_marks
        else:
            self.marks = []

    def _set_instance_tag_template(self):
        object_summary = get_object_by_id(self.object_id)
        self.instance_tag_template = get_instance_tag_template_by_id(object_summary["instance_tag_template_id"])

    def _set_headers(self, on_change=None):
        # NOTE: the renderer needs to be updated on change so the key/index can show the mark.
        #       this therefore get's called on change of the grid
        marks = get_instance_specs_marks(instance_spec_ids=[v["Id"] for v in self.value if isinstance(v["Id"], int)])
        renderer = create_vega_expression(di={idx: mark for idx, mark in enumerate(marks)})
        self.grid.renderers = {
            ('key', '', ''): TextRenderer(background_color=HEADER_BACKGROUND_COLOUR, text_value=Expr(renderer))
        }

    def _set_ui_add_default(self):
        self.ui_add.value = self.ui_add_default_value  # ui_add_default_value defined straight after init

    def _hide_id_widgets(self):
        self.ui_add.order = [
            property_ for property_ in self.ui_add.default_order if property_ not in ['TypeSpecId', 'Id']
        ]
        self.ui_edit.order = [
            property_ for property_ in self.ui_edit.default_order if property_ not in ['TypeSpecId', 'Id']
        ]


class InstanceSpecIO(EditTsvWithDiffAndKeyMapping):
        def __init__(self, **kwargs):
            kwargs = kwargs | {"primary_key_name": ["TypeMark", "InstanceReference"], "exclude_fields_from_model": ["TypeSpecId", "Id"], "filename_suffix": "-Instances"}  # noqa: E501
            super().__init__(**kwargs)


if __name__ == "__main__":
    DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
        project_number=ENV.AECTEMPLATER_PROJECT_NUMBER, revision=ENV.DEFAULT_PROJECT_REVISION
    )["id"]
    gr = InstanceSpecGrid(show_ui_io=True, project_revision_id=DEFAULT_PROJECT_REVISION_ID, object_id=3, ui_io=InstanceSpecIO, by_alias=True)  # noqa: E501
    display(gr)



