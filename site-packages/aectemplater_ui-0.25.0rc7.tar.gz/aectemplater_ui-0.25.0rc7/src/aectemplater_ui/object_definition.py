import typing
import ipywidgets as w
import pandas as pd
from markdown import markdown
from IPython.display import display

# +
from aectemplater_client import get_object_unique_name, get_pset_unique_name

from aectemplater_ui.object import ObjectsGrid
from aectemplater_ui.object_pset import ObjectPreview
from aectemplater_ui.propertysets import PropertySetsGrid
from aectemplater_ui.properties import PropertiesGrid
from aectemplater_ui.units import UnitsGrid, RevitDefaultUnitsGrid
from aectemplater_ui.pset_property import PsetPropertyUi
from aectemplater_ui.utils import ENV, stretch_tab_widths

stretch_tab_widths()
# -


AECTEMPLATER_FDIR_EXPORTS = ENV.AECTEMPLATER_FDIR_EXPORTS
ACC_TITLES = (
    "Data Templates",
    "Assign Property Sets to Templates",
    "Property Sets",
    "Assign Properties to Property Sets",
    "Properties",
    "Units",
    "Default Units",
)


# + tags=["remove-input"]
class ObjectDefinition(w.Tab):
    def __init__(self):
        super().__init__()
        self._init_ui()
        self._init_titles()
        self._init_controls()

    def _init_controls(self):
        self.object.buttonbar_grid.edit_psets.on_click(self._show_object_pset)
        self.pset.buttonbar_grid.edit_properties.on_click(self._show_pset_property)
        self.object.grid.observe(self._set_object_pset, "selections")
        self.pset.grid.observe(self._set_pset_property, "selections")
        self.observe(self._reload, "selected_index")

    def _init_ui(self):
        """Instantiate UI elements and set children."""
        self.unit = UnitsGrid()
        self.property = PropertiesGrid()
        self.pset = PropertySetsGrid()
        self.pset_property = PsetPropertyUi()
        self.object_pset = ObjectPreview()
        self.object = ObjectsGrid()
        self.children = [
            self.object,
            self.object_pset,
            self.pset,
            self.pset_property,
            self.property,
            self.unit,
            RevitDefaultUnitsGrid(),
        ]

    def _init_titles(self):
        """Set titles in tabs."""
        [self.set_title(n, nm) for n, nm in enumerate(ACC_TITLES)]

    def _set_object_pset(self, onchange=None):
        if (
            self.object.grid.selected
            and get_object_unique_name(self.object.grid.selected["id"])
            in self.object_pset.object_select.cmbx.widget.options
        ):
            self.object_pset.object_select._load()
            self.object_pset.object_select.cmbx.value = self.object.selected_unique_name

    def _set_pset_property(self, onchange=None):
        if (
            self.pset.grid.selected
            and get_pset_unique_name(self.pset.grid.selected["id"])
            in self.pset_property.gr_select.cmbx_psets.widget.options
        ):
            self.pset_property.gr_select._load_psets()
            self.pset_property.gr_select.cmbx_psets.value = self.pset.selected_unique_name

    def _show_object_pset(self, onchange=None):
        self.object.buttonbar_grid.message.value = ""
        if self.object.grid.selected:
            custodian = self.object.grid.selected["custodian"]
            if custodian != ENV.AECTEMPLATER_ORG:
                self.object.buttonbar_grid.message.value = (
                    f"❌ <i>Only allowed to edit Data Templates where custodian is {ENV.AECTEMPLATER_ORG}.</i>"
                )
            else:
                self._set_object_pset()
                self.selected_index = self.children.index(self.object_pset)  # Change view to Object Pset view

    def _show_pset_property(self, onchange=None):
        self.pset.buttonbar_grid.message.value = ""
        custodian = self.pset.grid.selected["custodian"]
        if custodian != ENV.AECTEMPLATER_ORG:
            self.pset.buttonbar_grid.message.value = (
                f"❌ <i>Only allowed to edit Property Sets where custodian is {ENV.AECTEMPLATER_ORG}.</i>"
            )
        else:
            self._set_pset_property()
            self.selected_index = self.children.index(self.pset_property)  # Change view to Pset Property view

    def _reload(self, onchange=None):
        if self.selected_index == 1:
            self.object_pset.object_select._load()
            self.object_pset.pset_select._load()
        elif self.selected_index == 3:
            self.pset_property.gr_all._load()
            self.pset_property.gr_select._load()


# -

if __name__ == "__main__":
    ui = ObjectDefinition()
    display(ui)
