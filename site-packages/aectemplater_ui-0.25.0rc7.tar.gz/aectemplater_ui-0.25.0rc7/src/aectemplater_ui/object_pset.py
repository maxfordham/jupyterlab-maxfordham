# +
import ipywidgets as w
import traitlets as tr
import typing as ty
import pandas as pd
import numpy as np
from IPython.display import display

from ipyautoui.custom.buttonbars import SaveButtonBar
from ipyautoui.custom.combobox_mapped import ComboboxMapped
from ipyautoui.constants import BUTTON_WIDTH_MIN
from aectemplater_client import (
    delete_psets_from_object,
    get_object_schema_preview,
    get_object_unique_name,
    get_objects_unique_names,
    get_psets_by_object,
    get_psets_unique_names,
    post_and_patch_object_order,
    post_psets_to_object,
)

from aectemplater_ui import ENV
from aectemplater_ui.constants import DES_OBJECT_PSET
from aectemplater_ui.object import ObjectPropertiesGrid, column_names, column_order
from aectemplater_ui.object_property import ObjectPropertyForm, ObjectPropertyFormSchema
from aectemplater_ui.utils import HandleOptions
import logging

logger = logging.getLogger(__name__)

# -
class ObjectPsetsSelect(HandleOptions, w.VBox):
    description = tr.Unicode()
    _value = tr.Dict(
        per_key_traits={"allowed_values": tr.List()},
        default_value={"allowed_values": []},
    )
    object_id = tr.Int()

    @tr.observe("object_id")
    def _object_id(self, on_change):
        self._set_psets()
        self.bbar.unsaved_changes = False

    @property
    def object_psets(self):
        return get_psets_by_object(self.object_id)

    @property
    def selected_psets(self):
        return [int(self.options_[name]) for name in self.allowed_values.value]

    def __init__(self, **kwargs):
        WIDTH = "150px"
        self.bbar = SaveButtonBar()
        self.bbar.fns_onrevert_add_action(self._revert_changes)
        self.bbar.fns_onsave_add_action(self._save)
        self.allowed_values = w.TagsInput(allow_duplicates=False, **kwargs)
        self._load()
        super().__init__(
            [
                self.bbar,
                self.allowed_values,
            ],
            **kwargs,
        )
        self.allowed_values.observe(self._set_unsaved_changes)
        {setattr(self, k, v) for k, v in kwargs.items()}

    def _load(self):
        self.options = get_psets_unique_names(custodian=ENV.AECTEMPLATER_ORG) | get_psets_unique_names(custodian="BSDD")
        self.allowed_values.allowed_tags = list(self.options.values())

    def _save(self):
        object_pset_ids = [object_pset["pset_id"] for object_pset in self.object_psets]
        new_object_pset_ids = [int(self.options_[value]) for value in self.allowed_values.value]
        post_psets_to_object(
            object_id=self.object_id, value=[id_ for id_ in new_object_pset_ids if id_ not in object_pset_ids]
        )
        delete_psets_from_object(
            object_id=self.object_id, value=[id_ for id_ in object_pset_ids if id_ not in new_object_pset_ids]
        )

    def _set_psets(self):
        pset_ids = [object_pset["pset_id"] for object_pset in self.object_psets]
        self.allowed_values.value = [self.options[str(pset_id)] for pset_id in pset_ids]

    def _set_unsaved_changes(self, onchange):
        self.bbar.unsaved_changes = True

    def _revert_changes(self):
        self._set_psets()
        self.bbar.unsaved_changes = False


if __name__ == "__main__":
    object_pset = ObjectPsetsSelect(object_id=3)
    display(object_pset)

if __name__ == "__main__":
    object_pset.object_id = 3


# +
class ObjectPropertiesPreviewGrid(ObjectPropertiesGrid):
    pset_ids = tr.List(tr.Int())

    @tr.observe("pset_ids")
    def _set_properties(self, on_change):
        self._load()

    @property
    def selected_property_id(self):
        if self.selected_cell_values:
            id_idx = self.column_names.index("Id")
            return self.selected_cell_values[id_idx]

    def __init__(self, **kwargs):
        super().__init__(selection_mode="row", **kwargs)

    def get_data(self) -> pd.DataFrame:
        """Get the Object properties dataframe."""
        if self.object_id == 0:
            df = pd.DataFrame([""] * len(column_names), index=column_names)
        else:
            object_schema = get_object_schema_preview(
                object_id=self.object_id, pset_ids=self.pset_ids, override_units=True
            )
            df = pd.DataFrame(object_schema["properties"])
        df = df.rename(index=column_names)
        df = df.reindex(column_names.values())
        df = df.T  # Transpose so each property is a row
        df = df.reset_index(drop=True)  # Remove property names from index
        df = df.replace(np.nan, None)  # Replace NaN values with None
        return df


if __name__ == "__main__":
    grid = ObjectPropertiesPreviewGrid(object_id=3, pset_ids=[1, 2])
    display(grid)

if __name__ == "__main__":
    grid.pset_ids = [2]


# +
# TODO: This most definitely can be moved to ipyautoui.
# This is modified from CrudButtonBar, but we could make an abstract class that inherits
from ipyautoui.custom.buttonbars import (
    CrudOptions,
    EDIT_BUTTON_KWARGS,
    RELOAD_BUTTON_KWARGS,
    TOGGLEBUTTON_ONCLICK_BORDER_LAYOUT,
)

view = dict(
    edit=CrudOptions(
        tooltip="Assign Property Sets to Object",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Assign Property Sets</i>",
    ),
    override=CrudOptions(
        tooltip="Override Properties in an Object",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Override Properties</i>",
    ),
    order=CrudOptions(
        tooltip="Order Properties in an Object",
        tooltip_clicked="Go back to table",
        button_style="primary",
        message="↕ <i>Order Properties</i>",
    ),
)


class ButtonBar(w.HBox):
    active = tr.Unicode(default_value=None, allow_none=True)
    view = tr.Dict(default_value=view)
    fn_backward = tr.Callable(default_value=lambda: logger.info("backward"))
    fn_reload = tr.Callable(default_value=lambda: logger.info("reload"), allow_none=True)

    @tr.observe("view")
    def _observe_view(self, change):
        self._set_view_options()

    @property
    def active_index(self):
        if self.active is None:
            return None
        else:
            return list(self.view.keys()).index(self.active)

    def __init__(
        self,
        **kwargs,
    ):
        self._init_form()
        super().__init__(**kwargs)  # main container
        self.out = w.Output()
        self.children = [
            self.edit,
            self.override,
            self.order,
            self.reload,
            self.message,
        ]
        self._init_controls()

    def _init_form(self):
        self.edit = w.ToggleButton(**EDIT_BUTTON_KWARGS)
        self.edit.icon = "cubes"
        self.override = w.ToggleButton(**EDIT_BUTTON_KWARGS)
        self.order = w.ToggleButton(**{'disabled': False, 'layout': {'width': '44px'}, 'style': {}, 'icon': 'sort'})
        self.reload = w.Button(**RELOAD_BUTTON_KWARGS)
        self.reload.tooltip = "Clear current selection"
        self.message = w.HTML()
        self._set_view_options()

    def _init_controls(self):
        self.edit.observe(self._edit, "value")
        self.override.observe(self._override, "value")
        self.order.observe(self._order, "value")
        self.reload.on_click(self._reload)

    def _onclick(self, button_name):
        w = getattr(self, button_name)
        if w.value:
            self.reset_toggles_except(button_name)
            self.active = button_name
            w.tooltip = self.view[button_name]["tooltip_clicked"]
            w.layout.border = TOGGLEBUTTON_ONCLICK_BORDER_LAYOUT
            self.message.value = self.view[button_name]["message"]
        else:
            self.active = None
            w.tooltip = self.view[button_name]["tooltip"]
            w.layout.border = None
            self.message.value = ""
            self.fn_backward()

    def _edit(self, onchange):
        self._onclick("edit")

    def _override(self, onchange):
        self._onclick("override")

    def _order(self, onchange):
        self._onclick("order")

    def _set_view_options(self):
        for button_name in self.view.keys():
            w = getattr(self, button_name)
            for k, v in self.view[button_name].items():
                if k in dir(w):
                    setattr(w, k, self.view[button_name][k])

    def reset_toggles_except(self, name=None):
        names = self.view.keys()
        if name is None:
            names = names
        elif name not in names:
            raise ValueError(f"`name` must be in {str(names)}. {name} given")
        names = [n for n in names if n != name]
        for n in names:
            setattr(getattr(self, n), "value", False)

    def _reload(self, on_click):
        self.fn_reload()


if __name__ == "__main__":
    bbar = ButtonBar()
    display(bbar)


# +
class ObjectSelectBar(w.HBox):
    def __init__(self, **kwargs):
        self.cmbx = ComboboxMapped(placeholder="Select Template")
        self.bbar = ButtonBar(fn_reload=self._load)
        super().__init__([self.cmbx, self.bbar], **kwargs)
        self._load()

    def _load(self):
        self.cmbx.options = {
            name: id_ for id_, name in get_objects_unique_names(custodian="MXF").items()
        } | {"": ""}


if __name__ == "__main__":
    object_select = ObjectSelectBar()
    display(object_select)


# -


class ObjectOrderButtonBar(SaveButtonBar):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bn_up = w.ToggleButton(
            icon="arrow-up",
            button_style="primary",
            style={"font_weight": "bold"},
            tooltip="Move selected property up",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        self.bn_down = w.ToggleButton(
            icon="arrow-down",
            button_style="primary",
            style={"font_weight": "bold"},
            tooltip="Move selected property down",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        self.children = [
            self.tgl_unsaved_changes,
            self.bn_up,
            self.bn_down,
            self.bn_revert,
            self.bn_save,
            self.message,
        ]


# +
class ObjectPreview(w.VBox):
    def __init__(self, **kwargs):
        title = w.HTML(f"<b>{DES_OBJECT_PSET['title']}</b>")
        description = w.HTML(f"<i>{DES_OBJECT_PSET['description']}</i>")
        self.object_select = ObjectSelectBar()
        self.pset_select = ObjectPsetsSelect()
        self.override = ObjectPropertyForm.from_pydantic_model(ObjectPropertyFormSchema)
        self.override.bn_shownull.value = True
        self.override.bn_shownull.layout.display = "none"
        self.order = ObjectOrderButtonBar()
        self.grid = ObjectPropertiesPreviewGrid()
        self.stk = w.Stack([self.pset_select, self.override, self.order])
        super().__init__([w.HBox([title, description]), self.object_select, self.stk, self.grid], **kwargs)
        self._init_controls()
        self.override.savebuttonbar.fns_onsave_add_action(self.grid._load)
        self.object_select.bbar.edit.value = True

    def _init_controls(self):
        self.object_select.cmbx.observe(self._set_grid_and_psets)
        self.object_select.bbar.observe(self._setview, "active")
        self.pset_select.allowed_values.observe(self._preview_properties)
        self.grid.observe(self._set_override_form, "selections")
        self.order.bn_down.observe(self._move_selected_rows_down)
        self.order.bn_up.observe(self._move_selected_rows_up)
        self.order.fns_onrevert_add_action(self.grid._load)
        self.order.fns_onsave_add_action(self._save_object_order)
        self.override.savebuttonbar.fns_onrevert_add_action(self.grid._load)
        self.pset_select.bbar.tgl_unsaved_changes.observe(self._set_buttons)

    def _setview(self, onchange):
        if self.object_select.bbar.active is None:
            self.stk.selected_index = None
        else:
            self.stk.selected_index = self.object_select.bbar.active_index

    def _set_buttons(self, onchange):
        if self.pset_select.bbar.unsaved_changes:
            self.object_select.bbar.override.disabled = True
            self.object_select.bbar.order.disabled = True
        else:
            self.object_select.bbar.override.disabled = False
            self.object_select.bbar.order.disabled = False

    def _preview_properties(self, onchange=None):
        self.grid.pset_ids = self.pset_select.selected_psets

    def _set_grid_and_psets(self, onchange):
        if self.object_select.cmbx.value:
            self.object_id = int(self.object_select.cmbx.value)
        else:
            self.object_id = 0
        self.pset_select.object_id = self.object_id
        self.grid.object_id = self.object_id
        self.override.object_id = self.object_id

    def _set_override_form(self, onchange):
        if self.grid.selected_property_id:
            self.override.property_id = self.grid.selected_property_id

    def _move_selected_rows_down(self, onchange):
        """Move the selected rows up visually."""
        if self.order.bn_down.value:
            # ^ Prevents spamming of button
            self._check_sections_selected()
            self.order.unsaved_changes = True
            max_index = max(self.grid.selected_indexes)
            if max_index == len(self.grid.data) - 1:
                self.order.bn_down.value = False
                raise Exception("Can't move down final row.")
            if self.grid.data.loc[max_index, "Section"] != self.grid.data.loc[max_index + 1, "Section"]:
                self.order.message.value = "❌ Not allowed to move property outside of section."
                self.order.bn_down.value = False
                raise Exception("Not allowed move property outside of section.")
            self.grid._move_indexes_up(self.grid.selected_indexes)
            self.order.bn_down.value = False

    def _move_selected_rows_up(self, onchange):
        """Move the selected rows down visually."""
        if self.order.bn_up.value:
            # ^ Prevents spamming of button
            self._check_sections_selected()
            min_index = min(self.grid.selected_indexes)
            if min_index == 0:
                self.order.bn_up.value = False
                raise Exception("Can't move up first row.")
            if self.grid.data.loc[min_index, "Section"] != self.grid.data.loc[min_index - 1, "Section"]:
                self.order.message.value = "❌ Not allowed to move property outside of section."
                self.order.bn_up.value = False
                raise Exception("Not allowed move property outside of section.")
            self.order.unsaved_changes = True
            self.grid._move_indexes_down(self.grid.selected_indexes)
            self.order.bn_up.value = False

    def _check_sections_selected(self):
        """Check if more than one section is selected"""
        if len({self.grid.data.loc[i, "Section"] for i in self.grid.selected_indexes}) > 1:
            self.override.savebuttonbar.message.value = "❌ <i>Only select properties from the same section.</i>"
            self.order.bn_down.value = False
            self.order.bn_up.value = False
            raise Exception("Moving properties that exist within different sections not allowed.")

    def _save_object_order(self):
        property_order = list(self.grid.data.loc[:, "Id"])
        post_and_patch_object_order(object_id=self.object_id, value=property_order)


if __name__ == "__main__":
    object_preview = ObjectPreview()
    display(object_preview)
