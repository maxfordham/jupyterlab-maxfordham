# +
import typing
import immutables
import itertools
import traitlets as tr
import typing as ty
import ipywidgets as w
import pandas as pd
from markdown import markdown
from IPython.display import display
from pydantic import RootModel, Field
from ipydatagrid import TextRenderer, Expr
from palettable.tableau import TableauMedium_10, BlueRed_12

from ipyautoui.custom.editgrid import AutoGrid
from ipyautoui.constants import BUTTON_WIDTH_MIN
from ipyautoui.custom.combobox_mapped import ComboboxMapped
from aectemplater_schemas.enumerations import (
    CategoriesEnum,
    SectionsEnum,
)
from aectemplater_client import (
    get_psets_unique_names,
    get_pset,
    get_properties,
    post_properties_to_pset,
    delete_properties_from_pset,
)


from aectemplater_ui import ENV
from aectemplater_ui.schemas import (
    PsetPropertyPost,
    PropertyGetFlattenUnit,
)
from aectemplater_ui.formatting import (
    get_properties_format,
    create_vega_expression,
    get_section_map_colours,
    get_category_map_colours,
)
from aectemplater_ui.constants import DES_LINKPROPS_ALL, DES_LINKPROPS_TEMPLATE

frozenmap = immutables.Map

KWARGS_DATAGRID_DEFAULT = get_properties_format()
COLUMN_WIDTHS = {
    "Section": 130,
    "Category": 120,
    "Name": 200,
    "Unit": 100,
    "Is Instance": 90,
    "Id": 5,
}
ORDER_COLS = ["section", "category", "name", "unit", "is_instance", "id"]
LI_SECTIONS = [section.value for section in SectionsEnum]  # Enforcing order of sections to order given in Enumeration.


# -


class PropertyDataFrame(RootModel):
    root: typing.List[PropertyGetFlattenUnit] = Field(format="dataframe")


class AllPropertiesGrid(w.VBox):
    """Used to show all properties. From here we can select template to filter on and properties to add."""

    @property
    def data(self):
        return self.grid.data

    @data.setter
    def data(self, data: pd.DataFrame):
        self.grid.data = self.grid._init_data(data)

    @property
    def pset_id(self):
        try:
            return int(self.cmbx_psets.value)
        except Exception:
            return None

    @property
    def df_selected_data(self) -> list:
        return self.data.iloc[self.grid.selected_indexes]

    @property
    def selected_properties(self) -> list:
        return (
            self.data.iloc[self.grid.selected_indexes]
            .rename(columns=self.grid.map_index_name)
            .to_dict(orient="records")
        )

    @property
    def properties(self) -> list:
        return self.data.rename(columns=self.grid.map_index_name).to_dict(orient="records")

    def __init__(self, fn_add: typing.Callable, **kwargs):
        self.fn_add = fn_add
        super().__init__(**kwargs)
        self._init_ui()
        self._init_controls()

    def _init_ui(self):
        """Define layout and UI elements: title, toolbar, and grid."""
        title = w.HTML(f"<b>{DES_LINKPROPS_ALL['title']}</b>")
        description = w.HTML(f"<i>{DES_LINKPROPS_ALL['description']}</i>")
        self.cmbx_psets = ComboboxMapped(
            placeholder="Filter by Property Set",
            ensure_option=False,
        )
        self.bn_reload = w.Button(
            icon="refresh",
            button_style="primary",
            style={"font_weight": "bold"},
            tooltip="Clear current Property Set selected",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        self.grid = AutoGrid(
            schema=PropertyDataFrame,
            order=ORDER_COLS,
            renderers=get_properties_format()["renderers"],
            header_renderer=get_properties_format()["header_renderer"],
            grid_style=get_properties_format()["grid_style"],
        )
        self.grid.column_widths = COLUMN_WIDTHS
        self.bn_add = w.Button(
            icon="plus",
            button_style="success",
            style={"font_weight": "bold"},
            tooltip="Add selected property",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        hbx_toolbar = w.HBox(
            [w.HBox([self.cmbx_psets, self.bn_reload]), self.bn_add],
            layout=w.Layout(justify_content="space-between"),
        )
        self.children = [w.HBox([title, description]), hbx_toolbar, self.grid]
        self.layout = w.Layout(width="48%")
        self._load_psets()
        self._load_properties()

    def _init_controls(self):
        self.cmbx_psets.observe(self._load_properties)
        self.bn_reload.on_click(self._load)
        self.bn_add.on_click(self._fn_add)

    def _fn_add(self, onchange):
        self.fn_add()

    def _load_psets(self):
        """Load the possible property sets into the combobox."""
        self.cmbx_psets.options = self.get_pset_options()

    def _load_properties(self, onchange=None):
        """Load the properties linked to the property set selected in the pset filter."""
        if self.cmbx_psets.value == "":
            self.data = self.get_properties()
        else:
            self.data = self.get_properties(self.pset_id)

    def _load(self, onchange=None):
        """Clear the property set combobox."""
        self._load_psets()
        self._load_properties()

    def get_pset_options(self):
        return {name: id_ for id_, name in get_psets_unique_names().items()}

    def get_properties(self, pset_id: ty.Union[int, None] = None) -> pd.DataFrame:
        """Get all properties or filter by pset_id."""
        if pset_id is None:
            properties = get_properties(limit=-1, include_units=True)
        else:
            properties = get_pset(self.pset_id, include_properties=True)["properties"]
        return pd.DataFrame([PropertyGetFlattenUnit.model_validate(property_).model_dump() for property_ in properties])


if __name__ == "__main__":
    fn_add = lambda: print("ADD")
    grid = AllPropertiesGrid(fn_add=fn_add)
    display(grid)


class SelectPropertiesGrid(w.VBox):
    @property
    def data(self):
        return self.grid.data

    @data.setter  # TODO: Maybe move to AutoGrid as a new setter?
    def data(self, data: pd.DataFrame):
        self.grid.data = self.grid._init_data(data)

    @property
    def pset_id(self):
        try:
            return int(self.cmbx_psets.value)
        except Exception:
            return None

    @property
    def selected_properties(self) -> list:
        return (
            self.data.iloc[self.grid.selected_indexes]
            .rename(columns=self.grid.map_index_name)
            .to_dict(orient="records")
        )

    @property
    def properties(self) -> list:
        return self.data.rename(columns=self.grid.map_index_name).to_dict(orient="records")

    def __init__(
        self,
        fn_delete: typing.Callable,
    ):
        self.fn_delete = fn_delete
        super().__init__()
        self._init_ui()
        self._init_controls()
        self._init_empty_data()

    def _init_ui(self):
        """Define layout and UI elements: title, description toolbar, and grid."""
        title = w.HTML(f"<b>{DES_LINKPROPS_TEMPLATE['title']}</b>")
        description = w.HTML(f"<i>{DES_LINKPROPS_TEMPLATE['description']}</i>")
        self.msg = w.HTML("")
        self.cmbx_psets = ComboboxMapped(
            placeholder="Select Property Set to edit",
            ensure_option=False,
        )
        self.bn_reload = w.Button(
            icon="refresh",
            button_style="primary",
            style={"font_weight": "bold"},
            tooltip="Clear current Property Set selected",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        self.grid = AutoGrid(
            schema=PropertyDataFrame,
            order=ORDER_COLS,
            renderers=get_properties_format()["renderers"],
            header_renderer=get_properties_format()["header_renderer"],
            grid_style=get_properties_format()["grid_style"],
        )
        self.grid.column_widths = COLUMN_WIDTHS
        self.bn_delete = w.Button(
            icon="trash",
            button_style="danger",
            style={"font_weight": "bold"},
            tooltip="Delete selected property",
            layout=w.Layout(width=BUTTON_WIDTH_MIN),
        )
        hbx_toolbar = w.HBox(
            [self.bn_delete, self.msg, w.HBox([self.cmbx_psets, self.bn_reload])],
            layout=w.Layout(justify_content="space-between"),
        )
        self.children = [
            w.HBox([title, description]),
            hbx_toolbar,
            self.grid,
        ]
        self.layout = w.Layout(width="48%")
        self._load_psets()

    def _init_controls(self):
        self.cmbx_psets.observe(self._load_properties)
        self.bn_reload.on_click(self._load)
        self.bn_delete.on_click(self._fn_delete)

    def _init_empty_data(self):
        df = self.data
        df.drop(df.index, inplace=True)
        df.index = pd.RangeIndex(0, len(df))
        self.data_empty = df
        self.data = self.data_empty

    def _fn_delete(self, onchange):
        self.fn_delete()

    def _load_psets(self):
        """Load the possible property sets into the filter (combobox) for the grid."""
        self.cmbx_psets.options = self.get_pset_options()

    def _load_properties(self, onchange=None):
        """Load the properties linked to the property set selected in the pset filter."""
        self.msg.value = ""
        if self.cmbx_psets.value == "" or self.pset_id is None:
            self.data = self.data_empty
        else:
            # patch_pset_properties_order_by_section(pset_id=self._psetfilter_id)
            self.data = self.get_properties(self.pset_id)

    def _load(self, onchange=None):
        """Clear the property set filter."""
        self._load_psets()
        self._load_properties()

    def get_pset_options(self):
        return {name: id_ for id_, name in get_psets_unique_names(custodian=ENV.AECTEMPLATER_ORG).items()}

    def get_properties(self, pset_id: int) -> pd.DataFrame:
        """Get all properties or filter by pset_id."""
        properties = get_pset(self.pset_id, include_properties=True)["properties"]
        return pd.DataFrame([PropertyGetFlattenUnit.model_validate(property_).model_dump() for property_ in properties])


if __name__ == "__main__":
    fn_delete = lambda: print("DELETE")
    gr_select = SelectPropertiesGrid(fn_delete=fn_delete)
    display(gr_select)


class PsetPropertyUi(w.HBox):
    """UI element with two datagrids where one grid shows all options and the other is the selected options."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._init_ui()
        self._init_controls()

    def _init_ui(self):
        """Define layout and UI elements: A grid showing all properties and another showing selected properties."""
        self.gr_all = AllPropertiesGrid(fn_add=self._fn_add)
        self.gr_select = SelectPropertiesGrid(fn_delete=self._fn_delete)
        self.children = [self.gr_all, self.gr_select]

    def _init_controls(self):
        self.gr_select.bn_reload.on_click(self._set_formatting)
        self.gr_select.cmbx_psets.observe(self._set_formatting)

    def _fn_add(self):
        """Add a property from the 'All Properties' grid to a specified property set in the 'Selected Properties' grid."""
        self._check_pset_selected()
        self.gr_select.grid.clear_selection()
        post_properties_to_pset(
            pset_id=self.gr_select.pset_id,
            value=[property_["id"] for property_ in self.gr_all.selected_properties],
        )
        self.gr_select._load_properties()
        self._set_formatting("onchange")

    def _fn_delete(self):
        """Delete a property from a selected Property Set in the 'Selected Properties' grid."""
        self._check_pset_selected()
        delete_properties_from_pset(
            pset_id=self.gr_select.pset_id,
            value=[property_["id"] for property_ in self.gr_select.selected_properties],
        )
        self.gr_select._load_properties()
        self._set_formatting("onchange")

    def _check_pset_selected(self):
        if self.gr_select.pset_id is None:
            self.gr_select.msg.value = "<i>Please select a Property Set</i> 👉 "
            raise Exception("Property Set must be selected.")

    def _set_formatting(self, onchange):
        """Set the formatting dynamically. Set the colours of the sections, categories, and grey out any properties selected."""
        gray_str = (
            "'gray' if cell.metadata.data['Name'] in " + str(list(self.gr_select.data["Name"])) + " else default_value"
        )
        final_str = create_vega_expression({**get_section_map_colours(), **get_category_map_colours()})
        self.gr_all.grid.renderers = {
            "Category": TextRenderer(background_color=Expr(gray_str.replace("default_value", final_str))),
            "Section": TextRenderer(background_color=Expr(gray_str.replace("default_value", final_str))),
            "Name": TextRenderer(background_color=Expr(gray_str)),
            "Unit": TextRenderer(background_color=Expr(gray_str)),
            "Is Instance": TextRenderer(background_color=Expr(gray_str)),
            "Id": TextRenderer(background_color=Expr(gray_str)),
        }
        self.gr_select.grid.renderers = {
            "Category": TextRenderer(background_color=Expr(final_str)),
            "Section": TextRenderer(background_color=Expr(final_str)),
        }


if __name__ == "__main__":
    pset_property = PsetPropertyUi()
    display(pset_property)
