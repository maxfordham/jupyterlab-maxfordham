# -*- coding: utf-8 -*-
# ---
# jupyter:
#   jupytext:
#     custom_cell_magics: kql
#     formats: py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.18.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %%
import functools
import logging
import os
import pathlib
import typing as ty
from datetime import datetime

import ipywidgets as w
import traitlets as tr
from aectemplater_client import (
    copy_document_into_project_revision,
    delete_document,
    delete_document_project_filter,
    get_document_by_id,
    get_document_code_and_description_by_project_revision,
    get_document_code_by_project_revision,
    get_project_filter_names_from_document,
    get_project_filter_names_not_in_use,
    get_project_revision_by_id,
    get_project_revision_by_project_number_and_revision,
    get_spec_tags_from_document,
    get_spec_tags_not_selected,
    is_document_code_unique,
    patch_issue_data,
    post_document_project_filter,
)
from aectemplater_schemas.enumerations import (
    DOCUMENT_TYPE_TO_USE_TYPE,
    DocumentTypeEnum,
    ParameterTypeEnum,
    UseTypeEnum,
)
from dirty_equals import IsNow
from document_issue_ui import get_document_issue_form
from ipyautoui.constants import (
    ADD_BUTTON_KWARGS,
    RELOAD_BUTTON_KWARGS,
    REMOVE_BUTTON_KWARGS,
    TOGGLEBUTTON_ONCLICK_BORDER_LAYOUT,
)
from ipyautoui.custom import SelectAndExecute
from ipyautoui.custom.filedownload import _FilesDownload, get_filename
from ipyautoui.custom.selectandclick import (
    AddMultiple,
    RemoveMultiple,
    SelectAndClickFormLayouts,
)
from ipyautoui.custom.svgspinner import SvgSpinner
from IPython.display import display

from aectemplater_ui import ENV, JOB_NUMBER_TO_NAME
from aectemplater_ui.utils import (
    build_aecschedule_pdf,
    get_fdir_build_project_schedule,
    get_fdir_project,
    hide_show_null,
    readable_datetime_string_from_fpth,
)

logger = logging.getLogger(__name__)


DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
    project_number=ENV.AECTEMPLATER_PROJECT_NUMBER, revision=ENV.DEFAULT_PROJECT_REVISION
)["id"]
USE_TYPE_TO_DOCUMENT_TYPE_OPTIONS = {}
for dt, ut in DOCUMENT_TYPE_TO_USE_TYPE.items():
    USE_TYPE_TO_DOCUMENT_TYPE_OPTIONS.setdefault(ut.value, []).append(dt.value)


# %%
class SpecsFromDocument(w.HBox):
    document_id = tr.Int(default_value=None, allow_none=True).tag(allow_None=True)
    parameter_type = tr.Enum(ParameterTypeEnum, ParameterTypeEnum.type)

    @tr.observe("document_id", "parameter_type")
    def _observe(self, on_change):
        self.load()

    def __init__(self, *args, **kwargs):
        self.html_title = w.HTML()
        self.html_specs = w.HTML()
        super().__init__(
            [
                self.html_title,
                self.html_specs,
            ],
            *args,
            **kwargs,
        )

    def load(self):
        if self.document_id is not None:
            self.specs = get_spec_tags_from_document(self.document_id)[self.parameter_type.value]
            doc = get_document_by_id(self.document_id)
            use_type = DOCUMENT_TYPE_TO_USE_TYPE.get(doc["issue"]["issue_data"]["document_type"])
            if self.specs:
                self.html_title.value = f"<b>{use_type.value}: </b>"
                self.html_specs.value = "<b><font color='blue'>" + ", ".join(self.specs) + "</font></b>"
            else:
                self.html_title.value = f"<b>No {use_type.value}</b>"
                self.html_specs.value = ""


if __name__ == "__main__":
    from IPython.display import display

    try:
        document_id = 1
        ui = SpecsFromDocument(document_id=document_id)
        display(ui)
    except:
        document_id = 3
        ui = SpecsFromDocument(document_id=document_id)
        display(ui)


# %%
class SpecsNotSelected(w.VBox):
    project_revision_id = tr.Int()
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)
    parameter_type = tr.Enum(ParameterTypeEnum, ParameterTypeEnum.type)

    @tr.observe("project_revision_id", "use_type", "parameter_type")
    def _observe(self, change):
        self.load()

    def __init__(self, *args, **kwargs):
        self.html_title = w.HTML()
        self.html_specs = w.HTML()
        super().__init__(
            [self.html_title, self.html_specs],
            *args,
            **kwargs,
        )

    def load(self):
        specs_not_selected = get_spec_tags_not_selected(
            project_revision_id=self.project_revision_id, use_type=self.use_type
        )[self.parameter_type.value]
        if specs_not_selected:
            self.html_title.value = f"<b>Unscheduled {self.use_type.value}</b>"  # 🡸|
            self.html_specs.value = " <b><font color='red'>" + ", ".join(specs_not_selected) + "</font></b>"
        else:
            self.html_title.value = f"<b>All {self.use_type.value} Scheduled ✔️</b>"
            self.html_specs.value = ""


# %%
if __name__ == "__main__":
    ui = SpecsNotSelected(project_revision_id=1)
    display(ui)


# %%
class DocumentProjectFiltersAddRemove(w.VBox):
    document_id = tr.Int(default_value=None, allow_none=True).tag(allow_None=True)
    fn_reload = tr.Callable(default_value=lambda: logger.info("RELOAD"))

    @tr.observe("document_id")
    def observe_document_id(self, change):
        self.add.update_options()
        self.remove.update_options()
        if self.document_id is not None:
            document = get_document_by_id(self.document_id)
            self.project_revision_id = document["project_revision_id"]

    def __init__(self, *args, **kwargs):
        self.add = AddMultiple(
            fn_onclick=[self.add_project_filter_to_document, self.reload],
            fn_get_options=self.get_add_options,
            fn_reload=self.reload,
            title="<b>Add Filters to Schedule</b>",
            fn_layout_form=SelectAndClickFormLayouts.align_horizontal_left,
            layout=dict(padding="0px 0px 0px 20px"),
        )
        self.remove = RemoveMultiple(
            fn_onclick=[self.remove_project_filter_from_document, self.reload],
            fn_get_options=self.get_remove_options,
            fn_reload=self.reload,
            title="<b>Current Filters in Schedule</b>",
            fn_layout_form=SelectAndClickFormLayouts.align_horizontal_left,
        )
        super().__init__(*args, **kwargs)
        self.add.select.layout.height = "150px"
        self.remove.select.layout.height = "150px"
        self.hide_message()
        self.add.bn.tooltip = "Add Selected Filters to Schedule"
        self.remove.bn.tooltip = "Remove Selected Filters from Schedule"
        self.bn_reload = w.Button(**RELOAD_BUTTON_KWARGS)
        self.bn_reload.tooltip = "Reload Filter Options"
        self.children = [
            self.bn_reload,
            w.HBox([self.remove, self.add]),
        ]
        self._init_controls()

    def _init_controls(self):
        self.bn_reload.on_click(self.toggle_reload)

    def get_add_options(self):
        if self.document_id:
            return [(name, id) for id, name in get_project_filter_names_not_in_use(self.document_id).items()]
        else:
            return []

    def get_remove_options(self):
        if self.document_id:
            return [(name, id) for id, name in get_project_filter_names_from_document(self.document_id).items()]
        else:
            return []

    def add_project_filter_to_document(self, value: list):
        for project_filter_id in value:
            post_document_project_filter(
                document_id=self.document_id,
                project_filter_id=int(project_filter_id),
            )

    def remove_project_filter_from_document(self, value: list):
        for project_filter_id in value:
            delete_document_project_filter(document_id=self.document_id, project_filter_id=int(project_filter_id))

    def reload(self, value=None):
        self.add.update_options()
        self.remove.update_options()
        self.fn_reload()

    def toggle_reload(self, change):
        self.reload()

    def hide_message(self):
        self.add.html_notify.layout.display = "None"
        self.add.html_value.layout.display = "None"
        self.remove.html_notify.layout.display = "None"
        self.remove.html_value.layout.display = "None"


# %%
if __name__ == "__main__":
    document_project_filters = DocumentProjectFiltersAddRemove(document_id=document_id)
    display(document_project_filters)


# %%
def check_document_name_warning_html(name: str) -> str:
    return (
        """
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            .banner {
                background-color: #ff9966; 
                width: 100%;
                height: 35px; /* Adjust the height as per your requirement */
                color: white; /* Change the text color as per your requirement */
                text-align: center;
                padding: 0px 0;
                font-size: 16px; /* Adjust the font size as per your requirement */
            }
        </style>
    </head>
    <body>
        <div class="banner">
            ⚠  WARNING: Document Name <b>"""
        + name
        + """</b> is already in use. ⚠<br>
        </div>
    </body>
    </html>
    """
    )


# %%
class CheckDocumentName(w.VBox):
    document_id = tr.Int(default_value=None, allow_none=True).tag(sync=True)

    @tr.observe("document_id")
    def observe_document_id(self, on_change):
        self.load()

    def __init__(self, *args, **kwargs):
        self.check_document_name = w.HTML()
        super().__init__([self.check_document_name], *args, **kwargs)

    def load(self):
        if self.document_id is not None:
            self.document = get_document_by_id(self.document_id)
            self.project_revision_id = self.document["project_revision_id"]
            self.document_code = self.document["issue"]["issue_data"]["document_name"]
            self.check_unique_document_code()

    def check_unique_document_code(self):
        document = get_document_by_id(self.document_id)
        if is_document_code_unique(document["issue"]["id"]):
            self.check_document_name.value = ""
        else:
            self.check_document_name.value = check_document_name_warning_html(self.document_code)


# %%
class ProjectScheduleOptions(w.VBox):
    document_id = tr.Int(default_value=None, allow_none=True).tag(allow_None=True)
    parameter_type = tr.Enum(ParameterTypeEnum, ParameterTypeEnum.type)

    @tr.observe("document_id")
    def observe_document_id(self, on_change):
        self.project_filters.document_id = self.document_id
        self.check_document_name.document_id = self.document_id
        self.specs.document_id = self.document_id
        if self.document_id is not None:
            self.document = get_document_by_id(self.document_id)
            self.issue.project_number = self.document["project_revision"]["project"]["project_number"]
            self.issue_id = self.document["issue"]["id"]
            self.issue_data = self.document["issue"]["issue_data"]
            self._set_document_type_options()
            self._set_status_revision()
            if (
                self.issue_data["project_number"] != self.issue.project_number
                or self.issue_data["project_name"] != self.issue.project_name
            ):  # Update issue data and patch if project number and name different to webapp
                self.issue_data["project_number"] = self.issue.project_number
                self.issue_data["project_name"] = self.issue.project_name
                self.issue.value = self.issue_data
                self.patch_issue_data()
            else:
                self.issue.value = self.issue_data
            self.issue.savebuttonbar.tgl_unsaved_changes.value = False

    @tr.observe("parameter_type")
    def observe_parameter_type(self, on_change):
        self.specs.parameter_type = self.parameter_type

    def _set_document_type_options(self):
        """Set the document type options."""
        if "document_type" in self.issue_data:
            use_type = DOCUMENT_TYPE_TO_USE_TYPE.get(self.issue_data["document_type"])
            self.issue.di_widgets["document_type"].options = USE_TYPE_TO_DOCUMENT_TYPE_OPTIONS.get(
                use_type, [dt.value for dt in DocumentTypeEnum]
            )
        else:
            self.issue.di_widgets["document_type"].options = [dt.value for dt in DocumentTypeEnum]

    def _set_status_revision(self):
        """Set the status revision file for the project.
        Looks for a status_revision.csv file in the project directory
        and sets the environment variable to it BEP_STATUS_REVISION if found.
        """
        self.document_code = self.document["issue"]["issue_data"]["document_name"]
        fdir_project = get_fdir_project(
            project_number=self.issue.project_number,
        )
        fpth = fdir_project / "status_revision.csv"
        if fpth.exists():
            os.environ["BEP_STATUS_REVISION"] = str(fpth)
        else:
            os.environ["BEP_STATUS_REVISION"] = ""
        self.issue.update_issue_model()

    def __init__(self, *args, **kwargs):
        self.project_filters = DocumentProjectFiltersAddRemove()
        self.check_document_name = CheckDocumentName()
        self.specs = SpecsFromDocument(layout=w.Layout(padding="0px 0px 10px 0px"))
        self.issue = get_document_issue_form(
            map_projects=JOB_NUMBER_TO_NAME,
            fns_onsave=[self.patch_issue_data, self.check_document_name.load],
            fns_onrevert=[self.revert],
        )
        hide_show_null(self.issue.di_widgets["issue_history"].ui_edit, self.issue.di_widgets["issue_history"].ui_add)
        self.project_schedule_tab = w.Tab(
            [
                self.issue,
                w.HBox(
                    [self.project_filters],
                    layout=w.Layout(justify_content="space-between"),
                ),
            ],
            titles=[
                "Schedule Header",
                "Schedule Filters",
            ],
        )
        super().__init__(
            [
                self.check_document_name,
                self.specs,
                self.project_schedule_tab,
            ],
            *args,
            **kwargs,
        )
        self.project_filters.fn_reload = self.specs.load

    def patch_issue_data(self):
        patch_issue_data(issue_id=self.issue_id, value=self.issue.value)
        self.issue_data = self.issue.value

    def revert(self):
        self.issue.value = self.issue_data


# %%
if __name__ == "__main__":
    project_schedule_options = ProjectScheduleOptions(document_id=document_id)
    display(project_schedule_options)


# %%
class ProjectScheduleAccordion(w.Accordion):
    project_revision_id = tr.Int()
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)
    parameter_type = tr.Enum(ParameterTypeEnum, ParameterTypeEnum.type)

    @tr.observe("parameter_type")
    def _observe_parameter_type(self, change):
        self.project_schedule.parameter_type = self.parameter_type

    @tr.observe("project_revision_id", "use_type")
    def _observe(self, change):
        self.selected_index = None
        self._load_documents()

    @tr.observe("selected_index")
    def _load_project_schedule(self, change):
        if self.selected_index is not None:
            self.project_schedule.document_id = self.accordion_index_to_document_id.get(self.selected_index)

    @property
    def selected_document_id(self) -> ty.Union[int, None]:
        if self.selected_index is not None:
            return self.accordion_index_to_document_id[self.selected_index]
        else:
            return None

    def __init__(self, *args, **kwargs):
        self.project_schedule = ProjectScheduleOptions()
        self.project_schedule.issue.savebuttonbar.fns_onsave += [self._load_documents]
        super().__init__(*args, **kwargs)

    def _load_documents(self):
        selected_document_id = self.selected_document_id  # Get currently selected document
        document_names = get_document_code_and_description_by_project_revision(
            project_revision_id=self.project_revision_id, use_type=self.use_type
        )
        self.children = [self.project_schedule] * len(document_names)
        self.titles = tuple(document_names.values())
        self.accordion_index_to_document_id = {
            idx: int(document_id) for idx, document_id in enumerate(document_names.keys())
        }
        self.num_schedules = len(document_names)
        # Set to document selected before if one was selected
        if selected_document_id is not None:
            document_id_to_accordion_index = {
                document_id: idx for idx, document_id in self.accordion_index_to_document_id.items()
            }
            if selected_document_id in document_id_to_accordion_index.keys():
                self.selected_index = document_id_to_accordion_index[selected_document_id]


# %%
if __name__ == "__main__":
    project_schedules_accordion = ProjectScheduleAccordion(project_revision_id=2, use_type=UseTypeEnum.equipment)
    display(project_schedules_accordion)

# %%
if __name__ == "__main__":
    project_schedules_accordion.use_type = UseTypeEnum.spaces


# %%
def align_left(ui):
    ui.layout.display = "flex"
    ui.layout.flex_flow = "row"
    ui.layout.align_items = "stretch"
    ui.children = [w.VBox([w.HBox([ui.bn, ui.html_title]), ui.select]), ui.hbx_message]


# %%
class DocumentAdd(w.VBox):
    project_revision_id = tr.Int()
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)
    fn_reload = tr.Callable(default_value=lambda: logger.info("reload"))

    @tr.observe("project_revision_id", "use_type")
    def _observe(self, change):
        self.add.update_options()

    def __init__(self, *args, **kwargs):
        self.add = AddMultiple(
            fn_onclick=[self.add_document, self.reload],
            title="<b>Add Schedules to Project</b>",
            fn_get_options=self.get_add_options,
            fn_layout_form=align_left,
        )
        self.add.select.layout = dict(width="600px", height="200px")
        self.hide_message()
        self.add.bn.tooltip = "Add Selected Schedules to Project"
        super().__init__(*args, **kwargs)
        self.children = [self.add]

    def get_add_options(self):
        if self.project_revision_id:
            return [
                (name, id)
                for id, name in get_document_code_and_description_by_project_revision(
                    project_revision_id=DEFAULT_PROJECT_REVISION_ID, use_type=self.use_type
                ).items()
            ]
        else:
            return []

    def add_document(self, value: list):
        for document_id in value:
            copy_document_into_project_revision(
                document_id=int(document_id),
                project_revision_id=self.project_revision_id,
            )

    def reload(self, value=None):
        self.add.update_options()
        self.fn_reload()

    def hide_message(self):
        self.add.html_notify.layout.display = "None"
        self.add.html_value.layout.display = "None"


if __name__ == "__main__":
    document_add = DocumentAdd(project_revision_id=1)
    display(document_add)


# %%
class DocumentRemove(w.VBox):
    project_revision_id = tr.Int()
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)
    fn_reload = tr.Callable(default_value=lambda: print("RELOAD"))

    @tr.observe("project_revision_id", "use_type")
    def _observe(self, change):
        self.remove.update_options()

    def __init__(self, *args, **kwargs):
        self.remove = RemoveMultiple(
            fn_onclick=[self.remove_document, self.reload],
            title="<b>Remove Schedules from Project</b>",
            fn_get_options=self.get_remove_options,
            fn_layout_form=align_left,
        )
        self.remove.select.layout = dict(width="600px", height="200px")
        self.hide_message()
        self.remove.bn.tooltip = "Remove Selected Schedules from Project"
        super().__init__(*args, **kwargs)
        self.children = [self.remove]

    def get_remove_options(self):
        if self.project_revision_id:
            return [
                (name, id)
                for id, name in get_document_code_and_description_by_project_revision(
                    project_revision_id=self.project_revision_id, use_type=self.use_type
                ).items()
            ]
        else:
            return []

    def remove_document(self, value: list):
        for document_id in value:
            delete_document(document_id=int(document_id))

    def reload(self, value=None):
        self.remove.update_options()
        self.fn_reload()

    def hide_message(self):
        self.remove.html_notify.layout.display = "None"
        self.remove.html_value.layout.display = "None"


if __name__ == "__main__":
    document_remove = DocumentRemove(project_revision_id=1)
    display(document_remove)


# %%
def build_aecschedule_pdf_and_report(document_id):
    print(f"document_id={document_id} - {datetime.now().strftime('%Y-%m-%dT%H:%M:%S')}")
    fpth = build_aecschedule_pdf(document_id)
    if fpth.is_file() and datetime.fromtimestamp(fpth.stat().st_mtime) == IsNow():
        return f"<i>⌚ {datetime.now().strftime('%Y-%m-%dT%H:%M:%S')}</i>"
    else:
        return f"☠ {fpth.name} ☠ GENERATION FAILED"


# %%
class DocumentDownload(_FilesDownload, SelectAndExecute):
    project_revision_id = tr.Int()
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)

    @tr.observe("project_revision_id", "use_type")
    def _observe(self, change):
        # Reset execute UI components
        self.execute.time_elapsed.start_time = datetime.now()
        self.execute.time_elapsed.end_time = None
        self.execute.progress.value = 0
        self.execute.vbx_tasks.children = []
        self._load_schedules()

    @tr.observe("tasks")
    def obs_tasks(self, on_change):
        if hasattr(self, "document_names"):
            # HOTFIX: Override select options to add custom icon
            self.select.select.options = {
                (
                    f"📃 {document_name} ⌚ {readable_datetime_string_from_fpth(self.document_name_to_pdf_fpth[document_name])}"
                    if self.document_name_to_pdf_fpth[document_name].exists()
                    else f"❌ {document_name}"
                ): document_name
                for document_id, document_name in self.document_names.items()
            }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.output = w.Output(layout=dict(display="None"))
        self._add_download_button()
        self.download.on_click(self._download)

    def _add_download_button(self):
        self.download = w.Button(
            layout={"width": "44px"},
            icon="download",
            tooltip="Download Selected Schedules",
        )
        self.select.bn.tooltip = "Generate Selected Schedules"
        self.title = "<b>Generate and Download Schedules"
        self.svg = SvgSpinner(layout=dict(display="None"))
        self.message = w.HTML()
        self.select.children = [
            w.HBox(
                [
                    self.select.bn,
                    self.download,
                    self.select.html_title,
                    w.HBox(
                        [self.svg, self.message],
                        layout=dict(padding="0px 0px 0px 10px"),
                    ),
                ]
            ),
            self.select.select,
            self.output,
        ]
        self.select.select.layout = dict(width="600px", height="200px", padding="0px 20px 0px 0px")

    def get_fpth_schedules(self) -> dict:
        return {
            k: self.get_fpth_schedule_from_document_code(v)
            for k, v in get_document_code_by_project_revision(
                project_revision_id=self.project_revision_id, use_type=self.use_type
            ).items()
        }

    def get_fpth_schedule_from_document_code(self, document_code: str) -> pathlib.Path:
        project_revision = get_project_revision_by_id(project_revision_id=self.project_revision_id)
        return get_fdir_build_project_schedule(
            project_number=project_revision["project"]["project_number"], document_code=document_code
        ) / (document_code + ".pdf")

    def _load_schedules(self):
        self.document_codes = get_document_code_by_project_revision(
            project_revision_id=self.project_revision_id, use_type=self.use_type
        )
        self.document_names = get_document_code_and_description_by_project_revision(
            project_revision_id=self.project_revision_id, use_type=self.use_type
        )
        self.document_name_to_pdf_fpth = {
            document_name: self.get_fpth_schedule_from_document_code(self.document_codes[document_id])
            for document_id, document_name in self.document_names.items()
        }
        self.fpth_schedules = self.get_fpth_schedules()
        self.tasks = {
            document_name: functools.partial(build_aecschedule_pdf_and_report, document_id)
            for document_id, document_name in self.document_names.items()
        }

    def fn_onclick(self, onclick):
        selected = self.select.select.value
        self.execute.progress.value = 0
        self.execute.tasks = {k: v for k, v in self.tasks.items() if k in self.select.select.value}
        self.execute.progress.max = self.execute.end
        self.execute.vbx_tasks.layout.display = ""
        self.execute.start()
        self._load_schedules()
        self.select.select.value = selected

    def _download(self, on_click):
        self.filename = get_filename()
        self.value = [
            self.document_name_to_pdf_fpth[v]
            for v in self.select.select.value
            if self.document_name_to_pdf_fpth[v].exists()
        ]
        if self.value:
            self.svg.layout.display = ""
            self.message.value = "<i>Downloading Schedules</i>"
            self.trigger_download()
            self.svg.layout.display = "None"
            self.message.value = ""


if __name__ == "__main__":
    document_download = DocumentDownload(project_revision_id=1)
    display(document_download)


# %%
class Options(ty.TypedDict):
    tooltip: str
    tooltip_clicked: str
    button_style: str
    message: str


class View(ty.TypedDict):
    add: Options
    remove: Options
    download: Options


SCHEDULES_BUTTONBAR_CONFIG = View(
    add=Options(
        tooltip="Add Schedules to Project",
        tooltip_clicked="Close Menu",
        button_style="success",
        message="📃 <i>Add Schedules</i>",
    ),
    remove=Options(
        tooltip="Remove Schedules from Project",
        tooltip_clicked="Close Menu",
        button_style="danger",
        message="🗑️ <i>Delete Schedules</i>",
    ),
    download=Options(
        tooltip="Download Schedules",
        tooltip_clicked="Close Menu",
        button_style="primary",
        message="📥 <i>Download Schedules</i>",
    ),
)


# %%
# TODO: This is replicating functionality of CrudButtonBar here: https://github.com/maxfordham/ipyautoui/blob/bd1e81850c55a8f3b17e9b6c52a057bfb278a8c8/src/ipyautoui/custom/buttonbars.py#L303-L414
# We can generalise CrudButtonBar and then use that here instead.
class ProjectScheduleButtonBar(w.HBox):
    active = tr.Unicode(default_value=None, allow_none=True)
    view = tr.Dict(default_value=SCHEDULES_BUTTONBAR_CONFIG)
    fn_reload = tr.Callable(default_value=lambda: print("fn_reload"))

    @tr.observe("fn_reload")
    def _observe_fn_reload(self, change):
        if change["new"] is None:
            self.reload.layout.display = "None"
        else:
            self.reload.layout.display = ""

    @tr.observe("view")
    def _observe_view(self, change):
        self._set_view_options()

    @property
    def active_index(self):
        if self.active is None:
            return None
        else:
            return list(self.view.keys()).index(self.active)

    def __init__(self, **kwargs):
        self._init_form()
        super().__init__(**kwargs)
        self.children = [
            self.add,
            self.remove,
            self.download,
            self.reload,
            self.message,
        ]
        self._init_controls()

    def _init_form(self):
        self.add = w.ToggleButton(**ADD_BUTTON_KWARGS)
        self.remove = w.ToggleButton(**REMOVE_BUTTON_KWARGS)
        self.download = w.ToggleButton(
            disabled=False,
            layout={"width": "44px"},
            icon="download",
        )
        self.reload = w.Button(**RELOAD_BUTTON_KWARGS)
        self.reload.tooltip = "Reload Schedules"
        self.message = w.HTML()
        self._set_view_options()

    def _init_controls(self):
        self.add.observe(self._add, "value")
        self.remove.observe(self._remove, "value")
        self.download.observe(self._download, "value")
        self.reload.on_click(self._reload)

    def _add(self, onchange):
        self._onclick("add")

    def _remove(self, onchange):
        self._onclick("remove")

    def _download(self, onchange):
        self._onclick("download")

    def _reload(self, on_click):
        self.message.value = "🔄 <i>Reloading Schedules</i>"
        self.fn_reload()
        self.message.value = "🔄 <i>Reloaded Schedules</i>"

    def _onclick(self, button_name):
        w = getattr(self, button_name)
        if w.value:
            self.reset_toggles_except(button_name)
            self.active = button_name
            w.tooltip = self.view[button_name]["tooltip_clicked"]
            w.layout.border = TOGGLEBUTTON_ONCLICK_BORDER_LAYOUT
            self.message.value = self.view[button_name]["message"]
        else:
            self.active = None
            w.tooltip = self.view[button_name]["tooltip"]
            w.layout.border = None
            self.message.value = ""

    def _set_view_options(self):
        for button_name in self.view.keys():
            w = getattr(self, button_name)
            for k, v in self.view[button_name].items():
                if k in dir(w):
                    setattr(w, k, self.view[button_name][k])

    def reset_toggles_except(self, name=None):
        names = self.view.keys()
        if name is None:
            names = names
        elif name not in names:
            raise ValueError(f"`name` must be in {str(names)}. {name} given")
        names = [n for n in names if n != name]
        for n in names:
            setattr(getattr(self, n), "value", False)


if __name__ == "__main__":
    ui = ProjectScheduleButtonBar()
    display(ui)


# %%
class ProjectSchedules(w.VBox):
    project_revision_id = tr.Int()
    use_type = tr.Enum(UseTypeEnum, UseTypeEnum.equipment)
    parameter_type = tr.Enum(ParameterTypeEnum, ParameterTypeEnum.type)

    @tr.observe("project_revision_id")
    def _observe_project(self, change):
        self.ui_add.project_revision_id = self.project_revision_id
        self.ui_remove.project_revision_id = self.project_revision_id
        self.ui_download.project_revision_id = self.project_revision_id
        self.specs_not_selected.project_revision_id = self.project_revision_id
        self.project_schedule_accordion.project_revision_id = self.project_revision_id

    @tr.observe("use_type")
    def _observe_use_type(self, change):
        self.ui_add.use_type = self.use_type
        self.ui_remove.use_type = self.use_type
        self.ui_download.use_type = self.use_type
        self.specs_not_selected.use_type = self.use_type
        self.project_schedule_accordion.use_type = self.use_type

    @tr.observe("parameter_type")
    def _observe_parameter_type(self, change):
        self.specs_not_selected.parameter_type = self.parameter_type
        self.project_schedule_accordion.parameter_type = self.parameter_type

    def __init__(self, **kwargs):
        self._init_form()
        super().__init__(**kwargs)
        self.children = [
            w.Box(
                [
                    w.Box(
                        [self.buttonbar, self.stack],
                        layout=dict(
                            justify_content="flex-start",
                            flex_flow="column wrap",
                        ),
                    ),
                    self.specs_not_selected,
                ],
                layout=dict(
                    justify_content="space-between",
                    flex_flow="row wrap",
                ),
            ),
            self.project_schedule_accordion,
        ]
        self._init_controls()
        self._init_reload()

    def _init_controls(self):
        self.buttonbar.observe(self._setview, "active")

    def _init_reload(self):
        self.ui_add.fn_reload = self._reload
        self.ui_remove.fn_reload = self._reload
        self.buttonbar.fn_reload = self._reload
        self.project_schedule_accordion.project_schedule.project_filters.fn_reload = self._reload
        self.project_schedule_accordion.project_schedule.issue.savebuttonbar.fns_onsave += [
            self._reload_add,
            self._reload_remove,
            self._reload_download,
        ]

    def _init_form(self):
        self.ui_add = DocumentAdd()
        self.ui_remove = DocumentRemove()
        self.ui_download = DocumentDownload()
        self.project_schedule_accordion = ProjectScheduleAccordion()
        self.specs_not_selected = SpecsNotSelected(layout=dict(max_width="40%"))
        self.buttonbar = ProjectScheduleButtonBar()
        self.stack = w.Stack(children=[self.ui_add, self.ui_remove, self.ui_download])

    def _setview(self, onchange):
        if self.buttonbar.active is None:
            self.stack.selected_index = None
        else:
            self.stack.selected_index = self.buttonbar.active_index

    def reload_project_schedules_and_specs(self):
        """Reload Schedules and Unscheduled Type Specs list.
        If an accordion is open and the schedule exists still then load the Type Specs.
        Else, close the selected accordion."""
        self.project_schedule_accordion._load_documents()
        self.specs_not_selected.load()
        if (
            self.project_schedule_accordion.project_schedule.document_id
            in self.project_schedule_accordion.accordion_index_to_document_id.values()
        ):  # Check schedule selected exists
            self.project_schedule_accordion.project_schedule.specs.load()
        else:  # If open schedule doesn't exist anymore then close accordion
            self.project_schedule_accordion.selected_index = None

    def _reload_add(self):
        """Reload function for ui_add"""
        self.ui_add.add.update_options()

    def _reload_remove(self):
        """Reload function for ui_remove"""
        self.ui_remove.remove.update_options()

    def _reload_download(self):
        """Reload function for ui_download"""
        self.ui_download._load_schedules()

    def _reload(self):
        self._reload_add()
        self._reload_remove()
        self._reload_download()
        self.reload_project_schedules_and_specs()


if __name__ == "__main__":
    project_schedules = ProjectSchedules(project_revision_id=1)
    display(project_schedules)

# %%
if __name__ == "__main__":
    # Check that the status revision is different
    # NOTE: Will need to add status_revision.csv to fdir_project
    # See _set_status_revision method in ProjectScheduleOptions
    project_schedules.project_revision_id = 3

# %%
if __name__ == "__main__":
    project_schedules.parameter_type = ParameterTypeEnum.instance

# %%
if __name__ == "__main__":
    project_schedules.use_type = UseTypeEnum.spaces

# %%
