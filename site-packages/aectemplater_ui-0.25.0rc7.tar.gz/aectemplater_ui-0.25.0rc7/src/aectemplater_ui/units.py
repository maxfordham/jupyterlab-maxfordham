# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.1
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# +
import pandas as pd
import ipywidgets as w
from ipydatagrid import DataGrid
from markdown import markdown
from IPython.display import display

from ipyautoui.custom.editgrid import EditGrid, DataHandler
from ipyautoui.custom.buttonbars import CrudOptions, CrudView
from aectemplater_schemas.data.utils import UnitsBaseData
from aectemplater_client import (
    delete_unit,
    get_units,
    patch_unit,
    post_unit,
)

from aectemplater_ui.unyt_deriver import UnitFormUi
from aectemplater_ui.constants import DES_UNITS
from aectemplater_ui.formatting import get_units_format
from aectemplater_ui.schemas import UnitsDataFrame
from aectemplater_ui.utils import hide_show_null

DI_UNITS_FORMAT = get_units_format()
# -
BUTTONBAR_CONFIG_TYPES = CrudView(
    add=CrudOptions(
        tooltip="Add Unit",
        tooltip_clicked="Go back to table",
        button_style="success",
        message="➕ <i>Add Unit</i>",
    ),
    edit=CrudOptions(
        tooltip="Edit Selected Unit",
        tooltip_clicked="Go back to table",
        button_style="warning",
        message="✏️ <i>Edit Unit</i>",
    ),
    delete=CrudOptions(
        tooltip="Delete Selected Units",
        tooltip_clicked="Go back to table",
        button_style="danger",
        message="🗑️ <i>Delete Units</i>",
    ),
)


class UnitsGrid(EditGrid):
    def __init__(self, *args, **kwargs):
        super().__init__(
            schema=UnitsDataFrame,
            datahandler=DataHandler(
                fn_get_all_data=self.get_units,
                fn_post=self.post_unit,
                fn_patch=self.patch_unit,
                fn_delete=self.delete_unit,
                fn_copy=self.copy_unit,
            ),
            ui_add=UnitFormUi,
            header_renderer=DI_UNITS_FORMAT["header_renderer"],
            grid_style=DI_UNITS_FORMAT["grid_style"],
            warn_on_delete=True,
            *args,
            **kwargs,
            **DES_UNITS,
        )
        self.buttonbar_grid.crud_view = BUTTONBAR_CONFIG_TYPES
        self.buttonbar_grid.copy.layout.display = "none"
        self.value = self.get_units()
        hide_show_null(self.ui_edit, self.ui_add)

    def _set_children(self):
        self.vbx_widget.children = [
            self.buttonbar_grid,
            self.stk_crud,
            self.grid,
        ]
        self.stk_crud.children = [
            self.ui_add,
            self.ui_edit,
            self.ui_delete,
        ]
        self.children = [self.hbx_title_description, self.vbx_widget]

    def get_units(self):
        return get_units(limit=-1)

    def post_unit(self, value: dict):
        return post_unit(value)

    def patch_unit(self, value: dict):
        return patch_unit(value["id"], value)

    def delete_unit(self, value: dict):
        return delete_unit(value["id"])

    def copy_unit(self, value: dict):
        value["name"] += " - DUPLICATE"
        return post_unit(value)


if __name__ == "__main__":
    units = UnitsGrid()
    display(units)

str_default_units = """
### Default Units

- All stored values in Revit are assigned a Revit Data Type; this helps define the scope of the value and, when applicable, associates the value with a measurable quantity.
- Within a Revit project, where a Revit Data Type is a measurable quantity, a single unit must be assigned to each Revit Data Type.
- To ensure consistency, the default units defined here have been reviewed and agreed by Engineering Standards and Digital Design, and will be applied to all projects.
- Sometimes, we may want to output parameters in different units on output Documents: the `aectemplater` supports conversion to a different specified unit during the export of the PDF Document.
- Output units can be defined in the "Link Properties" tab. 

### *Notes*

- In Revit, and the `aectemplater` database, values will be stored in the units defined here only.
- \* implies multiplication; ** implies exponent (to the power of).
"""


class RevitDefaultUnitsGrid(w.VBox):
    def __init__(self):
        super().__init__()
        li_revit_unit_data = [
            {
                "Revit Data Type": di["RevitDataType"],
                "Default Unit": (di["UnytDerivationSi"] if di["DefaultUnit"] == "" else di["DefaultUnit"]),
            }
            for di in UnitsBaseData().data_revit
        ]
        li_revit_unit_data = [
            di for di in li_revit_unit_data if di["Default Unit"] != "dimensionless" and di["Default Unit"] != ""
        ]
        self.grid = DataGrid(
            dataframe=pd.DataFrame.from_dict(li_revit_unit_data),
            grid_style=DI_UNITS_FORMAT["grid_style"],
        )
        self.grid.column_widths = {"Revit Data Type": 455, "Default Unit": 130}
        self.html_description = w.HTML(value=markdown(str_default_units))

        self.children = [w.HTML("<b>Default Revit Units</b>"), w.HBox([self.grid, self.html_description])]


if __name__ == "__main__":
    revit_default_units = RevitDefaultUnitsGrid()
    display(revit_default_units)
