from pyuniclass import UT
from ipyautoui.custom.combobox_mapped import ComboboxMapped


# +
class UniclassPr(ComboboxMapped):
    def __init__(self, **kwargs):
        super().__init__(**kwargs|{
            "options": UT.Pr.data.set_index('description')['Code'].to_dict() | {"": ""}})

class UniclassSs(ComboboxMapped):
    def __init__(self, **kwargs):
        super().__init__(**kwargs|{
            "options": UT.Ss.data.set_index('description')['Code'].to_dict() | {"": ""}})

class UniclassSL(ComboboxMapped):
    def __init__(self, **kwargs):
        super().__init__(**kwargs|{
            "options": UT.SL.data.set_index('description')['Code'].to_dict() | {"": ""}})

if __name__ == "__main__":
    from IPython.display import display
    pr = UniclassPr()
    ss = UniclassSs()
    sl = UniclassSL()
    display(pr)
    display(ss)
    display(sl)
# -


