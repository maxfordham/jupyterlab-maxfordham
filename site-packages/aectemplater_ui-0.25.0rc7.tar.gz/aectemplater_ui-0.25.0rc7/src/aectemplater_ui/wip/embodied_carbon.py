from aectemplater_ui.instance_specification import InstanceSpecGrid
from aectemplater_ui import ENV

from aectemplater_client import (
    get_object_by_code,
    get_project_revision_by_project_number_and_revision,
    post_type_spec_data,
)

DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
    project_number=ENV.AECTEMPLATER_PROJECT_NUMBER, revision=ENV.DEFAULT_PROJECT_REVISION
)["id"]
object_name = "MxfEmbodiedCarbon"
object_ = get_object_by_code(object_name)
OBJECT_ID_EMBODIED_CARBON = object_['id']
OBJECT_ID_BUILDING_AREA = get_object_by_code(code="MxfProjectBuildingArea")["id"]

# +
# post_type_spec_data(
#     object_id=OBJECT_ID_EMBODIED_CARBON,
#     project_revision_id=DEFAULT_PROJECT_REVISION_ID,
#     override_units=True,
#     value={"Abbreviation": "ECD", "TypeReference": 1},
# )

# +
# if not object_data_grid["data"]:
#     post_type_spec_data(
#         object_id=self.object_id,
#         project_revision_id=self.project_revision_id,
#         override_units=True,
#         value={"Abbreviation": self.abbreviation, "TypeReference": 1},
#     )
# -

object_
object_id

if __name__ == "__main__":
    DEFAULT_PROJECT_REVISION_ID = get_project_revision_by_project_number_and_revision(
        project_number=ENV.AECTEMPLATER_PROJECT_NUMBER, revision=ENV.DEFAULT_PROJECT_REVISION
    )["id"]
    gr = InstanceSpecGrid(project_revision_id=DEFAULT_PROJECT_REVISION_ID, object_id=OBJECT_ID_EMBODIED_CARBON)
    display(gr)

ENV.AECTEMPLATER_PROJECT_NUMBER
