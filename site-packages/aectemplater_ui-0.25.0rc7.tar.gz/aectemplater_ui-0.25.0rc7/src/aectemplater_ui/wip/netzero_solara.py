# PROOF OF CONCEPT: This is a proof of concept for integrating the NetZeroApp with Solara.
# Issues: 1. Lack of flexibility in the solara components e.g. removing fullscreen button from the navbar
#         2. FileDownload not working properly with callable

import solara
import solara.lab

from aectemplater_ui.apps.netzero import NetZeroApp

netzero = NetZeroApp()


@solara.component
def NetZeroAppSolara():
    with solara.AppLayout(title="Net-Zero Metrics", color="rgb(118, 180, 66)"):
        with solara.Sidebar():
            with solara.Card("Load Project", margin=2, elevation=0):
                solara.VBox([netzero.load_project.hbx_message, netzero.load_project.html_message])
                solara.HBox([netzero.load_project.select, netzero.load_project.bn])
        with solara.lab.Tabs(align="center"):
            with solara.lab.Tab("Project Summary"):
                with solara.Padding(5):
                    solara.HBox(
                        [
                            netzero.prj_summary.bn_download,
                            netzero.prj_summary.svg,
                            netzero.prj_summary.msg,
                            netzero.prj_summary.output,
                        ]
                    )
                with solara.Columns([2, 2]):
                    solara.Card(
                        title="Building Targets",
                        children=[
                            netzero.prj_summary.bx_building_targets_chart,
                            netzero.prj_summary.bx_gt_target_summary,
                        ],
                        margin=0,
                    )
                    solara.Card(title="Building Areas", children=[netzero.prj_summary.bx_gt_area_summary], margin=0)
                with solara.Columns([2, 2]):
                    solara.Card(title="Recorded Energy", children=[netzero.prj_summary.vbx_in_use_energy])
                    solara.Card(title="Predicted Energy", children=[netzero.prj_summary.vbx_predicted_energy])
            with solara.lab.Tab("Project Buildings"):
                solara.VBox([netzero.project_buildings])
            with solara.lab.Tab("Energy Targets"):
                solara.VBox([netzero.energy_targets])
            with solara.lab.Tab("Predicted Energy Use"):
                solara.VBox([netzero.energy_predicted])
            with solara.lab.Tab("Recorded Energy Use"):
                solara.VBox([netzero.energy_recorded])
            with solara.lab.Tab("Calculations"):
                solara.VBox([netzero.calc_accordion])
            with solara.lab.Tab("Dashboard - Practice Summary"):
                solara.VBox([netzero.energy_dashboard])
            with solara.lab.Tab("Inputs - Practice Summary"):
                solara.VBox([netzero.inputs_summary])


if __name__ == "__main__":
    display(NetZeroAppSolara())
