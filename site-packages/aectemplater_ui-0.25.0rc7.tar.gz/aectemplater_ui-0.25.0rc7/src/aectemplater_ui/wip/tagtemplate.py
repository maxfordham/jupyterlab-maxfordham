# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.15.2
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %load_ext lab_black



# +
import csv
from io import StringIO
from aectemplater_schemas.tag_template import (
    TypeTagTemplate,
    InstanceTagTemplate,
    Mark,
    TypeMark,
    MARK_DEFAULT_TAG,
    html_mark,
)

EXAMPLE_TAGS = """abbreviation,type_reference,instance_reference,volume_reference,level_reference,function_reference
LT,1,,,,
LT,1,,,,E
LT,1,1,,,
LT,10,2,,,E
MVHR,1,,,,
MVHR,1,,A1,L5,
DB,1,1,A1,L6,PLANT
DB,2,1,A1,L6,SMPWR
DB,2,1,A1,L6,LIGHTS
DB,2,1,A1,L6,LIGHTS
DB,2,1,A1,L6,LIGHTS
VAV,2,1,,,
SLCR,1,1,,,
BUFF,1,,J,,
"""


def read_example_tags():
    rows = [row for row in csv.reader(StringIO(EXAMPLE_TAGS), delimiter=",")]
    li = [dict(zip(rows[0], r)) for r in rows[1:]]
    fn_none = lambda v: None if v == "" else v
    li = [{k: fn_none(v) for k, v in l.items()} for l in li]
    li = [{k: v for k, v in l.items() if v is not None} for l in li]
    return li


tags_data = read_example_tags()
tag_data = tags_data[0]
# -

tag = TypeMark(template=TAG_TEMPLATE_TYPE_DEFAULT, tag_data=tag_data)

# +

s = f"{tag.type_mark} *{tag.type_mark_fstring}*"

# +
from markdown import markdown
from IPython.display import Markdown

MAP_REFS = {k: pascalcase(k) for k in MARK_DEFAULT_TAG.keys()}
s_refs = f"**{tag.type_mark}** *{tag.type_mark_fstring}*"
for k, v in MAP_REFS.items():
    if k in s_refs:
        s_refs = s_refs.replace(k, v)

s_refs = f"TypeMark = {s_refs}" + " **|** LT = lighting - fixture **|** IfcLightFixture"
Markdown(markdown(s_refs))
# -

from aectemplater_schemas.tag_template import (
    TAG_TEMPLATE_TYPE_DEFAULT,
    TAG_TEMPLATE_INSTANCE_DEFAULT,
    html_mark,
    MARK_DEFAULT_TAG
)

from stringcase import titlecase, pascalcase



TAG_TEMPLATE_TYPE_DEFAULT.model_dump()
