# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.14.5
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %run __init__.py
# %load_ext lab_black

# +
import pathlib
import ipywidgets as w
import traitlets as tr
from ipyautoui.autodisplay import AutoDisplay


def get_tutorials(fdir: pathlib.Path):
    return [p.resolve() for p in fdir.glob("*") if p.suffix in {".jpg", ".png", ".gif"}]  # , ""


class Tutorials(w.VBox):
    fdir = tr.Instance(allow_none=True, default_value=None, klass=pathlib.Path)
    paths = tr.List(allow_none=True, default_value=None, trait=tr.Instance(klass=pathlib.Path))

    @tr.observe("fdir")
    def _fdir(self, on_change):
        if on_change["new"] is None:
            self.paths = None
        else:
            self.paths = get_tutorials(on_change["new"])

    @tr.observe("paths")
    def _paths(self, on_change):
        if on_change["new"] is None:
            self.children = []
        else:
            self.tutorials = AutoDisplay.from_paths(on_change["new"], display_showhide=False)
            self.children = [self.tutorials.box_form]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


# if __name__ == "__main__":
#     DIR_TUTORIALS = DIR_ROOT / "docs" / "images" / "tutorials"
#     tuts = Tutorials(fdir=DIR_TUTORIALS)
#     display(tuts)
# -
