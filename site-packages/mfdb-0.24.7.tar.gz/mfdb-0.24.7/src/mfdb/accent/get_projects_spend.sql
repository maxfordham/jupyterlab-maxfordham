-- project_number = [4321, 3961]
-- date_range = ("2023-04-06", "2024-06-05")
SELECT   wt_jbnum, wt_datew, wt_wktyp, wt_wkdes, wt_accid, wt_ounit, wt_unit, wt_chge, wt_cost, wt_type, wt_uniq
FROM     ag_wiptrn 
WHERE    wt_jbnum 
IN       %s
AND      wt_datew
BETWEEN  %s
AND      %s