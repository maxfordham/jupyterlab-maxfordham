SELECT rl_name, rc_name
FROM mf_jobs.mf_roles
INNER JOIN mf_jobs.mf_role_category ON mf_jobs.mf_role_category.rc_ref=mf_jobs.mf_roles.rl_category
WHERE mf_jobs.mf_roles.rl_active = 1 
AND mf_jobs.mf_roles.rl_category <> 11
ORDER BY rl_category;