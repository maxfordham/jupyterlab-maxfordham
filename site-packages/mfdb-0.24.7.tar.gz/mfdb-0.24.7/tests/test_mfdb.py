from mfdb import (
    get_project_roles,
    get_job_number_to_name,
    get_user_names,
    get_project_spend,
    get_project_wktyp_spend,
    get_projects_spend,
)
import pytest
import os

CI = os.getenv("CI", False)
if CI == "true":
    CI = True
# ^ GH Actions sets this env var to "true". So if we are running on GH Actions, we will ignore these tests.
#   https://github.blog/changelog/2020-04-15-github-actions-sets-the-ci-environment-variable-to-true/


@pytest.mark.skipif(
    CI, reason="GH Actions does not have access to the internal database."
)
def test_get_project_roles():
    roles = get_project_roles()
    assert roles[0]["role_name"] == "director_in_charge"


@pytest.mark.skipif(
    CI, reason="GH Actions does not have access to the internal database."
)
def test_get_job_number_to_name():
    job_number_to_name = get_job_number_to_name()
    assert (
        job_number_to_name[7516]
        == "University of Portsmouth, Faculty of Technology Building"
    )
    assert job_number_to_name[5001] == "Test Project"
    assert job_number_to_name[5003] == "Engineering Standards"


@pytest.mark.skipif(
    CI, reason="GH Actions does not have access to the internal database."
)
def test_get_user_names():
    u_nms = get_user_names()
    assert "j.gunstone" in u_nms


@pytest.mark.skipif(
    CI, reason="GH Actions does not have access to the internal database."
)
def test_get_project_spend():
    project_number = 4321
    date_range = ("2023-04-06", "2025-04-05")
    data = get_project_spend(project_number, date_range)
    assert isinstance(data, list) and len(data) > 1


@pytest.mark.skipif(
    CI, reason="GH Actions does not have access to the internal database."
)
def test_get_project_wktyp_spend():
    project_number = 4321
    date_range = ("2023-04-06", "2025-04-05")
    work_types = ["TB19"]
    data = get_project_wktyp_spend(project_number, work_types, date_range)
    assert isinstance(data, list) and len(data) > 1


@pytest.mark.skipif(
    CI, reason="GH Actions does not have access to the internal database."
)
def test_get_projects_spend():
    project_number = [4321, 3961]
    date_range = ("2023-04-06", "2024-06-05")
    data = get_projects_spend(project_number, date_range)
    assert isinstance(data, list) and len(data) > 1
