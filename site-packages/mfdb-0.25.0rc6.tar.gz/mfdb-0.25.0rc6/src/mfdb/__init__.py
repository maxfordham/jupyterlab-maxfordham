"""mfdb package.

This package provides access to admin databases and templates useful queries.
"""

from __future__ import annotations

import re
from datetime import datetime
from importlib.resources import files

import mysql.connector

from mfdb.env import SETTINGS_ACCENT, SETTINGS_MFDB

DIR_MFDB = files("mfdb").joinpath("mfdb")
DIR_ACCENT = files("mfdb").joinpath("accent")

Q_PROJECT_ROLES = DIR_MFDB.joinpath("get_project_roles.sql").read_text()
Q_JOBS = DIR_MFDB.joinpath("get_jobs.sql").read_text()
Q_TABLES = DIR_MFDB.joinpath("get_tables.sql").read_text()
Q_USERS = DIR_MFDB.joinpath("get_users.sql").read_text()

Q_PROJECT_SPEND = DIR_ACCENT.joinpath("get_project_spend.sql").read_text()
Q_PROJECTS_SPEND = DIR_ACCENT.joinpath("get_projects_spend.sql").read_text()
Q_PROJECT_WKTYP_SPEND = DIR_ACCENT.joinpath("get_project_wktyp_spend.sql").read_text()
Q_PROJECT_WKTYP_SPEND_BY_WKDES = DIR_ACCENT.joinpath("get_project_wktyp_spend_by_wkdes.sql").read_text()
Q_GET_SPEND_IN_PERIOD = DIR_ACCENT.joinpath("get_spend_in_period.sql").read_text()

START_DATE="2021-01-01"
END_DATE = datetime.now().strftime("%Y-%m-%d")


def cnt_execute(query: str, *args: tuple, config: dict|None=None)-> list:
    """Execute a query against the database and return the results."""
    if config is None:
        msg = "Database configuration not provided. Cannot execute query."
        raise ValueError(msg)
    cnx = mysql.connector.connect(**config)
    # ^ NOTE: do I need to close this connection?
    #   maybe best to use a with: event handler...?
    cursor = cnx.cursor()
    if args:
        cursor.execute(query, args)  # parametrized query
    else:
        cursor.execute(query)
    return [cursor.column_names, *cursor.fetchall()]


def get_accent_config()-> dict:
    """Get the accent database configuration from env vars."""
    if SETTINGS_ACCENT is None:
        msg = "SETTINGS_ACCENT env vars not set. Access to accent database not possible"
        raise ValueError(msg)
    return SETTINGS_ACCENT.model_dump(by_alias=True)


def get_mfdb_config()-> dict:
    """Get the mfdb database configuration from env vars."""
    if SETTINGS_MFDB is None:
        msg = "SETTINGS_MFDB env vars not set. Access to mfdb database not possible"
        raise ValueError(msg)
    return SETTINGS_MFDB.model_dump(by_alias=True)


def mfaccent_cnt_execute(query: str, *args: tuple)-> list:
    """Execute a query against the accent database and return the results."""
    config = get_accent_config()
    return cnt_execute(query, *args, config=config)


def mfdb_cnt_execute(query: str, *args: tuple)-> list:
    """Execute a query against the mfdb database and return the results."""
    config = get_mfdb_config()
    return cnt_execute(query, *args, config=config)


def get_project_roles()-> list:
    """Get project roles from mfdb internal database."""
    data = mfdb_cnt_execute(Q_PROJECT_ROLES)
    return [
        dict(
            zip(
                ["role_name", "role_title", "role_category"],
                [x[0].lower().replace(" ", "_"), x[0], x[1]],
            )
        )
        for x in data[1:]
    ]


def get_job_number_to_name() -> dict[int, str]:
    """Get job number to name mapping from internal database."""
    data = mfdb_cnt_execute(Q_JOBS)
    job_number_to_name = dict(data[1:])
    job_number_to_name[5001] = "Test Project"
    job_number_to_name[5003] = "Engineering Standards"
    return job_number_to_name


def get_job_description_to_number()-> dict[str, int]:
    """Get job description to number mapping from internal database."""
    job_number_to_name = get_job_number_to_name()
    return {f"J{jb_numb}" + " - " + jb_name: jb_numb for (jb_numb, jb_name) in job_number_to_name.items()}


def get_table_names() -> list[str]:
    """Get table names from mfdb internal database."""
    data = mfdb_cnt_execute(Q_TABLES)
    return data[1:]


def get_user_names() -> list[str]:
    """Get user names from mfdb internal database."""
    data = mfdb_cnt_execute(Q_USERS)
    return sorted([re.sub("@maxfordham.com", "", x[0], flags=re.IGNORECASE) for x in data[1:]])


def get_project_spend(project_number: int, date_range: tuple[str, str])-> list:
    """Get project spend from accent database."""
    return mfaccent_cnt_execute(Q_PROJECT_SPEND, date_range[0], date_range[1], project_number)


def get_project_wktyp_spend(project_number: int, work_types: list, date_range: tuple[str, str])-> list:
    """Get project work type spend from accent database."""
    work_types_in = ",".join(work_types)
    data = mfaccent_cnt_execute(
        Q_PROJECT_WKTYP_SPEND,
        date_range[0],
        date_range[1],
        project_number,
        work_types_in,
    )
    return data

def get_project_wktyp_spend_by_wkdes(project_number: int, wkdes: str, date_range: tuple[str, str]|None, *, exact:bool=False)-> list:
    """Get project work type spend from accent database."""
    if not exact:
        wkdes = f"%{wkdes}%"
    if date_range is None:
        date_range = (START_DATE, END_DATE)
    data = mfaccent_cnt_execute(
        Q_PROJECT_WKTYP_SPEND_BY_WKDES,
        date_range[0],
        date_range[1],
        project_number,
        wkdes,
    )
    return data

def get_project_wktyp_spend_by_wkdes_sum(project_number: int, wkdes: str, date_range: tuple[str, str]|None, *, exact:bool=False)-> float:
    """Get project work type spend sum from accent database."""
    data = get_project_wktyp_spend_by_wkdes(project_number, wkdes, date_range, exact=exact)
    i = data[0].index("spend")
    if len(data)> 1:
        spend = [x[i] for x in data[1:]]
        if set(spend) == {None}:
            return 0.0
        return sum(spend)
    return 0.0

def get_projects_spend(projects: list[int], date_range: tuple[str, str])-> list:
    """Get projects spend from accent database."""
    projects_in = f"({','.join([str(x) for x in projects])})"
    q = """
SELECT   wt_jbnum, wt_datew, wt_wktyp, wt_wkdes, wt_accid, wt_ounit, wt_unit, wt_chge, wt_cost, wt_type, wt_uniq
FROM     ag_wiptrn
WHERE    wt_jbnum
IN       {projects_in}
AND      wt_datew
BETWEEN  {start}
AND      {end}""".format(projects_in=projects_in, start=f'"{date_range[0]}"', end=f'"{date_range[1]}"')
    # TODO: ^ this type of string formatting is not safe. Use parametrized queries.
    #       ^ was struggling to pass a list of ints as a parameter to the query.
    data = mfaccent_cnt_execute(q)
    return data

# def get_project_wktyp_spend_by_wkdes_sum(


def get_spend_in_period(date_range: tuple[str, str]=(START_DATE, END_DATE),
                        wt_type: str = "%",  # A, C, D, CB,
                        update_engineering_admin: bool = False,
                       ) -> list:
    """Get spend in period from accent database."""
    start_date, end_date = date_range
    data = mfaccent_cnt_execute(Q_GET_SPEND_IN_PERIOD, start_date, end_date, wt_type)
    if update_engineering_admin:
        from mfdb._update_admin_worktypes import _update_admin_worktypes
        data = _update_admin_worktypes(data)
    return data

