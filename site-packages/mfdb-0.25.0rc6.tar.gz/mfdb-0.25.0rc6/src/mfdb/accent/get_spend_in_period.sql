SELECT     wt.wt_jbnum, wt.wt_type, wt_wktyp, wt_wkdes, wt_accid, sum(wt.wt_cost * wt.wt_ounit) as spend, wj.wj_comm1, wt.wt_datew
FROM       ag_wiptrn wt
LEFT JOIN  ag_wipjob wj
ON         wt.wt_jbnum=wj.wj_jbnum
WHERE      wt.wt_datew
BETWEEN    %s
AND        %s
AND        wt.wt_type LIKE %s
GROUP BY   wt.wt_jbnum, wt_wktyp, wt_wkdes, wt_datew
ORDER BY   spend;