import logging
import pathlib

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)

FPTH_ENV = pathlib.Path(__file__).parents[2] / ".env"


class SettingsMfdb(BaseSettings):
    """project configuration settings, enables custom project templates."""

    USER: str = Field(serialization_alias="user")
    PASSWORD: str = Field(serialization_alias="password")
    HOST: str = Field(serialization_alias="host")
    DATABASE: str = Field(serialization_alias="database")

    model_config = SettingsConfigDict(
        env_prefix="MFDB_", env_file=FPTH_ENV, extra="ignore"
    )


# a git ignored .env file is required in the root directory of the pkg.
# that is then used for testing. in production, the environment variables must be set.
# ^ https://docs.pydantic.dev/latest/concepts/pydantic_settings/#dotenv-env-support


class SettingsAccent(BaseSettings):
    """project configuration settings, enables custom project templates."""

    USER: str = Field(serialization_alias="user")
    PASSWORD: str = Field(serialization_alias="password")
    HOST: str = Field(serialization_alias="host")
    DATABASE: str = Field(serialization_alias="database")

    model_config = SettingsConfigDict(
        env_prefix="ACCENT_", env_file=FPTH_ENV, extra="ignore"
    )


try:
    SETTINGS_MFDB = SettingsMfdb()
    SETTINGS_ACCENT = SettingsAccent()
except Exception as e:
    logger.error(f"Error loading mfdb env vars: {e}")
    SETTINGS_MFDB = SETTINGS_ACCENT = None
    