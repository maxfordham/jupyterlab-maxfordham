import ast
import csv
import pathlib
import re
from datetime import date  # Add import for datetime
from decimal import Decimal

from mfdb import DIR_ACCENT

MAP_WT_TYPE_DES = {
    "C": "Chargeable",
    "A": "Admin",
    "D": "Disbursements",
    "CB": "Bidding",
}
FPTH_ADMIN_SUBDES = DIR_ACCENT / "admin-jobs-subdes.csv"
FPTH_CENTRAL_ENG_MAP_WKTYPS = DIR_ACCENT / "central-engineering-map-wktyps-final.csv"

def read_csv_to_records(path: pathlib.Path) -> list[dict]:
    return list(csv.DictReader(path.read_text().splitlines()))


def _get_map_old_wktyp():
    di = {
        (int(_x["wt_jbnum"]), _x["wt_wkdes"]): _x["wktyp_new"]
        for _x in [x for x in read_csv_to_records(FPTH_CENTRAL_ENG_MAP_WKTYPS) if x["wktyp_new"] != ""]
    }
    di = {k: v if v != "Q999" else f"{v} {k[1]}" for k, v in di.items() if k[0] != 0}
    return di



def _get_map_sub_description_to_admin_codes():
    records = read_csv_to_records(FPTH_ADMIN_SUBDES)
    # Filter out records with missing 'wt_subdes'
    filtered = [r for r in records if r.get("wt_subdes") not in (None, "")]
    # Convert 'wt_jbnum' to int and build mapping
    return {int(ast.literal_eval(r["wt_jbnum"])): r["wt_subdes"] for r in filtered}


MAP_OLD_WKTYP = _get_map_old_wktyp()
MAP_JBNUM_SUBDES = _get_map_sub_description_to_admin_codes()
MAP_JBNUM_SUBDES_NEW = _get_map_sub_description_to_admin_codes()

def jbnum_decimal_to_int(jbnum: Decimal):
    return int(str(jbnum).split(".")[0])

def _add_wt_type_des(data: list) -> list:

    def _map_type_description(x: tuple, index: int) -> tuple:
        return (*list(x), MAP_WT_TYPE_DES[x[index]])

    def _get_wt_type_index(headers: list) -> int:
        try:
            return headers.index("wt_type")
        except ValueError as e:
            msg = f"wt_type not found in data headers - {e}."
            raise ValueError(msg)

    headers = [*list(data[0]), "wt_type_des"]
    index = _get_wt_type_index(headers)
    data = [_map_type_description(x, index) for x in data[1:]]

    return [headers, *data]


def _hack_rename_rvt_schedule_to_eng_data_infra(data: list) -> list:
    idx_datew, idx_wkdes = data[0].index("wt_datew"), data[0].index("wt_wkdes")

    for i, row in enumerate(data[1:]):
        date_val = row[idx_datew]
        wkdes_val = row[idx_wkdes]
        if (
            (wkdes_val == "Revit Schedules" or wkdes_val == "Engineering Data")
            and date_val >= date(2021, 4, 1)
            and date_val <= date(2022, 4, 1)
        ):
            row = list(row)
            row[idx_wkdes] = "Engineering Data Infrastructure"
            data[i + 1] = tuple(row)

    return data


def _add_internal_group_to_admin_jobs(data: list) -> list:
    def _map_group_to_job_description(x: tuple, i_jbnum: int) -> tuple:
        jbnum = jbnum_decimal_to_int(x[i_jbnum])
        v = MAP_JBNUM_SUBDES[jbnum] if jbnum in MAP_JBNUM_SUBDES.keys() else None
        return tuple(list(x) + [v])

    def _get_wt_jbnum(headers: list) -> int:
        try:
            return headers.index("wt_jbnum")
        except ValueError:
            msg = "wt_jbnum not found in data headers."
            raise ValueError(msg)

    headers = list(data[0]) + ["wt_subdes"]
    i_jbnum = _get_wt_jbnum(headers)
    data = [_map_group_to_job_description(x, i_jbnum) for x in data[1:]]
    return [headers, *data]


def _update_old_worktype_descriptions(data: list) -> list:
    headers = list(data[0])
    data = [list(x) for x in data[1:]]

    i_jbnum, i_wt_wkdes = headers.index("wt_jbnum"), headers.index("wt_wkdes")

    map_lkup_index = {n: (jbnum_decimal_to_int(x[i_jbnum]), x[i_wt_wkdes]) for n, x in enumerate(data[1:])}
    map_lkup_index = {k: v for k, v in map_lkup_index.items() if v in MAP_OLD_WKTYP.keys()}  # find indexes to change

    # change indexes
    for k, v in map_lkup_index.items():
        code = MAP_OLD_WKTYP[v]
        data[k + 1][i_wt_wkdes] = code

    return [headers, *data]


def _add_metadata_for_central_engineering_worktypes(data):
    headers = [*list(data[0]), "wktyp_code", "wktyp_group_des"]
    data = [[*list(x), "", ""] for x in data[1:]]

    i_wt_wkdes, i_wt_subdes, i_wktyp_code, i_wktyp_group_des = (
        headers.index("wt_wkdes"),
        headers.index("wt_subdes"),
        headers.index("wktyp_code"),
        headers.index("wktyp_group_des"),
    )
    map_group = {
        "Q": "Quality",
        "C": "Communication",
        "D": "Delivery",
        "E": "Error - Ungrouped",
    }
    regex_str = r"\b[A-Z][\d#]{3}\b"

    def _map(group, map_group=map_group):
        return map_group[group] if group != "" else None

    for x in data:
        if not x[i_wt_subdes] == "CentralEngineering":
            continue
        if re.match(regex_str, x[i_wt_wkdes]) is not None:
            x[i_wktyp_code] = x[i_wt_wkdes][0:4]
        else:
            x[i_wktyp_code] = "E999"
        x[i_wktyp_group_des] = _map(x[i_wktyp_code][0])

    return [headers, *data]


def _update_admin_worktypes(data):
    data = _add_wt_type_des(data)  # adds wt_type_des
    data = _hack_rename_rvt_schedule_to_eng_data_infra(data)  # edits wt_wkdes
    data = _update_old_worktype_descriptions(data) # edits wt_wkdes
    data = _add_internal_group_to_admin_jobs(data)  # adds wt_subdes
    data = _add_metadata_for_central_engineering_worktypes(data)  # add "wktyp_code", "wktyp_group_des"
    return data


__all__ = ["_update_admin_worktypes"]