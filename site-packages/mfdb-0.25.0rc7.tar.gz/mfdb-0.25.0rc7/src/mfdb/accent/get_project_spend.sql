
SELECT   wt_jbnum, wt_datew, wt_wktyp, wt_wkdes, wt_accid, wt_ounit, wt_unit, wt_chge, wt_cost, wt_type, wt_uniq, sum(wt_cost * wt_ounit) as spend
FROM     ag_wiptrn 
WHERE    wt_datew 
BETWEEN  %s
AND      %s
AND      wt_jbnum = %s
