import os
from decimal import Decimal

import pytest
from mfdb import (
    END_DATE,
    get_job_number_to_name,
    get_project_roles,
    get_project_spend,
    get_project_wktyp_spend,
    get_project_wktyp_spend_by_wkdes,
    get_project_wktyp_spend_by_wkdes_sum,
    get_projects_spend,
    get_spend_in_period,
    get_user_names,
)

reason_internal_db = "GH Actions does not have access to the internal database."
CI = os.getenv("CI", False)
if CI == "true":
    CI = True
# ^ GH Actions sets this env var to "true". So if we are running on GH Actions, we will ignore these tests.
#   https://github.blog/changelog/2020-04-15-github-actions-sets-the-ci-environment-variable-to-true/


@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_project_roles():
    roles = get_project_roles()
    assert roles[0]["role_name"] == "director_in_charge"


@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_job_number_to_name():
    job_number_to_name = get_job_number_to_name()
    assert (
        job_number_to_name[7516]
        == "University of Portsmouth, Faculty of Technology Building"
    )
    assert job_number_to_name[5001] == "Test Project"
    assert job_number_to_name[5003] == "Engineering Standards"


@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_user_names():
    u_nms = get_user_names()
    assert "j.gunstone" in u_nms


@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_project_spend():
    project_number = 4321
    date_range = ("2023-04-06", "2025-04-05")
    data = get_project_spend(project_number, date_range)
    assert isinstance(data, list) and len(data) > 1


@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_project_wktyp_spend():
    project_number = 4321
    date_range = ("2023-04-06", "2025-04-05")
    work_types = ["TB19"]
    data = get_project_wktyp_spend(project_number, work_types, date_range)
    assert isinstance(data, list) and len(data) > 1

@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_project_wktyp_spend_by_wkdes():
    project_number = 4321
    date_range = ("2023-04-06", "2025-04-05")
    wkdes = "Q002"
    data = get_project_wktyp_spend_by_wkdes(project_number, wkdes, date_range)
    assert isinstance(data, list) and len(data) > 1



@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_project_wktyp_spend_by_wkdes_sum():
    project_number = 4321
    date_range = ("2023-04-06", "2025-04-05")
    wkdes = "Q002"
    data = get_project_wktyp_spend_by_wkdes_sum(project_number, wkdes, date_range)

    assert isinstance(data, Decimal) and data > 1

@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_projects_spend():
    project_number = [4321, 3961]
    date_range = ("2023-04-06", "2024-06-05")
    data = get_projects_spend(project_number, date_range)
    assert isinstance(data, list) and len(data) > 1


@pytest.mark.skipif(
    CI, reason=reason_internal_db,
)
def test_get_spend_in_period():
    start_date="2025-01-01"
    date_range = (start_date, END_DATE)

    data = get_spend_in_period(date_range)
    assert list(data[0]) == ['wt_jbnum', 'wt_type', 'wt_wktyp', 'wt_wkdes', 'wt_accid', 'spend', 'wj_comm1', 'wt_datew']
    n_cols = len(data[0])

    data = get_spend_in_period(date_range, update_engineering_admin=True)
    assert len(data[0]) > n_cols 