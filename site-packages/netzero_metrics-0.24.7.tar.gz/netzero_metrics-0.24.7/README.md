# tmp Net Zero Metrics

Plan is to move this to a [separate netzero-metrics repo](https://github.com/maxfordham/netzero-metrics), but for now it's here.

## TODO

- [ ] Add generic python calcs and visualisations
  - [ ] add tests
  - [ ] add CI
  - [ ] add docs
- [ ] Move nzc datapackage here from `aecreference` and import it into `aecreference` as a dependency
  - [ ] setup `aecreference` as a [datacatog](https://framework.frictionlessdata.io/docs/framework/catalog.html)
- [ ] Move to separate repo
- [ ] observable dashboards that are packaged and can be imported by other js dashboards
- [ ] Add embodied carbon calcs
