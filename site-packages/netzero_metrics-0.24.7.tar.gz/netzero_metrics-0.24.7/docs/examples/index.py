# %% [markdown]
# ---
# title: simple-building
# execute:
#   echo: false
# ---

# %% [markdown]
"""
TBC
"""