from aecreference import aecdata

NZC_TARGET_NAME = "UK NZC Standard"
EUI_DATA = aecdata.energy_use_intensity
