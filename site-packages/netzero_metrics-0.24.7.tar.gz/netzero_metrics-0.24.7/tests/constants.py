import pathlib

fdir = pathlib.Path(__file__).parent
fdir_data = fdir / "data"
fdir_output = fdir / "outputs"
fdir_data_7763 = fdir / "data-7763"