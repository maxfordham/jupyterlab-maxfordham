
# Buildings

|   TargetYear | Name   |
|-------------:|:-------|
|         2025 | A      |
|         2030 | B      |
|         2025 | C      |

# Areas

|   GrossInternalArea | BuildingType                          | ConstructionDeliveryType   | BuildingName   |
|--------------------:|:--------------------------------------|:---------------------------|:---------------|
|                  10 | Office - General                      | newbuild                   | A              |
|                  10 | Office - General                      | retrofit-in-one-go         | A              |
|                  20 | Commercial Resi - Student Residential | newbuild                   | B              |
|                  20 | Commercial Resi - Student Residential | retrofit-in-one-go         | B              |

# Energy Use Intensities

| BuildingType                          |   Target | Description             | TargetName   | ConstructionDeliveryType   |
|:--------------------------------------|---------:|:------------------------|:-------------|:---------------------------|
| Office - General                      |       70 | better than NZC target! | ambitious!   | newbuild                   |
| Office - General                      |       70 | better than NZC target! | ambitious!   | retrofit-in-one-go         |
| Commercial Resi - Student Residential |       70 | better than NZC target! | ambitious!   | newbuild                   |
| Commercial Resi - Student Residential |       70 | better than NZC target! | ambitious!   | retrofit-in-one-go         |
