# pyrulefilter

Used to create rules for filtering lists of dictionaries (tabular style).

## Development Installation

Follow the instructions in the [Digital Schedules README.md](../../README.md#development-installation) to install the development environment.
